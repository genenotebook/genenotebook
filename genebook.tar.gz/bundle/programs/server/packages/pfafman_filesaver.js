(function () {

/* Package-scope variables */
var saveAs;



/* Exports */
Package._define("pfafman:filesaver", {
  saveAs: saveAs
});

})();
