var require = meteorInstall({"imports":{"api":{"blast":{"hasblastdb.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/blast/hasblastdb.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  hasBlastDb: () => hasBlastDb
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 1);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let existsSync;
module.watch(require("fs"), {
  existsSync(v) {
    existsSync = v;
  }

}, 4);
const hasBlastDb = new ValidatedMethod({
  name: 'hasBlastDb',
  validate: new SimpleSchema({
    trackName: {
      type: String
    }
  }).validator(),
  applyOptions: {
    noRetry: true
  },

  run({
    trackName
  }) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'curator')) {
      throw new Meteor.Error('not-authorized');
    }

    const cleanedTrackName = trackName.replace(/ |\./g, '_');
    const filenames = [`${cleanedTrackName}.nucl.nhr`, `${cleanedTrackName}.prot.phr`];
    console.log(filenames);

    if (!this.isSimulation) {
      console.log(filenames);
      console.log(filenames.every(existsSync));
      return filenames.every(existsSync);
    }
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"makeblastdb.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/blast/makeblastdb.js                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  makeBlastDb: () => makeBlastDb
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 1);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let hash;
module.watch(require("object-hash"), {
  default(v) {
    hash = v;
  }

}, 4);
let jobQueue;
module.watch(require("/imports/api/jobqueue/jobqueue.js"), {
  default(v) {
    jobQueue = v;
  }

}, 5);
let Job;
module.watch(require("meteor/vsivsi:job-collection"), {
  Job(v) {
    Job = v;
  }

}, 6);
let Genes;
module.watch(require("/imports/api/genes/gene_collection.js"), {
  Genes(v) {
    Genes = v;
  }

}, 7);
const makeBlastDb = new ValidatedMethod({
  name: 'makeBlastDb',
  validate: new SimpleSchema({
    trackName: {
      type: String
    },
    dbType: {
      type: String
    }
  }).validator(),
  applyOptions: {
    noRetry: true
  },

  run({
    trackName,
    dbType
  }) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'curator')) {
      throw new Meteor.Error('not-authorized');
    }

    if (!this.isSimulation) {
      const jobId = new Job(jobQueue, 'makeBlastDb', {
        trackName: trackName,
        dbType: dbType,
        user: Meteor.userId()
      }).priority('normal').save();
      return jobId;
    }
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"removeblastdb.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/blast/removeblastdb.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  removeBlastDb: () => removeBlastDb
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 1);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let Tracks;
module.watch(require("/imports/api/genomes/track_collection.js"), {
  Tracks(v) {
    Tracks = v;
  }

}, 4);
const removeBlastDb = new ValidatedMethod({
  name: 'removeBlastDb',
  validate: new SimpleSchema({
    trackName: {
      type: String
    }
  }).validator(),
  applyOptions: {
    noRetry: true
  },

  run({
    trackName
  }) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'admin')) {
      throw new Meteor.Error('not-authorized');
    }

    console.log(`remove ${trackName}`);

    if (!this.isSimulation) {
      const track = Tracks.findOne({
        trackName: trackName
      });
      console.log(track);
      Tracks.update({
        trackName: trackName
      }, {
        $unset: {
          'blastdbs': 1
        }
      });
    }
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"submitblastjob.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/blast/submitblastjob.js                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  submitBlastJob: () => submitBlastJob
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 1);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let jobQueue;
module.watch(require("/imports/api/jobqueue/jobqueue.js"), {
  default(v) {
    jobQueue = v;
  }

}, 4);
let Job;
module.watch(require("meteor/vsivsi:job-collection"), {
  Job(v) {
    Job = v;
  }

}, 5);
const submitBlastJob = new ValidatedMethod({
  name: 'submitBlastJob',
  validate: new SimpleSchema({
    blastType: {
      type: String
    },
    input: {
      type: String
    },
    trackNames: {
      type: Array
    },
    'trackNames.$': {
      type: String
    }
  }).validator(),
  applyOptions: {
    noRetry: true
  },

  run({
    blastType,
    input,
    trackNames
  }) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'user')) {
      throw new Meteor.Error('not-authorized');
    }

    console.log('submit blast job');
    const jobId = new Job(jobQueue, 'blast', {
      blastType: blastType,
      input: input,
      trackNames: trackNames,
      user: Meteor.userId()
    }).priority('normal').save();
    console.log(jobId);
    return jobId;
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"downloads":{"download_collection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/downloads/download_collection.js                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  Downloads: () => Downloads
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
//DESIGN SCHEMA
const Downloads = new Mongo.Collection('downloads');
const DownloadSchema = new SimpleSchema({
  query: {
    type: Object,
    blackbox: true
  },
  queryHash: {
    type: String
  },
  counts: {
    type: Number
  },
  accessed: {
    type: Date
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"genes":{"add_interproscan.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genes/add_interproscan.js                                                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  addInterproscan: () => addInterproscan
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let Papa;
module.watch(require("papaparse"), {
  default(v) {
    Papa = v;
  }

}, 3);
let Genes;
module.watch(require("/imports/api/genes/gene_collection.js"), {
  Genes(v) {
    Genes = v;
  }

}, 4);
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 5);

/**
 * [description]
 * @param  {[type]} attributeString [description]
 * @return {[type]}                 [description]
 */
const formatAttributes = attributeString => {
  return attributeString.split(';').reduce((attributes, stringPart) => {
    const [key, value] = stringPart.split('=');

    if (typeof key !== 'undefined' && typeof value !== 'undefined') {
      attributes[key] = value.split('"').join('').split(',').map(decodeURIComponent);
    }

    return attributes;
  }, {});
};

const debugFormatAttributes = attributeString => {
  arr = attributeString.split(';');
  console.log(arr);
  const attributes = arr.reduce((attr, stringPart) => {
    const [key, value] = stringPart.split('=');
    console.log(key, value);
    const values = value.split('"').join('').split(',').map(decodeURIComponent);
    console.log(values);
    attr[key] = values;
    return attr;
  }, {});
  console.log(attributes);
  return attributes;
};

const addInterproscan = new ValidatedMethod({
  name: 'addInterproscan',
  validate: new SimpleSchema({
    fileName: {
      type: String
    },
    trackName: {
      type: String
    }
  }).validator(),
  applyOptions: {
    noRetry: true
  },

  run({
    fileName,
    trackName
  }) {
    console.log('addInterproscan', trackName, fileName);
    let lineNumber = 0;
    const fileHandle = fs.readFileSync(fileName, {
      encoding: 'binary'
    });
    const interproIds = new Set();
    Papa.parse(fileHandle, {
      delimiter: '\t',
      dynamicTyping: true,
      skipEmptyLines: true,

      //comments: '#',
      error(error, file) {
        console.log(error);
      },

      step(line, parser) {
        lineNumber += 1;

        if (lineNumber % 100 === 0) {
          console.log(`Processed ${lineNumber} lines`);
        }

        const data = line.data[0];

        if (data[0][0] === '#') {
          if (/fasta/i.test(data[0])) {
            console.log('Encountered fasta section, stopped parsing');
            parser.abort();
          }
        } else {
          const [seqId, source, type, start, end, score, strand, phase, attributeString] = data;

          if (type === 'protein_match') {
            if (typeof attributeString !== 'undefined') {
              let attributes;

              try {
                attributes = formatAttributes(attributeString);
              } catch (error) {
                console.log(`Error line ${lineNumber}`);
                console.log(data.join('\t'));
                console.log(attributeString);
                console.log(debugFormatAttributes(attributeString));
                throw error;
              }

              const name = attributes['Name'][0];
              const proteinDomain = {
                start,
                end,
                source,
                score,
                name
              };
              const dbxref = attributes['Dbxref'];

              if (typeof dbxref !== 'undefined') {
                proteinDomain['dbxref'] = dbxref;
                let hasInterpro = false;
                dbxref.forEach(crossref => {
                  const [db, id] = crossref.split(':');

                  if (/InterPro/.test(db)) {
                    hasInterpro = true;
                    proteinDomain['interpro'] = id;
                    interproIds.add(id);
                  }
                });

                if (!hasInterpro) {
                  proteinDomain['interpro'] = 'Unintegrated signature';
                }
              } else {
                proteinDomain['interpro'] = 'Unintegrated signature';
              }

              if (typeof attributes['signature_desc'] !== 'undefined') {
                proteinDomain['signature_desc'] = attributes['signature_desc'][0];
              }

              Genes.update({
                'subfeatures.ID': seqId
              }, {
                $addToSet: {
                  'subfeatures.$.protein_domains': proteinDomain
                }
              });
            } else {
              console.log('Undefined attributes:');
              console.log(data.join('\t'));
            }
          }
        }
      },

      complete(results, file) {
        console.log('Finished'); //console.log(interproIds)
      }

    });
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"add_orthogroup_trees.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genes/add_orthogroup_trees.js                                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  addOrthogroupTrees: () => addOrthogroupTrees
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let Papa;
module.watch(require("papaparse"), {
  default(v) {
    Papa = v;
  }

}, 3);
let glob;
module.watch(require("glob"), {
  default(v) {
    glob = v;
  }

}, 4);
let Orthogroups;
module.watch(require("/imports/api/genes/orthogroup_collection.js"), {
  Orthogroups(v) {
    Orthogroups = v;
  }

}, 5);
let Genes;
module.watch(require("/imports/api/genes/gene_collection.js"), {
  Genes(v) {
    Genes = v;
  }

}, 6);
let parseNewick;
module.watch(require("/imports/api/util/util.js"), {
  parseNewick(v) {
    parseNewick = v;
  }

}, 7);
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 8);
const addOrthogroupTrees = new ValidatedMethod({
  name: 'addOrthogroupTrees',
  validate: new SimpleSchema({
    folder: {
      type: String
    }
  }).validator(),
  applyOptions: {
    noRetry: true
  },

  run({
    folder
  }) {
    console.log('addOrthogroupTrees', folder);
    const geneBulkOp = Genes.rawCollection().initializeUnorderedBulkOp();
    const orthoBulkOp = Orthogroups.rawCollection().initializeUnorderedBulkOp();
    glob(`${folder}/*`, (err, fileNames) => {
      fileNames.forEach(fileName => {
        //console.log(fileName)
        const orthogroupId = fileName.split('/').pop().split('_')[0];
        const data = fs.readFileSync(fileName, 'utf8'); //, (err, data) => {

        const tree = parseNewick(data);
        orthoBulkOp.insert({
          ID: orthogroupId,
          size: tree.size,
          tree: tree.tree,
          genes: tree.geneIds
        });
        geneBulkOp.find({
          ID: {
            $in: tree.geneIds
          }
        }).update({
          $set: {
            orthogroup: orthogroupId
          }
        }); //console.log(orthogroupId, tree.size, tree.geneIds);
        //});
      });
      console.log('geneBulkOp execute');
      const geneBulkOpResults = geneBulkOp.execute();
      console.log(geneBulkOpResults);
      console.log('orthoBulkOp execute');
      const orthoBulkOpResults = orthoBulkOp.execute();
      console.log(orthoBulkOpResults);
    });
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"attribute_collection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genes/attribute_collection.js                                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  Attributes: () => Attributes
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
//DESIGN SCHEMA
const Attributes = new Mongo.Collection('attributes');
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"download_genes.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genes/download_genes.js                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  downloadGenes: () => downloadGenes
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let hash;
module.watch(require("object-hash"), {
  default(v) {
    hash = v;
  }

}, 3);
let jobQueue;
module.watch(require("/imports/api/jobqueue/jobqueue.js"), {
  default(v) {
    jobQueue = v;
  }

}, 4);
let Job;
module.watch(require("meteor/vsivsi:job-collection"), {
  Job(v) {
    Job = v;
  }

}, 5);
let Genes;
module.watch(require("/imports/api/genes/gene_collection.js"), {
  Genes(v) {
    Genes = v;
  }

}, 6);
let Downloads;
module.watch(require("/imports/api/downloads/download_collection.js"), {
  Downloads(v) {
    Downloads = v;
  }

}, 7);
const downloadGenes = new ValidatedMethod({
  name: 'downloadGenes',
  validate: new SimpleSchema({
    query: {
      type: Object,
      blackbox: true
    },
    dataType: {
      type: String
    }
  }).validator(),
  applyOptions: {
    noRetry: true
  },

  run({
    query,
    dataType
  }) {
    /**
     * If the query has not been used before, create a file from it. 
     * Otherwise use the cached file and increment the download count.
     * Return md5 hash of download query as download url
     */
    console.log(`downloading ${dataType}`);
    console.log(query);
    const queryString = JSON.stringify(query);
    const queryHash = hash(`${queryString}${dataType}`);
    console.log(queryHash);

    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    const existingJob = jobQueue.findOne({
      'data.queryHash': queryHash
    });

    if (typeof existingJob === 'undefined') {
      console.log('initiating new download job');
      const job = new Job(jobQueue, 'download', {
        queryString: queryString,
        queryHash: queryHash,
        dataType: dataType
      });
      job.priority('high').save();
    }

    return queryHash;
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"edithistory_collection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genes/edithistory_collection.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  EditHistory: () => EditHistory
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
//DESIGN SCHEMA
const EditHistory = new Mongo.Collection('editHistory');
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"gene_collection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genes/gene_collection.js                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  Genes: () => Genes,
  GeneSchema: () => GeneSchema,
  SubfeatureSchema: () => SubfeatureSchema
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const Genes = new Mongo.Collection('genes'); //create a base schema so we can add it at multiple places

const IntervalBaseSchema = new SimpleSchema({
  ID: {
    type: String,
    unique: true,
    index: true,
    //denyUpdate: true,
    label: 'Unique gene ID'
  },
  type: {
    type: String,
    allowedValues: ['gene', 'mRNA', 'CDS', 'exon', 'three_prime_UTR', 'five_prime_UTR'],
    label: 'Interval type'
  },
  seq: {
    type: String,
    label: 'Reference sequence of this feature'
  },
  start: {
    type: Number,
    label: 'Start coordinate'
  },
  end: {
    type: Number,
    label: 'End coordinate'
  },
  score: {
    type: String,
    label: 'Score',
    custom: function () {
      if (!this.isSet) {
        return 'required';
      }

      if (this.value === '.') {
        return true;
      } else {
        let parsedValue = parseFloat(this.value);

        if (isNaN(parsedValue)) {
          return 'scoreError';
        } else {
          return true;
        }
      }
    }
  },
  attributes: {
    type: Object,
    blackbox: true,
    index: true,
    label: 'Any attributes'
  },
  children: {
    type: Array,
    //[String],
    optional: true,
    label: 'Child subfeatures'
  },
  'children.$': {
    type: String
  }
}); //Define subfeature schema first so we can then add it to the gene schema

const SubfeatureSchema = new SimpleSchema({
  phase: {
    type: SimpleSchema.oneOf(Number, String),
    allowedValues: [0, 1, 2, '.'],
    label: 'phase'
  },
  type: {
    type: String,
    allowedValues: ['CDS', 'exon', 'mRNA', 'five_prime_UTR', 'three_prime_UTR'],
    label: 'Subfeature types'
  },
  parents: {
    type: Array,
    //[String],
    label: 'Parent subfeatures'
  },
  'parents.$': {
    type: String
  },
  protein_domains: {
    type: Array,
    label: 'Interproscan protein domains',
    optional: true
  },
  'protein_domains.$': {
    type: Object,
    label: 'Interproscan protein domain',
    blackbox: true
  }
}); //extend the subfeature schema with base subfeatures

SubfeatureSchema.extend(IntervalBaseSchema);
const GeneSchema = new SimpleSchema({
  type: {
    type: String,
    allowedValues: ['gene'],
    label: 'Gene type'
  },
  editing: {
    type: String,
    optional: true
  },
  viewing: {
    type: Array,
    //[String],
    optional: true
  },
  'viewing.$': {
    type: String
  },
  changed: {
    type: Boolean,
    optional: true
  },
  expression: {
    type: Array,
    //[Object],
    optional: true,
    label: 'Transcriptome counts and TPM'
  },
  'expression.$': {
    type: Object,
    blackbox: true
  },
  subfeatures: {
    type: Array,
    //[SubfeatureSchema],
    //blackbox: true,
    optional: true,
    label: 'Array of subfeatures'
  },
  'subfeatures.$': {
    type: Object,
    blackbox: true
  },
  reference: {
    type: String,
    //denyUpdate: true,
    label: 'Reference genome'
  },
  seqid: {
    type: String,
    //denyUpdate: true,
    label: 'ID of the sequence on which the gene is, e.g. chr1'
  },
  source: {
    type: String,
    label: 'Source of the annotation'
  },
  type: {
    type: String,
    allowedValues: ['gene'],
    label: 'Type of the top level annotation (currently only "gene" is allowed)'
  },
  strand: {
    type: String,
    allowedValues: ['+', '-'],
    label: 'Strand'
  },
  track: {
    type: String,
    label: 'Track name'
  },
  permissions: {
    type: Array,
    //[String],
    label: 'Permission level'
  },
  'permissions.$': {
    type: String
  }
}); //extend the gene schema with base features

GeneSchema.extend(IntervalBaseSchema);
Genes.attachSchema(GeneSchema);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"interpro_collection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genes/interpro_collection.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  Interpro: () => Interpro
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
//DESIGN SCHEMA
const Interpro = new Mongo.Collection('interpro');
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"interproscan.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genes/interproscan.js                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 1);
let request;
module.watch(require("request"), {
  default(v) {
    request = v;
  }

}, 2);
let Future;
module.watch(require("fibers/future"), {
  default(v) {
    Future = v;
  }

}, 3);
let getGeneSequences;
module.watch(require("/imports/api/util/util.js"), {
  getGeneSequences(v) {
    getGeneSequences = v;
  }

}, 4);
let Genes;
module.watch(require("/imports/api/genes/gene_collection.js"), {
  Genes(v) {
    Genes = v;
  }

}, 5);

/**
 * Reverse complement a DNA string
 * @param  {[String]} seq [String representing DNA constisting of alphabet AaCcGgTtNn]
 * @return {[String]}     [String representing DNA constisting of alphabet AaCcGgTtNn, reverse complement of input]
 */
const revcomp = seq => {
  const comp = {
    'A': 'T',
    'a': 't',
    'T': 'A',
    't': 'a',
    'C': 'G',
    'c': 'g',
    'G': 'C',
    'g': 'c',
    'N': 'N',
    'n': 'n'
  };
  const revSeqArray = seq.split('').reverse();
  const revCompSeqArray = revSeqArray.map(nuc => {
    return comp[nuc];
  });
  const revCompSeq = revCompSeqArray.join('');
  return revCompSeq;
};
/**
 * Convert a DNA string into a amino acid string
 * @param  {[String]} seq [String representing DNA constisting of alphabet ACGTN]
 * @return {[String]}     [String representing the amino acid complement of input string]
 */


const translate = seq => {
  const trans = {
    'ACC': 'T',
    'ACA': 'T',
    'ACG': 'T',
    'AGG': 'R',
    'AGC': 'S',
    'GTA': 'V',
    'AGA': 'R',
    'ACT': 'T',
    'GTG': 'V',
    'AGT': 'S',
    'CCA': 'P',
    'CCC': 'P',
    'GGT': 'G',
    'CGA': 'R',
    'CGC': 'R',
    'TAT': 'Y',
    'CGG': 'R',
    'CCT': 'P',
    'GGG': 'G',
    'GGA': 'G',
    'GGC': 'G',
    'TAA': '*',
    'TAC': 'Y',
    'CGT': 'R',
    'TAG': '*',
    'ATA': 'I',
    'CTT': 'L',
    'ATG': 'M',
    'CTG': 'L',
    'ATT': 'I',
    'CTA': 'L',
    'TTT': 'F',
    'GAA': 'E',
    'TTG': 'L',
    'TTA': 'L',
    'TTC': 'F',
    'GTC': 'V',
    'AAG': 'K',
    'AAA': 'K',
    'AAC': 'N',
    'ATC': 'I',
    'CAT': 'H',
    'AAT': 'N',
    'GTT': 'V',
    'CAC': 'H',
    'CAA': 'Q',
    'CAG': 'Q',
    'CCG': 'P',
    'TCT': 'S',
    'TGC': 'C',
    'TGA': '*',
    'TGG': 'W',
    'TCG': 'S',
    'TCC': 'S',
    'TCA': 'S',
    'GAG': 'E',
    'GAC': 'D',
    'TGT': 'C',
    'GCA': 'A',
    'GCC': 'A',
    'GCG': 'A',
    'GCT': 'A',
    'CTC': 'L',
    'GAT': 'D'
  };
  const codonArray = seq.match(/.{1,3}/g);
  const pepArray = codonArray.map(codon => {
    let aminoAcid = 'X';

    if (codon.indexOf('N') < 0) {
      aminoAcid = trans[codon];
    }

    return aminoAcid;
  });
  const pep = pepArray.join('');
  return pep;
};

const makeFasta = gene => {
  let transcripts = gene.subfeatures.filter(subfeature => {
    return subfeature.type === 'mRNA';
  });
  let sequences = transcripts.map(transcript => {
    let transcriptSeq = `>${transcript.ID}\n`;
    let transcriptPep = `>${transcript.ID}\n`;
    let cdsArray = gene.subfeatures.filter(sub => {
      return sub.parents.indexOf(transcript.ID) >= 0 && sub.type === 'CDS';
    }).sort((a, b) => {
      return a.start - b.start;
    });
    let refStart = 10e99; //let referenceSubscription = Meteor.subscribe('references',gene.seqid)
    //find all reference fragments overlapping the mRNA feature

    let referenceArray = References.find({
      header: gene.seqid,
      $and: [{
        start: {
          $lte: gene.end
        }
      }, {
        end: {
          $gte: gene.start
        }
      }]
    }).fetch();

    if (referenceArray.length) {
      let reference = referenceArray.sort((a, b) => {
        //sort on start coordinate
        return a.start - b.start;
      }).map(ref => {
        //find starting position of first reference fragment
        refStart = Math.min(refStart, ref.start);
        return ref.seq;
      }).join('');
      seq = cdsArray.map((cds, index) => {
        let start = cds.start - refStart - 1;
        let end = cds.end - refStart;
        return reference.slice(start, end);
      }).join('');
      let phase;

      if (this.strand === '-') {
        seq = revcomp(seq);
        phase = cdsArray[cdsArray.length - 1].phase;
      } else {
        phase = cdsArray[0].phase;
      }

      if ([1, 2].indexOf(phase) >= 0) {
        seq = seq.slice(phase);
      }

      let pep = translate(seq.toUpperCase());
      transcriptSeq += seq;
      transcriptPep += pep;
      transcriptPep = transcriptPep.split('*').join('X');
    }

    return {
      ID: transcript.ID,
      seq: transcriptSeq,
      pep: transcriptPep
    };
  });
  return sequences;
};

function submitInterpro(sequenceId, peptide) {
  const submitJob = new Future();
  request.post({
    url: 'http://www.ebi.ac.uk/Tools/services/rest/iprscan5/run/',
    form: {
      email: 'rens.holmer@gmail.com',
      title: `genebook protein ${sequenceId}`,
      sequence: peptide
    }
  }, (error, response, jobId) => {
    console.log('error:', error); // Print the error if one occurred 

    console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received 

    console.log('requestId:', jobId);
    submitJob.return(jobId);
  });
  const jobId = submitJob.wait();
  return jobId;
}

function pollInterpro(jobId, cb) {
  const statusRequest = new Future();
  const url = `http://www.ebi.ac.uk/Tools/services/rest/iprscan5/status/${jobId}`;
  console.log(`Trying ${url}`);
  request.get(url, (error, response, body) => {
    console.log(error);
    console.log(body);
    statusRequest.return(body);
  });
  const status = statusRequest.wait();

  if (status === 'RUNNING') {
    //figure out a way to call the function with a parameter
    Meteor.setTimeout(function () {
      return pollInterpro(jobId, cb);
    }, 100000);
  } else {
    cb(status);
  }
}

function getInterproResults(jobId) {
  const future = new Future();
  const url = `http://www.ebi.ac.uk/Tools/services/rest/iprscan5/result/${jobId}/json`;
  console.log(`Trying ${url}`);
  request.get(url, (error, response, body) => {
    let interproAnnotation = JSON.parse(body);
    future.return(interproAnnotation);
  });
  const results = future.wait();
  return results;
}

Meteor.methods({
  interproscan(geneId) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'admin')) {
      throw new Meteor.Error('not-authorized');
    } //this.unblock();


    const gene = Genes.findOne({
      ID: geneId
    });
    const sequences = getGeneSequences(gene);
    const results = sequences.map(sequence => {
      // interproscan does not like stop codons, just replace all with X
      let pep = sequence.pep.split('*').join('X');
      const jobId = submitInterpro(sequence.ID, pep);
      const fut = new Future();
      pollInterpro(jobId, status => {
        console.log(`pollInterpro: ${status}`);
        fut.return(status);
      });
      const finished = fut.wait();
      let results;

      if (finished === 'FINISHED') {
        results = getInterproResults(jobId);
        console.log(results);
        Genes.update({
          'subfeatures.ID': sequence.ID
        }, {
          $set: {
            interproscan: results[0].matches
          }
        });
      }

      return results;
    });
    return results;
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"orthogroup_collection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genes/orthogroup_collection.js                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  Orthogroups: () => Orthogroups
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
//DESIGN SCHEMA
const Orthogroups = new Mongo.Collection('orthogroups');
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"scan_attributes.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genes/scan_attributes.js                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  scanGeneAttributes: () => scanGeneAttributes
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let Genes;
module.watch(require("/imports/api/genes/gene_collection.js"), {
  Genes(v) {
    Genes = v;
  }

}, 3);
let Attributes;
module.watch(require("/imports/api/genes/attribute_collection.js"), {
  Attributes(v) {
    Attributes = v;
  }

}, 4);
let Tracks;
module.watch(require("/imports/api/genomes/track_collection.js"), {
  Tracks(v) {
    Tracks = v;
  }

}, 5);

/**
 * Map function for mongodb mapreduce
 * @return {[type]} [description]
 */
const mapFunction = function () {
  printjson('map function'); //Use 'var' instead of 'let'! This will be executed in mongodb, which does not know 'const/let'

  var gene = this;

  if (typeof gene.attributes !== 'undefined') {
    emit(null, {
      attributeKeys: Object.keys(gene.attributes)
    });
  }
};
/**
 * Reduce function for mongodb mapreduce
 * @param  {[type]} _key    [description]
 * @param  {[type]} values [description]
 * @return {[type]}        [description]
 */


const reduceFunction = function (_key, values) {
  printjson('reduce function'); //Use 'var' instead of 'let'! This will be executed in mongodb, which does not know 'const/let'

  const attributeKeySet = new Set();
  values.forEach(value => {
    value.attributeKeys.forEach(attributeKey => {
      attributeKeySet.add(attributeKey);
    });
  }); //Use 'var' instead of 'let'! This will be executed in mongodb, which does not know 'const/let'

  const attributeKeys = Array.from(attributeKeySet);
  return {
    attributeKeys: attributeKeys
  };
};

const scanGeneAttributes = new ValidatedMethod({
  name: 'scanAttributes',
  validate: new SimpleSchema({
    trackName: {
      type: String
    }
  }).validator(),
  applyOptions: {
    noRetry: true
  },

  run({
    trackName
  }) {
    console.log(`scanGeneAttributes: ${trackName}`);

    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'curator')) {
      throw new Meteor.Error('not-authorized');
    }

    const track = Tracks.findOne({
      trackName: trackName
    }); //check if the track exists

    if (typeof track === 'undefined') {
      throw new Meteor.Error(`Unknown track: ${trackName}`);
    } //check that it is running on the server


    if (!this.isSimulation) {
      this.unblock();
      const mapReduceOptions = {
        out: {
          inline: 1
        },
        query: {
          track: trackName
        } //mapreduce to find all keys for all genes, this takes a while

      };
      console.log('mapreducing');
      const attributeScan = Genes.rawCollection().mapReduce(mapFunction, reduceFunction, mapReduceOptions).then(results => {
        console.log('mapreduce finished');
        results.forEach(result => {
          const attributeKeys = result.value.attributeKeys;
          attributeKeys.forEach(attributeKey => {
            Attributes.findAndModify({
              query: {
                name: attributeKey
              },
              update: {
                $addToSet: {
                  tracks: trackName,
                  references: track.reference
                },
                $setOnInsert: {
                  name: attributeKey,
                  query: `attributes.${attributeKey}`,
                  show: true,
                  canEdit: false,
                  reserved: false
                }
              },
              new: true,
              upsert: true
            });
          });
        });
      }).catch(err => {
        console.log(err);
        throw new Meteor.Error(err);
      });
      return true;
    }
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"genomes":{"add_gff.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genomes/add_gff.js                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  addGff: () => addGff
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let assert;
module.watch(require("assert"), {
  default(v) {
    assert = v;
  }

}, 3);
let Baby;
module.watch(require("babyparse"), {
  default(v) {
    Baby = v;
  }

}, 4);
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 5);
let findIndex;
module.watch(require("lodash/findIndex"), {
  default(v) {
    findIndex = v;
  }

}, 6);
let isEqual;
module.watch(require("lodash/isEqual"), {
  default(v) {
    isEqual = v;
  }

}, 7);
let isEmpty;
module.watch(require("lodash/isEmpty"), {
  default(v) {
    isEmpty = v;
  }

}, 8);
let mapValues;
module.watch(require("lodash/mapValues"), {
  default(v) {
    mapValues = v;
  }

}, 9);
let querystring;
module.watch(require("querystring"), {
  default(v) {
    querystring = v;
  }

}, 10);
let Genes, GeneSchema, SubfeatureSchema;
module.watch(require("/imports/api/genes/gene_collection.js"), {
  Genes(v) {
    Genes = v;
  },

  GeneSchema(v) {
    GeneSchema = v;
  },

  SubfeatureSchema(v) {
    SubfeatureSchema = v;
  }

}, 11);
let References, ReferenceInfo;
module.watch(require("/imports/api/genomes/reference_collection.js"), {
  References(v) {
    References = v;
  },

  ReferenceInfo(v) {
    ReferenceInfo = v;
  }

}, 12);
let Tracks;
module.watch(require("/imports/api/genomes/track_collection.js"), {
  Tracks(v) {
    Tracks = v;
  }

}, 13);
let scanGeneAttributes;
module.watch(require("/imports/api/genes/scan_attributes.js"), {
  scanGeneAttributes(v) {
    scanGeneAttributes = v;
  }

}, 14);

/**
 * Override the default querystring unescape function to be able to parse commas correctly in gff attributes
 * @param  {[type]}
 * @return {[type]}
 */
querystring.unescape = uri => uri;
/**
 * [Interval description]
 * @type {[type]}
 */


const Interval = class Interval {
  constructor({
    line,
    trackName,
    referenceName,
    referenceSequences
  }) {
    assert.equal(line.length, 9);
    const [seqid, source, type, start, end, score, strand, phase, attributes] = line;
    this.type = type;
    this.start = start;
    this.end = end;
    this.score = String(score);
    this.attributes = formatAttributes(attributes);
    this.ID = this.attributes.ID[0];
    delete this.attributes.ID;

    if (this.attributes.Parent !== undefined) {
      this.parents = this.attributes.Parent;
      delete this.attributes.Parent;
    }

    this.seq = referenceSequences[seqid].slice(start - 1, end);

    if (this.type === 'gene') {
      this.seqid = seqid;
      this.source = source;
      this.strand = strand;
      this.reference = referenceName;
      this.track = trackName;
      this.permissions = ['admin'];
      GeneSchema.validate(this);
    } else {
      this.phase = phase;
      SubfeatureSchema.validate(this);
    }
  }

};
/**
 * [GeneModel description]
 * @type {[type]}
 */

const GeneModel = class GeneModel {
  constructor(intervals) {
    console.log('constructing genemodel');
    Object.values(intervals).forEach(interval => {
      if (interval.parents !== undefined) {
        interval.parents.forEach(parentId => {
          let parent = intervals[parentId];

          if (parent.children === undefined) {
            intervals[parentId].children = [];
          }

          intervals[parentId].children.push(interval.ID);
        });
      }
    });
    const genes = Object.values(intervals).filter(interval => {
      return interval.type === 'gene';
    });
    assert.equal(genes.length, 1);
    const gene = genes[0];
    console.log(gene.ID);
    Object.keys(gene).forEach(key => {
      this[key] = gene[key];
    });
    this.subfeatures = Object.values(intervals).filter(interval => {
      return interval.type !== 'gene';
    });
  }

};
/**
 * [ValidatedMethod description]
 * @param {[type]} options.name:     'addGff'     [description]
 * @param {[type]} options.validate: new          SimpleSchema({		fileName: {            type:              String        [description]
 * @param {[type]} referenceName:    {           type:                      String        }                 [description]
 * @param {[type]} trackName:        {           type:                      String        }	}).validator() [description]
 * @param {[type]} applyOptions:     {		noRetry: true	}                    [description]
 * @param {[type]} run({            fileName,    referenceName,             trackName     }){		if          (!            this.userId)  {			throw new Meteor.Error('not-authorized');		}		if (! Roles.userIsInRole(this.userId,'curator')){			throw new Meteor.Error('not-authorized');		}		const existingTrack [description]
 */

const addGff = new ValidatedMethod({
  name: 'addGff',
  validate: new SimpleSchema({
    fileName: {
      type: String
    },
    referenceName: {
      type: String
    },
    trackName: {
      type: String
    }
  }).validator(),
  applyOptions: {
    noRetry: true
  },

  run({
    fileName,
    referenceName,
    trackName
  }) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'curator')) {
      throw new Meteor.Error('not-authorized');
    }

    const existingTrack = Tracks.find({
      trackName: trackName
    }).fetch().length;

    if (existingTrack) {
      throw new Meteor.Error('Track exists: ' + trackName);
    }

    const existingReference = References.find({
      referenceName: referenceName
    }).fetch().length;

    if (!existingReference) {
      throw new Meteor.Error('Invalid reference: ' + referenceName);
    }

    const fileHandle = fs.readFileSync(fileName, {
      encoding: 'binary'
    });
    let intervals = {};
    let geneCount = 0;
    console.log(`Gathering reference sequences for ${referenceName}`);
    const referenceSequences = getReferenceSequences(referenceName);
    console.log('start reading');
    Baby.parse(fileHandle, {
      delimiter: '\t',
      dynamicTyping: true,
      skipEmptyLines: true,
      comments: '#',

      error(error, file) {
        console.log(error);
      },

      step(line) {
        let interval = new Interval({
          line: line.data[0],
          referenceName: referenceName,
          trackName: trackName,
          referenceSequences: referenceSequences
        });

        if (interval.parents === undefined) {
          assert.equal(interval.type, 'gene');

          if (!isEmpty(intervals)) {
            const gene = new GeneModel(intervals);
            GeneSchema.validate(gene);
            Genes.insert(gene);
            geneCount += 1;
            intervals = {};
          }
        }

        intervals[interval.ID] = interval;
      },

      complete(results, file) {
        if (!isEmpty(intervals)) {
          console.log('constructing final gene');
          const gene = new GeneModel(intervals);
          GeneSchema.validate(gene);
          Genes.insert(gene);
          geneCount += 1;
          intervals = {};
        }

        Tracks.insert({
          trackName: trackName,
          reference: referenceName,
          geneCount: geneCount,
          permissions: ['admin']
        });
        scanGeneAttributes.call({
          trackName: trackName
        });
      }

    });
    return true;
  }

});

/**
 * [description]
 * @param  {[type]} referenceName [description]
 * @return {[type]}               [description]
 */
const getReferenceSequences = referenceName => {
  const headers = References.find({
    referenceName: referenceName
  }, {
    fields: {
      header: 1
    }
  }).map(reference => reference.header).reduce((headers, header) => {
    if (headers.indexOf(header) < 0) {
      headers.push(header);
    }

    return headers;
  }, []);
  const referenceSequences = headers.reduce((sequences, header) => {
    const sequence = References.find({
      referenceName: referenceName,
      header: header
    }, {
      sort: {
        start: 1
      }
    }).map(ref => ref.seq).join('');
    sequences[header] = sequence;
    return sequences;
  }, {});
  return referenceSequences;
};
/**
 * [description]
 * @param  {[type]} attributeString [description]
 * @return {[type]}                 [description]
 */


const formatAttributes = attributeString => {
  return attributeString.split(';').reduce((attributes, stringPart) => {
    const [key, value] = stringPart.split('=');
    attributes[key] = value.split(',').map(decodeURIComponent);
    return attributes;
  }, {});
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"add_reference.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genomes/add_reference.js                                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  addReference: () => addReference
});
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 3);
let readline;
module.watch(require("readline"), {
  default(v) {
    readline = v;
  }

}, 4);
let Fiber;
module.watch(require("fibers"), {
  default(v) {
    Fiber = v;
  }

}, 5);
let Future;
module.watch(require("fibers/future"), {
  default(v) {
    Future = v;
  }

}, 6);
let ReferenceInfo, References;
module.watch(require("/imports/api/genomes/reference_collection.js"), {
  ReferenceInfo(v) {
    ReferenceInfo = v;
  },

  References(v) {
    References = v;
  }

}, 7);
const parameterSchema = new SimpleSchema({
  fileName: {
    type: String
  },
  referenceName: {
    type: String
  }
});
const addReference = new ValidatedMethod({
  name: 'addReference',
  validate: parameterSchema.validator(),
  applyOptions: {
    noRetry: true
  },

  run({
    fileName,
    referenceName
  }) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'curator')) {
      throw new Meteor.Error('not-authorized');
    }

    const existingReference = ReferenceInfo.find({
      referenceName: referenceName
    }).fetch().length;

    if (existingReference) {
      throw new Meteor.Error('Existing reference: ' + referenceName);
    }

    const lineReader = readline.createInterface({
      input: fs.createReadStream(fileName, 'utf8')
    });
    const bulkOp = References.rawCollection().initializeUnorderedBulkOp();
    let seq = '';
    let header;
    let start = 0;
    let end = 0;
    const chunkSize = 10000;
    const fut = new Future();
    console.log('start parsing');
    lineReader.on('line', line => {
      if (line[0] === '>') {
        if (header !== undefined) {
          console.log(header);

          if (seq.length > 0) {
            end += seq.length;
            new Fiber(() => {
              References.insert({
                header: header,
                seq: seq,
                start: start,
                end: end,
                referenceName: referenceName,
                permissions: ['admin']
              });
            }).run();
          }
        }

        header = line.split('>')[1].split(' ')[0];
        seq = '';
        start = 0;
        end = 0;
      } else {
        seq += line;

        if (seq.length > chunkSize) {
          end += chunkSize;
          new Fiber(() => {
            References.insert({
              header: header,
              seq: seq.substring(0, chunkSize),
              start: start,
              end: end,
              referenceName: referenceName,
              permissions: ['admin']
            });
          }).run();
          seq = seq.substring(chunkSize);
          start += chunkSize;
        }
      }
    });
    lineReader.on('close', () => {
      end += seq.length;
      new Fiber(() => {
        References.insert({
          header: header,
          seq: seq,
          start: start,
          end: end,
          referenceName: referenceName,
          permissions: ['admin']
        });
        ReferenceInfo.insert({
          referenceName: referenceName,
          permissions: ['admin'],
          description: 'description',
          organism: 'organism'
        });
        console.log('finished parsing');
        fut.return(1);
      }).run();
    });
    return fut.wait();
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"reference_collection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genomes/reference_collection.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  References: () => References,
  ReferenceSchema: () => ReferenceSchema,
  ReferenceInfo: () => ReferenceInfo,
  ReferenceInfoSchema: () => ReferenceInfoSchema
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const References = new Mongo.Collection('references');
const ReferenceSchema = new SimpleSchema({
  header: {
    type: String,
    index: true,
    label: 'Fasta style sequence header'
  },
  seq: {
    type: String,
    label: 'Nucleotide sequence'
  },
  referenceName: {
    type: String,
    index: true,
    label: 'Reference name'
  },
  start: {
    type: Number,
    index: true,
    label: 'Start position of sequence fragment on original sequence'
  },
  end: {
    type: Number,
    index: true,
    label: 'End position of sequence fragment on original sequence'
  },
  permissions: {
    type: Array,
    //[String],
    label: 'User groups that are allowed to see this reference'
  },
  'permissions.$': {
    type: String
  }
});
References.attachSchema(ReferenceSchema);
const ReferenceInfo = new Mongo.Collection('referenceInfo');
const ReferenceInfoSchema = new SimpleSchema({
  referenceName: {
    type: String,
    label: 'Reference name',
    index: true,
    unique: true
  },
  permissions: {
    type: Array,
    //[String],
    label: 'User groups that are allowed to see this reference'
  },
  'permissions.$': {
    type: String
  },
  description: {
    type: String,
    label: 'Reference sequence description'
  },
  organism: {
    type: String,
    label: 'Organism name'
  }
});
ReferenceInfo.attachSchema(ReferenceInfoSchema);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"track_collection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genomes/track_collection.js                                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  Tracks: () => Tracks,
  trackSchema: () => trackSchema
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const Tracks = new Mongo.Collection('tracks');
const trackSchema = new SimpleSchema({
  trackName: {
    type: String,
    label: 'Annotation track name'
  },
  reference: {
    type: String,
    label: 'Reference sequence to which the annotation belongs'
  },
  blastdbs: {
    type: Object,
    optional: true
  },
  'blastdbs.nucl': {
    type: String,
    optional: true,
    label: 'Nucleotide blast database name'
  },
  'blastdbs.prot': {
    type: String,
    optional: true,
    label: 'Peptide blast database name'
  },
  permissions: {
    type: Array,
    //[String],
    label: 'Track permissions'
  },
  'permissions.$': {
    type: String
  }
});
Tracks.attachSchema(trackSchema);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"updateTrackPermissions.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/genomes/updateTrackPermissions.js                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  updateTrackPermissions: () => updateTrackPermissions
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 1);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let Tracks;
module.watch(require("/imports/api/genomes/track_collection.js"), {
  Tracks(v) {
    Tracks = v;
  }

}, 4);
const updateTrackPermissions = new ValidatedMethod({
  name: 'updateTrackPermissions',
  validate: new SimpleSchema({
    trackName: {
      type: String
    },
    permissions: {
      type: Array
    },
    'permissions.$': {
      type: String
    }
  }).validator(),
  applyOptions: {
    noRetry: true
  },

  run({
    trackName,
    permissions
  }) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'user')) {
      throw new Meteor.Error('not-authorized');
    }

    if (permissions.length === 0) {
      permissions.push('admin');
    }

    Tracks.update({
      trackName: trackName
    }, {
      $set: {
        permissions: permissions
      }
    });
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jobqueue":{"jobqueue.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/jobqueue/jobqueue.js                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
const jobQueue = new JobCollection('jobQueue', {
  noCollectionSuffix: true
}); //immediately build a 'job cleaning job' so that the jobcollection does not fill up endlessly

new Job(jobQueue, 'cleanup', {}).repeat({
  schedule: jobQueue.later.parse.text('every 20 minutes')
}).save({
  cancelRepeats: true
});
const cleanup = jobQueue.processJobs('cleanup', {
  pollInterval: false,
  workTimeout: 60 * 1000
}, (job, callback) => {
  let current = new Date();
  current.setMinutes(current.getMinutes() - 20);
  ids = jobQueue.find({
    status: {
      $in: Job.jobStatusRemovable
    },
    updated: {
      $lt: current
    }
  }, {
    fields: {
      _id: 1
    }
  }).map(job => job._id);

  if (ids.length > 0) {
    jobQueue.removeJobs(ids);
  }

  job.done(`removed ${ids.length} old jobs`);
  callback();
});
jobQueue.find({
  type: 'cleanup',
  status: 'ready'
}).observe({
  added() {
    return cleanup.trigger();
  }

});
module.exportDefault(jobQueue);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"process-blast.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/jobqueue/process-blast.js                                                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let jobQueue;
module.watch(require("./jobqueue.js"), {
  default(v) {
    jobQueue = v;
  }

}, 1);
let spawn;
module.watch(require("spawn-promise"), {
  default(v) {
    spawn = v;
  }

}, 2);
let xml2js;
module.watch(require("xml2js-es6-promise"), {
  default(v) {
    xml2js = v;
  }

}, 3);
let Tracks;
module.watch(require("/imports/api/genomes/track_collection.js"), {
  Tracks(v) {
    Tracks = v;
  }

}, 4);

/**
 * Keep track of what blast commands should use which databases
 * @type {Object}
 */
const DB_TYPES = {
  'blastn': 'nucl',
  'tblastn': 'nucl',
  'tblastx': 'nucl',
  'blastp': 'prot',
  'blastx': 'prot'
};
jobQueue.processJobs('blast', {
  concurrency: 1,
  payload: 1
}, (job, callback) => {
  console.log(job.data);
  const {
    blastType,
    input,
    trackNames,
    user
  } = job.data;
  const dbType = DB_TYPES[blastType];
  const dbs = Tracks.find({
    trackName: {
      $in: trackNames
    }
  }, {
    fields: {
      blastdbs: 1
    }
  }).map(track => {
    return track.blastdbs[dbType];
  }).join(' ');
  const options = ['-db', dbs, '-outfmt', '5', '-num_alignments', '20'];
  console.log(`${blastType} ${options.join(' ')} ${input.substring(0, 3)}...${input.substring(input.length - 3, input.length)}`);
  spawn(blastType, options, input).then(result => {
    console.log('blast finished');
    return xml2js(result.toString());
  }).then(resultJson => {
    job.done(resultJson);
    callback();
  }).catch(error => {
    console.log(error);
    job.fail(error.process);
    callback();
  }); //job.done(blastResult)
  //callback()
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"process-download.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/jobqueue/process-download.js                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let jobQueue;
module.watch(require("./jobqueue.js"), {
  default(v) {
    jobQueue = v;
  }

}, 1);
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 2);
let zlib;
module.watch(require("zlib"), {
  default(v) {
    zlib = v;
  }

}, 3);
let Genes;
module.watch(require("/imports/api/genes/gene_collection.js"), {
  Genes(v) {
    Genes = v;
  }

}, 4);
const DATATYPE_EXTENSIONS = {
  'Annotations': 'annotations.gff'
};
const queue = jobQueue.processJobs('download', {
  concurrency: 1,
  payload: 1
}, (job, callback) => {
  console.log(job.data);
  const {
    queryHash,
    queryString,
    dataType
  } = job.data;
  const query = JSON.parse(queryString);
  const extension = DATATYPE_EXTENSIONS[dataType];
  const fileName = `Genebook_download_${queryHash}.${extension}.gz`;
  const writeStream = fs.createWriteStream(fileName);
  const compress = zlib.createGzip();
  compress.pipe(writeStream); // the finish event is emitted when all data has been flushed from the stream

  compress.on('finish', () => {
    console.log('wrote all data to file');
  });
  Genes.find(query).forEach(gene => {
    console.log(gene.ID);
    compress.write(gene.ID);
  }); // close the stream

  compress.end(); //Meteor.call('interproscan',job.data.geneId)

  job.done(fileName);
  callback();
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"process-interproscan.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/jobqueue/process-interproscan.js                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let jobQueue;
module.watch(require("./jobqueue.js"), {
  default(v) {
    jobQueue = v;
  }

}, 1);
const queue = jobQueue.processJobs('interproscan', {
  concurrency: 4,
  payload: 1
}, function (job, callback) {
  console.log(job.data.geneId); //Meteor.call('interproscan',job.data.geneId)

  job.done();
  callback();
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"process-makeBlastDb.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/jobqueue/process-makeBlastDb.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let jobQueue;
module.watch(require("./jobqueue.js"), {
  default(v) {
    jobQueue = v;
  }

}, 1);
let spawn;
module.watch(require("spawn-promise"), {
  default(v) {
    spawn = v;
  }

}, 2);
let Genes;
module.watch(require("/imports/api/genes/gene_collection.js"), {
  Genes(v) {
    Genes = v;
  }

}, 3);
let Tracks;
module.watch(require("/imports/api/genomes/track_collection.js"), {
  Tracks(v) {
    Tracks = v;
  }

}, 4);
let getGeneSequences;
module.watch(require("/imports/api/util/util.js"), {
  getGeneSequences(v) {
    getGeneSequences = v;
  }

}, 5);
jobQueue.processJobs('makeBlastDb', {
  concurrency: 2,
  payload: 1
}, function (job, callback) {
  return Promise.asyncApply(() => {
    console.log('processing makeblastdb');
    console.log(job.data);
    const {
      trackName,
      dbType
    } = job.data;
    const trackId = trackName.split(/ |\./).join('_');
    const geneNumber = Genes.find({
      track: trackName
    }).count();
    const stepSize = Math.round(geneNumber / 10);
    console.log(`scanning ${geneNumber} genes`);
    const fasta = Genes.find({
      track: trackName
    }).map((gene, index) => {
      if (index % stepSize === 0) {
        job.progress(index, geneNumber, {
          echo: true
        });
      }

      let transcriptFasta = getGeneSequences(gene).map(transcript => {
        let sequence = dbType === 'prot' ? transcript.pep : transcript.seq; //keep track of gene ID and transcript ID for later processing

        return `>${gene.ID} ${transcript.ID}\n${sequence}`;
      }).join('\n');
      return transcriptFasta;
    }).join('\n');
    const outFile = `${trackId}.${dbType}`;
    const options = ['-dbtype', dbType, '-title', trackId, '-out', outFile];
    console.log(options);
    const dbFile = Promise.await(spawn('makeblastdb', options, fasta).then(result => {
      let stdout = result.toString();

      if (stdout) {
        console.log(`makeblastdb stdout:${stdout}`);
      }

      Tracks.findAndModify({
        query: {
          trackName: trackName
        },
        update: {
          $set: {
            [`blastdbs.${dbType}`]: `${trackId}.${dbType}`
          }
        }
      });
      return `${trackId}.${dbType}`;
    }).catch(error => {
      console.error(error);
    }));
    console.log(`${dbFile} done`);
    job.done(dbFile);
    callback();
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"list.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/methods/list.js                                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 1);
let Tracks;
module.watch(require("/imports/api/genomes/track_collection.js"), {
  Tracks(v) {
    Tracks = v;
  }

}, 2);
Meteor.methods({
  list: function (what) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'curator')) {
      throw new Meteor.Error('not-authorized');
    }

    let retval;

    switch (what) {
      case 'tracks':
        retval = Tracks.find({}, {
          fields: {
            _id: 0
          }
        }).fetch();
        break;

      case 'references':
        retval = References.find({}, {
          fields: {
            _id: 0,
            reference: 1
          }
        }).fetch().map(function (ret) {
          return ret.reference;
        });
        break;

      default:
        throw new Meteor.Error('Can not list: ' + what);
    }

    return [...new Set(retval)];
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/methods/methods.js                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let spawn;
module.watch(require("child_process"), {
  spawn(v) {
    spawn = v;
  }

}, 0);
let Future;
module.watch(require("fibers/future"), {
  default(v) {
    Future = v;
  }

}, 1);
let Genes;
module.watch(require("/imports/api/genes/gene_collection.js"), {
  Genes(v) {
    Genes = v;
  }

}, 2);
let Attributes;
module.watch(require("/imports/api/genes/attribute_collection.js"), {
  Attributes(v) {
    Attributes = v;
  }

}, 3);
let EditHistory;
module.watch(require("/imports/api/genes/edithistory_collection.js"), {
  EditHistory(v) {
    EditHistory = v;
  }

}, 4);
let reverseComplement, translate, getGeneSequences;
module.watch(require("/imports/api/util/util.js"), {
  reverseComplement(v) {
    reverseComplement = v;
  },

  translate(v) {
    translate = v;
  },

  getGeneSequences(v) {
    getGeneSequences = v;
  }

}, 5);
let hash;
module.watch(require("object-hash"), {
  default(v) {
    hash = v;
  }

}, 6);
Meteor.methods({
  /**
   * [formatFasta description]
   * @param  {[Object]} query        [Database query to select genes]
   * @param  {[String]} sequenceType [One of 'protein' or 'nucleotide']
   * @return {[Array]}               [Array of fasta formatted coding sequences]
   */
  formatFasta(query, sequenceType) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    console.log('formatFasta');
    console.log(query);
    const fasta = Genes.find(query).map((gene, index) => {
      const transcriptFasta = getGeneSequences(gene).map(transcript => {
        const sequence = sequenceType === 'protein' ? transcript.pep : transcript.seq;
        const wrappedSequence = sequence.match(/.{1,60}/g).join('\n');
        return `>${transcript.ID}\n${wrappedSequence}\n`;
      }).join('');
      return transcriptFasta;
    });
    return fasta;
  },

  queryCount(search, query) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'curator')) {
      throw new Meteor.Error('not-authorized');
    }

    if (search) {
      query.$or = [{
        'ID': {
          $regex: search,
          $options: 'i'
        }
      }, {
        'Name': {
          $regex: search,
          $options: 'i'
        }
      }];

      if (!query.hasOwnProperty('Productname')) {
        query.$or.push({
          'Productname': {
            $regex: search,
            $options: 'i'
          }
        });
      }
    }

    const count = Genes.find(query).count();
    return count;
  },

  removeFromViewing(geneId) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    Genes.update({
      'ID': geneId
    }, {
      $pull: {
        'viewing': this.userId
      }
    }, (err, res) => {
      if (err) {
        throw new Meteor.Error('removeFromViewing server method error');
      }

      const gene = Genes.findOne({
        'ID': geneId
      });
      console.log(gene); //if ( viewing.length === 0 ){
      //Genes.update({ 'ID': geneId },{ $unset: { 'viewing': 1 } } )
      //} 
    });
  },

  /**
   * Block a gene from being edited, this should happen when someone is editing a gene to prevent simultaneous edits
   * @param  {[type]}
   * @return {[type]}
   */
  lockGene(geneId) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'curator')) {
      throw new Meteor.Error('not-authorized');
    }

    Genes.update({
      'ID': geneId
    }, {
      $set: {
        editing: this.userId
      }
    }, (err, res) => {
      if (err) {
        throw new Meteor.Error('Locking gene failed');
      }

      console.log(`${this.userId} is editing gene ${geneId}`);
    });
  },

  /**
   * This unlocks a gene from being blocked during editing. 
   * A gene should only be unlocked by the person that locked it
   * @param  {[type]}
   * @return {[type]}
   */
  unlockGene(geneId) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'curator')) {
      throw new Meteor.Error('not-authorized');
    }

    const gene = Genes.findOne({
      ID: geneId
    });

    if (!gene) {
      throw new Meteor.Error('not-authorized');
    }

    if (!gene.editing) {
      throw new Meteor.Error('not-authorized');
    }

    if (!(gene.editing === this.userId)) {
      throw new Meteor.Error('not-authorized');
    }

    console.log('allow unlock ===', gene.editing === this.userId);

    if (gene.editing === this.userId) {
      console.log(`${this.userId} is no longer editing gene ${geneId}`);
      Genes.update({
        ID: geneId
      }, {
        $set: {
          editing: 'Unlocking'
        }
      }, (err, res) => {
        if (err) {
          throw new Meteor.Error('Unlocking failed');
        }

        Genes.update({
          ID: geneId
        }, {
          $unset: {
            editing: 1
          }
        });
      });
    }
  }

});
Meteor.methods({
  updateExperiments(_id, fields) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    ;

    if (!Roles.userIsInRole(this.userId, 'admin')) {
      throw new Meteor.Error('not-authorized');
    }

    Experiments.update({
      '_id': _id
    }, {
      $set: fields
    });
  },

  updateUsers(_id, fields) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    Meteor.users.update({
      '_id': _id
    }, {
      $set: fields
    });
  },

  updateGeneInfo(geneId, update, revert) {
    const userId = this.userId;

    if (!userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(userId, 'curator')) {
      throw new Meteor.Error('not-authorized');
    }

    console.log(`Updating gene ${geneId}`);
    console.log('Update:', update);
    console.log('Revert:', revert);
    let newAttributes = [];

    if (update.hasOwnProperty('$set')) {
      newAttributes = Object.keys(update['$set']).filter(key => {
        return key.startsWith('attributes.');
      }).map(key => {
        return {
          query: key,
          name: key.replace('attributes.', '')
        };
      });
    }

    console.log('New attributes:', newAttributes);
    const revertString = JSON.stringify(revert);
    const gene = Genes.findOne({
      ID: geneId
    });
    Genes.update({
      ID: geneId
    }, update, (err, res) => {
      if (!err) {
        EditHistory.insert({
          ID: geneId,
          date: new Date(),
          user: userId,
          revert: revertString
        });
        newAttributes.forEach(newAttribute => {
          Attributes.findAndModify({
            query: {
              name: newAttribute.name
            },
            update: {
              $setOnInsert: {
                name: newAttribute.name,
                query: newAttribute.query,
                show: true,
                reserved: false,
                canEdit: false
              },
              $push: {
                references: gene.reference,
                tracks: gene.track
              }
            },
            upsert: true,
            new: true
          });
        });
      }
    });
  },

  updateAttributes(_id, fields) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'admin')) {
      throw new Meteor.Error('not-authorized');
    }

    Attributes.update({
      '_id': _id
    }, {
      $set: fields
    });
  },

  /**
   * [formatGff3 description]
   * @param  {[Object]} query [description]
   * @return {[Array]}        [Array with gff3 formatted ]
   */
  formatGff3(query) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    const genes = Genes.find(query);
    const total = genes.count();
    let counter = 0;
    const gff = genes.map(function (gene) {
      counter += 1;
      let subLines = gene.subfeatures.map(function (sub) {
        let subFields = [gene.seqid, gene.source, sub.type, sub.start, sub.end, sub.score, gene.strand, sub.phase, 'ID=' + sub.ID + ';Parents=' + sub.parents.join()];
        return subFields.join('\t') + '\n';
      });
      let geneFields = [gene.seqid, gene.source, gene.type, gene.start, gene.end, gene.score, gene.strand, gene.phase, 'ID=' + gene.ID];
      let geneLine = geneFields.join('\t') + '\n'; //unshift adds to the beginning of the array

      subLines.unshift(geneLine);
      return subLines.join('');
    });
    return gff;
  },

  initializeDownload(query, format) {
    queryHash = hash(query);
    queryString = JSON.stringify(query);
    existing = Downloads.findOne({
      query: queryHash,
      format: format
    });
    let downloadId;

    if (existing === undefined) {
      downloadId = Downloads.insert({
        query: queryHash,
        queryString: queryString,
        format: format
      }); //return downloadId
    } else {
      downloadId = existing._id; //return existing._id
    }
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transcriptomes":{"add_transcriptome.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/transcriptomes/add_transcriptome.js                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 1);
let assert;
module.watch(require("assert"), {
  default(v) {
    assert = v;
  }

}, 2);
let Baby;
module.watch(require("babyparse"), {
  default(v) {
    Baby = v;
  }

}, 3);
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 4);
let Tracks;
module.watch(require("/imports/api/genomes/track_collection.js"), {
  Tracks(v) {
    Tracks = v;
  }

}, 5);
let Genes;
module.watch(require("/imports/api/genes/gene_collection.js"), {
  Genes(v) {
    Genes = v;
  }

}, 6);
let ExperimentInfo, Transcriptomes;
module.watch(require("/imports/api/transcriptomes/transcriptome_collection.js"), {
  ExperimentInfo(v) {
    ExperimentInfo = v;
  },

  Transcriptomes(v) {
    Transcriptomes = v;
  }

}, 7);
Meteor.methods({
  addTranscriptome(config) {
    console.log('trying to insert', config);

    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'curator')) {
      throw new Meteor.Error('not-authorized');
    }

    const existingTrack = Tracks.find({
      trackName: config.trackName
    }).fetch().length;

    if (!existingTrack) {
      throw new Meteor.Error(`Track does not exist: ${config.trackName}`);
    }

    const fileHandle = fs.readFileSync(config.fileName, {
      encoding: 'binary'
    });
    console.log(`Start reading ${config.fileName}`);
    Baby.parse(fileHandle, {
      delimiter: '\t',
      dynamicTyping: true,
      skipEmptyLines: true,
      comments: '#',
      header: true,

      error(error, file) {
        console.log(error);
      },

      complete(results, file) {
        const missingGenes = new Set();
        const tracks = new Set();
        console.log('Reading finished, start validating');
        results.data.forEach(result => {
          const gene = Genes.findOne({
            ID: result.target_id
          });

          if (gene === undefined) {
            missingGenes.add(result.target_id);
          } else {
            tracks.add(gene.track);
          }
        });

        if (missingGenes.size > 0) {
          throw new Meteor.Error(`${missingGenes.length} genes could not be found`);
        }

        if (tracks.size > 1) {
          throw new Meteor.Error(`Gene IDs are linked to more than one track: ${Array.from(tracks)}`);
        }

        console.log('Validation finished, start inserting experiment info');
        const experimentId = ExperimentInfo.insert({
          track: config.trackName,
          sampleName: config.sampleName,
          experimentGroup: config.experimentGroup,
          replicaGroup: config.replicaGroup,
          description: config.description,
          permissions: ['admin']
        });
        /*
        formattedResults = results.map(result => {
        	return {
        		geneId: result.target_id,
        		experimentId: experimentId,
        		permissions: ['admin'],
        		raw_counts: result.est_counts,
        		tpm: result.tpm
        	}
        })
        */

        console.log('Start inserting expression data');
        results.data.forEach(gene => {
          Transcriptomes.insert({
            geneId: gene.target_id,
            experimentId: experimentId,
            permissions: ['admin'],
            raw_counts: gene.est_counts,
            tpm: gene.tpm
          });
        });
      }

    });
    return `Succesfully inserted ${config.sampleName}`;
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"transcriptome_collection.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/transcriptomes/transcriptome_collection.js                                                            //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  ExperimentInfo: () => ExperimentInfo,
  ExperimentInfoSchema: () => ExperimentInfoSchema,
  Transcriptomes: () => Transcriptomes,
  TranscriptomeSchema: () => TranscriptomeSchema
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const ExperimentInfo = new Mongo.Collection('experiments');
const ExperimentInfoSchema = new SimpleSchema({
  sampleName: {
    type: String,
    label: 'Short name for the sample'
  },
  experimentGroup: {
    type: String,
    label: 'Identifier to group together samples from the same experiment'
  },
  replicaGroup: {
    type: String,
    label: 'Identifier to group together samples from the same replica'
  },
  track: {
    type: String,
    label: 'Annotation track to which the transcriptome is mapped'
  },
  description: {
    type: String,
    label: 'Experiment description'
  },
  permissions: {
    type: Array,
    label: 'User groups that can access this experiment'
  },
  'permissions.$': {
    type: String
  }
});
ExperimentInfo.attachSchema(ExperimentInfoSchema);
const Transcriptomes = new Mongo.Collection('transcriptomes');
const TranscriptomeSchema = new SimpleSchema({
  geneId: {
    type: String,
    label: 'Gene ID' //index: true

  },
  experimentId: {
    type: String,
    label: 'Experiment ID' //index: true

  },
  permissions: {
    type: Array,
    //[String],
    label: 'User groups that can access this experiment'
  },
  'permissions.$': {
    type: String
  },
  raw_counts: {
    type: Number,
    //decimal: true,
    label: 'Raw read counts'
  },
  tpm: {
    type: Number,
    //decimal: true,
    label: 'TPM normalized read counts'
  }
});
Transcriptomes.attachSchema(TranscriptomeSchema);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"updateSampleInfo.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/transcriptomes/updateSampleInfo.js                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  updateSampleInfo: () => updateSampleInfo
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 1);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 2);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
let ExperimentInfo;
module.watch(require("/imports/api/transcriptomes/transcriptome_collection.js"), {
  ExperimentInfo(v) {
    ExperimentInfo = v;
  }

}, 4);
const updateSampleInfo = new ValidatedMethod({
  name: 'updateSampleInfo',
  validate: new SimpleSchema({
    _id: {
      type: String
    },
    sampleName: {
      type: String
    },
    experimentGroup: {
      type: String
    },
    replicaGroup: {
      type: String
    },
    description: {
      type: String
    },
    permissions: {
      type: Array
    },
    'permissions.$': {
      type: String
    }
  }).validator(),
  applyOptions: {
    noRetry: true
  },

  run({
    _id,
    sampleName,
    experimentGroup,
    replicaGroup,
    description,
    permissions
  }) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'admin')) {
      throw new Meteor.Error('not-authorized');
    }

    if (permissions.length === 0) {
      permissions.push('admin');
    }

    console.log({
      _id,
      sampleName,
      experimentGroup,
      replicaGroup,
      description,
      permissions
    });
    ExperimentInfo.update({
      _id: _id
    }, {
      $set: {
        sampleName,
        experimentGroup,
        replicaGroup,
        description,
        permissions
      }
    });
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"users":{"users.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/users/users.js                                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  updateUserInfo: () => updateUserInfo
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatedMethod;
module.watch(require("meteor/mdg:validated-method"), {
  ValidatedMethod(v) {
    ValidatedMethod = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
const updateUserInfo = new ValidatedMethod({
  name: 'updateUserInfo',
  validate: new SimpleSchema({
    userId: {
      type: String
    },
    update: {
      type: Object,
      blackbox: true
    }
  }).validator(),
  applyOptions: {
    noRetry: true
  },

  run({
    userId,
    update
  }) {
    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    if (!Roles.userIsInRole(this.userId, 'admin')) {
      throw new Meteor.Error('not-authorized');
    }

    Meteor.users.update({
      _id: userId
    }, update);
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"util.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/util/util.js                                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  reverseComplement: () => reverseComplement,
  translate: () => translate,
  getGeneSequences: () => getGeneSequences,
  parseNewick: () => parseNewick
});
let References;
module.watch(require("/imports/api/genomes/reference_collection.js"), {
  References(v) {
    References = v;
  }

}, 0);

const reverseComplement = seq => {
  const comp = {
    'A': 'T',
    'a': 't',
    'T': 'A',
    't': 'a',
    'C': 'G',
    'c': 'g',
    'G': 'C',
    'g': 'c',
    'N': 'N',
    'n': 'n'
  };
  const revSeqArray = seq.split('').reverse();
  const revCompSeqArray = revSeqArray.map(nuc => {
    return comp[nuc];
  });
  const revCompSeq = revCompSeqArray.join('');
  return revCompSeq;
};

const translate = seq => {
  const trans = {
    'ACC': 'T',
    'ACA': 'T',
    'ACG': 'T',
    'AGG': 'R',
    'AGC': 'S',
    'GTA': 'V',
    'AGA': 'R',
    'ACT': 'T',
    'GTG': 'V',
    'AGT': 'S',
    'CCA': 'P',
    'CCC': 'P',
    'GGT': 'G',
    'CGA': 'R',
    'CGC': 'R',
    'TAT': 'Y',
    'CGG': 'R',
    'CCT': 'P',
    'GGG': 'G',
    'GGA': 'G',
    'GGC': 'G',
    'TAA': '*',
    'TAC': 'Y',
    'CGT': 'R',
    'TAG': '*',
    'ATA': 'I',
    'CTT': 'L',
    'ATG': 'M',
    'CTG': 'L',
    'ATT': 'I',
    'CTA': 'L',
    'TTT': 'F',
    'GAA': 'E',
    'TTG': 'L',
    'TTA': 'L',
    'TTC': 'F',
    'GTC': 'V',
    'AAG': 'K',
    'AAA': 'K',
    'AAC': 'N',
    'ATC': 'I',
    'CAT': 'H',
    'AAT': 'N',
    'GTT': 'V',
    'CAC': 'H',
    'CAA': 'Q',
    'CAG': 'Q',
    'CCG': 'P',
    'TCT': 'S',
    'TGC': 'C',
    'TGA': '*',
    'TGG': 'W',
    'TCG': 'S',
    'TCC': 'S',
    'TCA': 'S',
    'GAG': 'E',
    'GAC': 'D',
    'TGT': 'C',
    'GCA': 'A',
    'GCC': 'A',
    'GCG': 'A',
    'GCT': 'A',
    'CTC': 'L',
    'GAT': 'D'
  };
  const codonArray = seq.match(/.{1,3}/g);
  const pepArray = codonArray.map(codon => {
    let aminoAcid = 'X';

    if (codon.indexOf('N') < 0) {
      aminoAcid = trans[codon];
    }

    return aminoAcid;
  });
  const pep = pepArray.join('');
  return pep;
};

/**
 * Get nucleotide and protein sequences of all transcripts for a multiple genes (using CDS subfeatures)
 * @param  {[Array]<gene>} genes [Array of Object representing gene-models]
 * @return {[Array]}     [Array with objects, where each object has a transcriptId, 
 *                        nucleotide sequence and protein sequence field]
 */
const getMultipleGeneSequences = genes => {
  const seqids = genes.map(gene => {
    return gene.seqid;
  });
  const uniqueSeqids = [...new Set(seqids)];
  console.log(uniqueSeqids);
  const refSeqs = uniqueSeqids.reduce((obj, seqid, i) => {
    obj[seqid] = References.find({
      header: seqid
    }, {
      sort: {
        start: 1
      }
    }).map(ref => {
      return ref.seq;
    }).join('');
    return obj;
  }, {}); //this part is import, initialize reduce with empty object

  console.log(refSeqs);
};
/**
 * Get nucleotide and protein sequences of all transcripts for a single gene (using CDS subfeatures)
 * @param  {[Object]} gene [Object representing a gene-model]
 * @return {[Array]}     [Array with objects, where each object has a transcriptId, 
 *                        nucleotide sequence and protein sequence field]
 */


const getGeneSequences = gene => {
  //console.log(`getGeneSequences ${gene.ID}`)
  const transcripts = gene.subfeatures.filter(subfeature => {
    return subfeature.type === 'mRNA';
  });
  const sequences = transcripts.map(transcript => {
    let cdsArray = gene.subfeatures.filter(subfeature => {
      return subfeature.parents.indexOf(transcript.ID) >= 0 && subfeature.type === 'CDS';
    }).sort((a, b) => {
      //sort CDS subfeatures on start position
      return a.start - b.start;
    });
    let rawSeq = cdsArray.map((cds, index) => {
      return cds.seq;
    }).join('');
    const forward = gene.strand === '+';
    const phase = forward ? cdsArray[0].phase : cdsArray[cdsArray.length - 1].phase;
    const transcriptSeq = forward ? rawSeq : reverseComplement(rawSeq);
    const isPhased = phase === 1 | phase === 2;
    const codingSeq = isPhased ? transcriptSeq.slice(phase) : transcriptSeq;
    const codingPep = translate(codingSeq.toUpperCase());
    return {
      ID: transcript.ID,
      seq: codingSeq,
      pep: codingPep
    };
  });
  return sequences;
};

const parseNewick = newickString => {
  //Adapted from Jason Davies https://github.com/jasondavies/newick.js
  const ancestors = [];
  const tokens = newickString.split(/\s*(;|\(|\)|,|:)\s*/);
  const geneIds = [];
  let tree = {};
  let subtree = {};
  tokens.forEach((token, tokenIndex) => {
    switch (token) {
      case '(':
        //new branchset
        subtree = {};
        tree.branchset = [subtree];
        ancestors.push(tree);
        tree = subtree;
        break;

      case ',':
        //another branch
        subtree = {};
        ancestors[ancestors.length - 1].branchset.push(subtree);
        tree = subtree;
        break;

      case ')':
        //optional name next
        tree = ancestors.pop();
        break;

      case ':':
        //optional length next
        break;

      default:
        let previousToken = tokens[tokenIndex - 1];

        if (previousToken === '(' || previousToken === ')' || previousToken === ',') {
          tree.name = token;
          const geneId = token.split('.').slice(0, -1).join('.');

          if (geneId.length > 0) {
            geneIds.push(geneId);
          }
        } else if (previousToken === ':') {
          tree.branchLength = parseFloat(token);
        }

    }
  });
  return {
    tree: tree,
    geneIds: geneIds,
    size: geneIds.length
  };
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"api.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/api.js                                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.watch(require("./publications.js"));
module.watch(require("./transcriptomes/add_transcriptome.js"));
module.watch(require("./transcriptomes/updateSampleInfo.js"));
module.watch(require("./genomes/add_reference.js"));
module.watch(require("./genomes/add_gff.js"));
module.watch(require("./genomes/updateTrackPermissions.js"));
module.watch(require("./genes/interproscan.js"));
module.watch(require("./genes/add_interproscan.js"));
module.watch(require("./genes/add_orthogroup_trees.js"));
module.watch(require("./genes/download_genes.js"));
module.watch(require("./blast/makeblastdb.js"));
module.watch(require("./blast/hasblastdb.js"));
module.watch(require("./blast/removeblastdb.js"));
module.watch(require("./blast/submitblastjob.js"));
module.watch(require("./users/users.js"));
module.watch(require("./methods/methods.js"));
module.watch(require("./methods/list.js"));
module.watch(require("./jobqueue/process-interproscan.js"));
module.watch(require("./jobqueue/process-makeBlastDb.js"));
module.watch(require("./jobqueue/process-blast.js"));
module.watch(require("./jobqueue/process-download.js"));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/publications.js                                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let publishComposite;
module.watch(require("meteor/reywood:publish-composite"), {
  publishComposite(v) {
    publishComposite = v;
  }

}, 1);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 2);
let jobQueue;
module.watch(require("/imports/api/jobqueue/jobqueue.js"), {
  default(v) {
    jobQueue = v;
  }

}, 3);
let Genes;
module.watch(require("/imports/api/genes/gene_collection.js"), {
  Genes(v) {
    Genes = v;
  }

}, 4);
let Attributes;
module.watch(require("/imports/api/genes/attribute_collection.js"), {
  Attributes(v) {
    Attributes = v;
  }

}, 5);
let Interpro;
module.watch(require("/imports/api/genes/interpro_collection.js"), {
  Interpro(v) {
    Interpro = v;
  }

}, 6);
let Orthogroups;
module.watch(require("/imports/api/genes/orthogroup_collection.js"), {
  Orthogroups(v) {
    Orthogroups = v;
  }

}, 7);
let EditHistory;
module.watch(require("/imports/api/genes/edithistory_collection.js"), {
  EditHistory(v) {
    EditHistory = v;
  }

}, 8);
let Tracks;
module.watch(require("/imports/api/genomes/track_collection.js"), {
  Tracks(v) {
    Tracks = v;
  }

}, 9);
let References, ReferenceInfo;
module.watch(require("/imports/api/genomes/reference_collection.js"), {
  References(v) {
    References = v;
  },

  ReferenceInfo(v) {
    ReferenceInfo = v;
  }

}, 10);
let ExperimentInfo, Transcriptomes;
module.watch(require("/imports/api/transcriptomes/transcriptome_collection.js"), {
  ExperimentInfo(v) {
    ExperimentInfo = v;
  },

  Transcriptomes(v) {
    Transcriptomes = v;
  }

}, 11);
Meteor.publish('genes', function (limit, search, query) {
  console.log('publishing gene list');
  console.log('limit', limit);
  console.log('search', search);
  console.log('query', query);
  const publication = this;

  if (!publication.userId) {
    publication.stop();
  }

  limit = limit || 40;
  query = query || {};

  if (search) {
    query.$or = [{
      'ID': {
        $regex: search,
        $options: 'i'
      }
    }, {
      'Name': {
        $regex: search,
        $options: 'i'
      }
    }];

    if (!query.hasOwnProperty('Productname')) {
      query.$or.push({
        'Productname': {
          $regex: search,
          $options: 'i'
        }
      });
    }
  }

  const roles = Roles.getRolesForUser(publication.userId);
  query.permissions = {
    $in: roles
  };
  return Genes.find(query, {
    limit: limit
  });
});
/*
publishComposite('singleGene', function(geneId){
  //console.log('publishing single gene')
  const publication = this;
  if (!publication.userId){
    publication.stop()
  }

  const roles = Roles.getRolesForUser(publication.userId);

  return {
    find(){
      return Genes.find({
        ID: geneId,
        permissions: {
          $in: roles
        }
      })
    },
    children: [
      {
        find(gene){
          return Transcriptomes.find({
            geneId: gene.ID,
            permissions: {
              $in: roles
            }
          })
        },
        children: [
        {
          find(transcriptome){
            return ExperimentInfo.find({
              _id: transcriptome.experimentId,
              permissions: {
                $in: roles
              }
            })
          }
        }
        ]
      }
    ]
  }
})
*/

publishComposite('attributes', function () {
  const publication = this;

  if (!publication.userId) {
    publication.stop();
  }

  const roles = Roles.getRolesForUser(publication.userId);
  return {
    find() {
      return ReferenceInfo.find({
        permissions: {
          $in: roles
        }
      });
    },

    children: [{
      find(reference) {
        return Attributes.find({
          $or: [{
            references: reference.referenceName
          }, {
            allReferences: true
          }]
        });
      }

    }]
  };
});
Meteor.publish('users', function () {
  if (!this.userId) {
    this.stop(); //throw new Meteor.Error('Unauthorized')
  }

  if (Roles.userIsInRole(this.userId, 'admin')) {
    return Meteor.users.find({});
  } else if (Roles.userIsInRole(this.userId, ['user', 'curator'])) {
    return Meteor.users.find({}, {
      fields: {
        username: 1
      }
    });
  } else {
    this.ready(); //throw new Meteor.Error('Unauthorized')
  }
});
Meteor.publish({
  singleGene(geneId) {
    const publication = this;

    if (!publication.userId) {
      publication.stop();
    }

    const roles = Roles.getRolesForUser(publication.userId);
    return Genes.find({
      ID: geneId,
      permissions: {
        $in: roles
      }
    });
  },

  geneExpression(geneId) {
    const publication = this;

    if (!publication.userId) {
      publication.stop();
    }

    const roles = Roles.getRolesForUser(publication.userId);
    return Transcriptomes.find({
      geneId: geneId,
      permissions: {
        $in: roles
      }
    });
  },

  experimentInfo() {
    const publication = this;

    if (!publication.userId) {
      publication.stop();
    }

    const roles = Roles.getRolesForUser(publication.userId);
    return ExperimentInfo.find({
      permissions: {
        $in: roles
      }
    });
  },

  downloads(downloadId) {
    const publication = this;
    const roles = publication.userId ? Roles.getRolesForUser(publication.userId) : ['public'];
    return Downloads.findOne({
      ID: downloadId,
      permission: {
        $in: roles
      }
    });
  },

  jobQueue() {
    const publication = this;

    if (!publication.userId) {
      publication.stop();
    }

    return jobQueue.find({});
  },

  referenceInfo() {
    const publication = this;

    if (!publication.userId) {
      publication.stop();
    }

    const roles = Roles.getRolesForUser(publication.userId);
    return ReferenceInfo.find({
      permissions: {
        $in: roles
      }
    });
  },

  orthogroups(ID) {
    if (!this.userId) {
      this.stop();
    }

    return Orthogroups.find({
      'ID': ID
    });
  },

  tracks() {
    const publication = this;

    if (!publication.userId) {
      publication.stop(); //throw new Meteor.Error('Unauthorized')
    }

    const roles = Roles.getRolesForUser(publication.userId);
    console.log(`tracks publication for user ${publication.userId} with roles ${roles}`);
    return Tracks.find({
      permissions: {
        $in: roles
      }
    });
  },

  interpro() {
    if (!this.userId) {
      this.stop(); //throw new Meteor.Error('Unauthorized')
    }

    return Interpro.find({});
  },

  editHistory() {
    if (!this.userId) {
      this.stop(); //throw new Meteor.Error('Unauthorized')
    }

    return EditHistory.find({});
  }

});
/*
Meteor.publish('browser',function(track,seqid,start,end){
  return Genes.find({ 'seqid': seqid, 'start': { $gte: start }, 'end': { $lte: end } });
})
*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"startup":{"server":{"index.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/index.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.watch(require("./server-fixtures.js"));
module.watch(require("./useraccounts-configuration.js"));
module.watch(require("/imports/api/api.js"));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"server-fixtures.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/server-fixtures.js                                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 1);
let jobQueue;
module.watch(require("/imports/api/jobqueue/jobqueue.js"), {
  default(v) {
    jobQueue = v;
  }

}, 2);
let Attributes;
module.watch(require("/imports/api/genes/attribute_collection.js"), {
  Attributes(v) {
    Attributes = v;
  }

}, 3);
let Tracks;
module.watch(require("/imports/api/genomes/track_collection.js"), {
  Tracks(v) {
    Tracks = v;
  }

}, 4);
Meteor.startup(() => {
  if (Meteor.users.find().count() === 0) {
    console.log('Adding default admin user');
    const adminId = Accounts.createUser({
      username: 'admin',
      email: 'admin@none.com',
      password: 'admin',
      profile: {
        first_name: 'admin',
        last_name: 'admin'
      }
    });
    Roles.addUsersToRoles(adminId, ['admin', 'curator', 'user', 'registered']);
    console.log('Adding default guest user');
    const guestId = Accounts.createUser({
      username: 'guest',
      email: 'guest@none.com',
      password: 'guest',
      profile: {
        first_name: 'guest',
        last_name: 'guest'
      }
    });
    Roles.addUsersToRoles(guestId, ['user', 'registered']);
  } //add some default attributes to filter on


  const permanentAttributes = [{
    name: 'Viewing',
    query: 'viewing'
  }, {
    name: 'Editing',
    query: 'editing'
  }, {
    name: 'Orthogroup',
    query: 'orthogroup'
  }, {
    name: 'Protein domains',
    query: 'subfeatures.protein_domains'
  }];
  permanentAttributes.forEach(attribute => {
    console.log(`Adding default filter option: ${attribute.name}`);
    Attributes.findAndModify({
      query: {
        name: attribute.name
      },
      update: {
        $setOnInsert: {
          name: attribute.name,
          query: attribute.query,
          show: true,
          canEdit: false,
          reserved: true,
          allReferences: true
        }
      },
      new: true,
      upsert: true
    });
  });
  Tracks.find({
    blastdbs: {
      $exists: true
    }
  }).fetch().filter(track => {
    const hasNucDb = fs.existsSync(track.blastdbs.nuc);
    const hasProtDb = fs.existsSync(track.blastdbs.prot);
    return !hasProtDb || !hasNucDb;
  }).map(track => {
    Tracks.update({
      _id: track._id
    }, {
      $unset: {
        blastdbs: true
      }
    });
  }); // Start the myJobs queue running

  jobQueue.allow({
    // Grant permission to admin only
    admin: function (userId, method, params) {
      return Roles.userIsInRole(userId, 'admin');
    }
  });
  return jobQueue.startJobServer();
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"useraccounts-configuration.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/startup/server/useraccounts-configuration.js                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.watch(require("meteor/accounts-base"), {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 2);
let Genes;
module.watch(require("/imports/api/genes/gene_collection.js"), {
  default(v) {
    Genes = v;
  }

}, 3);
Accounts.onCreateUser((options, user) => {
  console.log('onCreateUser');
  user.roles = ['registered'];

  if (typeof user.profile === 'undefined') {
    user.profile = {
      first_name: '',
      last_name: ''
    };
  }

  return user;
});
Accounts.onLogout(options => {
  console.log('logout', options);
  Meteor.users.update({
    _id: options.user._id,
    'presence.status': 'online'
  }, {
    $set: {
      'presence.status': 'offline'
    }
  });
  Genes.update({
    'viewing': options.user._id
  }, {
    $pull: {
      'viewing': options.user._id
    }
  }, (err, res) => {
    Genes.update({
      'viewing': {
        $exists: true,
        $size: 0
      }
    }, {
      $unset: {
        'viewing': 1
      }
    });
  }); //Since we are on the server, the following does not work. Need to design a 'loggedIn' template / high order component
  //FlowRouter.redirect('/login')
});
Meteor.users.allow({
  update(userId, doc, fields, modifier) {
    console.log('User update');
    console.log(doc);
    console.log(fields);
    console.log(modifier);

    if (userId && Roles.userIsInRole(userId, 'admin')) {
      return true;
    }
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"scripts":{"add_annotation.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// scripts/add_annotation.js                                                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //

///usr/bin/env node
"use strict";

if (!module.parent) {
  const assert = require('assert');

  const commander = require('commander');

  const Baby = require('babyparse');

  const fs = require('fs');

  const asteroid = require('asteroid');

  const path = require('path');

  const WebSocket = require('ws');

  let fileName, reference;
  commander.arguments('<genome_annotation.gff>').option('-u, --username <username>', 'The user to authenticate as [REQUIRED]').option('-p, --password <password>', 'The user\'s password [REQUIRED]').option('-r, --reference <reference genome>', 'Reference genome on which the annotation fits [REQUIRED]').option('-t, --trackname <annotation trackname>', 'Name of the annotation track').action(function (file) {
    fileName = path.resolve(file);
  }).parse(process.argv);

  if (commander.username === undefined || commander.password === undefined || commander.reference === undefined || fileName === undefined) {
    commander.help();
  }

  const trackName = commander.trackname || fileName;
  const options = {
    fileName: fileName,
    referenceName: commander.reference,
    trackName: trackName
  };
  console.log(process.argv.join(' '));
  console.log(options);
  const Connection = asteroid.createClass();
  const portal = new Connection({
    endpoint: 'ws://localhost:2000/websocket',
    SocketConstructor: WebSocket
  });
  portal.loginWithPassword({
    username: commander.username,
    password: commander.password
  }).then(result => {
    portal.call('addGff', options).then(result => {
      console.log(result);
      portal.disconnect();
    }).catch(error => {
      console.log(error);
      portal.disconnect();
    });
  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"add_interproscan.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// scripts/add_interproscan.js                                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //

///usr/bin/env node
"use strict";

if (!module.parent) {
  const assert = require('assert');

  const commander = require('commander'); //const Baby = require('babyparse');


  const fs = require('fs');

  const asteroid = require('asteroid');

  const path = require('path');

  const WebSocket = require('ws');

  let fileName;
  commander.arguments('<interproscan_annotation.gff>').option('-u, --username <username>', 'The user to authenticate as [REQUIRED]').option('-p, --password <password>', 'The user\'s password [REQUIRED]').option('-t, --trackname <annotation trackname>', 'Name of the annotation track').action(function (file) {
    fileName = path.resolve(file);
  }).parse(process.argv);

  if (commander.username === undefined || commander.password === undefined || commander.trackname === undefined || fileName === undefined) {
    commander.help();
  }

  const options = {
    fileName: fileName,
    trackName: commander.trackname
  };
  console.log(process.argv.join(' '));
  console.log(options);
  const Connection = asteroid.createClass();
  const portal = new Connection({
    endpoint: 'ws://localhost:3000/websocket',
    SocketConstructor: WebSocket
  });
  portal.loginWithPassword({
    username: commander.username,
    password: commander.password
  }).then(result => {
    portal.call('addInterproscan', options).then(result => {
      console.log(result);
      portal.disconnect();
    }).catch(error => {
      console.log(error);
      portal.disconnect();
    });
  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"add_orthogroup_trees.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// scripts/add_orthogroup_trees.js                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //

///usr/bin/env node
"use strict";

if (!module.parent) {
  const commander = require('commander');

  const asteroid = require('asteroid');

  const path = require('path');

  const WebSocket = require('ws');

  let folder;
  commander.arguments('<interproscan_annotation.gff>').option('-u, --username <username>', 'The user to authenticate as [REQUIRED]').option('-p, --password <password>', 'The user\'s password [REQUIRED]').action(function (file) {
    folder = path.resolve(file);
  }).parse(process.argv);

  if (commander.username === undefined || commander.password === undefined || folder === undefined) {
    commander.help();
  }

  const options = {
    folder: folder
  };
  console.log(process.argv.join(' '));
  console.log(options);
  const Connection = asteroid.createClass();
  const portal = new Connection({
    endpoint: 'ws://localhost:3000/websocket',
    SocketConstructor: WebSocket
  });
  portal.loginWithPassword({
    username: commander.username,
    password: commander.password
  }).then(result => {
    portal.call('addOrthogroupTrees', options).then(result => {
      console.log(result);
      portal.disconnect();
    }).catch(error => {
      console.log(error);
      portal.disconnect();
    });
  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"add_reference.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// scripts/add_reference.js                                                                                          //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //

///usr/bin/env node
"use strict";

if (!module.parent) {
  const assert = require('assert');

  const commander = require('commander');

  const fs = require('fs');

  const asteroid = require('asteroid');

  const path = require('path');

  const WebSocket = require('ws');

  let fileName, reference;
  commander.arguments('<reference.fasta>').option('-u, --username <username>', 'The user to authenticate as [REQUIRED]').option('-p, --password <password>', 'The user\'s password [REQUIRED]').option('-r, --referencename <reference name>', 'Reference name').action(function (file) {
    fileName = path.resolve(file);
  }).parse(process.argv);

  if (commander.username === undefined || commander.password === undefined || fileName === undefined) {
    commander.help();
  }

  const referenceName = commander.referencename || fileName;
  const options = {
    fileName: fileName,
    referenceName: referenceName
  };
  console.log(process.argv.join(' '));
  console.log(options);
  const Connection = asteroid.createClass();
  const portal = new Connection({
    endpoint: 'ws://localhost:2000/websocket',
    SocketConstructor: WebSocket
  });
  portal.loginWithPassword({
    username: commander.username,
    password: commander.password
  }).then(result => {
    portal.call('addReference', options).then(result => {
      console.log(result);
      portal.disconnect();
    }).catch(error => {
      console.log(error);
      process.exit(1);
      portal.disconnect();
    });
  }).catch(error => {
    console.log(error);
  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"add_transcriptome.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// scripts/add_transcriptome.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //

///usr/bin/env node
"use strict";

if (!module.parent) {
  const assert = require('assert');

  const commander = require('commander');

  const Baby = require('babyparse');

  const fs = require('fs');

  const asteroid = require('asteroid');

  const path = require('path');

  const WebSocket = require('ws');

  let fileName, reference;
  commander.arguments('<kallisto_abundance.tsv>').option('-u, --username <username>', 'The user to authenticate as [REQUIRED]').option('-p, --password <password>', 'The user\'s password [REQUIRED]').option('-t, --trackname <annotation trackname>', 'Name of the annotation track to which the genes belong [REQUIRED]').option('-s, --samplename <sample name>', 'Name of the sample [REQUIRED]').option('-e, --experimentgroup [experiment group name]', 'Name of the experiment to which the sample belongs').option('-r, --replicagroup [replica group name]', 'Name of the replica group to which the sample belongs').option('-d, --description [sample description]', 'Description of the sample').action(function (file) {
    fileName = path.resolve(file);
  }).parse(process.argv);

  if (commander.username === undefined || commander.password === undefined || commander.trackname === undefined || commander.samplename === undefined || fileName === undefined) {
    commander.help();
  }

  console.log(commander.username, commander.password, fileName, commander.trackname);
  const config = {
    fileName: fileName,
    trackName: commander.trackname,
    sampleName: commander.samplename,
    experimentGroup: commander.experimentgroup ? commander.experimentgroup : commander.samplename,
    replicaGroup: commander.replicagroup ? commander.replicagroup : commander.samplename,
    description: 'description' //commander.description ? commander.description : commander.samplename,

  };
  console.log(config);
  const Connection = asteroid.createClass();
  const portal = new Connection({
    endpoint: 'ws://localhost:3000/websocket',
    SocketConstructor: WebSocket
  });
  portal.loginWithPassword({
    username: commander.username,
    password: commander.password
  }).then(result => {
    return portal.call('addTranscriptome', config);
  }).then(result => {
    console.log(result);
    portal.disconnect(); //process.exit(0)
  }).catch(error => {
    console.log(error);
    portal.disconnect(); //process.exit(1)
  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"list.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// scripts/list.js                                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //

///usr/bin/env node
if (!module.parent) {
  const commander = require('commander');

  const asteroid = require('asteroid');

  const WebSocket = require('ws');

  let what;
  commander.arguments('<what>').option('-u, --username <username>', 'The user to authenticate as [REQUIRED]').option('-p, --password <password>', 'The user\'s password [REQUIRED]').action(function (value) {
    what = value;
  }).parse(process.argv);

  if (commander.username === undefined || commander.password === undefined || what === undefined) {
    commander.help();
  }

  console.log(commander.username, commander.password, what);
  const Connection = asteroid.createClass();
  const portal = new Connection({
    endpoint: 'ws://localhost:3000/websocket',
    SocketConstructor: WebSocket
  });
  portal.loginWithPassword({
    username: commander.username,
    password: commander.password
  });
  portal.call('list', what).then(result => {
    console.log(result);
    portal.disconnect();
  }).catch(error => {
    console.log(error);
    portal.disconnect();
  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"test.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// scripts/test.js                                                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //

///usr/bin/env node
"use strict";

if (!module.parent) {
  const spawn = require('child-process-promise').spawn;

  const repeats = 1000000;
  spawn('tee', [], {
    capture: ['stdout', 'stderr']
  }).progress(childProcess => {
    let stdin = childProcess.stdin;

    for (let i = 0; i < repeats; i++) {
      let string = Math.random().toString(36) + '\n';
      stdin.write(string);
    }

    stdin.end();
  }).then(result => {
    console.log(result.stdout.toString());
  }).catch(error => {
    console.error(error);
  });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/main.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.watch(require("/imports/startup/server"));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});
require("/scripts/add_annotation.js");
require("/scripts/add_interproscan.js");
require("/scripts/add_orthogroup_trees.js");
require("/scripts/add_reference.js");
require("/scripts/add_transcriptome.js");
require("/scripts/list.js");
require("/scripts/test.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYmxhc3QvaGFzYmxhc3RkYi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYmxhc3QvbWFrZWJsYXN0ZGIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2JsYXN0L3JlbW92ZWJsYXN0ZGIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2JsYXN0L3N1Ym1pdGJsYXN0am9iLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9kb3dubG9hZHMvZG93bmxvYWRfY29sbGVjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZ2VuZXMvYWRkX2ludGVycHJvc2Nhbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZ2VuZXMvYWRkX29ydGhvZ3JvdXBfdHJlZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2dlbmVzL2F0dHJpYnV0ZV9jb2xsZWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9nZW5lcy9kb3dubG9hZF9nZW5lcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZ2VuZXMvZWRpdGhpc3RvcnlfY29sbGVjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZ2VuZXMvZ2VuZV9jb2xsZWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9nZW5lcy9pbnRlcnByb19jb2xsZWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9nZW5lcy9pbnRlcnByb3NjYW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2dlbmVzL29ydGhvZ3JvdXBfY29sbGVjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZ2VuZXMvc2Nhbl9hdHRyaWJ1dGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9nZW5vbWVzL2FkZF9nZmYuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2dlbm9tZXMvYWRkX3JlZmVyZW5jZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZ2Vub21lcy9yZWZlcmVuY2VfY29sbGVjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZ2Vub21lcy90cmFja19jb2xsZWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9nZW5vbWVzL3VwZGF0ZVRyYWNrUGVybWlzc2lvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2pvYnF1ZXVlL2pvYnF1ZXVlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9qb2JxdWV1ZS9wcm9jZXNzLWJsYXN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9qb2JxdWV1ZS9wcm9jZXNzLWRvd25sb2FkLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9qb2JxdWV1ZS9wcm9jZXNzLWludGVycHJvc2Nhbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvam9icXVldWUvcHJvY2Vzcy1tYWtlQmxhc3REYi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbWV0aG9kcy9saXN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tZXRob2RzL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3RyYW5zY3JpcHRvbWVzL2FkZF90cmFuc2NyaXB0b21lLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90cmFuc2NyaXB0b21lcy90cmFuc2NyaXB0b21lX2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3RyYW5zY3JpcHRvbWVzL3VwZGF0ZVNhbXBsZUluZm8uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3VzZXJzL3VzZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS91dGlsL3V0aWwuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2FwaS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL3NlcnZlci1maXh0dXJlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci91c2VyYWNjb3VudHMtY29uZmlndXJhdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2NyaXB0cy9hZGRfYW5ub3RhdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2NyaXB0cy9hZGRfaW50ZXJwcm9zY2FuLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zY3JpcHRzL2FkZF9vcnRob2dyb3VwX3RyZWVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zY3JpcHRzL2FkZF9yZWZlcmVuY2UuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NjcmlwdHMvYWRkX3RyYW5zY3JpcHRvbWUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NjcmlwdHMvbGlzdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2NyaXB0cy90ZXN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJoYXNCbGFzdERiIiwiTWV0ZW9yIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIlZhbGlkYXRlZE1ldGhvZCIsIlJvbGVzIiwiU2ltcGxlU2NoZW1hIiwiZGVmYXVsdCIsImV4aXN0c1N5bmMiLCJuYW1lIiwidmFsaWRhdGUiLCJ0cmFja05hbWUiLCJ0eXBlIiwiU3RyaW5nIiwidmFsaWRhdG9yIiwiYXBwbHlPcHRpb25zIiwibm9SZXRyeSIsInJ1biIsInVzZXJJZCIsIkVycm9yIiwidXNlcklzSW5Sb2xlIiwiY2xlYW5lZFRyYWNrTmFtZSIsInJlcGxhY2UiLCJmaWxlbmFtZXMiLCJjb25zb2xlIiwibG9nIiwiaXNTaW11bGF0aW9uIiwiZXZlcnkiLCJtYWtlQmxhc3REYiIsImhhc2giLCJqb2JRdWV1ZSIsIkpvYiIsIkdlbmVzIiwiZGJUeXBlIiwiam9iSWQiLCJ1c2VyIiwicHJpb3JpdHkiLCJzYXZlIiwicmVtb3ZlQmxhc3REYiIsIlRyYWNrcyIsInRyYWNrIiwiZmluZE9uZSIsInVwZGF0ZSIsIiR1bnNldCIsInN1Ym1pdEJsYXN0Sm9iIiwiYmxhc3RUeXBlIiwiaW5wdXQiLCJ0cmFja05hbWVzIiwiQXJyYXkiLCJEb3dubG9hZHMiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJEb3dubG9hZFNjaGVtYSIsInF1ZXJ5IiwiT2JqZWN0IiwiYmxhY2tib3giLCJxdWVyeUhhc2giLCJjb3VudHMiLCJOdW1iZXIiLCJhY2Nlc3NlZCIsIkRhdGUiLCJhZGRJbnRlcnByb3NjYW4iLCJQYXBhIiwiZnMiLCJmb3JtYXRBdHRyaWJ1dGVzIiwiYXR0cmlidXRlU3RyaW5nIiwic3BsaXQiLCJyZWR1Y2UiLCJhdHRyaWJ1dGVzIiwic3RyaW5nUGFydCIsImtleSIsInZhbHVlIiwiam9pbiIsIm1hcCIsImRlY29kZVVSSUNvbXBvbmVudCIsImRlYnVnRm9ybWF0QXR0cmlidXRlcyIsImFyciIsImF0dHIiLCJ2YWx1ZXMiLCJmaWxlTmFtZSIsImxpbmVOdW1iZXIiLCJmaWxlSGFuZGxlIiwicmVhZEZpbGVTeW5jIiwiZW5jb2RpbmciLCJpbnRlcnByb0lkcyIsIlNldCIsInBhcnNlIiwiZGVsaW1pdGVyIiwiZHluYW1pY1R5cGluZyIsInNraXBFbXB0eUxpbmVzIiwiZXJyb3IiLCJmaWxlIiwic3RlcCIsImxpbmUiLCJwYXJzZXIiLCJkYXRhIiwidGVzdCIsImFib3J0Iiwic2VxSWQiLCJzb3VyY2UiLCJzdGFydCIsImVuZCIsInNjb3JlIiwic3RyYW5kIiwicGhhc2UiLCJwcm90ZWluRG9tYWluIiwiZGJ4cmVmIiwiaGFzSW50ZXJwcm8iLCJmb3JFYWNoIiwiY3Jvc3NyZWYiLCJkYiIsImlkIiwiYWRkIiwiJGFkZFRvU2V0IiwiY29tcGxldGUiLCJyZXN1bHRzIiwiYWRkT3J0aG9ncm91cFRyZWVzIiwiZ2xvYiIsIk9ydGhvZ3JvdXBzIiwicGFyc2VOZXdpY2siLCJmb2xkZXIiLCJnZW5lQnVsa09wIiwicmF3Q29sbGVjdGlvbiIsImluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AiLCJvcnRob0J1bGtPcCIsImVyciIsImZpbGVOYW1lcyIsIm9ydGhvZ3JvdXBJZCIsInBvcCIsInRyZWUiLCJpbnNlcnQiLCJJRCIsInNpemUiLCJnZW5lcyIsImdlbmVJZHMiLCJmaW5kIiwiJGluIiwiJHNldCIsIm9ydGhvZ3JvdXAiLCJnZW5lQnVsa09wUmVzdWx0cyIsImV4ZWN1dGUiLCJvcnRob0J1bGtPcFJlc3VsdHMiLCJBdHRyaWJ1dGVzIiwiZG93bmxvYWRHZW5lcyIsImRhdGFUeXBlIiwicXVlcnlTdHJpbmciLCJKU09OIiwic3RyaW5naWZ5IiwiZXhpc3RpbmdKb2IiLCJqb2IiLCJFZGl0SGlzdG9yeSIsIkdlbmVTY2hlbWEiLCJTdWJmZWF0dXJlU2NoZW1hIiwiSW50ZXJ2YWxCYXNlU2NoZW1hIiwidW5pcXVlIiwiaW5kZXgiLCJsYWJlbCIsImFsbG93ZWRWYWx1ZXMiLCJzZXEiLCJjdXN0b20iLCJpc1NldCIsInBhcnNlZFZhbHVlIiwicGFyc2VGbG9hdCIsImlzTmFOIiwiY2hpbGRyZW4iLCJvcHRpb25hbCIsIm9uZU9mIiwicGFyZW50cyIsInByb3RlaW5fZG9tYWlucyIsImV4dGVuZCIsImVkaXRpbmciLCJ2aWV3aW5nIiwiY2hhbmdlZCIsIkJvb2xlYW4iLCJleHByZXNzaW9uIiwic3ViZmVhdHVyZXMiLCJyZWZlcmVuY2UiLCJzZXFpZCIsInBlcm1pc3Npb25zIiwiYXR0YWNoU2NoZW1hIiwiSW50ZXJwcm8iLCJyZXF1ZXN0IiwiRnV0dXJlIiwiZ2V0R2VuZVNlcXVlbmNlcyIsInJldmNvbXAiLCJjb21wIiwicmV2U2VxQXJyYXkiLCJyZXZlcnNlIiwicmV2Q29tcFNlcUFycmF5IiwibnVjIiwicmV2Q29tcFNlcSIsInRyYW5zbGF0ZSIsInRyYW5zIiwiY29kb25BcnJheSIsIm1hdGNoIiwicGVwQXJyYXkiLCJjb2RvbiIsImFtaW5vQWNpZCIsImluZGV4T2YiLCJwZXAiLCJtYWtlRmFzdGEiLCJnZW5lIiwidHJhbnNjcmlwdHMiLCJmaWx0ZXIiLCJzdWJmZWF0dXJlIiwic2VxdWVuY2VzIiwidHJhbnNjcmlwdCIsInRyYW5zY3JpcHRTZXEiLCJ0cmFuc2NyaXB0UGVwIiwiY2RzQXJyYXkiLCJzdWIiLCJzb3J0IiwiYSIsImIiLCJyZWZTdGFydCIsInJlZmVyZW5jZUFycmF5IiwiUmVmZXJlbmNlcyIsImhlYWRlciIsIiRhbmQiLCIkbHRlIiwiJGd0ZSIsImZldGNoIiwibGVuZ3RoIiwicmVmIiwiTWF0aCIsIm1pbiIsImNkcyIsInNsaWNlIiwidG9VcHBlckNhc2UiLCJzdWJtaXRJbnRlcnBybyIsInNlcXVlbmNlSWQiLCJwZXB0aWRlIiwic3VibWl0Sm9iIiwicG9zdCIsInVybCIsImZvcm0iLCJlbWFpbCIsInRpdGxlIiwic2VxdWVuY2UiLCJyZXNwb25zZSIsInN0YXR1c0NvZGUiLCJyZXR1cm4iLCJ3YWl0IiwicG9sbEludGVycHJvIiwiY2IiLCJzdGF0dXNSZXF1ZXN0IiwiZ2V0IiwiYm9keSIsInN0YXR1cyIsInNldFRpbWVvdXQiLCJnZXRJbnRlcnByb1Jlc3VsdHMiLCJmdXR1cmUiLCJpbnRlcnByb0Fubm90YXRpb24iLCJtZXRob2RzIiwiaW50ZXJwcm9zY2FuIiwiZ2VuZUlkIiwiZnV0IiwiZmluaXNoZWQiLCJtYXRjaGVzIiwic2NhbkdlbmVBdHRyaWJ1dGVzIiwibWFwRnVuY3Rpb24iLCJwcmludGpzb24iLCJlbWl0IiwiYXR0cmlidXRlS2V5cyIsImtleXMiLCJyZWR1Y2VGdW5jdGlvbiIsIl9rZXkiLCJhdHRyaWJ1dGVLZXlTZXQiLCJhdHRyaWJ1dGVLZXkiLCJmcm9tIiwidW5ibG9jayIsIm1hcFJlZHVjZU9wdGlvbnMiLCJvdXQiLCJpbmxpbmUiLCJhdHRyaWJ1dGVTY2FuIiwibWFwUmVkdWNlIiwidGhlbiIsInJlc3VsdCIsImZpbmRBbmRNb2RpZnkiLCJ0cmFja3MiLCJyZWZlcmVuY2VzIiwiJHNldE9uSW5zZXJ0Iiwic2hvdyIsImNhbkVkaXQiLCJyZXNlcnZlZCIsIm5ldyIsInVwc2VydCIsImNhdGNoIiwiYWRkR2ZmIiwiYXNzZXJ0IiwiQmFieSIsImZpbmRJbmRleCIsImlzRXF1YWwiLCJpc0VtcHR5IiwibWFwVmFsdWVzIiwicXVlcnlzdHJpbmciLCJSZWZlcmVuY2VJbmZvIiwidW5lc2NhcGUiLCJ1cmkiLCJJbnRlcnZhbCIsImNvbnN0cnVjdG9yIiwicmVmZXJlbmNlTmFtZSIsInJlZmVyZW5jZVNlcXVlbmNlcyIsImVxdWFsIiwiUGFyZW50IiwidW5kZWZpbmVkIiwiR2VuZU1vZGVsIiwiaW50ZXJ2YWxzIiwiaW50ZXJ2YWwiLCJwYXJlbnRJZCIsInBhcmVudCIsInB1c2giLCJleGlzdGluZ1RyYWNrIiwiZXhpc3RpbmdSZWZlcmVuY2UiLCJnZW5lQ291bnQiLCJnZXRSZWZlcmVuY2VTZXF1ZW5jZXMiLCJjb21tZW50cyIsImNhbGwiLCJoZWFkZXJzIiwiZmllbGRzIiwiYWRkUmVmZXJlbmNlIiwicmVhZGxpbmUiLCJGaWJlciIsInBhcmFtZXRlclNjaGVtYSIsImxpbmVSZWFkZXIiLCJjcmVhdGVJbnRlcmZhY2UiLCJjcmVhdGVSZWFkU3RyZWFtIiwiYnVsa09wIiwiY2h1bmtTaXplIiwib24iLCJzdWJzdHJpbmciLCJkZXNjcmlwdGlvbiIsIm9yZ2FuaXNtIiwiUmVmZXJlbmNlU2NoZW1hIiwiUmVmZXJlbmNlSW5mb1NjaGVtYSIsInRyYWNrU2NoZW1hIiwiYmxhc3RkYnMiLCJ1cGRhdGVUcmFja1Blcm1pc3Npb25zIiwiSm9iQ29sbGVjdGlvbiIsIm5vQ29sbGVjdGlvblN1ZmZpeCIsInJlcGVhdCIsInNjaGVkdWxlIiwibGF0ZXIiLCJ0ZXh0IiwiY2FuY2VsUmVwZWF0cyIsImNsZWFudXAiLCJwcm9jZXNzSm9icyIsInBvbGxJbnRlcnZhbCIsIndvcmtUaW1lb3V0IiwiY2FsbGJhY2siLCJjdXJyZW50Iiwic2V0TWludXRlcyIsImdldE1pbnV0ZXMiLCJpZHMiLCJqb2JTdGF0dXNSZW1vdmFibGUiLCJ1cGRhdGVkIiwiJGx0IiwiX2lkIiwicmVtb3ZlSm9icyIsImRvbmUiLCJvYnNlcnZlIiwiYWRkZWQiLCJ0cmlnZ2VyIiwiZXhwb3J0RGVmYXVsdCIsInNwYXduIiwieG1sMmpzIiwiREJfVFlQRVMiLCJjb25jdXJyZW5jeSIsInBheWxvYWQiLCJkYnMiLCJvcHRpb25zIiwidG9TdHJpbmciLCJyZXN1bHRKc29uIiwiZmFpbCIsInByb2Nlc3MiLCJ6bGliIiwiREFUQVRZUEVfRVhURU5TSU9OUyIsInF1ZXVlIiwiZXh0ZW5zaW9uIiwid3JpdGVTdHJlYW0iLCJjcmVhdGVXcml0ZVN0cmVhbSIsImNvbXByZXNzIiwiY3JlYXRlR3ppcCIsInBpcGUiLCJ3cml0ZSIsInRyYWNrSWQiLCJnZW5lTnVtYmVyIiwiY291bnQiLCJzdGVwU2l6ZSIsInJvdW5kIiwiZmFzdGEiLCJwcm9ncmVzcyIsImVjaG8iLCJ0cmFuc2NyaXB0RmFzdGEiLCJvdXRGaWxlIiwiZGJGaWxlIiwic3Rkb3V0IiwibGlzdCIsIndoYXQiLCJyZXR2YWwiLCJyZXQiLCJyZXZlcnNlQ29tcGxlbWVudCIsImZvcm1hdEZhc3RhIiwic2VxdWVuY2VUeXBlIiwid3JhcHBlZFNlcXVlbmNlIiwicXVlcnlDb3VudCIsInNlYXJjaCIsIiRvciIsIiRyZWdleCIsIiRvcHRpb25zIiwiaGFzT3duUHJvcGVydHkiLCJyZW1vdmVGcm9tVmlld2luZyIsIiRwdWxsIiwicmVzIiwibG9ja0dlbmUiLCJ1bmxvY2tHZW5lIiwidXBkYXRlRXhwZXJpbWVudHMiLCJFeHBlcmltZW50cyIsInVwZGF0ZVVzZXJzIiwidXNlcnMiLCJ1cGRhdGVHZW5lSW5mbyIsInJldmVydCIsIm5ld0F0dHJpYnV0ZXMiLCJzdGFydHNXaXRoIiwicmV2ZXJ0U3RyaW5nIiwiZGF0ZSIsIm5ld0F0dHJpYnV0ZSIsIiRwdXNoIiwidXBkYXRlQXR0cmlidXRlcyIsImZvcm1hdEdmZjMiLCJ0b3RhbCIsImNvdW50ZXIiLCJnZmYiLCJzdWJMaW5lcyIsInN1YkZpZWxkcyIsImdlbmVGaWVsZHMiLCJnZW5lTGluZSIsInVuc2hpZnQiLCJpbml0aWFsaXplRG93bmxvYWQiLCJmb3JtYXQiLCJleGlzdGluZyIsImRvd25sb2FkSWQiLCJFeHBlcmltZW50SW5mbyIsIlRyYW5zY3JpcHRvbWVzIiwiYWRkVHJhbnNjcmlwdG9tZSIsImNvbmZpZyIsIm1pc3NpbmdHZW5lcyIsInRhcmdldF9pZCIsImV4cGVyaW1lbnRJZCIsInNhbXBsZU5hbWUiLCJleHBlcmltZW50R3JvdXAiLCJyZXBsaWNhR3JvdXAiLCJyYXdfY291bnRzIiwiZXN0X2NvdW50cyIsInRwbSIsIkV4cGVyaW1lbnRJbmZvU2NoZW1hIiwiVHJhbnNjcmlwdG9tZVNjaGVtYSIsInVwZGF0ZVNhbXBsZUluZm8iLCJ1cGRhdGVVc2VySW5mbyIsImdldE11bHRpcGxlR2VuZVNlcXVlbmNlcyIsInNlcWlkcyIsInVuaXF1ZVNlcWlkcyIsInJlZlNlcXMiLCJvYmoiLCJpIiwicmF3U2VxIiwiZm9yd2FyZCIsImlzUGhhc2VkIiwiY29kaW5nU2VxIiwiY29kaW5nUGVwIiwibmV3aWNrU3RyaW5nIiwiYW5jZXN0b3JzIiwidG9rZW5zIiwic3VidHJlZSIsInRva2VuIiwidG9rZW5JbmRleCIsImJyYW5jaHNldCIsInByZXZpb3VzVG9rZW4iLCJicmFuY2hMZW5ndGgiLCJwdWJsaXNoQ29tcG9zaXRlIiwicHVibGlzaCIsImxpbWl0IiwicHVibGljYXRpb24iLCJzdG9wIiwicm9sZXMiLCJnZXRSb2xlc0ZvclVzZXIiLCJhbGxSZWZlcmVuY2VzIiwidXNlcm5hbWUiLCJyZWFkeSIsInNpbmdsZUdlbmUiLCJnZW5lRXhwcmVzc2lvbiIsImV4cGVyaW1lbnRJbmZvIiwiZG93bmxvYWRzIiwicGVybWlzc2lvbiIsInJlZmVyZW5jZUluZm8iLCJvcnRob2dyb3VwcyIsImludGVycHJvIiwiZWRpdEhpc3RvcnkiLCJzdGFydHVwIiwiYWRtaW5JZCIsIkFjY291bnRzIiwiY3JlYXRlVXNlciIsInBhc3N3b3JkIiwicHJvZmlsZSIsImZpcnN0X25hbWUiLCJsYXN0X25hbWUiLCJhZGRVc2Vyc1RvUm9sZXMiLCJndWVzdElkIiwicGVybWFuZW50QXR0cmlidXRlcyIsImF0dHJpYnV0ZSIsIiRleGlzdHMiLCJoYXNOdWNEYiIsImhhc1Byb3REYiIsInByb3QiLCJhbGxvdyIsImFkbWluIiwibWV0aG9kIiwicGFyYW1zIiwic3RhcnRKb2JTZXJ2ZXIiLCJvbkNyZWF0ZVVzZXIiLCJvbkxvZ291dCIsIiRzaXplIiwiZG9jIiwibW9kaWZpZXIiLCJjb21tYW5kZXIiLCJhcmd1bWVudHMiLCJwYXRoIiwicmVzb2x2ZSIsImFyZ3YiLCJoZWxwIiwiQ29ubmVjdGlvbiIsImFzdGVyb2lkIiwicG9ydGFsIiwiZW5kcG9pbnQiLCJTb2NrZXRDb25zdHJ1Y3RvciIsIldlYlNvY2tldCIsImRpc2Nvbm5lY3QiLCJ0cmFja25hbWUiLCJleGl0Iiwic2FtcGxlbmFtZSIsImV4cGVyaW1lbnRncm91cCIsInJlcGxpY2Fncm91cCIsImNyZWF0ZUNsYXNzIiwiY2FwdHVyZSIsImNoaWxkUHJvY2VzcyIsInN0ZGluIiwic3RyaW5nIiwicmFuZG9tIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxPQUFPQyxNQUFQLENBQWM7QUFBQ0MsY0FBVyxNQUFJQTtBQUFoQixDQUFkO0FBQTJDLElBQUlDLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxlQUFKO0FBQW9CUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDRSxrQkFBZ0JELENBQWhCLEVBQWtCO0FBQUNDLHNCQUFnQkQsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXBELEVBQTRGLENBQTVGO0FBQStGLElBQUlFLEtBQUo7QUFBVVIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0csUUFBTUYsQ0FBTixFQUFRO0FBQUNFLFlBQU1GLENBQU47QUFBUTs7QUFBbEIsQ0FBOUMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSUcsWUFBSjtBQUFpQlQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQ0csbUJBQWFILENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSUssVUFBSjtBQUFlWCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsSUFBUixDQUFiLEVBQTJCO0FBQUNNLGFBQVdMLENBQVgsRUFBYTtBQUFDSyxpQkFBV0wsQ0FBWDtBQUFhOztBQUE1QixDQUEzQixFQUF5RCxDQUF6RDtBQVlyWixNQUFNSixhQUFhLElBQUlLLGVBQUosQ0FBb0I7QUFDNUNLLFFBQU0sWUFEc0M7QUFFNUNDLFlBQVUsSUFBSUosWUFBSixDQUFpQjtBQUN6QkssZUFBVztBQUFFQyxZQUFNQztBQUFSO0FBRGMsR0FBakIsRUFFUEMsU0FGTyxFQUZrQztBQUs1Q0MsZ0JBQWM7QUFDWkMsYUFBUztBQURHLEdBTDhCOztBQVE1Q0MsTUFBSTtBQUFFTjtBQUFGLEdBQUosRUFBaUI7QUFDZixRQUFJLENBQUUsS0FBS08sTUFBWCxFQUFtQjtBQUNqQixZQUFNLElBQUlsQixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNEOztBQUNELFFBQUksQ0FBRWQsTUFBTWUsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUErQixTQUEvQixDQUFOLEVBQWdEO0FBQzlDLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0Q7O0FBRUQsVUFBTUUsbUJBQW1CVixVQUFVVyxPQUFWLENBQWtCLE9BQWxCLEVBQTBCLEdBQTFCLENBQXpCO0FBRUEsVUFBTUMsWUFBWSxDQUNmLEdBQUVGLGdCQUFpQixXQURKLEVBRWYsR0FBRUEsZ0JBQWlCLFdBRkosQ0FBbEI7QUFLQUcsWUFBUUMsR0FBUixDQUFZRixTQUFaOztBQUVBLFFBQUksQ0FBQyxLQUFLRyxZQUFWLEVBQXVCO0FBQ3JCRixjQUFRQyxHQUFSLENBQVlGLFNBQVo7QUFDQUMsY0FBUUMsR0FBUixDQUFZRixVQUFVSSxLQUFWLENBQWdCbkIsVUFBaEIsQ0FBWjtBQUNBLGFBQU9lLFVBQVVJLEtBQVYsQ0FBZ0JuQixVQUFoQixDQUFQO0FBQ0Q7QUFDRjs7QUE5QjJDLENBQXBCLENBQW5CLEM7Ozs7Ozs7Ozs7O0FDWlBYLE9BQU9DLE1BQVAsQ0FBYztBQUFDOEIsZUFBWSxNQUFJQTtBQUFqQixDQUFkO0FBQTZDLElBQUk1QixNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsZUFBSjtBQUFvQlAsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ0Usa0JBQWdCRCxDQUFoQixFQUFrQjtBQUFDQyxzQkFBZ0JELENBQWhCO0FBQWtCOztBQUF0QyxDQUFwRCxFQUE0RixDQUE1RjtBQUErRixJQUFJRSxLQUFKO0FBQVVSLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNHLFFBQU1GLENBQU4sRUFBUTtBQUFDRSxZQUFNRixDQUFOO0FBQVE7O0FBQWxCLENBQTlDLEVBQWtFLENBQWxFO0FBQXFFLElBQUlHLFlBQUo7QUFBaUJULE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUNHLG1CQUFhSCxDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBQXFFLElBQUkwQixJQUFKO0FBQVNoQyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDMEIsV0FBSzFCLENBQUw7QUFBTzs7QUFBbkIsQ0FBcEMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSTJCLFFBQUo7QUFBYWpDLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxtQ0FBUixDQUFiLEVBQTBEO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDMkIsZUFBUzNCLENBQVQ7QUFBVzs7QUFBdkIsQ0FBMUQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSTRCLEdBQUo7QUFBUWxDLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSw4QkFBUixDQUFiLEVBQXFEO0FBQUM2QixNQUFJNUIsQ0FBSixFQUFNO0FBQUM0QixVQUFJNUIsQ0FBSjtBQUFNOztBQUFkLENBQXJELEVBQXFFLENBQXJFO0FBQXdFLElBQUk2QixLQUFKO0FBQVVuQyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsdUNBQVIsQ0FBYixFQUE4RDtBQUFDOEIsUUFBTTdCLENBQU4sRUFBUTtBQUFDNkIsWUFBTTdCLENBQU47QUFBUTs7QUFBbEIsQ0FBOUQsRUFBa0YsQ0FBbEY7QUFrQjFvQixNQUFNeUIsY0FBYyxJQUFJeEIsZUFBSixDQUFvQjtBQUM3Q0ssUUFBTSxhQUR1QztBQUU3Q0MsWUFBVSxJQUFJSixZQUFKLENBQWlCO0FBQ3pCSyxlQUFXO0FBQUVDLFlBQU1DO0FBQVIsS0FEYztBQUV6Qm9CLFlBQVE7QUFBRXJCLFlBQU1DO0FBQVI7QUFGaUIsR0FBakIsRUFHUEMsU0FITyxFQUZtQztBQU03Q0MsZ0JBQWM7QUFDWkMsYUFBUztBQURHLEdBTitCOztBQVM3Q0MsTUFBSTtBQUFFTixhQUFGO0FBQWFzQjtBQUFiLEdBQUosRUFBMEI7QUFDeEIsUUFBSSxDQUFFLEtBQUtmLE1BQVgsRUFBbUI7QUFDakIsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDRDs7QUFDRCxRQUFJLENBQUVkLE1BQU1lLFlBQU4sQ0FBbUIsS0FBS0YsTUFBeEIsRUFBK0IsU0FBL0IsQ0FBTixFQUFnRDtBQUM5QyxZQUFNLElBQUlsQixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNEOztBQUVELFFBQUksQ0FBQyxLQUFLTyxZQUFWLEVBQXVCO0FBQ3JCLFlBQU1RLFFBQVEsSUFBSUgsR0FBSixDQUFRRCxRQUFSLEVBQWtCLGFBQWxCLEVBQWlDO0FBQzdDbkIsbUJBQVdBLFNBRGtDO0FBRTdDc0IsZ0JBQVFBLE1BRnFDO0FBRzdDRSxjQUFNbkMsT0FBT2tCLE1BQVA7QUFIdUMsT0FBakMsRUFJWGtCLFFBSlcsQ0FJRixRQUpFLEVBSVFDLElBSlIsRUFBZDtBQU1BLGFBQU9ILEtBQVA7QUFDRDtBQUNGOztBQTFCNEMsQ0FBcEIsQ0FBcEIsQzs7Ozs7Ozs7Ozs7QUNsQlByQyxPQUFPQyxNQUFQLENBQWM7QUFBQ3dDLGlCQUFjLE1BQUlBO0FBQW5CLENBQWQ7QUFBaUQsSUFBSXRDLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxlQUFKO0FBQW9CUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDRSxrQkFBZ0JELENBQWhCLEVBQWtCO0FBQUNDLHNCQUFnQkQsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXBELEVBQTRGLENBQTVGO0FBQStGLElBQUlFLEtBQUo7QUFBVVIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0csUUFBTUYsQ0FBTixFQUFRO0FBQUNFLFlBQU1GLENBQU47QUFBUTs7QUFBbEIsQ0FBOUMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSUcsWUFBSjtBQUFpQlQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQ0csbUJBQWFILENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSW9DLE1BQUo7QUFBVzFDLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSwwQ0FBUixDQUFiLEVBQWlFO0FBQUNxQyxTQUFPcEMsQ0FBUCxFQUFTO0FBQUNvQyxhQUFPcEMsQ0FBUDtBQUFTOztBQUFwQixDQUFqRSxFQUF1RixDQUF2RjtBQWF2WixNQUFNbUMsZ0JBQWdCLElBQUlsQyxlQUFKLENBQW9CO0FBQy9DSyxRQUFNLGVBRHlDO0FBRS9DQyxZQUFVLElBQUlKLFlBQUosQ0FBaUI7QUFDekJLLGVBQVc7QUFBRUMsWUFBTUM7QUFBUjtBQURjLEdBQWpCLEVBRVBDLFNBRk8sRUFGcUM7QUFLL0NDLGdCQUFjO0FBQ1pDLGFBQVM7QUFERyxHQUxpQzs7QUFRL0NDLE1BQUk7QUFBRU47QUFBRixHQUFKLEVBQWlCO0FBQ2YsUUFBSSxDQUFFLEtBQUtPLE1BQVgsRUFBbUI7QUFDakIsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDRDs7QUFDRCxRQUFJLENBQUVkLE1BQU1lLFlBQU4sQ0FBbUIsS0FBS0YsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTixFQUE4QztBQUM1QyxZQUFNLElBQUlsQixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNEOztBQUVESyxZQUFRQyxHQUFSLENBQWEsVUFBU2QsU0FBVSxFQUFoQzs7QUFFQSxRQUFJLENBQUMsS0FBS2UsWUFBVixFQUF1QjtBQUNyQixZQUFNYyxRQUFRRCxPQUFPRSxPQUFQLENBQWU7QUFBQzlCLG1CQUFXQTtBQUFaLE9BQWYsQ0FBZDtBQUNBYSxjQUFRQyxHQUFSLENBQVllLEtBQVo7QUFDQUQsYUFBT0csTUFBUCxDQUFjO0FBQ1ovQixtQkFBV0E7QUFEQyxPQUFkLEVBRUU7QUFDQWdDLGdCQUFRO0FBQ04sc0JBQVk7QUFETjtBQURSLE9BRkY7QUFPRDtBQUNGOztBQTdCOEMsQ0FBcEIsQ0FBdEIsQzs7Ozs7Ozs7Ozs7QUNiUDlDLE9BQU9DLE1BQVAsQ0FBYztBQUFDOEMsa0JBQWUsTUFBSUE7QUFBcEIsQ0FBZDtBQUFtRCxJQUFJNUMsTUFBSjtBQUFXSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFNBQU9HLENBQVAsRUFBUztBQUFDSCxhQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlDLGVBQUo7QUFBb0JQLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNFLGtCQUFnQkQsQ0FBaEIsRUFBa0I7QUFBQ0Msc0JBQWdCRCxDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBcEQsRUFBNEYsQ0FBNUY7QUFBK0YsSUFBSUUsS0FBSjtBQUFVUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDRyxRQUFNRixDQUFOLEVBQVE7QUFBQ0UsWUFBTUYsQ0FBTjtBQUFROztBQUFsQixDQUE5QyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJRyxZQUFKO0FBQWlCVCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDRyxtQkFBYUgsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJMkIsUUFBSjtBQUFhakMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLG1DQUFSLENBQWIsRUFBMEQ7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUMyQixlQUFTM0IsQ0FBVDtBQUFXOztBQUF2QixDQUExRCxFQUFtRixDQUFuRjtBQUFzRixJQUFJNEIsR0FBSjtBQUFRbEMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDhCQUFSLENBQWIsRUFBcUQ7QUFBQzZCLE1BQUk1QixDQUFKLEVBQU07QUFBQzRCLFVBQUk1QixDQUFKO0FBQU07O0FBQWQsQ0FBckQsRUFBcUUsQ0FBckU7QUFlemYsTUFBTXlDLGlCQUFpQixJQUFJeEMsZUFBSixDQUFvQjtBQUNoREssUUFBTSxnQkFEMEM7QUFFaERDLFlBQVUsSUFBSUosWUFBSixDQUFpQjtBQUN6QnVDLGVBQVc7QUFBRWpDLFlBQU1DO0FBQVIsS0FEYztBQUV6QmlDLFdBQU87QUFBRWxDLFlBQU1DO0FBQVIsS0FGa0I7QUFHekJrQyxnQkFBWTtBQUFFbkMsWUFBTW9DO0FBQVIsS0FIYTtBQUl6QixvQkFBZ0I7QUFBRXBDLFlBQU1DO0FBQVI7QUFKUyxHQUFqQixFQUtQQyxTQUxPLEVBRnNDO0FBUWhEQyxnQkFBYztBQUNaQyxhQUFTO0FBREcsR0FSa0M7O0FBV2hEQyxNQUFJO0FBQUU0QixhQUFGO0FBQWFDLFNBQWI7QUFBb0JDO0FBQXBCLEdBQUosRUFBcUM7QUFDbkMsUUFBSSxDQUFFLEtBQUs3QixNQUFYLEVBQW1CO0FBQ2pCLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0Q7O0FBQ0QsUUFBSSxDQUFFZCxNQUFNZSxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQStCLE1BQS9CLENBQU4sRUFBNkM7QUFDM0MsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDRDs7QUFFREssWUFBUUMsR0FBUixDQUFZLGtCQUFaO0FBRUEsVUFBTVMsUUFBUSxJQUFJSCxHQUFKLENBQVFELFFBQVIsRUFBa0IsT0FBbEIsRUFBMkI7QUFDdkNlLGlCQUFXQSxTQUQ0QjtBQUV2Q0MsYUFBT0EsS0FGZ0M7QUFHdkNDLGtCQUFZQSxVQUgyQjtBQUl2Q1osWUFBTW5DLE9BQU9rQixNQUFQO0FBSmlDLEtBQTNCLEVBS1hrQixRQUxXLENBS0YsUUFMRSxFQUtRQyxJQUxSLEVBQWQ7QUFPQWIsWUFBUUMsR0FBUixDQUFZUyxLQUFaO0FBRUEsV0FBT0EsS0FBUDtBQUVEOztBQWhDK0MsQ0FBcEIsQ0FBdkIsQzs7Ozs7Ozs7Ozs7QUNmUHJDLE9BQU9DLE1BQVAsQ0FBYztBQUFDbUQsYUFBVSxNQUFJQTtBQUFmLENBQWQ7QUFBeUMsSUFBSUMsS0FBSjtBQUFVckQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDZ0QsUUFBTS9DLENBQU4sRUFBUTtBQUFDK0MsWUFBTS9DLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUcsWUFBSjtBQUFpQlQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQ0csbUJBQWFILENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFHaEk7QUFFQSxNQUFNOEMsWUFBWSxJQUFJQyxNQUFNQyxVQUFWLENBQXFCLFdBQXJCLENBQWxCO0FBRUEsTUFBTUMsaUJBQWlCLElBQUk5QyxZQUFKLENBQWlCO0FBQ3RDK0MsU0FBTztBQUNMekMsVUFBTTBDLE1BREQ7QUFFTEMsY0FBVTtBQUZMLEdBRCtCO0FBS3RDQyxhQUFXO0FBQ1Q1QyxVQUFNQztBQURHLEdBTDJCO0FBUXRDNEMsVUFBUTtBQUNON0MsVUFBTThDO0FBREEsR0FSOEI7QUFXdENDLFlBQVU7QUFDUi9DLFVBQU1nRDtBQURFO0FBWDRCLENBQWpCLENBQXZCLEM7Ozs7Ozs7Ozs7O0FDUEEvRCxPQUFPQyxNQUFQLENBQWM7QUFBQytELG1CQUFnQixNQUFJQTtBQUFyQixDQUFkO0FBQXFELElBQUk3RCxNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsZUFBSjtBQUFvQlAsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ0Usa0JBQWdCRCxDQUFoQixFQUFrQjtBQUFDQyxzQkFBZ0JELENBQWhCO0FBQWtCOztBQUF0QyxDQUFwRCxFQUE0RixDQUE1RjtBQUErRixJQUFJRyxZQUFKO0FBQWlCVCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDRyxtQkFBYUgsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJMkQsSUFBSjtBQUFTakUsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLFdBQVIsQ0FBYixFQUFrQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQzJELFdBQUszRCxDQUFMO0FBQU87O0FBQW5CLENBQWxDLEVBQXVELENBQXZEO0FBQTBELElBQUk2QixLQUFKO0FBQVVuQyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsdUNBQVIsQ0FBYixFQUE4RDtBQUFDOEIsUUFBTTdCLENBQU4sRUFBUTtBQUFDNkIsWUFBTTdCLENBQU47QUFBUTs7QUFBbEIsQ0FBOUQsRUFBa0YsQ0FBbEY7QUFBcUYsSUFBSTRELEVBQUo7QUFBT2xFLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxJQUFSLENBQWIsRUFBMkI7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUM0RCxTQUFHNUQsQ0FBSDtBQUFLOztBQUFqQixDQUEzQixFQUE4QyxDQUE5Qzs7QUFTamY7Ozs7O0FBS0EsTUFBTTZELG1CQUFtQkMsbUJBQW1CO0FBQzFDLFNBQU9BLGdCQUFnQkMsS0FBaEIsQ0FBc0IsR0FBdEIsRUFBMkJDLE1BQTNCLENBQWtDLENBQUNDLFVBQUQsRUFBYUMsVUFBYixLQUE0QjtBQUNuRSxVQUFNLENBQUNDLEdBQUQsRUFBTUMsS0FBTixJQUFlRixXQUFXSCxLQUFYLENBQWlCLEdBQWpCLENBQXJCOztBQUNBLFFBQUksT0FBT0ksR0FBUCxLQUFlLFdBQWYsSUFBOEIsT0FBT0MsS0FBUCxLQUFpQixXQUFuRCxFQUErRDtBQUM3REgsaUJBQVdFLEdBQVgsSUFBa0JDLE1BQU1MLEtBQU4sQ0FBWSxHQUFaLEVBQWlCTSxJQUFqQixDQUFzQixFQUF0QixFQUEwQk4sS0FBMUIsQ0FBZ0MsR0FBaEMsRUFBcUNPLEdBQXJDLENBQXlDQyxrQkFBekMsQ0FBbEI7QUFDRDs7QUFDRCxXQUFPTixVQUFQO0FBQ0QsR0FOTSxFQU1KLEVBTkksQ0FBUDtBQU9ELENBUkQ7O0FBVUEsTUFBTU8sd0JBQXdCVixtQkFBbUI7QUFDL0NXLFFBQU1YLGdCQUFnQkMsS0FBaEIsQ0FBc0IsR0FBdEIsQ0FBTjtBQUNBMUMsVUFBUUMsR0FBUixDQUFZbUQsR0FBWjtBQUNBLFFBQU1SLGFBQWFRLElBQUlULE1BQUosQ0FBVyxDQUFDVSxJQUFELEVBQU9SLFVBQVAsS0FBc0I7QUFDbEQsVUFBTSxDQUFDQyxHQUFELEVBQU1DLEtBQU4sSUFBZUYsV0FBV0gsS0FBWCxDQUFpQixHQUFqQixDQUFyQjtBQUNBMUMsWUFBUUMsR0FBUixDQUFZNkMsR0FBWixFQUFnQkMsS0FBaEI7QUFDQSxVQUFNTyxTQUFTUCxNQUFNTCxLQUFOLENBQVksR0FBWixFQUFpQk0sSUFBakIsQ0FBc0IsRUFBdEIsRUFBMEJOLEtBQTFCLENBQWdDLEdBQWhDLEVBQXFDTyxHQUFyQyxDQUF5Q0Msa0JBQXpDLENBQWY7QUFDQWxELFlBQVFDLEdBQVIsQ0FBWXFELE1BQVo7QUFDQUQsU0FBS1AsR0FBTCxJQUFZUSxNQUFaO0FBQ0EsV0FBT0QsSUFBUDtBQUNELEdBUGtCLEVBT2hCLEVBUGdCLENBQW5CO0FBUUFyRCxVQUFRQyxHQUFSLENBQVkyQyxVQUFaO0FBQ0EsU0FBT0EsVUFBUDtBQUNELENBYkQ7O0FBZU8sTUFBTVAsa0JBQWtCLElBQUl6RCxlQUFKLENBQW9CO0FBQ2pESyxRQUFNLGlCQUQyQztBQUVqREMsWUFBVSxJQUFJSixZQUFKLENBQWlCO0FBQ3pCeUUsY0FBVTtBQUFFbkUsWUFBTUM7QUFBUixLQURlO0FBRXpCRixlQUFXO0FBQUVDLFlBQU1DO0FBQVI7QUFGYyxHQUFqQixFQUdQQyxTQUhPLEVBRnVDO0FBTWpEQyxnQkFBYztBQUNaQyxhQUFTO0FBREcsR0FObUM7O0FBU2pEQyxNQUFJO0FBQUU4RCxZQUFGO0FBQVlwRTtBQUFaLEdBQUosRUFBNEI7QUFDMUJhLFlBQVFDLEdBQVIsQ0FBWSxpQkFBWixFQUErQmQsU0FBL0IsRUFBMENvRSxRQUExQztBQUVBLFFBQUlDLGFBQWEsQ0FBakI7QUFFQSxVQUFNQyxhQUFhbEIsR0FBR21CLFlBQUgsQ0FBZ0JILFFBQWhCLEVBQTBCO0FBQUVJLGdCQUFTO0FBQVgsS0FBMUIsQ0FBbkI7QUFFQSxVQUFNQyxjQUFjLElBQUlDLEdBQUosRUFBcEI7QUFFQXZCLFNBQUt3QixLQUFMLENBQVdMLFVBQVgsRUFBdUI7QUFDckJNLGlCQUFXLElBRFU7QUFFckJDLHFCQUFlLElBRk07QUFHckJDLHNCQUFnQixJQUhLOztBQUlyQjtBQUNBQyxZQUFNQSxLQUFOLEVBQVlDLElBQVosRUFBa0I7QUFDaEJuRSxnQkFBUUMsR0FBUixDQUFZaUUsS0FBWjtBQUNELE9BUG9COztBQVFyQkUsV0FBS0MsSUFBTCxFQUFXQyxNQUFYLEVBQWtCO0FBQ2hCZCxzQkFBYyxDQUFkOztBQUNBLFlBQUlBLGFBQWEsR0FBYixLQUFxQixDQUF6QixFQUEyQjtBQUN6QnhELGtCQUFRQyxHQUFSLENBQWEsYUFBWXVELFVBQVcsUUFBcEM7QUFDRDs7QUFDRCxjQUFNZSxPQUFPRixLQUFLRSxJQUFMLENBQVUsQ0FBVixDQUFiOztBQUNBLFlBQUlBLEtBQUssQ0FBTCxFQUFRLENBQVIsTUFBZSxHQUFuQixFQUF1QjtBQUNyQixjQUFJLFNBQVNDLElBQVQsQ0FBY0QsS0FBSyxDQUFMLENBQWQsQ0FBSixFQUEyQjtBQUN6QnZFLG9CQUFRQyxHQUFSLENBQVksNENBQVo7QUFDQXFFLG1CQUFPRyxLQUFQO0FBQ0Q7QUFDRixTQUxELE1BS087QUFDTCxnQkFBTSxDQUNKQyxLQURJLEVBRUpDLE1BRkksRUFHSnZGLElBSEksRUFJSndGLEtBSkksRUFLSkMsR0FMSSxFQU1KQyxLQU5JLEVBT0pDLE1BUEksRUFRSkMsS0FSSSxFQVNKdkMsZUFUSSxJQVVGOEIsSUFWSjs7QUFZQSxjQUFJbkYsU0FBUyxlQUFiLEVBQTZCO0FBQzNCLGdCQUFJLE9BQU9xRCxlQUFQLEtBQTJCLFdBQS9CLEVBQTJDO0FBQ3pDLGtCQUFJRyxVQUFKOztBQUNBLGtCQUFJO0FBQ0ZBLDZCQUFhSixpQkFBaUJDLGVBQWpCLENBQWI7QUFDRCxlQUZELENBRUUsT0FBTXlCLEtBQU4sRUFBYTtBQUNibEUsd0JBQVFDLEdBQVIsQ0FBYSxjQUFhdUQsVUFBVyxFQUFyQztBQUNBeEQsd0JBQVFDLEdBQVIsQ0FBWXNFLEtBQUt2QixJQUFMLENBQVUsSUFBVixDQUFaO0FBQ0FoRCx3QkFBUUMsR0FBUixDQUFZd0MsZUFBWjtBQUNBekMsd0JBQVFDLEdBQVIsQ0FBWWtELHNCQUFzQlYsZUFBdEIsQ0FBWjtBQUNBLHNCQUFNeUIsS0FBTjtBQUNEOztBQUVELG9CQUFNakYsT0FBTzJELFdBQVcsTUFBWCxFQUFtQixDQUFuQixDQUFiO0FBQ0Esb0JBQU1xQyxnQkFBZ0I7QUFDcEJMLHFCQURvQjtBQUVwQkMsbUJBRm9CO0FBR3BCRixzQkFIb0I7QUFJcEJHLHFCQUpvQjtBQUtwQjdGO0FBTG9CLGVBQXRCO0FBT0Esb0JBQU1pRyxTQUFTdEMsV0FBVyxRQUFYLENBQWY7O0FBQ0Esa0JBQUksT0FBT3NDLE1BQVAsS0FBa0IsV0FBdEIsRUFBa0M7QUFDaENELDhCQUFjLFFBQWQsSUFBMEJDLE1BQTFCO0FBQ0Esb0JBQUlDLGNBQWMsS0FBbEI7QUFDQUQsdUJBQU9FLE9BQVAsQ0FBZUMsWUFBWTtBQUN6Qix3QkFBTSxDQUFDQyxFQUFELEVBQUtDLEVBQUwsSUFBV0YsU0FBUzNDLEtBQVQsQ0FBZSxHQUFmLENBQWpCOztBQUNBLHNCQUFJLFdBQVc4QixJQUFYLENBQWdCYyxFQUFoQixDQUFKLEVBQXdCO0FBQ3RCSCxrQ0FBYyxJQUFkO0FBQ0FGLGtDQUFjLFVBQWQsSUFBNEJNLEVBQTVCO0FBQ0EzQixnQ0FBWTRCLEdBQVosQ0FBZ0JELEVBQWhCO0FBQ0Q7QUFDRixpQkFQRDs7QUFRQSxvQkFBSSxDQUFDSixXQUFMLEVBQWtCO0FBQ2hCRixnQ0FBYyxVQUFkLElBQTRCLHdCQUE1QjtBQUNEO0FBQ0YsZUFkRCxNQWNPO0FBQ0xBLDhCQUFjLFVBQWQsSUFBNEIsd0JBQTVCO0FBQ0Q7O0FBRUQsa0JBQUksT0FBT3JDLFdBQVcsZ0JBQVgsQ0FBUCxLQUF3QyxXQUE1QyxFQUF3RDtBQUN0RHFDLDhCQUFjLGdCQUFkLElBQWtDckMsV0FBVyxnQkFBWCxFQUE2QixDQUE3QixDQUFsQztBQUNEOztBQUNEcEMsb0JBQU1VLE1BQU4sQ0FBYTtBQUNYLGtDQUFrQndEO0FBRFAsZUFBYixFQUVFO0FBQ0FlLDJCQUFXO0FBQ1QsbURBQWlDUjtBQUR4QjtBQURYLGVBRkY7QUFPRCxhQWpERCxNQWlETztBQUNMakYsc0JBQVFDLEdBQVIsQ0FBWSx1QkFBWjtBQUNBRCxzQkFBUUMsR0FBUixDQUFZc0UsS0FBS3ZCLElBQUwsQ0FBVSxJQUFWLENBQVo7QUFDRDtBQUNGO0FBQ0Y7QUFFRixPQXpGb0I7O0FBMEZyQjBDLGVBQVNDLE9BQVQsRUFBaUJ4QixJQUFqQixFQUF1QjtBQUNyQm5FLGdCQUFRQyxHQUFSLENBQVksVUFBWixFQURxQixDQUVyQjtBQUNEOztBQTdGb0IsS0FBdkI7QUErRkQ7O0FBakhnRCxDQUFwQixDQUF4QixDOzs7Ozs7Ozs7OztBQ3ZDUDVCLE9BQU9DLE1BQVAsQ0FBYztBQUFDc0gsc0JBQW1CLE1BQUlBO0FBQXhCLENBQWQ7QUFBMkQsSUFBSXBILE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxlQUFKO0FBQW9CUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDRSxrQkFBZ0JELENBQWhCLEVBQWtCO0FBQUNDLHNCQUFnQkQsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXBELEVBQTRGLENBQTVGO0FBQStGLElBQUlHLFlBQUo7QUFBaUJULE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUNHLG1CQUFhSCxDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBQXFFLElBQUkyRCxJQUFKO0FBQVNqRSxPQUFPSSxLQUFQLENBQWFDLFFBQVEsV0FBUixDQUFiLEVBQWtDO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDMkQsV0FBSzNELENBQUw7QUFBTzs7QUFBbkIsQ0FBbEMsRUFBdUQsQ0FBdkQ7QUFBMEQsSUFBSWtILElBQUo7QUFBU3hILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUNrSCxXQUFLbEgsQ0FBTDtBQUFPOztBQUFuQixDQUE3QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJbUgsV0FBSjtBQUFnQnpILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSw2Q0FBUixDQUFiLEVBQW9FO0FBQUNvSCxjQUFZbkgsQ0FBWixFQUFjO0FBQUNtSCxrQkFBWW5ILENBQVo7QUFBYzs7QUFBOUIsQ0FBcEUsRUFBb0csQ0FBcEc7QUFBdUcsSUFBSTZCLEtBQUo7QUFBVW5DLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx1Q0FBUixDQUFiLEVBQThEO0FBQUM4QixRQUFNN0IsQ0FBTixFQUFRO0FBQUM2QixZQUFNN0IsQ0FBTjtBQUFROztBQUFsQixDQUE5RCxFQUFrRixDQUFsRjtBQUFxRixJQUFJb0gsV0FBSjtBQUFnQjFILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSwyQkFBUixDQUFiLEVBQWtEO0FBQUNxSCxjQUFZcEgsQ0FBWixFQUFjO0FBQUNvSCxrQkFBWXBILENBQVo7QUFBYzs7QUFBOUIsQ0FBbEQsRUFBa0YsQ0FBbEY7QUFBcUYsSUFBSTRELEVBQUo7QUFBT2xFLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxJQUFSLENBQWIsRUFBMkI7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUM0RCxTQUFHNUQsQ0FBSDtBQUFLOztBQUFqQixDQUEzQixFQUE4QyxDQUE5QztBQVkxd0IsTUFBTWlILHFCQUFxQixJQUFJaEgsZUFBSixDQUFvQjtBQUNwREssUUFBTSxvQkFEOEM7QUFFcERDLFlBQVUsSUFBSUosWUFBSixDQUFpQjtBQUN6QmtILFlBQVE7QUFBRTVHLFlBQU1DO0FBQVI7QUFEaUIsR0FBakIsRUFFUEMsU0FGTyxFQUYwQztBQUtwREMsZ0JBQWM7QUFDWkMsYUFBUztBQURHLEdBTHNDOztBQVFwREMsTUFBSTtBQUFFdUc7QUFBRixHQUFKLEVBQWU7QUFDYmhHLFlBQVFDLEdBQVIsQ0FBWSxvQkFBWixFQUFrQytGLE1BQWxDO0FBQ0EsVUFBTUMsYUFBYXpGLE1BQU0wRixhQUFOLEdBQXNCQyx5QkFBdEIsRUFBbkI7QUFDQSxVQUFNQyxjQUFjTixZQUFZSSxhQUFaLEdBQTRCQyx5QkFBNUIsRUFBcEI7QUFDQU4sU0FBTSxHQUFFRyxNQUFPLElBQWYsRUFBb0IsQ0FBQ0ssR0FBRCxFQUFNQyxTQUFOLEtBQW9CO0FBQ3RDQSxnQkFBVWxCLE9BQVYsQ0FBa0I3QixZQUFZO0FBQzVCO0FBQ0EsY0FBTWdELGVBQWVoRCxTQUFTYixLQUFULENBQWUsR0FBZixFQUFvQjhELEdBQXBCLEdBQTBCOUQsS0FBMUIsQ0FBZ0MsR0FBaEMsRUFBcUMsQ0FBckMsQ0FBckI7QUFFQSxjQUFNNkIsT0FBT2hDLEdBQUdtQixZQUFILENBQWdCSCxRQUFoQixFQUEwQixNQUExQixDQUFiLENBSjRCLENBSWtCOztBQUM1QyxjQUFNa0QsT0FBT1YsWUFBWXhCLElBQVosQ0FBYjtBQUNBNkIsb0JBQVlNLE1BQVosQ0FBbUI7QUFDakJDLGNBQUlKLFlBRGE7QUFFakJLLGdCQUFNSCxLQUFLRyxJQUZNO0FBR2pCSCxnQkFBTUEsS0FBS0EsSUFITTtBQUlqQkksaUJBQU9KLEtBQUtLO0FBSkssU0FBbkI7QUFNQWIsbUJBQVdjLElBQVgsQ0FBZ0I7QUFBQ0osY0FBSTtBQUFDSyxpQkFBS1AsS0FBS0s7QUFBWDtBQUFMLFNBQWhCLEVBQTJDNUYsTUFBM0MsQ0FBa0Q7QUFBQytGLGdCQUFNO0FBQUNDLHdCQUFZWDtBQUFiO0FBQVAsU0FBbEQsRUFaMEIsQ0FhMUI7QUFDRjtBQUNELE9BZkQ7QUFnQkZ2RyxjQUFRQyxHQUFSLENBQVksb0JBQVo7QUFDQSxZQUFNa0gsb0JBQW9CbEIsV0FBV21CLE9BQVgsRUFBMUI7QUFDQXBILGNBQVFDLEdBQVIsQ0FBWWtILGlCQUFaO0FBRUFuSCxjQUFRQyxHQUFSLENBQVkscUJBQVo7QUFDQSxZQUFNb0gscUJBQXFCakIsWUFBWWdCLE9BQVosRUFBM0I7QUFDQXBILGNBQVFDLEdBQVIsQ0FBWW9ILGtCQUFaO0FBQ0MsS0F4QkQ7QUEyQkQ7O0FBdkNtRCxDQUFwQixDQUEzQixDOzs7Ozs7Ozs7OztBQ1pQaEosT0FBT0MsTUFBUCxDQUFjO0FBQUNnSixjQUFXLE1BQUlBO0FBQWhCLENBQWQ7QUFBMkMsSUFBSTVGLEtBQUo7QUFBVXJELE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ2dELFFBQU0vQyxDQUFOLEVBQVE7QUFBQytDLFlBQU0vQyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlHLFlBQUo7QUFBaUJULE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUNHLG1CQUFhSCxDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBR2xJO0FBRUEsTUFBTTJJLGFBQWEsSUFBSTVGLE1BQU1DLFVBQVYsQ0FBcUIsWUFBckIsQ0FBbkIsQzs7Ozs7Ozs7Ozs7QUNMQXRELE9BQU9DLE1BQVAsQ0FBYztBQUFDaUosaUJBQWMsTUFBSUE7QUFBbkIsQ0FBZDtBQUFpRCxJQUFJL0ksTUFBSjtBQUFXSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFNBQU9HLENBQVAsRUFBUztBQUFDSCxhQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlDLGVBQUo7QUFBb0JQLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNFLGtCQUFnQkQsQ0FBaEIsRUFBa0I7QUFBQ0Msc0JBQWdCRCxDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBcEQsRUFBNEYsQ0FBNUY7QUFBK0YsSUFBSUcsWUFBSjtBQUFpQlQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQ0csbUJBQWFILENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSTBCLElBQUo7QUFBU2hDLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUMwQixXQUFLMUIsQ0FBTDtBQUFPOztBQUFuQixDQUFwQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJMkIsUUFBSjtBQUFhakMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLG1DQUFSLENBQWIsRUFBMEQ7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUMyQixlQUFTM0IsQ0FBVDtBQUFXOztBQUF2QixDQUExRCxFQUFtRixDQUFuRjtBQUFzRixJQUFJNEIsR0FBSjtBQUFRbEMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDhCQUFSLENBQWIsRUFBcUQ7QUFBQzZCLE1BQUk1QixDQUFKLEVBQU07QUFBQzRCLFVBQUk1QixDQUFKO0FBQU07O0FBQWQsQ0FBckQsRUFBcUUsQ0FBckU7QUFBd0UsSUFBSTZCLEtBQUo7QUFBVW5DLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx1Q0FBUixDQUFiLEVBQThEO0FBQUM4QixRQUFNN0IsQ0FBTixFQUFRO0FBQUM2QixZQUFNN0IsQ0FBTjtBQUFROztBQUFsQixDQUE5RCxFQUFrRixDQUFsRjtBQUFxRixJQUFJOEMsU0FBSjtBQUFjcEQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLCtDQUFSLENBQWIsRUFBc0U7QUFBQytDLFlBQVU5QyxDQUFWLEVBQVk7QUFBQzhDLGdCQUFVOUMsQ0FBVjtBQUFZOztBQUExQixDQUF0RSxFQUFrRyxDQUFsRztBQWFscUIsTUFBTTRJLGdCQUFnQixJQUFJM0ksZUFBSixDQUFvQjtBQUMvQ0ssUUFBTSxlQUR5QztBQUUvQ0MsWUFBVSxJQUFJSixZQUFKLENBQWlCO0FBQ3pCK0MsV0FBTztBQUNMekMsWUFBTTBDLE1BREQ7QUFFTEMsZ0JBQVU7QUFGTCxLQURrQjtBQUt6QnlGLGNBQVU7QUFBRXBJLFlBQU1DO0FBQVI7QUFMZSxHQUFqQixFQU1QQyxTQU5PLEVBRnFDO0FBUy9DQyxnQkFBYztBQUNaQyxhQUFTO0FBREcsR0FUaUM7O0FBWS9DQyxNQUFJO0FBQUVvQyxTQUFGO0FBQVMyRjtBQUFULEdBQUosRUFBd0I7QUFDdEI7Ozs7O0FBS0F4SCxZQUFRQyxHQUFSLENBQWEsZUFBY3VILFFBQVMsRUFBcEM7QUFDQXhILFlBQVFDLEdBQVIsQ0FBWTRCLEtBQVo7QUFFQSxVQUFNNEYsY0FBY0MsS0FBS0MsU0FBTCxDQUFlOUYsS0FBZixDQUFwQjtBQUVBLFVBQU1HLFlBQVkzQixLQUFNLEdBQUVvSCxXQUFZLEdBQUVELFFBQVMsRUFBL0IsQ0FBbEI7QUFHQXhILFlBQVFDLEdBQVIsQ0FBWStCLFNBQVo7O0FBQ0EsUUFBSSxDQUFFLEtBQUt0QyxNQUFYLEVBQW1CO0FBQ2pCLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0Q7O0FBQ0QsVUFBTWlJLGNBQWN0SCxTQUFTVyxPQUFULENBQWlCO0FBQUUsd0JBQWtCZTtBQUFwQixLQUFqQixDQUFwQjs7QUFFQSxRQUFJLE9BQU80RixXQUFQLEtBQXVCLFdBQTNCLEVBQXVDO0FBQ3JDNUgsY0FBUUMsR0FBUixDQUFZLDZCQUFaO0FBQ0EsWUFBTTRILE1BQU0sSUFBSXRILEdBQUosQ0FBUUQsUUFBUixFQUFrQixVQUFsQixFQUE4QjtBQUN4Q21ILHFCQUFhQSxXQUQyQjtBQUV4Q3pGLG1CQUFXQSxTQUY2QjtBQUd4Q3dGLGtCQUFVQTtBQUg4QixPQUE5QixDQUFaO0FBS0FLLFVBQUlqSCxRQUFKLENBQWEsTUFBYixFQUFxQkMsSUFBckI7QUFDRDs7QUFFRCxXQUFPbUIsU0FBUDtBQUNEOztBQTNDOEMsQ0FBcEIsQ0FBdEIsQzs7Ozs7Ozs7Ozs7QUNiUDNELE9BQU9DLE1BQVAsQ0FBYztBQUFDd0osZUFBWSxNQUFJQTtBQUFqQixDQUFkO0FBQTZDLElBQUlwRyxLQUFKO0FBQVVyRCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNnRCxRQUFNL0MsQ0FBTixFQUFRO0FBQUMrQyxZQUFNL0MsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRyxZQUFKO0FBQWlCVCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDRyxtQkFBYUgsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUdwSTtBQUVBLE1BQU1tSixjQUFjLElBQUlwRyxNQUFNQyxVQUFWLENBQXFCLGFBQXJCLENBQXBCLEM7Ozs7Ozs7Ozs7O0FDTEF0RCxPQUFPQyxNQUFQLENBQWM7QUFBQ2tDLFNBQU0sTUFBSUEsS0FBWDtBQUFpQnVILGNBQVcsTUFBSUEsVUFBaEM7QUFBMkNDLG9CQUFpQixNQUFJQTtBQUFoRSxDQUFkO0FBQWlHLElBQUl0RyxLQUFKO0FBQVVyRCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNnRCxRQUFNL0MsQ0FBTixFQUFRO0FBQUMrQyxZQUFNL0MsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRyxZQUFKO0FBQWlCVCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDRyxtQkFBYUgsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUd4TCxNQUFNNkIsUUFBUSxJQUFJa0IsTUFBTUMsVUFBVixDQUFxQixPQUFyQixDQUFkLEMsQ0FFQTs7QUFDQSxNQUFNc0cscUJBQXFCLElBQUluSixZQUFKLENBQWlCO0FBQzFDNkgsTUFBSTtBQUNGdkgsVUFBTUMsTUFESjtBQUVGNkksWUFBUSxJQUZOO0FBR0ZDLFdBQU8sSUFITDtBQUlGO0FBQ0FDLFdBQU87QUFMTCxHQURzQztBQVExQ2hKLFFBQU07QUFDSkEsVUFBTUMsTUFERjtBQUVKZ0osbUJBQWUsQ0FBQyxNQUFELEVBQVEsTUFBUixFQUFlLEtBQWYsRUFBcUIsTUFBckIsRUFBNEIsaUJBQTVCLEVBQThDLGdCQUE5QyxDQUZYO0FBR0pELFdBQU87QUFISCxHQVJvQztBQWExQ0UsT0FBSztBQUNIbEosVUFBTUMsTUFESDtBQUVIK0ksV0FBTztBQUZKLEdBYnFDO0FBaUIxQ3hELFNBQU87QUFDTHhGLFVBQU04QyxNQUREO0FBRUxrRyxXQUFPO0FBRkYsR0FqQm1DO0FBcUIxQ3ZELE9BQUs7QUFDSHpGLFVBQU04QyxNQURIO0FBRUhrRyxXQUFPO0FBRkosR0FyQnFDO0FBeUIxQ3RELFNBQU87QUFDTDFGLFVBQU1DLE1BREQ7QUFFTCtJLFdBQU8sT0FGRjtBQUdMRyxZQUFRLFlBQVU7QUFDaEIsVUFBSSxDQUFDLEtBQUtDLEtBQVYsRUFBZ0I7QUFDZCxlQUFPLFVBQVA7QUFDRDs7QUFDRCxVQUFJLEtBQUt6RixLQUFMLEtBQWUsR0FBbkIsRUFBdUI7QUFDckIsZUFBTyxJQUFQO0FBQ0QsT0FGRCxNQUVPO0FBQ0wsWUFBSTBGLGNBQWNDLFdBQVcsS0FBSzNGLEtBQWhCLENBQWxCOztBQUNBLFlBQUk0RixNQUFNRixXQUFOLENBQUosRUFBdUI7QUFDckIsaUJBQU8sWUFBUDtBQUNELFNBRkQsTUFFTztBQUNMLGlCQUFPLElBQVA7QUFDRDtBQUNGO0FBQ0Y7QUFqQkksR0F6Qm1DO0FBNEMxQzdGLGNBQVk7QUFDVnhELFVBQU0wQyxNQURJO0FBRVZDLGNBQVUsSUFGQTtBQUdWb0csV0FBTyxJQUhHO0FBSVZDLFdBQU87QUFKRyxHQTVDOEI7QUFrRDFDUSxZQUFVO0FBQ1J4SixVQUFNb0MsS0FERTtBQUNJO0FBQ1pxSCxjQUFVLElBRkY7QUFHUlQsV0FBTztBQUhDLEdBbERnQztBQXVEMUMsZ0JBQWM7QUFDWmhKLFVBQU1DO0FBRE07QUF2RDRCLENBQWpCLENBQTNCLEMsQ0E2REE7O0FBQ0EsTUFBTTJJLG1CQUFtQixJQUFJbEosWUFBSixDQUFpQjtBQUN4Q2tHLFNBQU87QUFDTDVGLFVBQU1OLGFBQWFnSyxLQUFiLENBQW1CNUcsTUFBbkIsRUFBMEI3QyxNQUExQixDQUREO0FBRUxnSixtQkFBZSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQUssQ0FBTCxFQUFPLEdBQVAsQ0FGVjtBQUdMRCxXQUFPO0FBSEYsR0FEaUM7QUFNeENoSixRQUFNO0FBQ0pBLFVBQU1DLE1BREY7QUFFSmdKLG1CQUFlLENBQUMsS0FBRCxFQUFPLE1BQVAsRUFBYyxNQUFkLEVBQXFCLGdCQUFyQixFQUFzQyxpQkFBdEMsQ0FGWDtBQUdKRCxXQUFPO0FBSEgsR0FOa0M7QUFXeENXLFdBQVM7QUFDUDNKLFVBQU1vQyxLQURDO0FBQ0s7QUFDWjRHLFdBQU87QUFGQSxHQVgrQjtBQWV4QyxlQUFhO0FBQ1hoSixVQUFNQztBQURLLEdBZjJCO0FBa0J4QzJKLG1CQUFpQjtBQUNmNUosVUFBTW9DLEtBRFM7QUFFZjRHLFdBQU8sOEJBRlE7QUFHZlMsY0FBVTtBQUhLLEdBbEJ1QjtBQXVCeEMsdUJBQXFCO0FBQ25CekosVUFBTTBDLE1BRGE7QUFFbkJzRyxXQUFPLDZCQUZZO0FBR25CckcsY0FBVTtBQUhTO0FBdkJtQixDQUFqQixDQUF6QixDLENBOEJBOztBQUNBaUcsaUJBQWlCaUIsTUFBakIsQ0FBd0JoQixrQkFBeEI7QUFFQSxNQUFNRixhQUFhLElBQUlqSixZQUFKLENBQWlCO0FBQ2xDTSxRQUFNO0FBQ0pBLFVBQU1DLE1BREY7QUFFSmdKLG1CQUFlLENBQUMsTUFBRCxDQUZYO0FBR0pELFdBQU87QUFISCxHQUQ0QjtBQU1sQ2MsV0FBUztBQUNQOUosVUFBTUMsTUFEQztBQUVQd0osY0FBVTtBQUZILEdBTnlCO0FBVWxDTSxXQUFTO0FBQ1AvSixVQUFNb0MsS0FEQztBQUNLO0FBQ1pxSCxjQUFVO0FBRkgsR0FWeUI7QUFjbEMsZUFBYTtBQUNYekosVUFBTUM7QUFESyxHQWRxQjtBQWlCbEMrSixXQUFTO0FBQ1BoSyxVQUFNaUssT0FEQztBQUVQUixjQUFVO0FBRkgsR0FqQnlCO0FBcUJsQ1MsY0FBWTtBQUNWbEssVUFBTW9DLEtBREk7QUFDRTtBQUNacUgsY0FBVSxJQUZBO0FBR1ZULFdBQU87QUFIRyxHQXJCc0I7QUEwQmxDLGtCQUFnQjtBQUNkaEosVUFBTTBDLE1BRFE7QUFFZEMsY0FBVTtBQUZJLEdBMUJrQjtBQThCbEN3SCxlQUFhO0FBQ1huSyxVQUFNb0MsS0FESztBQUNDO0FBQ1o7QUFDQXFILGNBQVUsSUFIQztBQUlYVCxXQUFPO0FBSkksR0E5QnFCO0FBb0NsQyxtQkFBaUI7QUFDZmhKLFVBQU0wQyxNQURTO0FBRWZDLGNBQVU7QUFGSyxHQXBDaUI7QUF3Q2xDeUgsYUFBVztBQUNUcEssVUFBTUMsTUFERztBQUVUO0FBQ0ErSSxXQUFPO0FBSEUsR0F4Q3VCO0FBNkNsQ3FCLFNBQU87QUFDTHJLLFVBQU1DLE1BREQ7QUFFTDtBQUNBK0ksV0FBTztBQUhGLEdBN0MyQjtBQWtEbEN6RCxVQUFRO0FBQ052RixVQUFNQyxNQURBO0FBRU4rSSxXQUFPO0FBRkQsR0FsRDBCO0FBc0RsQ2hKLFFBQU07QUFDSkEsVUFBTUMsTUFERjtBQUVKZ0osbUJBQWUsQ0FBQyxNQUFELENBRlg7QUFHSkQsV0FBTztBQUhILEdBdEQ0QjtBQTJEbENyRCxVQUFRO0FBQ04zRixVQUFNQyxNQURBO0FBRU5nSixtQkFBZSxDQUFDLEdBQUQsRUFBTSxHQUFOLENBRlQ7QUFHTkQsV0FBTztBQUhELEdBM0QwQjtBQWdFbENwSCxTQUFPO0FBQ0w1QixVQUFNQyxNQUREO0FBRUwrSSxXQUFPO0FBRkYsR0FoRTJCO0FBb0VsQ3NCLGVBQWE7QUFDWHRLLFVBQU1vQyxLQURLO0FBQ0M7QUFDWjRHLFdBQU87QUFGSSxHQXBFcUI7QUF3RWxDLG1CQUFpQjtBQUNmaEosVUFBTUM7QUFEUztBQXhFaUIsQ0FBakIsQ0FBbkIsQyxDQTZFQTs7QUFDQTBJLFdBQVdrQixNQUFYLENBQWtCaEIsa0JBQWxCO0FBRUF6SCxNQUFNbUosWUFBTixDQUFtQjVCLFVBQW5CLEU7Ozs7Ozs7Ozs7O0FDckxBMUosT0FBT0MsTUFBUCxDQUFjO0FBQUNzTCxZQUFTLE1BQUlBO0FBQWQsQ0FBZDtBQUF1QyxJQUFJbEksS0FBSjtBQUFVckQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDZ0QsUUFBTS9DLENBQU4sRUFBUTtBQUFDK0MsWUFBTS9DLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUcsWUFBSjtBQUFpQlQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQ0csbUJBQWFILENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFHOUg7QUFFQSxNQUFNaUwsV0FBVyxJQUFJbEksTUFBTUMsVUFBVixDQUFxQixVQUFyQixDQUFqQixDOzs7Ozs7Ozs7OztBQ0xBLElBQUluRCxNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUUsS0FBSjtBQUFVUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDRyxRQUFNRixDQUFOLEVBQVE7QUFBQ0UsWUFBTUYsQ0FBTjtBQUFROztBQUFsQixDQUE5QyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJa0wsT0FBSjtBQUFZeEwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLFNBQVIsQ0FBYixFQUFnQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQ2tMLGNBQVFsTCxDQUFSO0FBQVU7O0FBQXRCLENBQWhDLEVBQXdELENBQXhEO0FBQTJELElBQUltTCxNQUFKO0FBQVd6TCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDbUwsYUFBT25MLENBQVA7QUFBUzs7QUFBckIsQ0FBdEMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSW9MLGdCQUFKO0FBQXFCMUwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDJCQUFSLENBQWIsRUFBa0Q7QUFBQ3FMLG1CQUFpQnBMLENBQWpCLEVBQW1CO0FBQUNvTCx1QkFBaUJwTCxDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBbEQsRUFBNEYsQ0FBNUY7QUFBK0YsSUFBSTZCLEtBQUo7QUFBVW5DLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx1Q0FBUixDQUFiLEVBQThEO0FBQUM4QixRQUFNN0IsQ0FBTixFQUFRO0FBQUM2QixZQUFNN0IsQ0FBTjtBQUFROztBQUFsQixDQUE5RCxFQUFrRixDQUFsRjs7QUFTemE7Ozs7O0FBS0EsTUFBTXFMLFVBQVcxQixHQUFELElBQVM7QUFDdkIsUUFBTTJCLE9BQU87QUFDWCxTQUFJLEdBRE87QUFDSCxTQUFJLEdBREQ7QUFFWCxTQUFJLEdBRk87QUFFSCxTQUFJLEdBRkQ7QUFHWCxTQUFJLEdBSE87QUFHSCxTQUFJLEdBSEQ7QUFJWCxTQUFJLEdBSk87QUFJSCxTQUFJLEdBSkQ7QUFLWCxTQUFJLEdBTE87QUFLSCxTQUFJO0FBTEQsR0FBYjtBQU9BLFFBQU1DLGNBQWM1QixJQUFJNUYsS0FBSixDQUFVLEVBQVYsRUFBY3lILE9BQWQsRUFBcEI7QUFDQSxRQUFNQyxrQkFBa0JGLFlBQVlqSCxHQUFaLENBQWtCb0gsR0FBRCxJQUFTO0FBQ2hELFdBQU9KLEtBQUtJLEdBQUwsQ0FBUDtBQUNELEdBRnVCLENBQXhCO0FBR0EsUUFBTUMsYUFBYUYsZ0JBQWdCcEgsSUFBaEIsQ0FBcUIsRUFBckIsQ0FBbkI7QUFDQSxTQUFPc0gsVUFBUDtBQUNELENBZEQ7QUFnQkE7Ozs7Ozs7QUFLQSxNQUFNQyxZQUFhakMsR0FBRCxJQUFTO0FBQ3pCLFFBQU1rQyxRQUFRO0FBQ1osV0FBTyxHQURLO0FBQ0EsV0FBTyxHQURQO0FBQ1ksV0FBTyxHQURuQjtBQUVaLFdBQU8sR0FGSztBQUVBLFdBQU8sR0FGUDtBQUVZLFdBQU8sR0FGbkI7QUFHWixXQUFPLEdBSEs7QUFHQSxXQUFPLEdBSFA7QUFHWSxXQUFPLEdBSG5CO0FBSVosV0FBTyxHQUpLO0FBSUEsV0FBTyxHQUpQO0FBSVksV0FBTyxHQUpuQjtBQUtaLFdBQU8sR0FMSztBQUtBLFdBQU8sR0FMUDtBQUtZLFdBQU8sR0FMbkI7QUFNWixXQUFPLEdBTks7QUFNQSxXQUFPLEdBTlA7QUFNWSxXQUFPLEdBTm5CO0FBT1osV0FBTyxHQVBLO0FBT0EsV0FBTyxHQVBQO0FBT1ksV0FBTyxHQVBuQjtBQVFaLFdBQU8sR0FSSztBQVFBLFdBQU8sR0FSUDtBQVFZLFdBQU8sR0FSbkI7QUFTWixXQUFPLEdBVEs7QUFTQSxXQUFPLEdBVFA7QUFTWSxXQUFPLEdBVG5CO0FBVVosV0FBTyxHQVZLO0FBVUEsV0FBTyxHQVZQO0FBVVksV0FBTyxHQVZuQjtBQVdaLFdBQU8sR0FYSztBQVdBLFdBQU8sR0FYUDtBQVdZLFdBQU8sR0FYbkI7QUFZWixXQUFPLEdBWks7QUFZQSxXQUFPLEdBWlA7QUFZWSxXQUFPLEdBWm5CO0FBYVosV0FBTyxHQWJLO0FBYUEsV0FBTyxHQWJQO0FBYVksV0FBTyxHQWJuQjtBQWNaLFdBQU8sR0FkSztBQWNBLFdBQU8sR0FkUDtBQWNZLFdBQU8sR0FkbkI7QUFlWixXQUFPLEdBZks7QUFlQSxXQUFPLEdBZlA7QUFlWSxXQUFPLEdBZm5CO0FBZ0JaLFdBQU8sR0FoQks7QUFnQkEsV0FBTyxHQWhCUDtBQWdCWSxXQUFPLEdBaEJuQjtBQWlCWixXQUFPLEdBakJLO0FBaUJBLFdBQU8sR0FqQlA7QUFpQlksV0FBTyxHQWpCbkI7QUFrQlosV0FBTyxHQWxCSztBQWtCQSxXQUFPLEdBbEJQO0FBa0JZLFdBQU8sR0FsQm5CO0FBbUJaLFdBQU8sR0FuQks7QUFtQkEsV0FBTyxHQW5CUDtBQW1CWSxXQUFPLEdBbkJuQjtBQW9CWixXQUFPLEdBcEJLO0FBb0JBLFdBQU8sR0FwQlA7QUFvQlksV0FBTyxHQXBCbkI7QUFxQlosV0FBTyxHQXJCSztBQXFCQSxXQUFPLEdBckJQO0FBcUJZLFdBQU8sR0FyQm5CO0FBc0JaLFdBQU87QUF0QkssR0FBZDtBQXVCQSxRQUFNQyxhQUFhbkMsSUFBSW9DLEtBQUosQ0FBVSxTQUFWLENBQW5CO0FBQ0EsUUFBTUMsV0FBV0YsV0FBV3hILEdBQVgsQ0FBaUIySCxLQUFELElBQVc7QUFDMUMsUUFBSUMsWUFBWSxHQUFoQjs7QUFDQSxRQUFJRCxNQUFNRSxPQUFOLENBQWMsR0FBZCxJQUFxQixDQUF6QixFQUEyQjtBQUN6QkQsa0JBQVlMLE1BQU1JLEtBQU4sQ0FBWjtBQUNEOztBQUNELFdBQU9DLFNBQVA7QUFDRCxHQU5nQixDQUFqQjtBQU9BLFFBQU1FLE1BQU1KLFNBQVMzSCxJQUFULENBQWMsRUFBZCxDQUFaO0FBQ0EsU0FBTytILEdBQVA7QUFDRCxDQWxDRDs7QUFvQ0EsTUFBTUMsWUFBYUMsSUFBRCxJQUFVO0FBQzFCLE1BQUlDLGNBQWNELEtBQUsxQixXQUFMLENBQWlCNEIsTUFBakIsQ0FBMEJDLFVBQUQsSUFBZ0I7QUFBRSxXQUFPQSxXQUFXaE0sSUFBWCxLQUFvQixNQUEzQjtBQUFtQyxHQUE5RSxDQUFsQjtBQUNBLE1BQUlpTSxZQUFZSCxZQUFZakksR0FBWixDQUFrQnFJLFVBQUQsSUFBZ0I7QUFDL0MsUUFBSUMsZ0JBQWlCLElBQUdELFdBQVczRSxFQUFHLElBQXRDO0FBQ0EsUUFBSTZFLGdCQUFpQixJQUFHRixXQUFXM0UsRUFBRyxJQUF0QztBQUNBLFFBQUk4RSxXQUFXUixLQUFLMUIsV0FBTCxDQUFpQjRCLE1BQWpCLENBQTBCTyxHQUFELElBQVM7QUFDL0MsYUFBT0EsSUFBSTNDLE9BQUosQ0FBWStCLE9BQVosQ0FBb0JRLFdBQVczRSxFQUEvQixLQUFzQyxDQUF0QyxJQUEyQytFLElBQUl0TSxJQUFKLEtBQWEsS0FBL0Q7QUFDRCxLQUZjLEVBRVp1TSxJQUZZLENBRU4sQ0FBQ0MsQ0FBRCxFQUFHQyxDQUFILEtBQVM7QUFDaEIsYUFBT0QsRUFBRWhILEtBQUYsR0FBVWlILEVBQUVqSCxLQUFuQjtBQUNELEtBSmMsQ0FBZjtBQU1BLFFBQUlrSCxXQUFXLEtBQWYsQ0FUK0MsQ0FVL0M7QUFFQTs7QUFDQSxRQUFJQyxpQkFBaUJDLFdBQVdqRixJQUFYLENBQWdCO0FBQ25Da0YsY0FBUWhCLEtBQUt4QixLQURzQjtBQUVuQ3lDLFlBQU0sQ0FDSjtBQUFFdEgsZUFBTztBQUFDdUgsZ0JBQU1sQixLQUFLcEc7QUFBWjtBQUFULE9BREksRUFFSjtBQUFFQSxhQUFLO0FBQUN1SCxnQkFBTW5CLEtBQUtyRztBQUFaO0FBQVAsT0FGSTtBQUY2QixLQUFoQixFQU1sQnlILEtBTmtCLEVBQXJCOztBQVFBLFFBQUlOLGVBQWVPLE1BQW5CLEVBQTBCO0FBQ3hCLFVBQUk5QyxZQUFZdUMsZUFBZUosSUFBZixDQUFxQixDQUFDQyxDQUFELEVBQUdDLENBQUgsS0FBUztBQUM1QztBQUNBLGVBQU9ELEVBQUVoSCxLQUFGLEdBQVVpSCxFQUFFakgsS0FBbkI7QUFDRCxPQUhlLEVBR2IzQixHQUhhLENBR1BzSixHQUFELElBQVM7QUFDZjtBQUNBVCxtQkFBV1UsS0FBS0MsR0FBTCxDQUFTWCxRQUFULEVBQWtCUyxJQUFJM0gsS0FBdEIsQ0FBWDtBQUNBLGVBQU8ySCxJQUFJakUsR0FBWDtBQUNELE9BUGUsRUFPYnRGLElBUGEsQ0FPUixFQVBRLENBQWhCO0FBU0FzRixZQUFNbUQsU0FBU3hJLEdBQVQsQ0FBYyxDQUFDeUosR0FBRCxFQUFNdkUsS0FBTixLQUFnQjtBQUNsQyxZQUFJdkQsUUFBUThILElBQUk5SCxLQUFKLEdBQVlrSCxRQUFaLEdBQXVCLENBQW5DO0FBQ0EsWUFBSWpILE1BQU02SCxJQUFJN0gsR0FBSixHQUFVaUgsUUFBcEI7QUFDQSxlQUFPdEMsVUFBVW1ELEtBQVYsQ0FBZ0IvSCxLQUFoQixFQUFzQkMsR0FBdEIsQ0FBUDtBQUNELE9BSkssRUFJSDdCLElBSkcsQ0FJRSxFQUpGLENBQU47QUFNQSxVQUFJZ0MsS0FBSjs7QUFDQSxVQUFJLEtBQUtELE1BQUwsS0FBZ0IsR0FBcEIsRUFBd0I7QUFDdEJ1RCxjQUFNMEIsUUFBUTFCLEdBQVIsQ0FBTjtBQUNBdEQsZ0JBQVF5RyxTQUFTQSxTQUFTYSxNQUFULEdBQWlCLENBQTFCLEVBQTZCdEgsS0FBckM7QUFDRCxPQUhELE1BR087QUFDTEEsZ0JBQVF5RyxTQUFTLENBQVQsRUFBWXpHLEtBQXBCO0FBQ0Q7O0FBRUQsVUFBSSxDQUFDLENBQUQsRUFBRyxDQUFILEVBQU04RixPQUFOLENBQWM5RixLQUFkLEtBQXdCLENBQTVCLEVBQThCO0FBQzVCc0QsY0FBTUEsSUFBSXFFLEtBQUosQ0FBVTNILEtBQVYsQ0FBTjtBQUNEOztBQUVELFVBQUkrRixNQUFNUixVQUFVakMsSUFBSXNFLFdBQUosRUFBVixDQUFWO0FBRUFyQix1QkFBaUJqRCxHQUFqQjtBQUVBa0QsdUJBQWlCVCxHQUFqQjtBQUNBUyxzQkFBZ0JBLGNBQWM5SSxLQUFkLENBQW9CLEdBQXBCLEVBQXlCTSxJQUF6QixDQUE4QixHQUE5QixDQUFoQjtBQUNEOztBQUNELFdBQU87QUFBQzJELFVBQUcyRSxXQUFXM0UsRUFBZjtBQUFtQjJCLFdBQUtpRCxhQUF4QjtBQUF1Q1IsV0FBS1M7QUFBNUMsS0FBUDtBQUNELEdBekRlLENBQWhCO0FBMERBLFNBQU9ILFNBQVA7QUFDRCxDQTdERDs7QUErREEsU0FBU3dCLGNBQVQsQ0FBd0JDLFVBQXhCLEVBQW1DQyxPQUFuQyxFQUEyQztBQUN6QyxRQUFNQyxZQUFZLElBQUlsRCxNQUFKLEVBQWxCO0FBRUFELFVBQVFvRCxJQUFSLENBQWE7QUFDWEMsU0FBSyx3REFETTtBQUVYQyxVQUFNO0FBQ0pDLGFBQU8sdUJBREg7QUFFSkMsYUFBUSxvQkFBbUJQLFVBQVcsRUFGbEM7QUFHSlEsZ0JBQVVQO0FBSE47QUFGSyxHQUFiLEVBT0csQ0FBQzdJLEtBQUQsRUFBUXFKLFFBQVIsRUFBa0I3TSxLQUFsQixLQUE0QjtBQUM3QlYsWUFBUUMsR0FBUixDQUFZLFFBQVosRUFBc0JpRSxLQUF0QixFQUQ2QixDQUNDOztBQUM5QmxFLFlBQVFDLEdBQVIsQ0FBWSxhQUFaLEVBQTJCc04sWUFBWUEsU0FBU0MsVUFBaEQsRUFGNkIsQ0FFZ0M7O0FBQzdEeE4sWUFBUUMsR0FBUixDQUFZLFlBQVosRUFBMEJTLEtBQTFCO0FBQ0FzTSxjQUFVUyxNQUFWLENBQWlCL00sS0FBakI7QUFDRCxHQVpEO0FBY0EsUUFBTUEsUUFBUXNNLFVBQVVVLElBQVYsRUFBZDtBQUVBLFNBQU9oTixLQUFQO0FBQ0Q7O0FBRUQsU0FBU2lOLFlBQVQsQ0FBc0JqTixLQUF0QixFQUE0QmtOLEVBQTVCLEVBQStCO0FBQzdCLFFBQU1DLGdCQUFnQixJQUFJL0QsTUFBSixFQUF0QjtBQUNBLFFBQU1vRCxNQUFPLDREQUEyRHhNLEtBQU0sRUFBOUU7QUFDQVYsVUFBUUMsR0FBUixDQUFhLFVBQVNpTixHQUFJLEVBQTFCO0FBQ0FyRCxVQUFRaUUsR0FBUixDQUFZWixHQUFaLEVBQWlCLENBQUNoSixLQUFELEVBQU9xSixRQUFQLEVBQWdCUSxJQUFoQixLQUF5QjtBQUN4Qy9OLFlBQVFDLEdBQVIsQ0FBWWlFLEtBQVo7QUFDQWxFLFlBQVFDLEdBQVIsQ0FBWThOLElBQVo7QUFDQUYsa0JBQWNKLE1BQWQsQ0FBcUJNLElBQXJCO0FBQ0QsR0FKRDtBQUtBLFFBQU1DLFNBQVNILGNBQWNILElBQWQsRUFBZjs7QUFDQSxNQUFJTSxXQUFXLFNBQWYsRUFBeUI7QUFDdkI7QUFDQXhQLFdBQU95UCxVQUFQLENBQWtCLFlBQVU7QUFBQyxhQUFPTixhQUFhak4sS0FBYixFQUFtQmtOLEVBQW5CLENBQVA7QUFBOEIsS0FBM0QsRUFBNkQsTUFBN0Q7QUFDRCxHQUhELE1BR087QUFDTEEsT0FBR0ksTUFBSDtBQUNEO0FBQ0Y7O0FBRUQsU0FBU0Usa0JBQVQsQ0FBNEJ4TixLQUE1QixFQUFrQztBQUNoQyxRQUFNeU4sU0FBUyxJQUFJckUsTUFBSixFQUFmO0FBQ0EsUUFBTW9ELE1BQU8sNERBQTJEeE0sS0FBTSxPQUE5RTtBQUNBVixVQUFRQyxHQUFSLENBQWEsVUFBU2lOLEdBQUksRUFBMUI7QUFDQXJELFVBQVFpRSxHQUFSLENBQVlaLEdBQVosRUFBaUIsQ0FBQ2hKLEtBQUQsRUFBT3FKLFFBQVAsRUFBZ0JRLElBQWhCLEtBQXlCO0FBQ3hDLFFBQUlLLHFCQUFxQjFHLEtBQUs1RCxLQUFMLENBQVdpSyxJQUFYLENBQXpCO0FBQ0FJLFdBQU9WLE1BQVAsQ0FBY1csa0JBQWQ7QUFDRCxHQUhEO0FBSUEsUUFBTXpJLFVBQVV3SSxPQUFPVCxJQUFQLEVBQWhCO0FBQ0EsU0FBTy9ILE9BQVA7QUFDRDs7QUFFRG5ILE9BQU82UCxPQUFQLENBQWU7QUFDYkMsZUFBYUMsTUFBYixFQUFvQjtBQUNsQixRQUFJLENBQUUsS0FBSzdPLE1BQVgsRUFBbUI7QUFDakIsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDRDs7QUFDRCxRQUFJLENBQUVkLE1BQU1lLFlBQU4sQ0FBbUIsS0FBS0YsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTixFQUE4QztBQUM1QyxZQUFNLElBQUlsQixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNELEtBTmlCLENBUWxCOzs7QUFDQSxVQUFNc0wsT0FBT3pLLE1BQU1TLE9BQU4sQ0FBYztBQUFDMEYsVUFBSTRIO0FBQUwsS0FBZCxDQUFiO0FBQ0EsVUFBTWxELFlBQVl0QixpQkFBaUJrQixJQUFqQixDQUFsQjtBQUNBLFVBQU10RixVQUFVMEYsVUFBVXBJLEdBQVYsQ0FBZXFLLFFBQUQsSUFBYztBQUUxQztBQUNBLFVBQUl2QyxNQUFNdUMsU0FBU3ZDLEdBQVQsQ0FBYXJJLEtBQWIsQ0FBbUIsR0FBbkIsRUFBd0JNLElBQXhCLENBQTZCLEdBQTdCLENBQVY7QUFFQSxZQUFNdEMsUUFBUW1NLGVBQWVTLFNBQVMzRyxFQUF4QixFQUE0Qm9FLEdBQTVCLENBQWQ7QUFFQSxZQUFNeUQsTUFBTSxJQUFJMUUsTUFBSixFQUFaO0FBQ0E2RCxtQkFBYWpOLEtBQWIsRUFBcUJzTixNQUFELElBQVk7QUFDOUJoTyxnQkFBUUMsR0FBUixDQUFhLGlCQUFnQitOLE1BQU8sRUFBcEM7QUFDQVEsWUFBSWYsTUFBSixDQUFXTyxNQUFYO0FBQ0QsT0FIRDtBQUtBLFlBQU1TLFdBQVdELElBQUlkLElBQUosRUFBakI7QUFFQSxVQUFJL0gsT0FBSjs7QUFFQSxVQUFJOEksYUFBYSxVQUFqQixFQUE0QjtBQUMxQjlJLGtCQUFVdUksbUJBQW1CeE4sS0FBbkIsQ0FBVjtBQUNBVixnQkFBUUMsR0FBUixDQUFZMEYsT0FBWjtBQUNBbkYsY0FBTVUsTUFBTixDQUFhO0FBQUMsNEJBQWlCb00sU0FBUzNHO0FBQTNCLFNBQWIsRUFBNEM7QUFBQ00sZ0JBQUs7QUFBQ3FILDBCQUFhM0ksUUFBUSxDQUFSLEVBQVcrSTtBQUF6QjtBQUFOLFNBQTVDO0FBQ0Q7O0FBRUQsYUFBTy9JLE9BQVA7QUFDRCxLQXhCZSxDQUFoQjtBQTJCQSxXQUFPQSxPQUFQO0FBQ0Q7O0FBeENZLENBQWYsRTs7Ozs7Ozs7Ozs7QUMxTEF0SCxPQUFPQyxNQUFQLENBQWM7QUFBQ3dILGVBQVksTUFBSUE7QUFBakIsQ0FBZDtBQUE2QyxJQUFJcEUsS0FBSjtBQUFVckQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDZ0QsUUFBTS9DLENBQU4sRUFBUTtBQUFDK0MsWUFBTS9DLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUcsWUFBSjtBQUFpQlQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQ0csbUJBQWFILENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFHcEk7QUFFQSxNQUFNbUgsY0FBYyxJQUFJcEUsTUFBTUMsVUFBVixDQUFxQixhQUFyQixDQUFwQixDOzs7Ozs7Ozs7OztBQ0xBdEQsT0FBT0MsTUFBUCxDQUFjO0FBQUNxUSxzQkFBbUIsTUFBSUE7QUFBeEIsQ0FBZDtBQUEyRCxJQUFJblEsTUFBSjtBQUFXSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFNBQU9HLENBQVAsRUFBUztBQUFDSCxhQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlDLGVBQUo7QUFBb0JQLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNFLGtCQUFnQkQsQ0FBaEIsRUFBa0I7QUFBQ0Msc0JBQWdCRCxDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBcEQsRUFBNEYsQ0FBNUY7QUFBK0YsSUFBSUcsWUFBSjtBQUFpQlQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQ0csbUJBQWFILENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSTZCLEtBQUo7QUFBVW5DLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx1Q0FBUixDQUFiLEVBQThEO0FBQUM4QixRQUFNN0IsQ0FBTixFQUFRO0FBQUM2QixZQUFNN0IsQ0FBTjtBQUFROztBQUFsQixDQUE5RCxFQUFrRixDQUFsRjtBQUFxRixJQUFJMkksVUFBSjtBQUFlakosT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDRDQUFSLENBQWIsRUFBbUU7QUFBQzRJLGFBQVczSSxDQUFYLEVBQWE7QUFBQzJJLGlCQUFXM0ksQ0FBWDtBQUFhOztBQUE1QixDQUFuRSxFQUFpRyxDQUFqRztBQUFvRyxJQUFJb0MsTUFBSjtBQUFXMUMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDBDQUFSLENBQWIsRUFBaUU7QUFBQ3FDLFNBQU9wQyxDQUFQLEVBQVM7QUFBQ29DLGFBQU9wQyxDQUFQO0FBQVM7O0FBQXBCLENBQWpFLEVBQXVGLENBQXZGOztBQVUzaUI7Ozs7QUFJQSxNQUFNaVEsY0FBYyxZQUFVO0FBQzdCQyxZQUFVLGNBQVYsRUFENkIsQ0FFN0I7O0FBQ0EsTUFBSTVELE9BQU8sSUFBWDs7QUFDQSxNQUFJLE9BQU9BLEtBQUtySSxVQUFaLEtBQTJCLFdBQS9CLEVBQTJDO0FBQzFDa00sU0FBSyxJQUFMLEVBQVc7QUFBRUMscUJBQWVqTixPQUFPa04sSUFBUCxDQUFZL0QsS0FBS3JJLFVBQWpCO0FBQWpCLEtBQVg7QUFDQTtBQUNELENBUEQ7QUFTQTs7Ozs7Ozs7QUFNQSxNQUFNcU0saUJBQWlCLFVBQVNDLElBQVQsRUFBZTVMLE1BQWYsRUFBc0I7QUFDNUN1TCxZQUFVLGlCQUFWLEVBRDRDLENBRTVDOztBQUNBLFFBQU1NLGtCQUFrQixJQUFJdEwsR0FBSixFQUF4QjtBQUNBUCxTQUFPOEIsT0FBUCxDQUFlckMsU0FBUztBQUN2QkEsVUFBTWdNLGFBQU4sQ0FBb0IzSixPQUFwQixDQUE0QmdLLGdCQUFnQjtBQUMzQ0Qsc0JBQWdCM0osR0FBaEIsQ0FBb0I0SixZQUFwQjtBQUNBLEtBRkQ7QUFHQSxHQUpELEVBSjRDLENBUzVDOztBQUNBLFFBQU1MLGdCQUFnQnZOLE1BQU02TixJQUFOLENBQVdGLGVBQVgsQ0FBdEI7QUFDQSxTQUFPO0FBQUVKLG1CQUFlQTtBQUFqQixHQUFQO0FBQ0EsQ0FaRDs7QUFjTyxNQUFNSixxQkFBcUIsSUFBSS9QLGVBQUosQ0FBb0I7QUFDckRLLFFBQU0sZ0JBRCtDO0FBRXJEQyxZQUFVLElBQUlKLFlBQUosQ0FBaUI7QUFDMUJLLGVBQVc7QUFBRUMsWUFBTUM7QUFBUjtBQURlLEdBQWpCLEVBRVBDLFNBRk8sRUFGMkM7QUFLckRDLGdCQUFjO0FBQ2JDLGFBQVM7QUFESSxHQUx1Qzs7QUFRckRDLE1BQUk7QUFBRU47QUFBRixHQUFKLEVBQWtCO0FBQ2pCYSxZQUFRQyxHQUFSLENBQWEsdUJBQXNCZCxTQUFVLEVBQTdDOztBQUNBLFFBQUksQ0FBRSxLQUFLTyxNQUFYLEVBQW1CO0FBQ2xCLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0E7O0FBQ0QsUUFBSSxDQUFFZCxNQUFNZSxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQStCLFNBQS9CLENBQU4sRUFBZ0Q7QUFDL0MsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQTs7QUFFRCxVQUFNcUIsUUFBUUQsT0FBT0UsT0FBUCxDQUFlO0FBQUM5QixpQkFBV0E7QUFBWixLQUFmLENBQWQsQ0FUaUIsQ0FXakI7O0FBQ0EsUUFBSSxPQUFPNkIsS0FBUCxLQUFpQixXQUFyQixFQUFpQztBQUNoQyxZQUFNLElBQUl4QyxPQUFPbUIsS0FBWCxDQUFrQixrQkFBaUJSLFNBQVUsRUFBN0MsQ0FBTjtBQUNBLEtBZGdCLENBZ0JqQjs7O0FBQ0EsUUFBSyxDQUFDLEtBQUtlLFlBQVgsRUFBeUI7QUFDeEIsV0FBS29QLE9BQUw7QUFDQSxZQUFNQyxtQkFBbUI7QUFDdkJDLGFBQUs7QUFBRUMsa0JBQVE7QUFBVixTQURrQjtBQUV2QjVOLGVBQU87QUFBRWIsaUJBQU83QjtBQUFULFNBRmdCLENBSXpCOztBQUp5QixPQUF6QjtBQUtBYSxjQUFRQyxHQUFSLENBQVksYUFBWjtBQUNBLFlBQU15UCxnQkFBZ0JsUCxNQUFNMEYsYUFBTixHQUNwQnlKLFNBRG9CLENBQ1ZmLFdBRFUsRUFDR0ssY0FESCxFQUNtQk0sZ0JBRG5CLEVBRXBCSyxJQUZvQixDQUVmakssV0FBVztBQUNoQjNGLGdCQUFRQyxHQUFSLENBQVksb0JBQVo7QUFDQTBGLGdCQUFRUCxPQUFSLENBQWlCeUssVUFBVTtBQUMxQixnQkFBTWQsZ0JBQWdCYyxPQUFPOU0sS0FBUCxDQUFhZ00sYUFBbkM7QUFDQUEsd0JBQWMzSixPQUFkLENBQXNCZ0ssZ0JBQWdCO0FBQ3JDOUgsdUJBQVd3SSxhQUFYLENBQXlCO0FBQ3hCak8scUJBQU87QUFDTjVDLHNCQUFNbVE7QUFEQSxlQURpQjtBQUl4QmxPLHNCQUFRO0FBQ1B1RSwyQkFBVztBQUNWc0ssMEJBQVE1USxTQURFO0FBRVY2USw4QkFBWWhQLE1BQU13STtBQUZSLGlCQURKO0FBS1B5Ryw4QkFBYztBQUNiaFIsd0JBQU1tUSxZQURPO0FBRWJ2Tix5QkFBUSxjQUFhdU4sWUFBYSxFQUZyQjtBQUdiYyx3QkFBTSxJQUhPO0FBSWJDLDJCQUFTLEtBSkk7QUFLYkMsNEJBQVU7QUFMRztBQUxQLGVBSmdCO0FBaUJ4QkMsbUJBQUssSUFqQm1CO0FBa0J4QkMsc0JBQVE7QUFsQmdCLGFBQXpCO0FBb0JBLFdBckJEO0FBc0JBLFNBeEJEO0FBeUJBLE9BN0JvQixFQThCcEJDLEtBOUJvQixDQThCZGxLLE9BQU87QUFDYnJHLGdCQUFRQyxHQUFSLENBQVlvRyxHQUFaO0FBQ0EsY0FBTSxJQUFJN0gsT0FBT21CLEtBQVgsQ0FBaUIwRyxHQUFqQixDQUFOO0FBQ0EsT0FqQ29CLENBQXRCO0FBa0NBLGFBQU8sSUFBUDtBQUNBO0FBQ0Q7O0FBckVvRCxDQUFwQixDQUEzQixDOzs7Ozs7Ozs7OztBQzNDUGhJLE9BQU9DLE1BQVAsQ0FBYztBQUFDa1MsVUFBTyxNQUFJQTtBQUFaLENBQWQ7QUFBbUMsSUFBSWhTLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxlQUFKO0FBQW9CUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDRSxrQkFBZ0JELENBQWhCLEVBQWtCO0FBQUNDLHNCQUFnQkQsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXBELEVBQTRGLENBQTVGO0FBQStGLElBQUlHLFlBQUo7QUFBaUJULE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUNHLG1CQUFhSCxDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBQXFFLElBQUk4UixNQUFKO0FBQVdwUyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDOFIsYUFBTzlSLENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSStSLElBQUo7QUFBU3JTLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxXQUFSLENBQWIsRUFBa0M7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUMrUixXQUFLL1IsQ0FBTDtBQUFPOztBQUFuQixDQUFsQyxFQUF1RCxDQUF2RDtBQUEwRCxJQUFJNEQsRUFBSjtBQUFPbEUsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLElBQVIsQ0FBYixFQUEyQjtBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQzRELFNBQUc1RCxDQUFIO0FBQUs7O0FBQWpCLENBQTNCLEVBQThDLENBQTlDO0FBQWlELElBQUlnUyxTQUFKO0FBQWN0UyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsa0JBQVIsQ0FBYixFQUF5QztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQ2dTLGdCQUFVaFMsQ0FBVjtBQUFZOztBQUF4QixDQUF6QyxFQUFtRSxDQUFuRTtBQUFzRSxJQUFJaVMsT0FBSjtBQUFZdlMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGdCQUFSLENBQWIsRUFBdUM7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUNpUyxjQUFRalMsQ0FBUjtBQUFVOztBQUF0QixDQUF2QyxFQUErRCxDQUEvRDtBQUFrRSxJQUFJa1MsT0FBSjtBQUFZeFMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGdCQUFSLENBQWIsRUFBdUM7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUNrUyxjQUFRbFMsQ0FBUjtBQUFVOztBQUF0QixDQUF2QyxFQUErRCxDQUEvRDtBQUFrRSxJQUFJbVMsU0FBSjtBQUFjelMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGtCQUFSLENBQWIsRUFBeUM7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUNtUyxnQkFBVW5TLENBQVY7QUFBWTs7QUFBeEIsQ0FBekMsRUFBbUUsQ0FBbkU7QUFBc0UsSUFBSW9TLFdBQUo7QUFBZ0IxUyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDb1Msa0JBQVlwUyxDQUFaO0FBQWM7O0FBQTFCLENBQXBDLEVBQWdFLEVBQWhFO0FBQW9FLElBQUk2QixLQUFKLEVBQVV1SCxVQUFWLEVBQXFCQyxnQkFBckI7QUFBc0MzSixPQUFPSSxLQUFQLENBQWFDLFFBQVEsdUNBQVIsQ0FBYixFQUE4RDtBQUFDOEIsUUFBTTdCLENBQU4sRUFBUTtBQUFDNkIsWUFBTTdCLENBQU47QUFBUSxHQUFsQjs7QUFBbUJvSixhQUFXcEosQ0FBWCxFQUFhO0FBQUNvSixpQkFBV3BKLENBQVg7QUFBYSxHQUE5Qzs7QUFBK0NxSixtQkFBaUJySixDQUFqQixFQUFtQjtBQUFDcUosdUJBQWlCckosQ0FBakI7QUFBbUI7O0FBQXRGLENBQTlELEVBQXNKLEVBQXRKO0FBQTBKLElBQUlxTixVQUFKLEVBQWVnRixhQUFmO0FBQTZCM1MsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDhDQUFSLENBQWIsRUFBcUU7QUFBQ3NOLGFBQVdyTixDQUFYLEVBQWE7QUFBQ3FOLGlCQUFXck4sQ0FBWDtBQUFhLEdBQTVCOztBQUE2QnFTLGdCQUFjclMsQ0FBZCxFQUFnQjtBQUFDcVMsb0JBQWNyUyxDQUFkO0FBQWdCOztBQUE5RCxDQUFyRSxFQUFxSSxFQUFySTtBQUF5SSxJQUFJb0MsTUFBSjtBQUFXMUMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDBDQUFSLENBQWIsRUFBaUU7QUFBQ3FDLFNBQU9wQyxDQUFQLEVBQVM7QUFBQ29DLGFBQU9wQyxDQUFQO0FBQVM7O0FBQXBCLENBQWpFLEVBQXVGLEVBQXZGO0FBQTJGLElBQUlnUSxrQkFBSjtBQUF1QnRRLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx1Q0FBUixDQUFiLEVBQThEO0FBQUNpUSxxQkFBbUJoUSxDQUFuQixFQUFxQjtBQUFDZ1EseUJBQW1CaFEsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQTlELEVBQTRHLEVBQTVHOztBQW1CaDNDOzs7OztBQUtBb1MsWUFBWUUsUUFBWixHQUF1QkMsT0FBT0EsR0FBOUI7QUFFQTs7Ozs7O0FBSUEsTUFBTUMsV0FBVyxNQUFNQSxRQUFOLENBQWM7QUFDOUJDLGNBQVk7QUFBRS9NLFFBQUY7QUFBUWxGLGFBQVI7QUFBbUJrUyxpQkFBbkI7QUFBbUNDO0FBQW5DLEdBQVosRUFBb0U7QUFDbkViLFdBQU9jLEtBQVAsQ0FBYWxOLEtBQUtpSSxNQUFsQixFQUF5QixDQUF6QjtBQUNBLFVBQU0sQ0FDTDdDLEtBREssRUFFTDlFLE1BRkssRUFHTHZGLElBSEssRUFJTHdGLEtBSkssRUFLTEMsR0FMSyxFQU1MQyxLQU5LLEVBT0xDLE1BUEssRUFRTEMsS0FSSyxFQVNMcEMsVUFUSyxJQVVGeUIsSUFWSjtBQVlBLFNBQUtqRixJQUFMLEdBQVlBLElBQVo7QUFDQSxTQUFLd0YsS0FBTCxHQUFhQSxLQUFiO0FBQ0EsU0FBS0MsR0FBTCxHQUFXQSxHQUFYO0FBQ0EsU0FBS0MsS0FBTCxHQUFhekYsT0FBT3lGLEtBQVAsQ0FBYjtBQUNBLFNBQUtsQyxVQUFMLEdBQWtCSixpQkFBaUJJLFVBQWpCLENBQWxCO0FBRUEsU0FBSytELEVBQUwsR0FBVSxLQUFLL0QsVUFBTCxDQUFnQitELEVBQWhCLENBQW1CLENBQW5CLENBQVY7QUFDQSxXQUFPLEtBQUsvRCxVQUFMLENBQWdCK0QsRUFBdkI7O0FBRUEsUUFBSSxLQUFLL0QsVUFBTCxDQUFnQjRPLE1BQWhCLEtBQTJCQyxTQUEvQixFQUF5QztBQUN4QyxXQUFLMUksT0FBTCxHQUFlLEtBQUtuRyxVQUFMLENBQWdCNE8sTUFBL0I7QUFDQSxhQUFPLEtBQUs1TyxVQUFMLENBQWdCNE8sTUFBdkI7QUFDQTs7QUFFRCxTQUFLbEosR0FBTCxHQUFXZ0osbUJBQW1CN0gsS0FBbkIsRUFBMEJrRCxLQUExQixDQUFnQy9ILFFBQVEsQ0FBeEMsRUFBMkNDLEdBQTNDLENBQVg7O0FBQ0EsUUFBSSxLQUFLekYsSUFBTCxLQUFjLE1BQWxCLEVBQXlCO0FBQ3ZCLFdBQUtxSyxLQUFMLEdBQWFBLEtBQWI7QUFDQSxXQUFLOUUsTUFBTCxHQUFjQSxNQUFkO0FBQ0EsV0FBS0ksTUFBTCxHQUFjQSxNQUFkO0FBQ0EsV0FBS3lFLFNBQUwsR0FBaUI2SCxhQUFqQjtBQUNBLFdBQUtyUSxLQUFMLEdBQWE3QixTQUFiO0FBQ0EsV0FBS3VLLFdBQUwsR0FBa0IsQ0FBQyxPQUFELENBQWxCO0FBQ0QzQixpQkFBVzdJLFFBQVgsQ0FBb0IsSUFBcEI7QUFDQSxLQVJELE1BUU87QUFDTixXQUFLOEYsS0FBTCxHQUFhQSxLQUFiO0FBQ0FnRCx1QkFBaUI5SSxRQUFqQixDQUEwQixJQUExQjtBQUNBO0FBQ0Q7O0FBMUM2QixDQUEvQjtBQTZDQTs7Ozs7QUFJQSxNQUFNd1MsWUFBWSxNQUFNQSxTQUFOLENBQWU7QUFDaENOLGNBQVlPLFNBQVosRUFBc0I7QUFDckIzUixZQUFRQyxHQUFSLENBQVksd0JBQVo7QUFDQTZCLFdBQU93QixNQUFQLENBQWNxTyxTQUFkLEVBQXlCdk0sT0FBekIsQ0FBa0N3TSxZQUFZO0FBQzdDLFVBQUlBLFNBQVM3SSxPQUFULEtBQXFCMEksU0FBekIsRUFBbUM7QUFDbENHLGlCQUFTN0ksT0FBVCxDQUFpQjNELE9BQWpCLENBQTBCeU0sWUFBWTtBQUNyQyxjQUFJQyxTQUFTSCxVQUFVRSxRQUFWLENBQWI7O0FBQ0EsY0FBSUMsT0FBT2xKLFFBQVAsS0FBb0I2SSxTQUF4QixFQUFrQztBQUNqQ0Usc0JBQVVFLFFBQVYsRUFBb0JqSixRQUFwQixHQUErQixFQUEvQjtBQUNBOztBQUNEK0ksb0JBQVVFLFFBQVYsRUFBb0JqSixRQUFwQixDQUE2Qm1KLElBQTdCLENBQWtDSCxTQUFTakwsRUFBM0M7QUFDQSxTQU5EO0FBT0E7QUFDRCxLQVZEO0FBV0EsVUFBTUUsUUFBUS9FLE9BQU93QixNQUFQLENBQWNxTyxTQUFkLEVBQXlCeEcsTUFBekIsQ0FBaUN5RyxZQUFZO0FBQzFELGFBQU9BLFNBQVN4UyxJQUFULEtBQWtCLE1BQXpCO0FBQ0EsS0FGYSxDQUFkO0FBR0FxUixXQUFPYyxLQUFQLENBQWExSyxNQUFNeUYsTUFBbkIsRUFBMkIsQ0FBM0I7QUFDQSxVQUFNckIsT0FBT3BFLE1BQU0sQ0FBTixDQUFiO0FBRUE3RyxZQUFRQyxHQUFSLENBQVlnTCxLQUFLdEUsRUFBakI7QUFFQTdFLFdBQU9rTixJQUFQLENBQVkvRCxJQUFaLEVBQWtCN0YsT0FBbEIsQ0FBMEJ0QyxPQUFPO0FBQ2hDLFdBQUtBLEdBQUwsSUFBWW1JLEtBQUtuSSxHQUFMLENBQVo7QUFDQSxLQUZEO0FBSUEsU0FBS3lHLFdBQUwsR0FBbUJ6SCxPQUFPd0IsTUFBUCxDQUFjcU8sU0FBZCxFQUF5QnhHLE1BQXpCLENBQWlDeUcsWUFBWTtBQUMvRCxhQUFPQSxTQUFTeFMsSUFBVCxLQUFrQixNQUF6QjtBQUNBLEtBRmtCLENBQW5CO0FBR0E7O0FBN0IrQixDQUFqQztBQWdDQTs7Ozs7Ozs7OztBQVNPLE1BQU1vUixTQUFTLElBQUk1UixlQUFKLENBQW9CO0FBQ3pDSyxRQUFNLFFBRG1DO0FBRXpDQyxZQUFVLElBQUlKLFlBQUosQ0FBaUI7QUFDMUJ5RSxjQUFVO0FBQUVuRSxZQUFNQztBQUFSLEtBRGdCO0FBRTFCZ1MsbUJBQWU7QUFBRWpTLFlBQU1DO0FBQVIsS0FGVztBQUcxQkYsZUFBVztBQUFFQyxZQUFNQztBQUFSO0FBSGUsR0FBakIsRUFJUEMsU0FKTyxFQUYrQjtBQU96Q0MsZ0JBQWM7QUFDYkMsYUFBUztBQURJLEdBUDJCOztBQVV6Q0MsTUFBSTtBQUFFOEQsWUFBRjtBQUFZOE4saUJBQVo7QUFBMkJsUztBQUEzQixHQUFKLEVBQTJDO0FBQzFDLFFBQUksQ0FBRSxLQUFLTyxNQUFYLEVBQW1CO0FBQ2xCLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0E7O0FBQ0QsUUFBSSxDQUFFZCxNQUFNZSxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQStCLFNBQS9CLENBQU4sRUFBZ0Q7QUFDL0MsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQTs7QUFFRCxVQUFNcVMsZ0JBQWdCalIsT0FBT2dHLElBQVAsQ0FBWTtBQUFFNUgsaUJBQVdBO0FBQWIsS0FBWixFQUFzQ2tOLEtBQXRDLEdBQThDQyxNQUFwRTs7QUFDQSxRQUFJMEYsYUFBSixFQUFrQjtBQUNqQixZQUFNLElBQUl4VCxPQUFPbUIsS0FBWCxDQUFpQixtQkFBbUJSLFNBQXBDLENBQU47QUFDQTs7QUFFRCxVQUFNOFMsb0JBQW9CakcsV0FBV2pGLElBQVgsQ0FBZ0I7QUFBRXNLLHFCQUFlQTtBQUFqQixLQUFoQixFQUFrRGhGLEtBQWxELEdBQTBEQyxNQUFwRjs7QUFDQSxRQUFJLENBQUMyRixpQkFBTCxFQUF1QjtBQUN0QixZQUFNLElBQUl6VCxPQUFPbUIsS0FBWCxDQUFpQix3QkFBd0IwUixhQUF6QyxDQUFOO0FBQ0E7O0FBRUQsVUFBTTVOLGFBQWFsQixHQUFHbUIsWUFBSCxDQUFnQkgsUUFBaEIsRUFBeUI7QUFBQ0ksZ0JBQVM7QUFBVixLQUF6QixDQUFuQjtBQUVBLFFBQUlnTyxZQUFZLEVBQWhCO0FBQ0EsUUFBSU8sWUFBWSxDQUFoQjtBQUVBbFMsWUFBUUMsR0FBUixDQUFhLHFDQUFvQ29SLGFBQWMsRUFBL0Q7QUFDQSxVQUFNQyxxQkFBcUJhLHNCQUFzQmQsYUFBdEIsQ0FBM0I7QUFFQXJSLFlBQVFDLEdBQVIsQ0FBWSxlQUFaO0FBQ0F5USxTQUFLNU0sS0FBTCxDQUFXTCxVQUFYLEVBQXVCO0FBQ3RCTSxpQkFBVyxJQURXO0FBRXRCQyxxQkFBZSxJQUZPO0FBR3RCQyxzQkFBZ0IsSUFITTtBQUl0Qm1PLGdCQUFVLEdBSlk7O0FBS3RCbE8sWUFBTUEsS0FBTixFQUFZQyxJQUFaLEVBQWtCO0FBQ2pCbkUsZ0JBQVFDLEdBQVIsQ0FBWWlFLEtBQVo7QUFDQSxPQVBxQjs7QUFRdEJFLFdBQUtDLElBQUwsRUFBVTtBQUNULFlBQUl1TixXQUFXLElBQUlULFFBQUosQ0FBYTtBQUMzQjlNLGdCQUFNQSxLQUFLRSxJQUFMLENBQVUsQ0FBVixDQURxQjtBQUUzQjhNLHlCQUFlQSxhQUZZO0FBRzNCbFMscUJBQVdBLFNBSGdCO0FBSTNCbVMsOEJBQW9CQTtBQUpPLFNBQWIsQ0FBZjs7QUFPQSxZQUFJTSxTQUFTN0ksT0FBVCxLQUFxQjBJLFNBQXpCLEVBQW1DO0FBQ2xDaEIsaUJBQU9jLEtBQVAsQ0FBYUssU0FBU3hTLElBQXRCLEVBQTRCLE1BQTVCOztBQUNBLGNBQUssQ0FBQ3lSLFFBQVFjLFNBQVIsQ0FBTixFQUEyQjtBQUMxQixrQkFBTTFHLE9BQU8sSUFBSXlHLFNBQUosQ0FBY0MsU0FBZCxDQUFiO0FBQ0E1Six1QkFBVzdJLFFBQVgsQ0FBb0IrTCxJQUFwQjtBQUNBekssa0JBQU1rRyxNQUFOLENBQWF1RSxJQUFiO0FBQ0FpSCx5QkFBYSxDQUFiO0FBQ0FQLHdCQUFZLEVBQVo7QUFDQTtBQUNEOztBQUNEQSxrQkFBVUMsU0FBU2pMLEVBQW5CLElBQXlCaUwsUUFBekI7QUFDQSxPQTNCcUI7O0FBNEJ0QmxNLGVBQVNDLE9BQVQsRUFBaUJ4QixJQUFqQixFQUF1QjtBQUV0QixZQUFLLENBQUMwTSxRQUFRYyxTQUFSLENBQU4sRUFBMkI7QUFDMUIzUixrQkFBUUMsR0FBUixDQUFZLHlCQUFaO0FBQ0EsZ0JBQU1nTCxPQUFPLElBQUl5RyxTQUFKLENBQWNDLFNBQWQsQ0FBYjtBQUNBNUoscUJBQVc3SSxRQUFYLENBQW9CK0wsSUFBcEI7QUFDQXpLLGdCQUFNa0csTUFBTixDQUFhdUUsSUFBYjtBQUNBaUgsdUJBQWEsQ0FBYjtBQUNBUCxzQkFBWSxFQUFaO0FBQ0E7O0FBRUQ1USxlQUFPMkYsTUFBUCxDQUFjO0FBQ2J2SCxxQkFBV0EsU0FERTtBQUVicUsscUJBQVc2SCxhQUZFO0FBR2JhLHFCQUFXQSxTQUhFO0FBSWJ4SSx1QkFBYSxDQUFDLE9BQUQ7QUFKQSxTQUFkO0FBT0FpRiwyQkFBbUIwRCxJQUFuQixDQUF3QjtBQUFFbFQscUJBQVdBO0FBQWIsU0FBeEI7QUFDQTs7QUEvQ3FCLEtBQXZCO0FBaURBLFdBQU8sSUFBUDtBQUNBOztBQXZGd0MsQ0FBcEIsQ0FBZjs7QUEwRlA7Ozs7O0FBS0EsTUFBTWdULHdCQUF5QmQsYUFBRCxJQUFtQjtBQUNoRCxRQUFNaUIsVUFBVXRHLFdBQVdqRixJQUFYLENBQWdCO0FBQy9Cc0ssbUJBQWVBO0FBRGdCLEdBQWhCLEVBRWQ7QUFDRGtCLFlBQVE7QUFDUHRHLGNBQVE7QUFERDtBQURQLEdBRmMsRUFNYmhKLEdBTmEsQ0FNVHVHLGFBQWFBLFVBQVV5QyxNQU5kLEVBTXNCdEosTUFOdEIsQ0FNNkIsQ0FBQzJQLE9BQUQsRUFBVXJHLE1BQVYsS0FBcUI7QUFDakUsUUFBSXFHLFFBQVF4SCxPQUFSLENBQWdCbUIsTUFBaEIsSUFBMEIsQ0FBOUIsRUFBZ0M7QUFDL0JxRyxjQUFRUCxJQUFSLENBQWE5RixNQUFiO0FBQ0E7O0FBQ0QsV0FBT3FHLE9BQVA7QUFDQSxHQVhlLEVBV2QsRUFYYyxDQUFoQjtBQWFBLFFBQU1oQixxQkFBcUJnQixRQUFRM1AsTUFBUixDQUFlLENBQUMwSSxTQUFELEVBQVlZLE1BQVosS0FBdUI7QUFDaEUsVUFBTXFCLFdBQVd0QixXQUFXakYsSUFBWCxDQUFnQjtBQUNoQ3NLLHFCQUFlQSxhQURpQjtBQUVoQ3BGLGNBQVFBO0FBRndCLEtBQWhCLEVBR2Y7QUFDRE4sWUFBTTtBQUNML0csZUFBTztBQURGO0FBREwsS0FIZSxFQU9kM0IsR0FQYyxDQU9Uc0osT0FBT0EsSUFBSWpFLEdBUEYsRUFPT3RGLElBUFAsQ0FPWSxFQVBaLENBQWpCO0FBUUFxSSxjQUFVWSxNQUFWLElBQW9CcUIsUUFBcEI7QUFDQSxXQUFPakMsU0FBUDtBQUNBLEdBWDBCLEVBV3pCLEVBWHlCLENBQTNCO0FBWUEsU0FBT2lHLGtCQUFQO0FBQ0EsQ0EzQkQ7QUE2QkE7Ozs7Ozs7QUFLQSxNQUFNOU8sbUJBQW9CQyxlQUFELElBQXFCO0FBQzdDLFNBQU9BLGdCQUFnQkMsS0FBaEIsQ0FBc0IsR0FBdEIsRUFBMkJDLE1BQTNCLENBQWtDLENBQUNDLFVBQUQsRUFBYUMsVUFBYixLQUE0QjtBQUNwRSxVQUFNLENBQUNDLEdBQUQsRUFBTUMsS0FBTixJQUFlRixXQUFXSCxLQUFYLENBQWlCLEdBQWpCLENBQXJCO0FBQ0FFLGVBQVdFLEdBQVgsSUFBa0JDLE1BQU1MLEtBQU4sQ0FBWSxHQUFaLEVBQWlCTyxHQUFqQixDQUFxQkMsa0JBQXJCLENBQWxCO0FBQ0EsV0FBT04sVUFBUDtBQUNBLEdBSk0sRUFJSixFQUpJLENBQVA7QUFLQSxDQU5ELEM7Ozs7Ozs7Ozs7O0FDelBBdkUsT0FBT0MsTUFBUCxDQUFjO0FBQUNrVSxnQkFBYSxNQUFJQTtBQUFsQixDQUFkO0FBQStDLElBQUk1VCxlQUFKO0FBQW9CUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDRSxrQkFBZ0JELENBQWhCLEVBQWtCO0FBQUNDLHNCQUFnQkQsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXBELEVBQTRGLENBQTVGO0FBQStGLElBQUlILE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJRyxZQUFKO0FBQWlCVCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDRyxtQkFBYUgsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJNEQsRUFBSjtBQUFPbEUsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLElBQVIsQ0FBYixFQUEyQjtBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQzRELFNBQUc1RCxDQUFIO0FBQUs7O0FBQWpCLENBQTNCLEVBQThDLENBQTlDO0FBQWlELElBQUk4VCxRQUFKO0FBQWFwVSxPQUFPSSxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDOFQsZUFBUzlULENBQVQ7QUFBVzs7QUFBdkIsQ0FBakMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSStULEtBQUo7QUFBVXJVLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUMrVCxZQUFNL1QsQ0FBTjtBQUFROztBQUFwQixDQUEvQixFQUFxRCxDQUFyRDtBQUF3RCxJQUFJbUwsTUFBSjtBQUFXekwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQ21MLGFBQU9uTCxDQUFQO0FBQVM7O0FBQXJCLENBQXRDLEVBQTZELENBQTdEO0FBQWdFLElBQUlxUyxhQUFKLEVBQWtCaEYsVUFBbEI7QUFBNkIzTixPQUFPSSxLQUFQLENBQWFDLFFBQVEsOENBQVIsQ0FBYixFQUFxRTtBQUFDc1MsZ0JBQWNyUyxDQUFkLEVBQWdCO0FBQUNxUyxvQkFBY3JTLENBQWQ7QUFBZ0IsR0FBbEM7O0FBQW1DcU4sYUFBV3JOLENBQVgsRUFBYTtBQUFDcU4saUJBQVdyTixDQUFYO0FBQWE7O0FBQTlELENBQXJFLEVBQXFJLENBQXJJO0FBVzltQixNQUFNZ1Usa0JBQWtCLElBQUk3VCxZQUFKLENBQWlCO0FBQ3hDeUUsWUFBVTtBQUFFbkUsVUFBTUM7QUFBUixHQUQ4QjtBQUV4Q2dTLGlCQUFlO0FBQUVqUyxVQUFNQztBQUFSO0FBRnlCLENBQWpCLENBQXhCO0FBS08sTUFBTW1ULGVBQWUsSUFBSTVULGVBQUosQ0FBb0I7QUFDL0NLLFFBQU0sY0FEeUM7QUFFL0NDLFlBQVV5VCxnQkFBZ0JyVCxTQUFoQixFQUZxQztBQUcvQ0MsZ0JBQWM7QUFDYkMsYUFBUztBQURJLEdBSGlDOztBQU0vQ0MsTUFBSTtBQUFFOEQsWUFBRjtBQUFZOE47QUFBWixHQUFKLEVBQWlDO0FBQ2hDLFFBQUksQ0FBRSxLQUFLM1IsTUFBWCxFQUFtQjtBQUNsQixZQUFNLElBQUlsQixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBOztBQUNELFFBQUksQ0FBRWQsTUFBTWUsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUErQixTQUEvQixDQUFOLEVBQWdEO0FBQy9DLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0E7O0FBRUQsVUFBTXNTLG9CQUFvQmpCLGNBQWNqSyxJQUFkLENBQW1CO0FBQUNzSyxxQkFBZUE7QUFBaEIsS0FBbkIsRUFBbURoRixLQUFuRCxHQUEyREMsTUFBckY7O0FBQ0EsUUFBSTJGLGlCQUFKLEVBQXNCO0FBQ3JCLFlBQU0sSUFBSXpULE9BQU9tQixLQUFYLENBQWlCLHlCQUF5QjBSLGFBQTFDLENBQU47QUFDQTs7QUFFRCxVQUFNdUIsYUFBYUgsU0FBU0ksZUFBVCxDQUF5QjtBQUMzQ3ZSLGFBQU9pQixHQUFHdVEsZ0JBQUgsQ0FBb0J2UCxRQUFwQixFQUE4QixNQUE5QjtBQURvQyxLQUF6QixDQUFuQjtBQUlBLFVBQU13UCxTQUFTL0csV0FBVzlGLGFBQVgsR0FBMkJDLHlCQUEzQixFQUFmO0FBRUEsUUFBSW1DLE1BQU0sRUFBVjtBQUNBLFFBQUkyRCxNQUFKO0FBQ0EsUUFBSXJILFFBQVEsQ0FBWjtBQUNBLFFBQUlDLE1BQU0sQ0FBVjtBQUNBLFVBQU1tTyxZQUFZLEtBQWxCO0FBRUEsVUFBTXhFLE1BQU0sSUFBSTFFLE1BQUosRUFBWjtBQUNBOUosWUFBUUMsR0FBUixDQUFZLGVBQVo7QUFDQTJTLGVBQVdLLEVBQVgsQ0FBYyxNQUFkLEVBQXVCNU8sSUFBRCxJQUFVO0FBQy9CLFVBQUlBLEtBQUssQ0FBTCxNQUFZLEdBQWhCLEVBQW9CO0FBQ25CLFlBQUk0SCxXQUFXd0YsU0FBZixFQUF5QjtBQUN4QnpSLGtCQUFRQyxHQUFSLENBQVlnTSxNQUFaOztBQUNBLGNBQUkzRCxJQUFJZ0UsTUFBSixHQUFhLENBQWpCLEVBQW1CO0FBQ2xCekgsbUJBQU95RCxJQUFJZ0UsTUFBWDtBQUNBLGdCQUFJb0csS0FBSixDQUFVLE1BQUk7QUFDYjFHLHlCQUFXdEYsTUFBWCxDQUFrQjtBQUNqQnVGLHdCQUFRQSxNQURTO0FBRWpCM0QscUJBQUtBLEdBRlk7QUFHakIxRCx1QkFBT0EsS0FIVTtBQUlqQkMscUJBQUtBLEdBSlk7QUFLakJ3TSwrQkFBZUEsYUFMRTtBQU1qQjNILDZCQUFhLENBQUMsT0FBRDtBQU5JLGVBQWxCO0FBUUEsYUFURCxFQVNHakssR0FUSDtBQVVBO0FBQ0Q7O0FBQ0R3TSxpQkFBUzVILEtBQUszQixLQUFMLENBQVcsR0FBWCxFQUFnQixDQUFoQixFQUFtQkEsS0FBbkIsQ0FBeUIsR0FBekIsRUFBOEIsQ0FBOUIsQ0FBVDtBQUNBNEYsY0FBTSxFQUFOO0FBQ0ExRCxnQkFBUSxDQUFSO0FBQ0FDLGNBQU0sQ0FBTjtBQUVBLE9BdEJELE1Bc0JPO0FBQ055RCxlQUFPakUsSUFBUDs7QUFDQSxZQUFLaUUsSUFBSWdFLE1BQUosR0FBYTBHLFNBQWxCLEVBQTZCO0FBQzVCbk8saUJBQU9tTyxTQUFQO0FBQ0EsY0FBSU4sS0FBSixDQUFVLE1BQUk7QUFDYjFHLHVCQUFXdEYsTUFBWCxDQUFrQjtBQUNqQnVGLHNCQUFRQSxNQURTO0FBRWpCM0QsbUJBQUtBLElBQUk0SyxTQUFKLENBQWMsQ0FBZCxFQUFnQkYsU0FBaEIsQ0FGWTtBQUdqQnBPLHFCQUFPQSxLQUhVO0FBSWpCQyxtQkFBS0EsR0FKWTtBQUtqQndNLDZCQUFlQSxhQUxFO0FBTWpCM0gsMkJBQWEsQ0FBQyxPQUFEO0FBTkksYUFBbEI7QUFRQSxXQVRELEVBU0dqSyxHQVRIO0FBVUE2SSxnQkFBTUEsSUFBSTRLLFNBQUosQ0FBY0YsU0FBZCxDQUFOO0FBQ0FwTyxtQkFBU29PLFNBQVQ7QUFDQTtBQUNEO0FBQ0QsS0F6Q0Q7QUEyQ0FKLGVBQVdLLEVBQVgsQ0FBYyxPQUFkLEVBQXVCLE1BQU07QUFDNUJwTyxhQUFPeUQsSUFBSWdFLE1BQVg7QUFDQSxVQUFJb0csS0FBSixDQUFVLE1BQUk7QUFDYjFHLG1CQUFXdEYsTUFBWCxDQUFrQjtBQUNqQnVGLGtCQUFRQSxNQURTO0FBRWpCM0QsZUFBS0EsR0FGWTtBQUdqQjFELGlCQUFPQSxLQUhVO0FBSWpCQyxlQUFLQSxHQUpZO0FBS2pCd00seUJBQWVBLGFBTEU7QUFNakIzSCx1QkFBYSxDQUFDLE9BQUQ7QUFOSSxTQUFsQjtBQVFBc0gsc0JBQWN0SyxNQUFkLENBQXFCO0FBQ3BCMksseUJBQWVBLGFBREs7QUFFcEIzSCx1QkFBYSxDQUFDLE9BQUQsQ0FGTztBQUdwQnlKLHVCQUFhLGFBSE87QUFJcEJDLG9CQUFVO0FBSlUsU0FBckI7QUFNQXBULGdCQUFRQyxHQUFSLENBQVksa0JBQVo7QUFFQXVPLFlBQUlmLE1BQUosQ0FBVyxDQUFYO0FBQ0EsT0FsQkQsRUFrQkdoTyxHQWxCSDtBQXFCQSxLQXZCRDtBQXdCQSxXQUFPK08sSUFBSWQsSUFBSixFQUFQO0FBQ0E7O0FBckc4QyxDQUFwQixDQUFyQixDOzs7Ozs7Ozs7OztBQ2hCUHJQLE9BQU9DLE1BQVAsQ0FBYztBQUFDME4sY0FBVyxNQUFJQSxVQUFoQjtBQUEyQnFILG1CQUFnQixNQUFJQSxlQUEvQztBQUErRHJDLGlCQUFjLE1BQUlBLGFBQWpGO0FBQStGc0MsdUJBQW9CLE1BQUlBO0FBQXZILENBQWQ7QUFBMkosSUFBSTVSLEtBQUo7QUFBVXJELE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ2dELFFBQU0vQyxDQUFOLEVBQVE7QUFBQytDLFlBQU0vQyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlHLFlBQUo7QUFBaUJULE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUNHLG1CQUFhSCxDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBR2xQLE1BQU1xTixhQUFhLElBQUl0SyxNQUFNQyxVQUFWLENBQXFCLFlBQXJCLENBQW5CO0FBRUEsTUFBTTBSLGtCQUFrQixJQUFJdlUsWUFBSixDQUFpQjtBQUN4Q21OLFVBQVE7QUFDUDdNLFVBQU1DLE1BREM7QUFFUDhJLFdBQU8sSUFGQTtBQUdQQyxXQUFPO0FBSEEsR0FEZ0M7QUFNeENFLE9BQUs7QUFDSmxKLFVBQU1DLE1BREY7QUFFSitJLFdBQU87QUFGSCxHQU5tQztBQVV4Q2lKLGlCQUFlO0FBQ2RqUyxVQUFNQyxNQURRO0FBRWQ4SSxXQUFPLElBRk87QUFHZEMsV0FBTztBQUhPLEdBVnlCO0FBZXhDeEQsU0FBTztBQUNOeEYsVUFBTThDLE1BREE7QUFFTmlHLFdBQU8sSUFGRDtBQUdOQyxXQUFPO0FBSEQsR0FmaUM7QUFvQnhDdkQsT0FBSztBQUNKekYsVUFBTThDLE1BREY7QUFFSmlHLFdBQU8sSUFGSDtBQUdKQyxXQUFPO0FBSEgsR0FwQm1DO0FBeUJ4Q3NCLGVBQWE7QUFDWnRLLFVBQU1vQyxLQURNO0FBQ0E7QUFDWjRHLFdBQU87QUFGSyxHQXpCMkI7QUE2QnhDLG1CQUFrQjtBQUNqQmhKLFVBQU1DO0FBRFc7QUE3QnNCLENBQWpCLENBQXhCO0FBa0NBMk0sV0FBV3JDLFlBQVgsQ0FBd0IwSixlQUF4QjtBQUVBLE1BQU1yQyxnQkFBZ0IsSUFBSXRQLE1BQU1DLFVBQVYsQ0FBcUIsZUFBckIsQ0FBdEI7QUFFQSxNQUFNMlIsc0JBQXNCLElBQUl4VSxZQUFKLENBQWlCO0FBQzVDdVMsaUJBQWU7QUFDZGpTLFVBQU1DLE1BRFE7QUFFZCtJLFdBQU8sZ0JBRk87QUFHZEQsV0FBTyxJQUhPO0FBSWRELFlBQVE7QUFKTSxHQUQ2QjtBQU81Q3dCLGVBQWE7QUFDWnRLLFVBQU1vQyxLQURNO0FBQ0E7QUFDWjRHLFdBQU87QUFGSyxHQVArQjtBQVc1QyxtQkFBaUI7QUFDaEJoSixVQUFNQztBQURVLEdBWDJCO0FBYzVDOFQsZUFBYTtBQUNaL1QsVUFBTUMsTUFETTtBQUVaK0ksV0FBTztBQUZLLEdBZCtCO0FBa0I1Q2dMLFlBQVU7QUFDVGhVLFVBQU1DLE1BREc7QUFFVCtJLFdBQU87QUFGRTtBQWxCa0MsQ0FBakIsQ0FBNUI7QUF3QkE0SSxjQUFjckgsWUFBZCxDQUEyQjJKLG1CQUEzQixFOzs7Ozs7Ozs7OztBQ25FQWpWLE9BQU9DLE1BQVAsQ0FBYztBQUFDeUMsVUFBTyxNQUFJQSxNQUFaO0FBQW1Cd1MsZUFBWSxNQUFJQTtBQUFuQyxDQUFkO0FBQStELElBQUk3UixLQUFKO0FBQVVyRCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNnRCxRQUFNL0MsQ0FBTixFQUFRO0FBQUMrQyxZQUFNL0MsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRyxZQUFKO0FBQWlCVCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDRyxtQkFBYUgsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUd0SixNQUFNb0MsU0FBUyxJQUFJVyxNQUFNQyxVQUFWLENBQXFCLFFBQXJCLENBQWY7QUFFQSxNQUFNNFIsY0FBYyxJQUFJelUsWUFBSixDQUFpQjtBQUNwQ0ssYUFBVztBQUNWQyxVQUFNQyxNQURJO0FBRVIrSSxXQUFPO0FBRkMsR0FEeUI7QUFLcENvQixhQUFXO0FBQ1ZwSyxVQUFNQyxNQURJO0FBRVIrSSxXQUFPO0FBRkMsR0FMeUI7QUFTbkNvTCxZQUFVO0FBQ1JwVSxVQUFNMEMsTUFERTtBQUVSK0csY0FBVTtBQUZGLEdBVHlCO0FBYW5DLG1CQUFpQjtBQUNmekosVUFBTUMsTUFEUztBQUVmd0osY0FBVSxJQUZLO0FBR2ZULFdBQU87QUFIUSxHQWJrQjtBQWtCbkMsbUJBQWlCO0FBQ2ZoSixVQUFNQyxNQURTO0FBRWZ3SixjQUFVLElBRks7QUFHZlQsV0FBTztBQUhRLEdBbEJrQjtBQXVCbkNzQixlQUFhO0FBQ1h0SyxVQUFNb0MsS0FESztBQUNDO0FBQ1o0RyxXQUFPO0FBRkksR0F2QnNCO0FBMkJuQyxtQkFBaUI7QUFDZmhKLFVBQU1DO0FBRFM7QUEzQmtCLENBQWpCLENBQXBCO0FBZ0NBMEIsT0FBTzRJLFlBQVAsQ0FBb0I0SixXQUFwQixFOzs7Ozs7Ozs7OztBQ3JDQWxWLE9BQU9DLE1BQVAsQ0FBYztBQUFDbVYsMEJBQXVCLE1BQUlBO0FBQTVCLENBQWQ7QUFBbUUsSUFBSWpWLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxlQUFKO0FBQW9CUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDRSxrQkFBZ0JELENBQWhCLEVBQWtCO0FBQUNDLHNCQUFnQkQsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXBELEVBQTRGLENBQTVGO0FBQStGLElBQUlFLEtBQUo7QUFBVVIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0csUUFBTUYsQ0FBTixFQUFRO0FBQUNFLFlBQU1GLENBQU47QUFBUTs7QUFBbEIsQ0FBOUMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSUcsWUFBSjtBQUFpQlQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQ0csbUJBQWFILENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSW9DLE1BQUo7QUFBVzFDLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSwwQ0FBUixDQUFiLEVBQWlFO0FBQUNxQyxTQUFPcEMsQ0FBUCxFQUFTO0FBQUNvQyxhQUFPcEMsQ0FBUDtBQUFTOztBQUFwQixDQUFqRSxFQUF1RixDQUF2RjtBQWN6YSxNQUFNOFUseUJBQXlCLElBQUk3VSxlQUFKLENBQW9CO0FBQ3hESyxRQUFNLHdCQURrRDtBQUV4REMsWUFBVSxJQUFJSixZQUFKLENBQWlCO0FBQ3pCSyxlQUFXO0FBQUVDLFlBQU1DO0FBQVIsS0FEYztBQUV6QnFLLGlCQUFhO0FBQUV0SyxZQUFNb0M7QUFBUixLQUZZO0FBR3pCLHFCQUFpQjtBQUFFcEMsWUFBTUM7QUFBUjtBQUhRLEdBQWpCLEVBSVBDLFNBSk8sRUFGOEM7QUFPeERDLGdCQUFjO0FBQ1pDLGFBQVM7QUFERyxHQVAwQzs7QUFVeERDLE1BQUk7QUFBRU4sYUFBRjtBQUFhdUs7QUFBYixHQUFKLEVBQStCO0FBQzdCLFFBQUksQ0FBRSxLQUFLaEssTUFBWCxFQUFtQjtBQUNqQixZQUFNLElBQUlsQixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNEOztBQUNELFFBQUksQ0FBRWQsTUFBTWUsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUErQixNQUEvQixDQUFOLEVBQTZDO0FBQzNDLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0Q7O0FBRUQsUUFBSStKLFlBQVk0QyxNQUFaLEtBQXVCLENBQTNCLEVBQTZCO0FBQzNCNUMsa0JBQVlxSSxJQUFaLENBQWlCLE9BQWpCO0FBQ0Q7O0FBRURoUixXQUFPRyxNQUFQLENBQWM7QUFDWi9CLGlCQUFXQTtBQURDLEtBQWQsRUFFRTtBQUNBOEgsWUFBTTtBQUNKeUMscUJBQWFBO0FBRFQ7QUFETixLQUZGO0FBUUQ7O0FBOUJ1RCxDQUFwQixDQUEvQixDOzs7Ozs7Ozs7OztBQ2RQLE1BQU1wSixXQUFXLElBQUlvVCxhQUFKLENBQWtCLFVBQWxCLEVBQThCO0FBQUVDLHNCQUFvQjtBQUF0QixDQUE5QixDQUFqQixDLENBRUE7O0FBQ0EsSUFBSXBULEdBQUosQ0FBUUQsUUFBUixFQUFrQixTQUFsQixFQUE0QixFQUE1QixFQUNHc1QsTUFESCxDQUNVO0FBQUVDLFlBQVV2VCxTQUFTd1QsS0FBVCxDQUFlaFEsS0FBZixDQUFxQmlRLElBQXJCLENBQTBCLGtCQUExQjtBQUFaLENBRFYsRUFFR2xULElBRkgsQ0FFUTtBQUFFbVQsaUJBQWU7QUFBakIsQ0FGUjtBQUlBLE1BQU1DLFVBQVUzVCxTQUFTNFQsV0FBVCxDQUNkLFNBRGMsRUFFZDtBQUNFQyxnQkFBYyxLQURoQjtBQUVFQyxlQUFhLEtBQUs7QUFGcEIsQ0FGYyxFQU1kLENBQUN2TSxHQUFELEVBQUt3TSxRQUFMLEtBQWtCO0FBQ2hCLE1BQUlDLFVBQVUsSUFBSWxTLElBQUosRUFBZDtBQUNBa1MsVUFBUUMsVUFBUixDQUFtQkQsUUFBUUUsVUFBUixLQUF1QixFQUExQztBQUNBQyxRQUFNblUsU0FBU3lHLElBQVQsQ0FBYztBQUNsQmlILFlBQVE7QUFDTmhILFdBQUt6RyxJQUFJbVU7QUFESCxLQURVO0FBSWxCQyxhQUFTO0FBQ1BDLFdBQUtOO0FBREU7QUFKUyxHQUFkLEVBT0o7QUFDQS9CLFlBQVE7QUFDTnNDLFdBQUs7QUFEQztBQURSLEdBUEksRUFXSDVSLEdBWEcsQ0FXQzRFLE9BQU9BLElBQUlnTixHQVhaLENBQU47O0FBYUEsTUFBSUosSUFBSW5JLE1BQUosR0FBYSxDQUFqQixFQUFtQjtBQUNqQmhNLGFBQVN3VSxVQUFULENBQW9CTCxHQUFwQjtBQUNEOztBQUNENU0sTUFBSWtOLElBQUosQ0FBVSxXQUFVTixJQUFJbkksTUFBTyxXQUEvQjtBQUNBK0g7QUFDRCxDQTNCYSxDQUFoQjtBQTZCQS9ULFNBQVN5RyxJQUFULENBQWM7QUFDWjNILFFBQU0sU0FETTtBQUVaNE8sVUFBUTtBQUZJLENBQWQsRUFHR2dILE9BSEgsQ0FHVztBQUNUQyxVQUFPO0FBQ0wsV0FBT2hCLFFBQVFpQixPQUFSLEVBQVA7QUFDRDs7QUFIUSxDQUhYO0FBcENBN1csT0FBTzhXLGFBQVAsQ0E2Q2U3VSxRQTdDZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUk5QixNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSTJCLFFBQUo7QUFBYWpDLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUMyQixlQUFTM0IsQ0FBVDtBQUFXOztBQUF2QixDQUF0QyxFQUErRCxDQUEvRDtBQUFrRSxJQUFJeVcsS0FBSjtBQUFVL1csT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQ3lXLFlBQU16VyxDQUFOO0FBQVE7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUkwVyxNQUFKO0FBQVdoWCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsb0JBQVIsQ0FBYixFQUEyQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQzBXLGFBQU8xVyxDQUFQO0FBQVM7O0FBQXJCLENBQTNDLEVBQWtFLENBQWxFO0FBQXFFLElBQUlvQyxNQUFKO0FBQVcxQyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsMENBQVIsQ0FBYixFQUFpRTtBQUFDcUMsU0FBT3BDLENBQVAsRUFBUztBQUFDb0MsYUFBT3BDLENBQVA7QUFBUzs7QUFBcEIsQ0FBakUsRUFBdUYsQ0FBdkY7O0FBUzdUOzs7O0FBSUEsTUFBTTJXLFdBQVc7QUFDZixZQUFTLE1BRE07QUFFZixhQUFVLE1BRks7QUFHZixhQUFVLE1BSEs7QUFJZixZQUFTLE1BSk07QUFLZixZQUFTO0FBTE0sQ0FBakI7QUFRQWhWLFNBQVM0VCxXQUFULENBQ0UsT0FERixFQUVFO0FBQ0VxQixlQUFhLENBRGY7QUFFRUMsV0FBUztBQUZYLENBRkYsRUFNRSxDQUFDM04sR0FBRCxFQUFNd00sUUFBTixLQUFtQjtBQUNqQnJVLFVBQVFDLEdBQVIsQ0FBWTRILElBQUl0RCxJQUFoQjtBQUVBLFFBQU07QUFDSmxELGFBREk7QUFFSkMsU0FGSTtBQUdKQyxjQUhJO0FBSUpaO0FBSkksTUFLRGtILElBQUl0RCxJQUxUO0FBT0EsUUFBTTlELFNBQVM2VSxTQUFTalUsU0FBVCxDQUFmO0FBRUEsUUFBTW9VLE1BQU0xVSxPQUFPZ0csSUFBUCxDQUFZO0FBQ3RCNUgsZUFBVztBQUNUNkgsV0FBS3pGO0FBREk7QUFEVyxHQUFaLEVBSVY7QUFDQWdSLFlBQVE7QUFDTmlCLGdCQUFVO0FBREo7QUFEUixHQUpVLEVBUVR2USxHQVJTLENBUUxqQyxTQUFTO0FBQ2QsV0FBT0EsTUFBTXdTLFFBQU4sQ0FBZS9TLE1BQWYsQ0FBUDtBQUNELEdBVlcsRUFVVHVDLElBVlMsQ0FVSixHQVZJLENBQVo7QUFZQSxRQUFNMFMsVUFBVSxDQUFDLEtBQUQsRUFBT0QsR0FBUCxFQUFXLFNBQVgsRUFBcUIsR0FBckIsRUFBeUIsaUJBQXpCLEVBQTJDLElBQTNDLENBQWhCO0FBRUF6VixVQUFRQyxHQUFSLENBQWEsR0FBRW9CLFNBQVUsSUFBR3FVLFFBQVExUyxJQUFSLENBQWEsR0FBYixDQUFrQixJQUFHMUIsTUFBTTRSLFNBQU4sQ0FBZ0IsQ0FBaEIsRUFBa0IsQ0FBbEIsQ0FBcUIsTUFBSzVSLE1BQU00UixTQUFOLENBQWdCNVIsTUFBTWdMLE1BQU4sR0FBZSxDQUEvQixFQUFrQ2hMLE1BQU1nTCxNQUF4QyxDQUFnRCxFQUEzSDtBQUVBOEksUUFBTS9ULFNBQU4sRUFBaUJxVSxPQUFqQixFQUEwQnBVLEtBQTFCLEVBQ0dzTyxJQURILENBQ1NDLFVBQVU7QUFDZjdQLFlBQVFDLEdBQVIsQ0FBWSxnQkFBWjtBQUNBLFdBQU9vVixPQUFPeEYsT0FBTzhGLFFBQVAsRUFBUCxDQUFQO0FBQ0QsR0FKSCxFQUtHL0YsSUFMSCxDQUtTZ0csY0FBYztBQUNuQi9OLFFBQUlrTixJQUFKLENBQVNhLFVBQVQ7QUFDQXZCO0FBQ0QsR0FSSCxFQVNHOUQsS0FUSCxDQVNVck0sU0FBUztBQUNmbEUsWUFBUUMsR0FBUixDQUFZaUUsS0FBWjtBQUNBMkQsUUFBSWdPLElBQUosQ0FBUzNSLE1BQU00UixPQUFmO0FBQ0F6QjtBQUNELEdBYkgsRUE1QmlCLENBMENqQjtBQUNBO0FBQ0QsQ0FsREgsRTs7Ozs7Ozs7Ozs7QUNyQkEsSUFBSTdWLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJMkIsUUFBSjtBQUFhakMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQzJCLGVBQVMzQixDQUFUO0FBQVc7O0FBQXZCLENBQXRDLEVBQStELENBQS9EO0FBQWtFLElBQUk0RCxFQUFKO0FBQU9sRSxPQUFPSSxLQUFQLENBQWFDLFFBQVEsSUFBUixDQUFiLEVBQTJCO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDNEQsU0FBRzVELENBQUg7QUFBSzs7QUFBakIsQ0FBM0IsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSW9YLElBQUo7QUFBUzFYLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUNvWCxXQUFLcFgsQ0FBTDtBQUFPOztBQUFuQixDQUE3QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJNkIsS0FBSjtBQUFVbkMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVDQUFSLENBQWIsRUFBOEQ7QUFBQzhCLFFBQU03QixDQUFOLEVBQVE7QUFBQzZCLFlBQU03QixDQUFOO0FBQVE7O0FBQWxCLENBQTlELEVBQWtGLENBQWxGO0FBUXpSLE1BQU1xWCxzQkFBc0I7QUFDMUIsaUJBQWU7QUFEVyxDQUE1QjtBQUlBLE1BQU1DLFFBQVEzVixTQUFTNFQsV0FBVCxDQUNaLFVBRFksRUFFWjtBQUNFcUIsZUFBYSxDQURmO0FBRUVDLFdBQVM7QUFGWCxDQUZZLEVBTVosQ0FBQzNOLEdBQUQsRUFBTXdNLFFBQU4sS0FBbUI7QUFDakJyVSxVQUFRQyxHQUFSLENBQVk0SCxJQUFJdEQsSUFBaEI7QUFDQSxRQUFNO0FBQUV2QyxhQUFGO0FBQWF5RixlQUFiO0FBQTBCRDtBQUExQixNQUF1Q0ssSUFBSXRELElBQWpEO0FBQ0EsUUFBTTFDLFFBQVE2RixLQUFLNUQsS0FBTCxDQUFXMkQsV0FBWCxDQUFkO0FBQ0EsUUFBTXlPLFlBQVlGLG9CQUFvQnhPLFFBQXBCLENBQWxCO0FBRUEsUUFBTWpFLFdBQVkscUJBQW9CdkIsU0FBVSxJQUFHa1UsU0FBVSxLQUE3RDtBQUVBLFFBQU1DLGNBQWM1VCxHQUFHNlQsaUJBQUgsQ0FBcUI3UyxRQUFyQixDQUFwQjtBQUNBLFFBQU04UyxXQUFXTixLQUFLTyxVQUFMLEVBQWpCO0FBQ0FELFdBQVNFLElBQVQsQ0FBY0osV0FBZCxFQVZpQixDQVlqQjs7QUFDQUUsV0FBU3BELEVBQVQsQ0FBWSxRQUFaLEVBQXNCLE1BQU07QUFDeEJqVCxZQUFRQyxHQUFSLENBQVksd0JBQVo7QUFDSCxHQUZEO0FBSUFPLFFBQU11RyxJQUFOLENBQVdsRixLQUFYLEVBQWtCdUQsT0FBbEIsQ0FBMEI2RixRQUFRO0FBQ2hDakwsWUFBUUMsR0FBUixDQUFZZ0wsS0FBS3RFLEVBQWpCO0FBQ0EwUCxhQUFTRyxLQUFULENBQWV2TCxLQUFLdEUsRUFBcEI7QUFDRCxHQUhELEVBakJpQixDQXNCakI7O0FBQ0EwUCxXQUFTeFIsR0FBVCxHQXZCaUIsQ0F5QmpCOztBQUNBZ0QsTUFBSWtOLElBQUosQ0FBU3hSLFFBQVQ7QUFDQThRO0FBQ0QsQ0FsQ1csQ0FBZCxDOzs7Ozs7Ozs7OztBQ1pBLElBQUk3VixNQUFKO0FBQVdILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSTJCLFFBQUo7QUFBYWpDLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUMyQixlQUFTM0IsQ0FBVDtBQUFXOztBQUF2QixDQUF0QyxFQUErRCxDQUEvRDtBQUd2RixNQUFNc1gsUUFBUTNWLFNBQVM0VCxXQUFULENBQ1osY0FEWSxFQUVaO0FBQ0VxQixlQUFhLENBRGY7QUFFRUMsV0FBUztBQUZYLENBRlksRUFNWixVQUFTM04sR0FBVCxFQUFjd00sUUFBZCxFQUF1QjtBQUNyQnJVLFVBQVFDLEdBQVIsQ0FBWTRILElBQUl0RCxJQUFKLENBQVNnSyxNQUFyQixFQURxQixDQUVyQjs7QUFDQTFHLE1BQUlrTixJQUFKO0FBQ0FWO0FBQ0QsQ0FYVyxDQUFkLEM7Ozs7Ozs7Ozs7O0FDSEEsSUFBSTdWLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJMkIsUUFBSjtBQUFhakMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQzJCLGVBQVMzQixDQUFUO0FBQVc7O0FBQXZCLENBQXRDLEVBQStELENBQS9EO0FBQWtFLElBQUl5VyxLQUFKO0FBQVUvVyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDeVcsWUFBTXpXLENBQU47QUFBUTs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSTZCLEtBQUo7QUFBVW5DLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx1Q0FBUixDQUFiLEVBQThEO0FBQUM4QixRQUFNN0IsQ0FBTixFQUFRO0FBQUM2QixZQUFNN0IsQ0FBTjtBQUFROztBQUFsQixDQUE5RCxFQUFrRixDQUFsRjtBQUFxRixJQUFJb0MsTUFBSjtBQUFXMUMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDBDQUFSLENBQWIsRUFBaUU7QUFBQ3FDLFNBQU9wQyxDQUFQLEVBQVM7QUFBQ29DLGFBQU9wQyxDQUFQO0FBQVM7O0FBQXBCLENBQWpFLEVBQXVGLENBQXZGO0FBQTBGLElBQUlvTCxnQkFBSjtBQUFxQjFMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSwyQkFBUixDQUFiLEVBQWtEO0FBQUNxTCxtQkFBaUJwTCxDQUFqQixFQUFtQjtBQUFDb0wsdUJBQWlCcEwsQ0FBakI7QUFBbUI7O0FBQXhDLENBQWxELEVBQTRGLENBQTVGO0FBVTNiMkIsU0FBUzRULFdBQVQsQ0FDRSxhQURGLEVBRUU7QUFDRXFCLGVBQWEsQ0FEZjtBQUVFQyxXQUFTO0FBRlgsQ0FGRixFQU1FLFVBQWUzTixHQUFmLEVBQW9Cd00sUUFBcEI7QUFBQSxrQ0FBNkI7QUFDM0JyVSxZQUFRQyxHQUFSLENBQVksd0JBQVo7QUFDQUQsWUFBUUMsR0FBUixDQUFZNEgsSUFBSXRELElBQWhCO0FBQ0EsVUFBTTtBQUFFcEYsZUFBRjtBQUFhc0I7QUFBYixRQUF3Qm9ILElBQUl0RCxJQUFsQztBQUdBLFVBQU1rUyxVQUFVdFgsVUFBVXVELEtBQVYsQ0FBZ0IsTUFBaEIsRUFBd0JNLElBQXhCLENBQTZCLEdBQTdCLENBQWhCO0FBRUEsVUFBTTBULGFBQWFsVyxNQUFNdUcsSUFBTixDQUFXO0FBQUUvRixhQUFPN0I7QUFBVCxLQUFYLEVBQWlDd1gsS0FBakMsRUFBbkI7QUFDQSxVQUFNQyxXQUFXcEssS0FBS3FLLEtBQUwsQ0FBV0gsYUFBYSxFQUF4QixDQUFqQjtBQUNBMVcsWUFBUUMsR0FBUixDQUFhLFlBQVd5VyxVQUFXLFFBQW5DO0FBR0EsVUFBTUksUUFBUXRXLE1BQU11RyxJQUFOLENBQVc7QUFBRS9GLGFBQU83QjtBQUFULEtBQVgsRUFBaUM4RCxHQUFqQyxDQUFzQyxDQUFDZ0ksSUFBRCxFQUFPOUMsS0FBUCxLQUFpQjtBQUVuRSxVQUFJQSxRQUFReU8sUUFBUixLQUFxQixDQUF6QixFQUEyQjtBQUN6Qi9PLFlBQUlrUCxRQUFKLENBQWE1TyxLQUFiLEVBQW9CdU8sVUFBcEIsRUFBZ0M7QUFBRU0sZ0JBQU07QUFBUixTQUFoQztBQUNEOztBQUVELFVBQUlDLGtCQUFrQmxOLGlCQUFpQmtCLElBQWpCLEVBQXVCaEksR0FBdkIsQ0FBMkJxSSxjQUFjO0FBQzdELFlBQUlnQyxXQUFXN00sV0FBVyxNQUFYLEdBQW9CNkssV0FBV1AsR0FBL0IsR0FBcUNPLFdBQVdoRCxHQUEvRCxDQUQ2RCxDQUU3RDs7QUFDQSxlQUFRLElBQUcyQyxLQUFLdEUsRUFBRyxJQUFHMkUsV0FBVzNFLEVBQUcsS0FBSTJHLFFBQVMsRUFBakQ7QUFDRCxPQUpxQixFQUluQnRLLElBSm1CLENBSWQsSUFKYyxDQUF0QjtBQUtBLGFBQU9pVSxlQUFQO0FBQ0QsS0FaYSxFQVlYalUsSUFaVyxDQVlOLElBWk0sQ0FBZDtBQWNBLFVBQU1rVSxVQUFXLEdBQUVULE9BQVEsSUFBR2hXLE1BQU8sRUFBckM7QUFDQSxVQUFNaVYsVUFBVSxDQUFDLFNBQUQsRUFBWWpWLE1BQVosRUFBb0IsUUFBcEIsRUFBOEJnVyxPQUE5QixFQUF1QyxNQUF2QyxFQUErQ1MsT0FBL0MsQ0FBaEI7QUFDQWxYLFlBQVFDLEdBQVIsQ0FBWXlWLE9BQVo7QUFFQSxVQUFNeUIsdUJBQWdCL0IsTUFBTSxhQUFOLEVBQXFCTSxPQUFyQixFQUE4Qm9CLEtBQTlCLEVBQ25CbEgsSUFEbUIsQ0FDYkMsVUFBVTtBQUNmLFVBQUl1SCxTQUFTdkgsT0FBTzhGLFFBQVAsRUFBYjs7QUFDQSxVQUFJeUIsTUFBSixFQUFXO0FBQ1RwWCxnQkFBUUMsR0FBUixDQUFhLHNCQUFxQm1YLE1BQU8sRUFBekM7QUFDRDs7QUFFRHJXLGFBQU8rTyxhQUFQLENBQXFCO0FBQ25Cak8sZUFBTztBQUNMMUMscUJBQVdBO0FBRE4sU0FEWTtBQUluQitCLGdCQUFRO0FBQ04rRixnQkFBTTtBQUNKLGFBQUUsWUFBV3hHLE1BQU8sRUFBcEIsR0FBeUIsR0FBRWdXLE9BQVEsSUFBR2hXLE1BQU87QUFEekM7QUFEQTtBQUpXLE9BQXJCO0FBVUEsYUFBUSxHQUFFZ1csT0FBUSxJQUFHaFcsTUFBTyxFQUE1QjtBQUNELEtBbEJtQixFQWtCakI4UCxLQWxCaUIsQ0FrQlhyTSxTQUFTO0FBQ2hCbEUsY0FBUWtFLEtBQVIsQ0FBY0EsS0FBZDtBQUNELEtBcEJtQixDQUFoQixDQUFOO0FBcUJBbEUsWUFBUUMsR0FBUixDQUFhLEdBQUVrWCxNQUFPLE9BQXRCO0FBRUF0UCxRQUFJa04sSUFBSixDQUFTb0MsTUFBVDtBQUNBOUM7QUFDRCxHQXhERDtBQUFBLENBTkYsRTs7Ozs7Ozs7Ozs7QUNWQSxJQUFJN1YsTUFBSjtBQUFXSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFNBQU9HLENBQVAsRUFBUztBQUFDSCxhQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlFLEtBQUo7QUFBVVIsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0csUUFBTUYsQ0FBTixFQUFRO0FBQUNFLFlBQU1GLENBQU47QUFBUTs7QUFBbEIsQ0FBOUMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSW9DLE1BQUo7QUFBVzFDLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSwwQ0FBUixDQUFiLEVBQWlFO0FBQUNxQyxTQUFPcEMsQ0FBUCxFQUFTO0FBQUNvQyxhQUFPcEMsQ0FBUDtBQUFTOztBQUFwQixDQUFqRSxFQUF1RixDQUF2RjtBQU1wS0gsT0FBTzZQLE9BQVAsQ0FBZTtBQUNkZ0osUUFBTSxVQUFTQyxJQUFULEVBQWM7QUFDbkIsUUFBSSxDQUFFLEtBQUs1WCxNQUFYLEVBQW1CO0FBQ2xCLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0E7O0FBQ0QsUUFBSSxDQUFFZCxNQUFNZSxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQStCLFNBQS9CLENBQU4sRUFBZ0Q7QUFDL0MsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQTs7QUFDRCxRQUFJNFgsTUFBSjs7QUFDQSxZQUFRRCxJQUFSO0FBQ0MsV0FBSyxRQUFMO0FBQ0NDLGlCQUFTeFcsT0FBT2dHLElBQVAsQ0FBWSxFQUFaLEVBQWU7QUFBRXdMLGtCQUFRO0FBQUVzQyxpQkFBSztBQUFQO0FBQVYsU0FBZixFQUFxQ3hJLEtBQXJDLEVBQVQ7QUFDQTs7QUFDRCxXQUFLLFlBQUw7QUFDQ2tMLGlCQUFTdkwsV0FBV2pGLElBQVgsQ0FDUixFQURRLEVBRVI7QUFBRXdMLGtCQUFRO0FBQUVzQyxpQkFBSyxDQUFQO0FBQVVyTCx1QkFBVztBQUFyQjtBQUFWLFNBRlEsRUFHTjZDLEtBSE0sR0FHRXBKLEdBSEYsQ0FHTSxVQUFTdVUsR0FBVCxFQUFhO0FBQzFCLGlCQUFPQSxJQUFJaE8sU0FBWDtBQUNBLFNBTE8sQ0FBVDtBQU1BOztBQUNEO0FBQ0MsY0FBTSxJQUFJaEwsT0FBT21CLEtBQVgsQ0FBaUIsbUJBQW1CMlgsSUFBcEMsQ0FBTjtBQWJGOztBQWVBLFdBQU8sQ0FBQyxHQUFHLElBQUl6VCxHQUFKLENBQVEwVCxNQUFSLENBQUosQ0FBUDtBQUNBO0FBekJhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNOQSxJQUFJbkMsS0FBSjtBQUFVL1csT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDMFcsUUFBTXpXLENBQU4sRUFBUTtBQUFDeVcsWUFBTXpXLENBQU47QUFBUTs7QUFBbEIsQ0FBdEMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSW1MLE1BQUo7QUFBV3pMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUNtTCxhQUFPbkwsQ0FBUDtBQUFTOztBQUFyQixDQUF0QyxFQUE2RCxDQUE3RDtBQUFnRSxJQUFJNkIsS0FBSjtBQUFVbkMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVDQUFSLENBQWIsRUFBOEQ7QUFBQzhCLFFBQU03QixDQUFOLEVBQVE7QUFBQzZCLFlBQU03QixDQUFOO0FBQVE7O0FBQWxCLENBQTlELEVBQWtGLENBQWxGO0FBQXFGLElBQUkySSxVQUFKO0FBQWVqSixPQUFPSSxLQUFQLENBQWFDLFFBQVEsNENBQVIsQ0FBYixFQUFtRTtBQUFDNEksYUFBVzNJLENBQVgsRUFBYTtBQUFDMkksaUJBQVczSSxDQUFYO0FBQWE7O0FBQTVCLENBQW5FLEVBQWlHLENBQWpHO0FBQW9HLElBQUltSixXQUFKO0FBQWdCekosT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDhDQUFSLENBQWIsRUFBcUU7QUFBQ29KLGNBQVluSixDQUFaLEVBQWM7QUFBQ21KLGtCQUFZbkosQ0FBWjtBQUFjOztBQUE5QixDQUFyRSxFQUFxRyxDQUFyRztBQUF3RyxJQUFJOFksaUJBQUosRUFBc0JsTixTQUF0QixFQUFnQ1IsZ0JBQWhDO0FBQWlEMUwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDJCQUFSLENBQWIsRUFBa0Q7QUFBQytZLG9CQUFrQjlZLENBQWxCLEVBQW9CO0FBQUM4WSx3QkFBa0I5WSxDQUFsQjtBQUFvQixHQUExQzs7QUFBMkM0TCxZQUFVNUwsQ0FBVixFQUFZO0FBQUM0TCxnQkFBVTVMLENBQVY7QUFBWSxHQUFwRTs7QUFBcUVvTCxtQkFBaUJwTCxDQUFqQixFQUFtQjtBQUFDb0wsdUJBQWlCcEwsQ0FBakI7QUFBbUI7O0FBQTVHLENBQWxELEVBQWdLLENBQWhLO0FBQW1LLElBQUkwQixJQUFKO0FBQVNoQyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDMEIsV0FBSzFCLENBQUw7QUFBTzs7QUFBbkIsQ0FBcEMsRUFBeUQsQ0FBekQ7QUFhenJCSCxPQUFPNlAsT0FBUCxDQUFlO0FBQ2Q7Ozs7OztBQU1BcUosY0FBYTdWLEtBQWIsRUFBb0I4VixZQUFwQixFQUFpQztBQUNoQyxRQUFJLENBQUUsS0FBS2pZLE1BQVgsRUFBbUI7QUFDbEIsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQTs7QUFDREssWUFBUUMsR0FBUixDQUFZLGFBQVo7QUFDQUQsWUFBUUMsR0FBUixDQUFZNEIsS0FBWjtBQUVBLFVBQU1pVixRQUFRdFcsTUFBTXVHLElBQU4sQ0FBV2xGLEtBQVgsRUFBa0JvQixHQUFsQixDQUF1QixDQUFDZ0ksSUFBRCxFQUFPOUMsS0FBUCxLQUFpQjtBQUNsRCxZQUFNOE8sa0JBQWtCbE4saUJBQWlCa0IsSUFBakIsRUFBdUJoSSxHQUF2QixDQUEyQnFJLGNBQWM7QUFDL0QsY0FBTWdDLFdBQVdxSyxpQkFBaUIsU0FBakIsR0FBNkJyTSxXQUFXUCxHQUF4QyxHQUE4Q08sV0FBV2hELEdBQTFFO0FBQ0EsY0FBTXNQLGtCQUFrQnRLLFNBQVM1QyxLQUFULENBQWUsVUFBZixFQUEyQjFILElBQTNCLENBQWdDLElBQWhDLENBQXhCO0FBQ0EsZUFBUSxJQUFHc0ksV0FBVzNFLEVBQUcsS0FBSWlSLGVBQWdCLElBQTdDO0FBQ0QsT0FKdUIsRUFJckI1VSxJQUpxQixDQUloQixFQUpnQixDQUF4QjtBQUtBLGFBQU9pVSxlQUFQO0FBQ0QsS0FQVyxDQUFkO0FBU0EsV0FBT0gsS0FBUDtBQUNBLEdBeEJhOztBQXlCZGUsYUFBWUMsTUFBWixFQUFtQmpXLEtBQW5CLEVBQXlCO0FBQ3hCLFFBQUksQ0FBRSxLQUFLbkMsTUFBWCxFQUFtQjtBQUNsQixZQUFNLElBQUlsQixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBOztBQUNELFFBQUksQ0FBRWQsTUFBTWUsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUErQixTQUEvQixDQUFOLEVBQWdEO0FBQy9DLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0E7O0FBQ0QsUUFBSW1ZLE1BQUosRUFBWTtBQUNYalcsWUFBTWtXLEdBQU4sR0FBWSxDQUFDO0FBQUUsY0FBTTtBQUFFQyxrQkFBUUYsTUFBVjtBQUFtQkcsb0JBQVU7QUFBN0I7QUFBUixPQUFELEVBQThDO0FBQUUsZ0JBQVE7QUFBRUQsa0JBQVFGLE1BQVY7QUFBbUJHLG9CQUFVO0FBQTdCO0FBQVYsT0FBOUMsQ0FBWjs7QUFDQSxVQUFJLENBQUNwVyxNQUFNcVcsY0FBTixDQUFxQixhQUFyQixDQUFMLEVBQXlDO0FBQ3hDclcsY0FBTWtXLEdBQU4sQ0FBVWhHLElBQVYsQ0FBZTtBQUFFLHlCQUFlO0FBQUVpRyxvQkFBUUYsTUFBVjtBQUFtQkcsc0JBQVU7QUFBN0I7QUFBakIsU0FBZjtBQUNBO0FBQ0Q7O0FBQ0QsVUFBTXRCLFFBQVFuVyxNQUFNdUcsSUFBTixDQUFXbEYsS0FBWCxFQUFrQjhVLEtBQWxCLEVBQWQ7QUFDQSxXQUFPQSxLQUFQO0FBQ0EsR0F4Q2E7O0FBeUNkd0Isb0JBQW1CNUosTUFBbkIsRUFBMEI7QUFDekIsUUFBSSxDQUFFLEtBQUs3TyxNQUFYLEVBQW1CO0FBQ2xCLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0E7O0FBQ0RhLFVBQU1VLE1BQU4sQ0FBYTtBQUFFLFlBQU1xTjtBQUFSLEtBQWIsRUFBOEI7QUFBRTZKLGFBQU87QUFBRSxtQkFBVyxLQUFLMVk7QUFBbEI7QUFBVCxLQUE5QixFQUFxRSxDQUFDMkcsR0FBRCxFQUFLZ1MsR0FBTCxLQUFhO0FBQ2pGLFVBQUloUyxHQUFKLEVBQVM7QUFDUixjQUFNLElBQUk3SCxPQUFPbUIsS0FBWCxDQUFpQix1Q0FBakIsQ0FBTjtBQUNBOztBQUNELFlBQU1zTCxPQUFPekssTUFBTVMsT0FBTixDQUFjO0FBQUMsY0FBTXNOO0FBQVAsT0FBZCxDQUFiO0FBQ0F2TyxjQUFRQyxHQUFSLENBQVlnTCxJQUFaLEVBTGlGLENBTWpGO0FBQ0M7QUFDRDtBQUNBLEtBVEQ7QUFXQSxHQXhEYTs7QUF5RGQ7Ozs7O0FBS0FxTixXQUFVL0osTUFBVixFQUFrQjtBQUNqQixRQUFJLENBQUUsS0FBSzdPLE1BQVgsRUFBbUI7QUFDbEIsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQTs7QUFDRCxRQUFJLENBQUVkLE1BQU1lLFlBQU4sQ0FBbUIsS0FBS0YsTUFBeEIsRUFBK0IsU0FBL0IsQ0FBTixFQUFnRDtBQUMvQyxZQUFNLElBQUlsQixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBOztBQUNEYSxVQUFNVSxNQUFOLENBQWE7QUFBRSxZQUFNcU47QUFBUixLQUFiLEVBQThCO0FBQUV0SCxZQUFNO0FBQUVpQyxpQkFBUyxLQUFLeEo7QUFBaEI7QUFBUixLQUE5QixFQUFrRSxDQUFDMkcsR0FBRCxFQUFLZ1MsR0FBTCxLQUFhO0FBQzlFLFVBQUloUyxHQUFKLEVBQVE7QUFDUCxjQUFNLElBQUk3SCxPQUFPbUIsS0FBWCxDQUFpQixxQkFBakIsQ0FBTjtBQUNBOztBQUNESyxjQUFRQyxHQUFSLENBQWEsR0FBRSxLQUFLUCxNQUFPLG9CQUFtQjZPLE1BQU8sRUFBckQ7QUFDQSxLQUxEO0FBTUEsR0EzRWE7O0FBNEVkOzs7Ozs7QUFNQWdLLGFBQVloSyxNQUFaLEVBQW9CO0FBQ25CLFFBQUksQ0FBRSxLQUFLN08sTUFBWCxFQUFtQjtBQUNsQixZQUFNLElBQUlsQixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBOztBQUNELFFBQUksQ0FBRWQsTUFBTWUsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUErQixTQUEvQixDQUFOLEVBQWdEO0FBQy9DLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0E7O0FBQ0QsVUFBTXNMLE9BQU96SyxNQUFNUyxPQUFOLENBQWM7QUFBRTBGLFVBQUk0SDtBQUFOLEtBQWQsQ0FBYjs7QUFDQSxRQUFJLENBQUN0RCxJQUFMLEVBQVU7QUFDVCxZQUFNLElBQUl6TSxPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBOztBQUVELFFBQUksQ0FBQ3NMLEtBQUsvQixPQUFWLEVBQWtCO0FBQ2pCLFlBQU0sSUFBSTFLLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0E7O0FBRUQsUUFBSSxFQUFFc0wsS0FBSy9CLE9BQUwsS0FBaUIsS0FBS3hKLE1BQXhCLENBQUosRUFBb0M7QUFDbkMsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQTs7QUFFREssWUFBUUMsR0FBUixDQUFZLGtCQUFaLEVBQStCZ0wsS0FBSy9CLE9BQUwsS0FBaUIsS0FBS3hKLE1BQXJEOztBQUNBLFFBQUl1TCxLQUFLL0IsT0FBTCxLQUFpQixLQUFLeEosTUFBMUIsRUFBaUM7QUFDaENNLGNBQVFDLEdBQVIsQ0FBYSxHQUFFLEtBQUtQLE1BQU8sOEJBQTZCNk8sTUFBTyxFQUEvRDtBQUNBL04sWUFBTVUsTUFBTixDQUFhO0FBQUV5RixZQUFJNEg7QUFBTixPQUFiLEVBQTRCO0FBQUV0SCxjQUFNO0FBQUVpQyxtQkFBUztBQUFYO0FBQVIsT0FBNUIsRUFBZ0UsQ0FBQzdDLEdBQUQsRUFBS2dTLEdBQUwsS0FBYTtBQUM1RSxZQUFJaFMsR0FBSixFQUFRO0FBQ1AsZ0JBQU0sSUFBSTdILE9BQU9tQixLQUFYLENBQWlCLGtCQUFqQixDQUFOO0FBQ0E7O0FBQ0RhLGNBQU1VLE1BQU4sQ0FBYTtBQUFFeUYsY0FBSTRIO0FBQU4sU0FBYixFQUE0QjtBQUFFcE4sa0JBQVE7QUFBRStILHFCQUFTO0FBQVg7QUFBVixTQUE1QjtBQUNBLE9BTEQ7QUFNQTtBQUNEOztBQWhIYSxDQUFmO0FBbUhBMUssT0FBTzZQLE9BQVAsQ0FBZTtBQUNkbUssb0JBQW1CM0QsR0FBbkIsRUFBdUJ0QyxNQUF2QixFQUE4QjtBQUM3QixRQUFJLENBQUUsS0FBSzdTLE1BQVgsRUFBbUI7QUFDbEIsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQTs7QUFBQTs7QUFDRCxRQUFJLENBQUVkLE1BQU1lLFlBQU4sQ0FBbUIsS0FBS0YsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTixFQUE4QztBQUM3QyxZQUFNLElBQUlsQixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBOztBQUNEOFksZ0JBQVl2WCxNQUFaLENBQW1CO0FBQUMsYUFBTTJUO0FBQVAsS0FBbkIsRUFBK0I7QUFBQzVOLFlBQUtzTDtBQUFOLEtBQS9CO0FBQ0EsR0FUYTs7QUFVYm1HLGNBQWE3RCxHQUFiLEVBQWlCdEMsTUFBakIsRUFBd0I7QUFDeEIsUUFBSSxDQUFFLEtBQUs3UyxNQUFYLEVBQW1CO0FBQ2xCLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0E7O0FBQ0RuQixXQUFPbWEsS0FBUCxDQUFhelgsTUFBYixDQUFvQjtBQUFDLGFBQU0yVDtBQUFQLEtBQXBCLEVBQWdDO0FBQUM1TixZQUFLc0w7QUFBTixLQUFoQztBQUNBLEdBZmE7O0FBZ0JkcUcsaUJBQWdCckssTUFBaEIsRUFBdUJyTixNQUF2QixFQUE4QjJYLE1BQTlCLEVBQXFDO0FBQ3BDLFVBQU1uWixTQUFTLEtBQUtBLE1BQXBCOztBQUNBLFFBQUksQ0FBRUEsTUFBTixFQUFjO0FBQ2IsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQTs7QUFDRCxRQUFJLENBQUVkLE1BQU1lLFlBQU4sQ0FBbUJGLE1BQW5CLEVBQTBCLFNBQTFCLENBQU4sRUFBMkM7QUFDMUMsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQTs7QUFDREssWUFBUUMsR0FBUixDQUFhLGlCQUFnQnNPLE1BQU8sRUFBcEM7QUFDQXZPLFlBQVFDLEdBQVIsQ0FBWSxTQUFaLEVBQXNCaUIsTUFBdEI7QUFDQWxCLFlBQVFDLEdBQVIsQ0FBWSxTQUFaLEVBQXNCNFksTUFBdEI7QUFFQSxRQUFJQyxnQkFBZ0IsRUFBcEI7O0FBRUEsUUFBSTVYLE9BQU9nWCxjQUFQLENBQXNCLE1BQXRCLENBQUosRUFBa0M7QUFDakNZLHNCQUFnQmhYLE9BQU9rTixJQUFQLENBQVk5TixPQUFPLE1BQVAsQ0FBWixFQUE0QmlLLE1BQTVCLENBQW9DckksT0FBTztBQUMxRCxlQUFPQSxJQUFJaVcsVUFBSixDQUFlLGFBQWYsQ0FBUDtBQUNBLE9BRmUsRUFFYjlWLEdBRmEsQ0FFUkgsT0FBTztBQUNkLGVBQU87QUFDTmpCLGlCQUFPaUIsR0FERDtBQUVON0QsZ0JBQU02RCxJQUFJaEQsT0FBSixDQUFZLGFBQVosRUFBMEIsRUFBMUI7QUFGQSxTQUFQO0FBSUEsT0FQZSxDQUFoQjtBQVFBOztBQUVERSxZQUFRQyxHQUFSLENBQVksaUJBQVosRUFBK0I2WSxhQUEvQjtBQUVBLFVBQU1FLGVBQWV0UixLQUFLQyxTQUFMLENBQWVrUixNQUFmLENBQXJCO0FBRUEsVUFBTTVOLE9BQU96SyxNQUFNUyxPQUFOLENBQWM7QUFBQzBGLFVBQUk0SDtBQUFMLEtBQWQsQ0FBYjtBQUVBL04sVUFBTVUsTUFBTixDQUFhO0FBQUV5RixVQUFJNEg7QUFBTixLQUFiLEVBQTZCck4sTUFBN0IsRUFBcUMsQ0FBQ21GLEdBQUQsRUFBS2dTLEdBQUwsS0FBYTtBQUNqRCxVQUFJLENBQUNoUyxHQUFMLEVBQVM7QUFDUnlCLG9CQUFZcEIsTUFBWixDQUFtQjtBQUNsQkMsY0FBSTRILE1BRGM7QUFFbEIwSyxnQkFBTSxJQUFJN1csSUFBSixFQUZZO0FBR2xCekIsZ0JBQU1qQixNQUhZO0FBSWxCbVosa0JBQVFHO0FBSlUsU0FBbkI7QUFNQUYsc0JBQWMxVCxPQUFkLENBQXVCOFQsZ0JBQWdCO0FBQ3RDNVIscUJBQVd3SSxhQUFYLENBQXlCO0FBQ3hCak8sbUJBQU87QUFDTjVDLG9CQUFNaWEsYUFBYWphO0FBRGIsYUFEaUI7QUFJeEJpQyxvQkFBUTtBQUNQK08sNEJBQWM7QUFDYmhSLHNCQUFNaWEsYUFBYWphLElBRE47QUFFYjRDLHVCQUFPcVgsYUFBYXJYLEtBRlA7QUFHYnFPLHNCQUFNLElBSE87QUFJYkUsMEJBQVUsS0FKRztBQUtiRCx5QkFBUztBQUxJLGVBRFA7QUFRUGdKLHFCQUFPO0FBQ05uSiw0QkFBWS9FLEtBQUt6QixTQURYO0FBRU51Ryx3QkFBUTlFLEtBQUtqSztBQUZQO0FBUkEsYUFKZ0I7QUFpQnhCc1Asb0JBQVEsSUFqQmdCO0FBa0J4QkQsaUJBQUs7QUFsQm1CLFdBQXpCO0FBb0JBLFNBckJEO0FBc0JBO0FBQ0QsS0EvQkQ7QUFnQ0EsR0EvRWE7O0FBZ0ZkK0ksbUJBQWtCdkUsR0FBbEIsRUFBc0J0QyxNQUF0QixFQUE2QjtBQUM1QixRQUFJLENBQUUsS0FBSzdTLE1BQVgsRUFBbUI7QUFDbEIsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQTs7QUFDRCxRQUFJLENBQUVkLE1BQU1lLFlBQU4sQ0FBbUIsS0FBS0YsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBTixFQUE4QztBQUM3QyxZQUFNLElBQUlsQixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBOztBQUNEMkgsZUFBV3BHLE1BQVgsQ0FBa0I7QUFBQyxhQUFNMlQ7QUFBUCxLQUFsQixFQUE4QjtBQUFDNU4sWUFBS3NMO0FBQU4sS0FBOUI7QUFDQSxHQXhGYTs7QUF5RmQ7Ozs7O0FBS0E4RyxhQUFZeFgsS0FBWixFQUFrQjtBQUNqQixRQUFJLENBQUUsS0FBS25DLE1BQVgsRUFBbUI7QUFDbEIsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQTs7QUFFRCxVQUFNa0gsUUFBUXJHLE1BQU11RyxJQUFOLENBQVdsRixLQUFYLENBQWQ7QUFDQSxVQUFNeVgsUUFBUXpTLE1BQU04UCxLQUFOLEVBQWQ7QUFDQSxRQUFJNEMsVUFBVSxDQUFkO0FBQ0EsVUFBTUMsTUFBTTNTLE1BQU01RCxHQUFOLENBQVUsVUFBU2dJLElBQVQsRUFBYztBQUNuQ3NPLGlCQUFXLENBQVg7QUFDQSxVQUFJRSxXQUFXeE8sS0FBSzFCLFdBQUwsQ0FBaUJ0RyxHQUFqQixDQUFxQixVQUFTeUksR0FBVCxFQUFhO0FBQ2hELFlBQUlnTyxZQUFZLENBQ2Z6TyxLQUFLeEIsS0FEVSxFQUVmd0IsS0FBS3RHLE1BRlUsRUFHZitHLElBQUl0TSxJQUhXLEVBSWZzTSxJQUFJOUcsS0FKVyxFQUtmOEcsSUFBSTdHLEdBTFcsRUFNZjZHLElBQUk1RyxLQU5XLEVBT2ZtRyxLQUFLbEcsTUFQVSxFQVFmMkcsSUFBSTFHLEtBUlcsRUFTZixRQUFNMEcsSUFBSS9FLEVBQVYsR0FBYSxXQUFiLEdBQXlCK0UsSUFBSTNDLE9BQUosQ0FBWS9GLElBQVosRUFUVixDQUFoQjtBQVdBLGVBQU8wVyxVQUFVMVcsSUFBVixDQUFlLElBQWYsSUFBdUIsSUFBOUI7QUFDQSxPQWJjLENBQWY7QUFjQSxVQUFJMlcsYUFBYSxDQUNoQjFPLEtBQUt4QixLQURXLEVBRWhCd0IsS0FBS3RHLE1BRlcsRUFHaEJzRyxLQUFLN0wsSUFIVyxFQUloQjZMLEtBQUtyRyxLQUpXLEVBS2hCcUcsS0FBS3BHLEdBTFcsRUFNaEJvRyxLQUFLbkcsS0FOVyxFQU9oQm1HLEtBQUtsRyxNQVBXLEVBUWhCa0csS0FBS2pHLEtBUlcsRUFTaEIsUUFBTWlHLEtBQUt0RSxFQVRLLENBQWpCO0FBV0EsVUFBSWlULFdBQVdELFdBQVczVyxJQUFYLENBQWdCLElBQWhCLElBQXdCLElBQXZDLENBM0JtQyxDQTZCbkM7O0FBQ0F5VyxlQUFTSSxPQUFULENBQWlCRCxRQUFqQjtBQUVBLGFBQU9ILFNBQVN6VyxJQUFULENBQWMsRUFBZCxDQUFQO0FBQ0EsS0FqQ1csQ0FBWjtBQWtDQSxXQUFPd1csR0FBUDtBQUNBLEdBeklhOztBQTBJZE0scUJBQW9CalksS0FBcEIsRUFBMEJrWSxNQUExQixFQUFpQztBQUNoQy9YLGdCQUFZM0IsS0FBS3dCLEtBQUwsQ0FBWjtBQUNBNEYsa0JBQWNDLEtBQUtDLFNBQUwsQ0FBZTlGLEtBQWYsQ0FBZDtBQUNBbVksZUFBV3ZZLFVBQVVSLE9BQVYsQ0FBa0I7QUFBQ1ksYUFBTUcsU0FBUDtBQUFpQitYLGNBQU9BO0FBQXhCLEtBQWxCLENBQVg7QUFDQSxRQUFJRSxVQUFKOztBQUNBLFFBQUlELGFBQWF2SSxTQUFqQixFQUEyQjtBQUMxQndJLG1CQUFheFksVUFBVWlGLE1BQVYsQ0FBaUI7QUFBQzdFLGVBQU1HLFNBQVA7QUFBaUJ5RixxQkFBWUEsV0FBN0I7QUFBeUNzUyxnQkFBT0E7QUFBaEQsT0FBakIsQ0FBYixDQUQwQixDQUUxQjtBQUNBLEtBSEQsTUFHTztBQUNORSxtQkFBYUQsU0FBU25GLEdBQXRCLENBRE0sQ0FFTjtBQUNBO0FBQ0Q7O0FBdEphLENBQWYsRTs7Ozs7Ozs7Ozs7QUNoSUEsSUFBSXJXLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJRSxLQUFKO0FBQVVSLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNHLFFBQU1GLENBQU4sRUFBUTtBQUFDRSxZQUFNRixDQUFOO0FBQVE7O0FBQWxCLENBQTlDLEVBQWtFLENBQWxFO0FBQXFFLElBQUk4UixNQUFKO0FBQVdwUyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDOFIsYUFBTzlSLENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSStSLElBQUo7QUFBU3JTLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxXQUFSLENBQWIsRUFBa0M7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUMrUixXQUFLL1IsQ0FBTDtBQUFPOztBQUFuQixDQUFsQyxFQUF1RCxDQUF2RDtBQUEwRCxJQUFJNEQsRUFBSjtBQUFPbEUsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLElBQVIsQ0FBYixFQUEyQjtBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQzRELFNBQUc1RCxDQUFIO0FBQUs7O0FBQWpCLENBQTNCLEVBQThDLENBQTlDO0FBQWlELElBQUlvQyxNQUFKO0FBQVcxQyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsMENBQVIsQ0FBYixFQUFpRTtBQUFDcUMsU0FBT3BDLENBQVAsRUFBUztBQUFDb0MsYUFBT3BDLENBQVA7QUFBUzs7QUFBcEIsQ0FBakUsRUFBdUYsQ0FBdkY7QUFBMEYsSUFBSTZCLEtBQUo7QUFBVW5DLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx1Q0FBUixDQUFiLEVBQThEO0FBQUM4QixRQUFNN0IsQ0FBTixFQUFRO0FBQUM2QixZQUFNN0IsQ0FBTjtBQUFROztBQUFsQixDQUE5RCxFQUFrRixDQUFsRjtBQUFxRixJQUFJdWIsY0FBSixFQUFtQkMsY0FBbkI7QUFBa0M5YixPQUFPSSxLQUFQLENBQWFDLFFBQVEseURBQVIsQ0FBYixFQUFnRjtBQUFDd2IsaUJBQWV2YixDQUFmLEVBQWlCO0FBQUN1YixxQkFBZXZiLENBQWY7QUFBaUIsR0FBcEM7O0FBQXFDd2IsaUJBQWV4YixDQUFmLEVBQWlCO0FBQUN3YixxQkFBZXhiLENBQWY7QUFBaUI7O0FBQXhFLENBQWhGLEVBQTBKLENBQTFKO0FBVzlqQkgsT0FBTzZQLE9BQVAsQ0FBZTtBQUNkK0wsbUJBQWlCQyxNQUFqQixFQUF3QjtBQUN2QnJhLFlBQVFDLEdBQVIsQ0FBWSxrQkFBWixFQUErQm9hLE1BQS9COztBQUNBLFFBQUksQ0FBRSxLQUFLM2EsTUFBWCxFQUFtQjtBQUNsQixZQUFNLElBQUlsQixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBOztBQUNELFFBQUksQ0FBRWQsTUFBTWUsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUErQixTQUEvQixDQUFOLEVBQWdEO0FBQy9DLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0E7O0FBRUQsVUFBTXFTLGdCQUFnQmpSLE9BQU9nRyxJQUFQLENBQVk7QUFBRTVILGlCQUFXa2IsT0FBT2xiO0FBQXBCLEtBQVosRUFBNkNrTixLQUE3QyxHQUFxREMsTUFBM0U7O0FBQ0EsUUFBSSxDQUFDMEYsYUFBTCxFQUFtQjtBQUNsQixZQUFNLElBQUl4VCxPQUFPbUIsS0FBWCxDQUFrQix5QkFBd0IwYSxPQUFPbGIsU0FBVSxFQUEzRCxDQUFOO0FBQ0E7O0FBRUQsVUFBTXNFLGFBQWFsQixHQUFHbUIsWUFBSCxDQUFnQjJXLE9BQU85VyxRQUF2QixFQUFpQztBQUFFSSxnQkFBVTtBQUFaLEtBQWpDLENBQW5CO0FBRUEzRCxZQUFRQyxHQUFSLENBQWEsaUJBQWdCb2EsT0FBTzlXLFFBQVMsRUFBN0M7QUFFQW1OLFNBQUs1TSxLQUFMLENBQVdMLFVBQVgsRUFBdUI7QUFDdEJNLGlCQUFXLElBRFc7QUFFdEJDLHFCQUFlLElBRk87QUFHdEJDLHNCQUFnQixJQUhNO0FBSXRCbU8sZ0JBQVUsR0FKWTtBQUt0Qm5HLGNBQVEsSUFMYzs7QUFNdEIvSCxZQUFNQSxLQUFOLEVBQVlDLElBQVosRUFBa0I7QUFDakJuRSxnQkFBUUMsR0FBUixDQUFZaUUsS0FBWjtBQUNBLE9BUnFCOztBQVN0QndCLGVBQVNDLE9BQVQsRUFBaUJ4QixJQUFqQixFQUF1QjtBQUN0QixjQUFNbVcsZUFBZSxJQUFJelcsR0FBSixFQUFyQjtBQUNBLGNBQU1rTSxTQUFTLElBQUlsTSxHQUFKLEVBQWY7QUFFQTdELGdCQUFRQyxHQUFSLENBQVksb0NBQVo7QUFFQTBGLGdCQUFRcEIsSUFBUixDQUFhYSxPQUFiLENBQXFCeUssVUFBVTtBQUM5QixnQkFBTTVFLE9BQU96SyxNQUFNUyxPQUFOLENBQWM7QUFBQzBGLGdCQUFJa0osT0FBTzBLO0FBQVosV0FBZCxDQUFiOztBQUNBLGNBQUl0UCxTQUFTd0csU0FBYixFQUF1QjtBQUN0QjZJLHlCQUFhOVUsR0FBYixDQUFpQnFLLE9BQU8wSyxTQUF4QjtBQUNBLFdBRkQsTUFFTztBQUNOeEssbUJBQU92SyxHQUFQLENBQVd5RixLQUFLakssS0FBaEI7QUFDQTtBQUNELFNBUEQ7O0FBU0EsWUFBSXNaLGFBQWExVCxJQUFiLEdBQW9CLENBQXhCLEVBQTBCO0FBQ3pCLGdCQUFNLElBQUlwSSxPQUFPbUIsS0FBWCxDQUFrQixHQUFFMmEsYUFBYWhPLE1BQU8sMkJBQXhDLENBQU47QUFDQTs7QUFFRCxZQUFJeUQsT0FBT25KLElBQVAsR0FBYyxDQUFsQixFQUFvQjtBQUNuQixnQkFBTSxJQUFJcEksT0FBT21CLEtBQVgsQ0FBa0IsK0NBQThDNkIsTUFBTTZOLElBQU4sQ0FBV1UsTUFBWCxDQUFtQixFQUFuRixDQUFOO0FBQ0E7O0FBRUQvUCxnQkFBUUMsR0FBUixDQUFZLHNEQUFaO0FBQ0EsY0FBTXVhLGVBQWVOLGVBQWV4VCxNQUFmLENBQXNCO0FBQzFDMUYsaUJBQU9xWixPQUFPbGIsU0FENEI7QUFFMUNzYixzQkFBWUosT0FBT0ksVUFGdUI7QUFHMUNDLDJCQUFpQkwsT0FBT0ssZUFIa0I7QUFJMUNDLHdCQUFjTixPQUFPTSxZQUpxQjtBQUsxQ3hILHVCQUFha0gsT0FBT2xILFdBTHNCO0FBTTFDekosdUJBQWEsQ0FBQyxPQUFEO0FBTjZCLFNBQXRCLENBQXJCO0FBU0E7Ozs7Ozs7Ozs7OztBQVdBMUosZ0JBQVFDLEdBQVIsQ0FBWSxpQ0FBWjtBQUNBMEYsZ0JBQVFwQixJQUFSLENBQWFhLE9BQWIsQ0FBdUI2RixJQUFELElBQVU7QUFDL0JrUCx5QkFBZXpULE1BQWYsQ0FBc0I7QUFDckI2SCxvQkFBUXRELEtBQUtzUCxTQURRO0FBRXJCQywwQkFBY0EsWUFGTztBQUdyQjlRLHlCQUFhLENBQUMsT0FBRCxDQUhRO0FBSXJCa1Isd0JBQVkzUCxLQUFLNFAsVUFKSTtBQUtyQkMsaUJBQUs3UCxLQUFLNlA7QUFMVyxXQUF0QjtBQVFBLFNBVEQ7QUFZQTs7QUFsRXFCLEtBQXZCO0FBb0VBLFdBQVEsd0JBQXVCVCxPQUFPSSxVQUFXLEVBQWpEO0FBQ0E7O0FBeEZhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNYQXBjLE9BQU9DLE1BQVAsQ0FBYztBQUFDNGIsa0JBQWUsTUFBSUEsY0FBcEI7QUFBbUNhLHdCQUFxQixNQUFJQSxvQkFBNUQ7QUFBaUZaLGtCQUFlLE1BQUlBLGNBQXBHO0FBQW1IYSx1QkFBb0IsTUFBSUE7QUFBM0ksQ0FBZDtBQUErSyxJQUFJdFosS0FBSjtBQUFVckQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDZ0QsUUFBTS9DLENBQU4sRUFBUTtBQUFDK0MsWUFBTS9DLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUcsWUFBSjtBQUFpQlQsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQ0csbUJBQWFILENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFHdFEsTUFBTXViLGlCQUFpQixJQUFJeFksTUFBTUMsVUFBVixDQUFxQixhQUFyQixDQUF2QjtBQUVBLE1BQU1vWix1QkFBdUIsSUFBSWpjLFlBQUosQ0FBaUI7QUFDN0MyYixjQUFZO0FBQ1hyYixVQUFNQyxNQURLO0FBRVgrSSxXQUFPO0FBRkksR0FEaUM7QUFLN0NzUyxtQkFBaUI7QUFDaEJ0YixVQUFNQyxNQURVO0FBRWhCK0ksV0FBTztBQUZTLEdBTDRCO0FBUzdDdVMsZ0JBQWM7QUFDYnZiLFVBQU1DLE1BRE87QUFFYitJLFdBQU87QUFGTSxHQVQrQjtBQWE3Q3BILFNBQU87QUFDTjVCLFVBQU1DLE1BREE7QUFFTitJLFdBQU87QUFGRCxHQWJzQztBQWlCN0MrSyxlQUFhO0FBQ1ovVCxVQUFNQyxNQURNO0FBRVorSSxXQUFPO0FBRkssR0FqQmdDO0FBcUI3Q3NCLGVBQWE7QUFDWnRLLFVBQU1vQyxLQURNO0FBRVo0RyxXQUFPO0FBRkssR0FyQmdDO0FBeUI3QyxtQkFBaUI7QUFDaEJoSixVQUFNQztBQURVO0FBekI0QixDQUFqQixDQUE3QjtBQThCQTZhLGVBQWV2USxZQUFmLENBQTRCb1Isb0JBQTVCO0FBRUEsTUFBTVosaUJBQWlCLElBQUl6WSxNQUFNQyxVQUFWLENBQXFCLGdCQUFyQixDQUF2QjtBQUVBLE1BQU1xWixzQkFBc0IsSUFBSWxjLFlBQUosQ0FBaUI7QUFDNUN5UCxVQUFRO0FBQ1BuUCxVQUFNQyxNQURDO0FBRVArSSxXQUFPLFNBRkEsQ0FHUDs7QUFITyxHQURvQztBQU01Q29TLGdCQUFjO0FBQ2JwYixVQUFNQyxNQURPO0FBRWIrSSxXQUFPLGVBRk0sQ0FHYjs7QUFIYSxHQU44QjtBQVc1Q3NCLGVBQVk7QUFDWHRLLFVBQU1vQyxLQURLO0FBQ0M7QUFDWjRHLFdBQU87QUFGSSxHQVhnQztBQWU1QyxtQkFBaUI7QUFDaEJoSixVQUFNQztBQURVLEdBZjJCO0FBa0I1Q3ViLGNBQVk7QUFDWHhiLFVBQU04QyxNQURLO0FBRVg7QUFDQWtHLFdBQU87QUFISSxHQWxCZ0M7QUF1QjVDMFMsT0FBSztBQUNKMWIsVUFBTThDLE1BREY7QUFFSjtBQUNBa0csV0FBTztBQUhIO0FBdkJ1QyxDQUFqQixDQUE1QjtBQThCQStSLGVBQWV4USxZQUFmLENBQTRCcVIsbUJBQTVCLEU7Ozs7Ozs7Ozs7O0FDckVBM2MsT0FBT0MsTUFBUCxDQUFjO0FBQUMyYyxvQkFBaUIsTUFBSUE7QUFBdEIsQ0FBZDtBQUF1RCxJQUFJemMsTUFBSjtBQUFXSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFNBQU9HLENBQVAsRUFBUztBQUFDSCxhQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlDLGVBQUo7QUFBb0JQLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNFLGtCQUFnQkQsQ0FBaEIsRUFBa0I7QUFBQ0Msc0JBQWdCRCxDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBcEQsRUFBNEYsQ0FBNUY7QUFBK0YsSUFBSUUsS0FBSjtBQUFVUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDRyxRQUFNRixDQUFOLEVBQVE7QUFBQ0UsWUFBTUYsQ0FBTjtBQUFROztBQUFsQixDQUE5QyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJRyxZQUFKO0FBQWlCVCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDRyxtQkFBYUgsQ0FBYjtBQUFlOztBQUEzQixDQUFyQyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJdWIsY0FBSjtBQUFtQjdiLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx5REFBUixDQUFiLEVBQWdGO0FBQUN3YixpQkFBZXZiLENBQWYsRUFBaUI7QUFBQ3ViLHFCQUFldmIsQ0FBZjtBQUFpQjs7QUFBcEMsQ0FBaEYsRUFBc0gsQ0FBdEg7QUFjcmEsTUFBTXNjLG1CQUFtQixJQUFJcmMsZUFBSixDQUFvQjtBQUNsREssUUFBTSxrQkFENEM7QUFFbERDLFlBQVUsSUFBSUosWUFBSixDQUFpQjtBQUN6QitWLFNBQUs7QUFBRXpWLFlBQU1DO0FBQVIsS0FEb0I7QUFFekJvYixnQkFBWTtBQUFFcmIsWUFBTUM7QUFBUixLQUZhO0FBR3pCcWIscUJBQWlCO0FBQUV0YixZQUFNQztBQUFSLEtBSFE7QUFJekJzYixrQkFBYztBQUFFdmIsWUFBTUM7QUFBUixLQUpXO0FBS3pCOFQsaUJBQWE7QUFBRS9ULFlBQU1DO0FBQVIsS0FMWTtBQU16QnFLLGlCQUFhO0FBQUV0SyxZQUFNb0M7QUFBUixLQU5ZO0FBT3pCLHFCQUFpQjtBQUFFcEMsWUFBTUM7QUFBUjtBQVBRLEdBQWpCLEVBUVBDLFNBUk8sRUFGd0M7QUFXbERDLGdCQUFjO0FBQ1pDLGFBQVM7QUFERyxHQVhvQzs7QUFjbERDLE1BQUk7QUFBRW9WLE9BQUY7QUFBTzRGLGNBQVA7QUFBbUJDLG1CQUFuQjtBQUFvQ0MsZ0JBQXBDO0FBQWtEeEgsZUFBbEQ7QUFBK0R6SjtBQUEvRCxHQUFKLEVBQWlGO0FBQy9FLFFBQUksQ0FBRSxLQUFLaEssTUFBWCxFQUFtQjtBQUNqQixZQUFNLElBQUlsQixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNEOztBQUNELFFBQUksQ0FBRWQsTUFBTWUsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUErQixPQUEvQixDQUFOLEVBQThDO0FBQzVDLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0Q7O0FBRUQsUUFBSStKLFlBQVk0QyxNQUFaLEtBQXVCLENBQTNCLEVBQTZCO0FBQzNCNUMsa0JBQVlxSSxJQUFaLENBQWlCLE9BQWpCO0FBQ0Q7O0FBRUQvUixZQUFRQyxHQUFSLENBQVk7QUFDVjRVLFNBRFU7QUFDTjRGLGdCQURNO0FBQ0tDLHFCQURMO0FBQ3FCQyxrQkFEckI7QUFDa0N4SCxpQkFEbEM7QUFDOEN6SjtBQUQ5QyxLQUFaO0FBSUF3USxtQkFBZWhaLE1BQWYsQ0FBc0I7QUFDcEIyVCxXQUFLQTtBQURlLEtBQXRCLEVBRUU7QUFDQTVOLFlBQU07QUFDSndULGtCQURJO0FBRUpDLHVCQUZJO0FBR0pDLG9CQUhJO0FBSUp4SCxtQkFKSTtBQUtKeko7QUFMSTtBQUROLEtBRkY7QUFXRDs7QUF6Q2lELENBQXBCLENBQXpCLEM7Ozs7Ozs7Ozs7O0FDZFByTCxPQUFPQyxNQUFQLENBQWM7QUFBQzRjLGtCQUFlLE1BQUlBO0FBQXBCLENBQWQ7QUFBbUQsSUFBSTFjLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxlQUFKO0FBQW9CUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDRSxrQkFBZ0JELENBQWhCLEVBQWtCO0FBQUNDLHNCQUFnQkQsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXBELEVBQTRGLENBQTVGO0FBQStGLElBQUlHLFlBQUo7QUFBaUJULE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUNHLG1CQUFhSCxDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBTTFQLE1BQU11YyxpQkFBaUIsSUFBSXRjLGVBQUosQ0FBb0I7QUFDaERLLFFBQU0sZ0JBRDBDO0FBRWhEQyxZQUFVLElBQUlKLFlBQUosQ0FBaUI7QUFDekJZLFlBQVE7QUFBRU4sWUFBTUM7QUFBUixLQURpQjtBQUV6QjZCLFlBQVE7QUFBRTlCLFlBQU0wQyxNQUFSO0FBQWdCQyxnQkFBVTtBQUExQjtBQUZpQixHQUFqQixFQUdQekMsU0FITyxFQUZzQztBQU1oREMsZ0JBQWM7QUFDWkMsYUFBUztBQURHLEdBTmtDOztBQVNoREMsTUFBSTtBQUFFQyxVQUFGO0FBQVV3QjtBQUFWLEdBQUosRUFBdUI7QUFDckIsUUFBSSxDQUFFLEtBQUt4QixNQUFYLEVBQW1CO0FBQ2pCLFlBQU0sSUFBSWxCLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0Q7O0FBQ0QsUUFBSSxDQUFFZCxNQUFNZSxZQUFOLENBQW1CLEtBQUtGLE1BQXhCLEVBQStCLE9BQS9CLENBQU4sRUFBOEM7QUFDNUMsWUFBTSxJQUFJbEIsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDRDs7QUFFRG5CLFdBQU9tYSxLQUFQLENBQWF6WCxNQUFiLENBQW9CO0FBQUMyVCxXQUFLblY7QUFBTixLQUFwQixFQUFrQ3dCLE1BQWxDO0FBQ0Q7O0FBbEIrQyxDQUFwQixDQUF2QixDOzs7Ozs7Ozs7OztBQ05QN0MsT0FBT0MsTUFBUCxDQUFjO0FBQUNtWixxQkFBa0IsTUFBSUEsaUJBQXZCO0FBQXlDbE4sYUFBVSxNQUFJQSxTQUF2RDtBQUFpRVIsb0JBQWlCLE1BQUlBLGdCQUF0RjtBQUF1R2hFLGVBQVksTUFBSUE7QUFBdkgsQ0FBZDtBQUFtSixJQUFJaUcsVUFBSjtBQUFlM04sT0FBT0ksS0FBUCxDQUFhQyxRQUFRLDhDQUFSLENBQWIsRUFBcUU7QUFBQ3NOLGFBQVdyTixDQUFYLEVBQWE7QUFBQ3FOLGlCQUFXck4sQ0FBWDtBQUFhOztBQUE1QixDQUFyRSxFQUFtRyxDQUFuRzs7QUFPM0osTUFBTThZLG9CQUFxQm5QLEdBQUQsSUFBUztBQUN4QyxRQUFNMkIsT0FBTztBQUNYLFNBQUksR0FETztBQUNILFNBQUksR0FERDtBQUVYLFNBQUksR0FGTztBQUVILFNBQUksR0FGRDtBQUdYLFNBQUksR0FITztBQUdILFNBQUksR0FIRDtBQUlYLFNBQUksR0FKTztBQUlILFNBQUksR0FKRDtBQUtYLFNBQUksR0FMTztBQUtILFNBQUk7QUFMRCxHQUFiO0FBT0EsUUFBTUMsY0FBYzVCLElBQUk1RixLQUFKLENBQVUsRUFBVixFQUFjeUgsT0FBZCxFQUFwQjtBQUNBLFFBQU1DLGtCQUFrQkYsWUFBWWpILEdBQVosQ0FBa0JvSCxHQUFELElBQVM7QUFDaEQsV0FBT0osS0FBS0ksR0FBTCxDQUFQO0FBQ0QsR0FGdUIsQ0FBeEI7QUFHQSxRQUFNQyxhQUFhRixnQkFBZ0JwSCxJQUFoQixDQUFxQixFQUFyQixDQUFuQjtBQUNBLFNBQU9zSCxVQUFQO0FBQ0QsQ0FkTTs7QUFxQkEsTUFBTUMsWUFBYWpDLEdBQUQsSUFBUztBQUNoQyxRQUFNa0MsUUFBUTtBQUNaLFdBQU8sR0FESztBQUNBLFdBQU8sR0FEUDtBQUNZLFdBQU8sR0FEbkI7QUFFWixXQUFPLEdBRks7QUFFQSxXQUFPLEdBRlA7QUFFWSxXQUFPLEdBRm5CO0FBR1osV0FBTyxHQUhLO0FBR0EsV0FBTyxHQUhQO0FBR1ksV0FBTyxHQUhuQjtBQUlaLFdBQU8sR0FKSztBQUlBLFdBQU8sR0FKUDtBQUlZLFdBQU8sR0FKbkI7QUFLWixXQUFPLEdBTEs7QUFLQSxXQUFPLEdBTFA7QUFLWSxXQUFPLEdBTG5CO0FBTVosV0FBTyxHQU5LO0FBTUEsV0FBTyxHQU5QO0FBTVksV0FBTyxHQU5uQjtBQU9aLFdBQU8sR0FQSztBQU9BLFdBQU8sR0FQUDtBQU9ZLFdBQU8sR0FQbkI7QUFRWixXQUFPLEdBUks7QUFRQSxXQUFPLEdBUlA7QUFRWSxXQUFPLEdBUm5CO0FBU1osV0FBTyxHQVRLO0FBU0EsV0FBTyxHQVRQO0FBU1ksV0FBTyxHQVRuQjtBQVVaLFdBQU8sR0FWSztBQVVBLFdBQU8sR0FWUDtBQVVZLFdBQU8sR0FWbkI7QUFXWixXQUFPLEdBWEs7QUFXQSxXQUFPLEdBWFA7QUFXWSxXQUFPLEdBWG5CO0FBWVosV0FBTyxHQVpLO0FBWUEsV0FBTyxHQVpQO0FBWVksV0FBTyxHQVpuQjtBQWFaLFdBQU8sR0FiSztBQWFBLFdBQU8sR0FiUDtBQWFZLFdBQU8sR0FibkI7QUFjWixXQUFPLEdBZEs7QUFjQSxXQUFPLEdBZFA7QUFjWSxXQUFPLEdBZG5CO0FBZVosV0FBTyxHQWZLO0FBZUEsV0FBTyxHQWZQO0FBZVksV0FBTyxHQWZuQjtBQWdCWixXQUFPLEdBaEJLO0FBZ0JBLFdBQU8sR0FoQlA7QUFnQlksV0FBTyxHQWhCbkI7QUFpQlosV0FBTyxHQWpCSztBQWlCQSxXQUFPLEdBakJQO0FBaUJZLFdBQU8sR0FqQm5CO0FBa0JaLFdBQU8sR0FsQks7QUFrQkEsV0FBTyxHQWxCUDtBQWtCWSxXQUFPLEdBbEJuQjtBQW1CWixXQUFPLEdBbkJLO0FBbUJBLFdBQU8sR0FuQlA7QUFtQlksV0FBTyxHQW5CbkI7QUFvQlosV0FBTyxHQXBCSztBQW9CQSxXQUFPLEdBcEJQO0FBb0JZLFdBQU8sR0FwQm5CO0FBcUJaLFdBQU8sR0FyQks7QUFxQkEsV0FBTyxHQXJCUDtBQXFCWSxXQUFPLEdBckJuQjtBQXNCWixXQUFPO0FBdEJLLEdBQWQ7QUF1QkEsUUFBTUMsYUFBYW5DLElBQUlvQyxLQUFKLENBQVUsU0FBVixDQUFuQjtBQUNBLFFBQU1DLFdBQVdGLFdBQVd4SCxHQUFYLENBQWlCMkgsS0FBRCxJQUFXO0FBQzFDLFFBQUlDLFlBQVksR0FBaEI7O0FBQ0EsUUFBSUQsTUFBTUUsT0FBTixDQUFjLEdBQWQsSUFBcUIsQ0FBekIsRUFBMkI7QUFDekJELGtCQUFZTCxNQUFNSSxLQUFOLENBQVo7QUFDRDs7QUFDRCxXQUFPQyxTQUFQO0FBQ0QsR0FOZ0IsQ0FBakI7QUFPQSxRQUFNRSxNQUFNSixTQUFTM0gsSUFBVCxDQUFjLEVBQWQsQ0FBWjtBQUNBLFNBQU8rSCxHQUFQO0FBQ0QsQ0FsQ007O0FBb0NQOzs7Ozs7QUFNQSxNQUFNb1EsMkJBQTRCdFUsS0FBRCxJQUFXO0FBQzFDLFFBQU11VSxTQUFTdlUsTUFBTTVELEdBQU4sQ0FBVWdJLFFBQVE7QUFDL0IsV0FBT0EsS0FBS3hCLEtBQVo7QUFDRCxHQUZjLENBQWY7QUFHQSxRQUFNNFIsZUFBZSxDQUFDLEdBQUcsSUFBSXhYLEdBQUosQ0FBUXVYLE1BQVIsQ0FBSixDQUFyQjtBQUVBcGIsVUFBUUMsR0FBUixDQUFZb2IsWUFBWjtBQUVBLFFBQU1DLFVBQVVELGFBQWExWSxNQUFiLENBQW9CLENBQUM0WSxHQUFELEVBQUs5UixLQUFMLEVBQVcrUixDQUFYLEtBQWlCO0FBQ25ERCxRQUFJOVIsS0FBSixJQUFhdUMsV0FBV2pGLElBQVgsQ0FBZ0I7QUFDM0JrRixjQUFReEM7QUFEbUIsS0FBaEIsRUFFWDtBQUNBa0MsWUFBTTtBQUFFL0csZUFBTztBQUFUO0FBRE4sS0FGVyxFQUlWM0IsR0FKVSxDQUlOc0osT0FBTztBQUNaLGFBQU9BLElBQUlqRSxHQUFYO0FBQ0QsS0FOWSxFQU1WdEYsSUFOVSxDQU1MLEVBTkssQ0FBYjtBQU9BLFdBQU91WSxHQUFQO0FBQ0QsR0FUZSxFQVNkLEVBVGMsQ0FBaEIsQ0FSMEMsQ0FpQm5DOztBQUNQdmIsVUFBUUMsR0FBUixDQUFZcWIsT0FBWjtBQUNELENBbkJEO0FBc0JBOzs7Ozs7OztBQU1PLE1BQU12UixtQkFBb0JrQixJQUFELElBQVU7QUFDeEM7QUFDQSxRQUFNQyxjQUFjRCxLQUFLMUIsV0FBTCxDQUFpQjRCLE1BQWpCLENBQXlCQyxjQUFjO0FBQ3pELFdBQU9BLFdBQVdoTSxJQUFYLEtBQW9CLE1BQTNCO0FBQ0QsR0FGbUIsQ0FBcEI7QUFHQSxRQUFNaU0sWUFBWUgsWUFBWWpJLEdBQVosQ0FBaUJxSSxjQUFjO0FBQy9DLFFBQUlHLFdBQVdSLEtBQUsxQixXQUFMLENBQWlCNEIsTUFBakIsQ0FBeUJDLGNBQWM7QUFDcEQsYUFBT0EsV0FBV3JDLE9BQVgsQ0FBbUIrQixPQUFuQixDQUEyQlEsV0FBVzNFLEVBQXRDLEtBQTZDLENBQTdDLElBQWtEeUUsV0FBV2hNLElBQVgsS0FBb0IsS0FBN0U7QUFDRCxLQUZjLEVBRVp1TSxJQUZZLENBRU4sQ0FBQ0MsQ0FBRCxFQUFHQyxDQUFILEtBQVM7QUFDaEI7QUFDQSxhQUFPRCxFQUFFaEgsS0FBRixHQUFVaUgsRUFBRWpILEtBQW5CO0FBQ0QsS0FMYyxDQUFmO0FBT0EsUUFBSTZXLFNBQVNoUSxTQUFTeEksR0FBVCxDQUFjLENBQUN5SixHQUFELEVBQU12RSxLQUFOLEtBQWdCO0FBQ3pDLGFBQU91RSxJQUFJcEUsR0FBWDtBQUNELEtBRlksRUFFVnRGLElBRlUsQ0FFTCxFQUZLLENBQWI7QUFJQSxVQUFNMFksVUFBVXpRLEtBQUtsRyxNQUFMLEtBQWdCLEdBQWhDO0FBQ0EsVUFBTUMsUUFBUTBXLFVBQVVqUSxTQUFTLENBQVQsRUFBWXpHLEtBQXRCLEdBQThCeUcsU0FBU0EsU0FBU2EsTUFBVCxHQUFrQixDQUEzQixFQUE4QnRILEtBQTFFO0FBQ0EsVUFBTXVHLGdCQUFnQm1RLFVBQVVELE1BQVYsR0FBbUJoRSxrQkFBa0JnRSxNQUFsQixDQUF6QztBQUVBLFVBQU1FLFdBQVczVyxVQUFVLENBQVYsR0FBY0EsVUFBVSxDQUF6QztBQUNBLFVBQU00VyxZQUFZRCxXQUFXcFEsY0FBY29CLEtBQWQsQ0FBb0IzSCxLQUFwQixDQUFYLEdBQXdDdUcsYUFBMUQ7QUFFQSxVQUFNc1EsWUFBWXRSLFVBQVVxUixVQUFVaFAsV0FBVixFQUFWLENBQWxCO0FBRUEsV0FBTztBQUNMakcsVUFBSTJFLFdBQVczRSxFQURWO0FBRUwyQixXQUFLc1QsU0FGQTtBQUdMN1EsV0FBSzhRO0FBSEEsS0FBUDtBQUtELEdBMUJpQixDQUFsQjtBQTJCQSxTQUFPeFEsU0FBUDtBQUNELENBakNNOztBQW1DQSxNQUFNdEYsY0FBZStWLFlBQUQsSUFBa0I7QUFDM0M7QUFDQSxRQUFNQyxZQUFZLEVBQWxCO0FBQ0EsUUFBTUMsU0FBU0YsYUFBYXBaLEtBQWIsQ0FBbUIscUJBQW5CLENBQWY7QUFDQSxRQUFNb0UsVUFBVSxFQUFoQjtBQUNBLE1BQUlMLE9BQU8sRUFBWDtBQUNBLE1BQUl3VixVQUFVLEVBQWQ7QUFDQUQsU0FBTzVXLE9BQVAsQ0FBZSxDQUFDOFcsS0FBRCxFQUFRQyxVQUFSLEtBQXVCO0FBQ3BDLFlBQU9ELEtBQVA7QUFDRSxXQUFLLEdBQUw7QUFBVTtBQUNSRCxrQkFBVSxFQUFWO0FBQ0F4VixhQUFLMlYsU0FBTCxHQUFpQixDQUFDSCxPQUFELENBQWpCO0FBQ0FGLGtCQUFVaEssSUFBVixDQUFldEwsSUFBZjtBQUNBQSxlQUFPd1YsT0FBUDtBQUNBOztBQUNGLFdBQUssR0FBTDtBQUFVO0FBQ1JBLGtCQUFVLEVBQVY7QUFDQUYsa0JBQVVBLFVBQVV6UCxNQUFWLEdBQW1CLENBQTdCLEVBQWdDOFAsU0FBaEMsQ0FBMENySyxJQUExQyxDQUErQ2tLLE9BQS9DO0FBQ0F4VixlQUFPd1YsT0FBUDtBQUNBOztBQUNGLFdBQUssR0FBTDtBQUFVO0FBQ1J4VixlQUFPc1YsVUFBVXZWLEdBQVYsRUFBUDtBQUNBOztBQUNGLFdBQUssR0FBTDtBQUFVO0FBQ1I7O0FBQ0Y7QUFDRSxZQUFJNlYsZ0JBQWdCTCxPQUFPRyxhQUFhLENBQXBCLENBQXBCOztBQUNBLFlBQ0VFLGtCQUFrQixHQUFsQixJQUNBQSxrQkFBa0IsR0FEbEIsSUFFQUEsa0JBQWtCLEdBSHBCLEVBSUM7QUFDQzVWLGVBQUt4SCxJQUFMLEdBQVlpZCxLQUFaO0FBQ0EsZ0JBQU0zTixTQUFTMk4sTUFBTXhaLEtBQU4sQ0FBWSxHQUFaLEVBQWlCaUssS0FBakIsQ0FBdUIsQ0FBdkIsRUFBeUIsQ0FBQyxDQUExQixFQUE2QjNKLElBQTdCLENBQWtDLEdBQWxDLENBQWY7O0FBQ0EsY0FBSXVMLE9BQU9qQyxNQUFQLEdBQWdCLENBQXBCLEVBQXNCO0FBQ3BCeEYsb0JBQVFpTCxJQUFSLENBQWF4RCxNQUFiO0FBQ0Q7QUFDRixTQVZELE1BVU8sSUFBSThOLGtCQUFrQixHQUF0QixFQUEwQjtBQUMvQjVWLGVBQUs2VixZQUFMLEdBQW9CNVQsV0FBV3dULEtBQVgsQ0FBcEI7QUFDRDs7QUEvQkw7QUFpQ0QsR0FsQ0Q7QUFtQ0EsU0FBTztBQUNMelYsVUFBTUEsSUFERDtBQUVMSyxhQUFTQSxPQUZKO0FBR0xGLFVBQU1FLFFBQVF3RjtBQUhULEdBQVA7QUFLRCxDQS9DTSxDOzs7Ozs7Ozs7OztBQ3JJUGpPLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxtQkFBUixDQUFiO0FBQTJDTCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsdUNBQVIsQ0FBYjtBQUErREwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHNDQUFSLENBQWI7QUFBOERMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSw0QkFBUixDQUFiO0FBQW9ETCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYjtBQUE4Q0wsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHFDQUFSLENBQWI7QUFBNkRMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx5QkFBUixDQUFiO0FBQWlETCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYjtBQUFxREwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGlDQUFSLENBQWI7QUFBeURMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSwyQkFBUixDQUFiO0FBQW1ETCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYjtBQUFnREwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWI7QUFBK0NMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiO0FBQWtETCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYjtBQUFtREwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGtCQUFSLENBQWI7QUFBMENMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiO0FBQThDTCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsbUJBQVIsQ0FBYjtBQUEyQ0wsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLG9DQUFSLENBQWI7QUFBNERMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxtQ0FBUixDQUFiO0FBQTJETCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYjtBQUFxREwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGdDQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBNWdDLElBQUlGLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJNGQsZ0JBQUo7QUFBcUJsZSxPQUFPSSxLQUFQLENBQWFDLFFBQVEsa0NBQVIsQ0FBYixFQUF5RDtBQUFDNmQsbUJBQWlCNWQsQ0FBakIsRUFBbUI7QUFBQzRkLHVCQUFpQjVkLENBQWpCO0FBQW1COztBQUF4QyxDQUF6RCxFQUFtRyxDQUFuRztBQUFzRyxJQUFJRSxLQUFKO0FBQVVSLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNHLFFBQU1GLENBQU4sRUFBUTtBQUFDRSxZQUFNRixDQUFOO0FBQVE7O0FBQWxCLENBQTlDLEVBQWtFLENBQWxFO0FBQXFFLElBQUkyQixRQUFKO0FBQWFqQyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsbUNBQVIsQ0FBYixFQUEwRDtBQUFDSyxVQUFRSixDQUFSLEVBQVU7QUFBQzJCLGVBQVMzQixDQUFUO0FBQVc7O0FBQXZCLENBQTFELEVBQW1GLENBQW5GO0FBQXNGLElBQUk2QixLQUFKO0FBQVVuQyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsdUNBQVIsQ0FBYixFQUE4RDtBQUFDOEIsUUFBTTdCLENBQU4sRUFBUTtBQUFDNkIsWUFBTTdCLENBQU47QUFBUTs7QUFBbEIsQ0FBOUQsRUFBa0YsQ0FBbEY7QUFBcUYsSUFBSTJJLFVBQUo7QUFBZWpKLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSw0Q0FBUixDQUFiLEVBQW1FO0FBQUM0SSxhQUFXM0ksQ0FBWCxFQUFhO0FBQUMySSxpQkFBVzNJLENBQVg7QUFBYTs7QUFBNUIsQ0FBbkUsRUFBaUcsQ0FBakc7QUFBb0csSUFBSWlMLFFBQUo7QUFBYXZMLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSwyQ0FBUixDQUFiLEVBQWtFO0FBQUNrTCxXQUFTakwsQ0FBVCxFQUFXO0FBQUNpTCxlQUFTakwsQ0FBVDtBQUFXOztBQUF4QixDQUFsRSxFQUE0RixDQUE1RjtBQUErRixJQUFJbUgsV0FBSjtBQUFnQnpILE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSw2Q0FBUixDQUFiLEVBQW9FO0FBQUNvSCxjQUFZbkgsQ0FBWixFQUFjO0FBQUNtSCxrQkFBWW5ILENBQVo7QUFBYzs7QUFBOUIsQ0FBcEUsRUFBb0csQ0FBcEc7QUFBdUcsSUFBSW1KLFdBQUo7QUFBZ0J6SixPQUFPSSxLQUFQLENBQWFDLFFBQVEsOENBQVIsQ0FBYixFQUFxRTtBQUFDb0osY0FBWW5KLENBQVosRUFBYztBQUFDbUosa0JBQVluSixDQUFaO0FBQWM7O0FBQTlCLENBQXJFLEVBQXFHLENBQXJHO0FBQXdHLElBQUlvQyxNQUFKO0FBQVcxQyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsMENBQVIsQ0FBYixFQUFpRTtBQUFDcUMsU0FBT3BDLENBQVAsRUFBUztBQUFDb0MsYUFBT3BDLENBQVA7QUFBUzs7QUFBcEIsQ0FBakUsRUFBdUYsQ0FBdkY7QUFBMEYsSUFBSXFOLFVBQUosRUFBZWdGLGFBQWY7QUFBNkIzUyxPQUFPSSxLQUFQLENBQWFDLFFBQVEsOENBQVIsQ0FBYixFQUFxRTtBQUFDc04sYUFBV3JOLENBQVgsRUFBYTtBQUFDcU4saUJBQVdyTixDQUFYO0FBQWEsR0FBNUI7O0FBQTZCcVMsZ0JBQWNyUyxDQUFkLEVBQWdCO0FBQUNxUyxvQkFBY3JTLENBQWQ7QUFBZ0I7O0FBQTlELENBQXJFLEVBQXFJLEVBQXJJO0FBQXlJLElBQUl1YixjQUFKLEVBQW1CQyxjQUFuQjtBQUFrQzliLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx5REFBUixDQUFiLEVBQWdGO0FBQUN3YixpQkFBZXZiLENBQWYsRUFBaUI7QUFBQ3ViLHFCQUFldmIsQ0FBZjtBQUFpQixHQUFwQzs7QUFBcUN3YixpQkFBZXhiLENBQWYsRUFBaUI7QUFBQ3diLHFCQUFleGIsQ0FBZjtBQUFpQjs7QUFBeEUsQ0FBaEYsRUFBMEosRUFBMUo7QUFlanRDSCxPQUFPZ2UsT0FBUCxDQUFlLE9BQWYsRUFBd0IsVUFBU0MsS0FBVCxFQUFnQjNFLE1BQWhCLEVBQXdCalcsS0FBeEIsRUFBK0I7QUFDckQ3QixVQUFRQyxHQUFSLENBQVksc0JBQVo7QUFDQUQsVUFBUUMsR0FBUixDQUFZLE9BQVosRUFBb0J3YyxLQUFwQjtBQUNBemMsVUFBUUMsR0FBUixDQUFZLFFBQVosRUFBcUI2WCxNQUFyQjtBQUNBOVgsVUFBUUMsR0FBUixDQUFZLE9BQVosRUFBb0I0QixLQUFwQjtBQUNBLFFBQU02YSxjQUFjLElBQXBCOztBQUNBLE1BQUksQ0FBQ0EsWUFBWWhkLE1BQWpCLEVBQXdCO0FBQ3RCZ2QsZ0JBQVlDLElBQVo7QUFDRDs7QUFFREYsVUFBUUEsU0FBUyxFQUFqQjtBQUNBNWEsVUFBUUEsU0FBUyxFQUFqQjs7QUFDQSxNQUFJaVcsTUFBSixFQUFZO0FBQ1ZqVyxVQUFNa1csR0FBTixHQUFZLENBQUM7QUFBRSxZQUFNO0FBQUVDLGdCQUFRRixNQUFWO0FBQW1CRyxrQkFBVTtBQUE3QjtBQUFSLEtBQUQsRUFBOEM7QUFBRSxjQUFRO0FBQUVELGdCQUFRRixNQUFWO0FBQW1CRyxrQkFBVTtBQUE3QjtBQUFWLEtBQTlDLENBQVo7O0FBQ0EsUUFBSSxDQUFDcFcsTUFBTXFXLGNBQU4sQ0FBcUIsYUFBckIsQ0FBTCxFQUF5QztBQUN2Q3JXLFlBQU1rVyxHQUFOLENBQVVoRyxJQUFWLENBQWU7QUFBRSx1QkFBZTtBQUFFaUcsa0JBQVFGLE1BQVY7QUFBbUJHLG9CQUFVO0FBQTdCO0FBQWpCLE9BQWY7QUFDRDtBQUNGOztBQUVELFFBQU0yRSxRQUFRL2QsTUFBTWdlLGVBQU4sQ0FBc0JILFlBQVloZCxNQUFsQyxDQUFkO0FBRUFtQyxRQUFNNkgsV0FBTixHQUFvQjtBQUFFMUMsU0FBSzRWO0FBQVAsR0FBcEI7QUFFQSxTQUFPcGMsTUFBTXVHLElBQU4sQ0FBV2xGLEtBQVgsRUFBaUI7QUFBQzRhLFdBQU9BO0FBQVIsR0FBakIsQ0FBUDtBQUNELENBeEJEO0FBMEJBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQStDQUYsaUJBQWlCLFlBQWpCLEVBQStCLFlBQVU7QUFDdkMsUUFBTUcsY0FBYyxJQUFwQjs7QUFDQSxNQUFJLENBQUNBLFlBQVloZCxNQUFqQixFQUF3QjtBQUN0QmdkLGdCQUFZQyxJQUFaO0FBQ0Q7O0FBRUQsUUFBTUMsUUFBUS9kLE1BQU1nZSxlQUFOLENBQXNCSCxZQUFZaGQsTUFBbEMsQ0FBZDtBQUVBLFNBQU87QUFDTHFILFdBQU07QUFDSixhQUFPaUssY0FBY2pLLElBQWQsQ0FBbUI7QUFDeEIyQyxxQkFBYTtBQUNYMUMsZUFBSzRWO0FBRE07QUFEVyxPQUFuQixDQUFQO0FBS0QsS0FQSTs7QUFRTGhVLGNBQVUsQ0FDUjtBQUNFN0IsV0FBS3lDLFNBQUwsRUFBZTtBQUNiLGVBQU9sQyxXQUFXUCxJQUFYLENBQWdCO0FBQ3JCZ1IsZUFBSyxDQUNIO0FBQ0UvSCx3QkFBWXhHLFVBQVU2SDtBQUR4QixXQURHLEVBSUg7QUFDRXlMLDJCQUFlO0FBRGpCLFdBSkc7QUFEZ0IsU0FBaEIsQ0FBUDtBQVVEOztBQVpILEtBRFE7QUFSTCxHQUFQO0FBeUJELENBakNEO0FBbUNBdGUsT0FBT2dlLE9BQVAsQ0FBZSxPQUFmLEVBQXdCLFlBQVk7QUFDbEMsTUFBSSxDQUFDLEtBQUs5YyxNQUFWLEVBQWlCO0FBQ2YsU0FBS2lkLElBQUwsR0FEZSxDQUVmO0FBQ0Q7O0FBQ0QsTUFBSTlkLE1BQU1lLFlBQU4sQ0FBbUIsS0FBS0YsTUFBeEIsRUFBK0IsT0FBL0IsQ0FBSixFQUE0QztBQUMxQyxXQUFPbEIsT0FBT21hLEtBQVAsQ0FBYTVSLElBQWIsQ0FBa0IsRUFBbEIsQ0FBUDtBQUNELEdBRkQsTUFFTyxJQUFJbEksTUFBTWUsWUFBTixDQUFtQixLQUFLRixNQUF4QixFQUErQixDQUFDLE1BQUQsRUFBUSxTQUFSLENBQS9CLENBQUosRUFBdUQ7QUFDNUQsV0FBT2xCLE9BQU9tYSxLQUFQLENBQWE1UixJQUFiLENBQWtCLEVBQWxCLEVBQXFCO0FBQUN3TCxjQUFPO0FBQUN3SyxrQkFBUztBQUFWO0FBQVIsS0FBckIsQ0FBUDtBQUNELEdBRk0sTUFFQTtBQUNMLFNBQUtDLEtBQUwsR0FESyxDQUVMO0FBQ0Q7QUFDRixDQWJEO0FBZUF4ZSxPQUFPZ2UsT0FBUCxDQUFlO0FBQ2JTLGFBQVkxTyxNQUFaLEVBQW9CO0FBQ2xCLFVBQU1tTyxjQUFjLElBQXBCOztBQUNBLFFBQUksQ0FBQ0EsWUFBWWhkLE1BQWpCLEVBQXdCO0FBQ3RCZ2Qsa0JBQVlDLElBQVo7QUFDRDs7QUFDRCxVQUFNQyxRQUFRL2QsTUFBTWdlLGVBQU4sQ0FBc0JILFlBQVloZCxNQUFsQyxDQUFkO0FBQ0EsV0FBT2MsTUFBTXVHLElBQU4sQ0FBVztBQUNoQkosVUFBSTRILE1BRFk7QUFFaEI3RSxtQkFBYTtBQUNYMUMsYUFBSzRWO0FBRE07QUFGRyxLQUFYLENBQVA7QUFNRCxHQWJZOztBQWNiTSxpQkFBZ0IzTyxNQUFoQixFQUF3QjtBQUN0QixVQUFNbU8sY0FBYyxJQUFwQjs7QUFDQSxRQUFJLENBQUNBLFlBQVloZCxNQUFqQixFQUF3QjtBQUN0QmdkLGtCQUFZQyxJQUFaO0FBQ0Q7O0FBQ0QsVUFBTUMsUUFBUS9kLE1BQU1nZSxlQUFOLENBQXNCSCxZQUFZaGQsTUFBbEMsQ0FBZDtBQUNBLFdBQU95YSxlQUFlcFQsSUFBZixDQUFvQjtBQUN6QndILGNBQVFBLE1BRGlCO0FBRXpCN0UsbUJBQWE7QUFDWDFDLGFBQUs0VjtBQURNO0FBRlksS0FBcEIsQ0FBUDtBQU1ELEdBMUJZOztBQTJCYk8sbUJBQWlCO0FBQ2YsVUFBTVQsY0FBYyxJQUFwQjs7QUFDQSxRQUFJLENBQUNBLFlBQVloZCxNQUFqQixFQUF3QjtBQUN0QmdkLGtCQUFZQyxJQUFaO0FBQ0Q7O0FBQ0QsVUFBTUMsUUFBUS9kLE1BQU1nZSxlQUFOLENBQXNCSCxZQUFZaGQsTUFBbEMsQ0FBZDtBQUNBLFdBQU93YSxlQUFlblQsSUFBZixDQUFvQjtBQUN6QjJDLG1CQUFhO0FBQ1gxQyxhQUFLNFY7QUFETTtBQURZLEtBQXBCLENBQVA7QUFLRCxHQXRDWTs7QUF1Q2JRLFlBQVduRCxVQUFYLEVBQXVCO0FBQ3JCLFVBQU15QyxjQUFjLElBQXBCO0FBQ0EsVUFBTUUsUUFBUUYsWUFBWWhkLE1BQVosR0FBcUJiLE1BQU1nZSxlQUFOLENBQXNCSCxZQUFZaGQsTUFBbEMsQ0FBckIsR0FBaUUsQ0FBQyxRQUFELENBQS9FO0FBQ0EsV0FBTytCLFVBQVVSLE9BQVYsQ0FBa0I7QUFBQzBGLFVBQUlzVCxVQUFMO0FBQWlCb0Qsa0JBQVk7QUFBQ3JXLGFBQUs0VjtBQUFOO0FBQTdCLEtBQWxCLENBQVA7QUFDRCxHQTNDWTs7QUE0Q2J0YyxhQUFZO0FBQ1YsVUFBTW9jLGNBQWMsSUFBcEI7O0FBQ0EsUUFBSSxDQUFDQSxZQUFZaGQsTUFBakIsRUFBd0I7QUFDdEJnZCxrQkFBWUMsSUFBWjtBQUNEOztBQUNELFdBQU9yYyxTQUFTeUcsSUFBVCxDQUFjLEVBQWQsQ0FBUDtBQUNELEdBbERZOztBQW1EYnVXLGtCQUFpQjtBQUNmLFVBQU1aLGNBQWMsSUFBcEI7O0FBQ0EsUUFBSSxDQUFDQSxZQUFZaGQsTUFBakIsRUFBd0I7QUFDdEJnZCxrQkFBWUMsSUFBWjtBQUNEOztBQUNELFVBQU1DLFFBQVEvZCxNQUFNZ2UsZUFBTixDQUFzQkgsWUFBWWhkLE1BQWxDLENBQWQ7QUFDQSxXQUFPc1IsY0FBY2pLLElBQWQsQ0FBbUI7QUFDeEIyQyxtQkFBYTtBQUNYMUMsYUFBSzRWO0FBRE07QUFEVyxLQUFuQixDQUFQO0FBS0QsR0E5RFk7O0FBK0RiVyxjQUFhNVcsRUFBYixFQUFpQjtBQUNmLFFBQUksQ0FBQyxLQUFLakgsTUFBVixFQUFpQjtBQUNmLFdBQUtpZCxJQUFMO0FBQ0Q7O0FBQ0QsV0FBTzdXLFlBQVlpQixJQUFaLENBQWlCO0FBQUUsWUFBTUo7QUFBUixLQUFqQixDQUFQO0FBQ0QsR0FwRVk7O0FBcUVib0osV0FBUztBQUNQLFVBQU0yTSxjQUFjLElBQXBCOztBQUNBLFFBQUksQ0FBQ0EsWUFBWWhkLE1BQWpCLEVBQXdCO0FBQ3RCZ2Qsa0JBQVlDLElBQVosR0FEc0IsQ0FFdEI7QUFDRDs7QUFDRCxVQUFNQyxRQUFRL2QsTUFBTWdlLGVBQU4sQ0FBc0JILFlBQVloZCxNQUFsQyxDQUFkO0FBQ0FNLFlBQVFDLEdBQVIsQ0FBYSwrQkFBOEJ5YyxZQUFZaGQsTUFBTyxlQUFja2QsS0FBTSxFQUFsRjtBQUNBLFdBQU83YixPQUFPZ0csSUFBUCxDQUFZO0FBQ2pCMkMsbUJBQWE7QUFDWDFDLGFBQUs0VjtBQURNO0FBREksS0FBWixDQUFQO0FBS0QsR0FsRlk7O0FBbUZiWSxhQUFXO0FBQ1QsUUFBSSxDQUFDLEtBQUs5ZCxNQUFWLEVBQWlCO0FBQ2YsV0FBS2lkLElBQUwsR0FEZSxDQUVmO0FBQ0Q7O0FBQ0QsV0FBTy9TLFNBQVM3QyxJQUFULENBQWMsRUFBZCxDQUFQO0FBQ0QsR0F6Rlk7O0FBMEZiMFcsZ0JBQWM7QUFDWixRQUFJLENBQUMsS0FBSy9kLE1BQVYsRUFBaUI7QUFDZixXQUFLaWQsSUFBTCxHQURlLENBRWY7QUFDRDs7QUFDRCxXQUFPN1UsWUFBWWYsSUFBWixDQUFpQixFQUFqQixDQUFQO0FBQ0Q7O0FBaEdZLENBQWY7QUFtR0E7Ozs7Ozs7Ozs7Ozs7OztBQzdPQTFJLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiO0FBQThDTCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsaUNBQVIsQ0FBYjtBQUF5REwsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHFCQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBdkcsSUFBSUYsTUFBSjtBQUFXSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFNBQU9HLENBQVAsRUFBUztBQUFDSCxhQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUk0RCxFQUFKO0FBQU9sRSxPQUFPSSxLQUFQLENBQWFDLFFBQVEsSUFBUixDQUFiLEVBQTJCO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDNEQsU0FBRzVELENBQUg7QUFBSzs7QUFBakIsQ0FBM0IsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSTJCLFFBQUo7QUFBYWpDLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxtQ0FBUixDQUFiLEVBQTBEO0FBQUNLLFVBQVFKLENBQVIsRUFBVTtBQUFDMkIsZUFBUzNCLENBQVQ7QUFBVzs7QUFBdkIsQ0FBMUQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSTJJLFVBQUo7QUFBZWpKLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSw0Q0FBUixDQUFiLEVBQW1FO0FBQUM0SSxhQUFXM0ksQ0FBWCxFQUFhO0FBQUMySSxpQkFBVzNJLENBQVg7QUFBYTs7QUFBNUIsQ0FBbkUsRUFBaUcsQ0FBakc7QUFBb0csSUFBSW9DLE1BQUo7QUFBVzFDLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSwwQ0FBUixDQUFiLEVBQWlFO0FBQUNxQyxTQUFPcEMsQ0FBUCxFQUFTO0FBQUNvQyxhQUFPcEMsQ0FBUDtBQUFTOztBQUFwQixDQUFqRSxFQUF1RixDQUF2RjtBQVFuV0gsT0FBT2tmLE9BQVAsQ0FBZ0IsTUFBTTtBQUNwQixNQUFLbGYsT0FBT21hLEtBQVAsQ0FBYTVSLElBQWIsR0FBb0I0UCxLQUFwQixPQUFnQyxDQUFyQyxFQUF5QztBQUN2QzNXLFlBQVFDLEdBQVIsQ0FBWSwyQkFBWjtBQUNBLFVBQU0wZCxVQUFVQyxTQUFTQyxVQUFULENBQW9CO0FBQ2xDZCxnQkFBVSxPQUR3QjtBQUVsQzNQLGFBQU8sZ0JBRjJCO0FBR2xDMFEsZ0JBQVUsT0FId0I7QUFJbENDLGVBQVM7QUFDUEMsb0JBQVksT0FETDtBQUVQQyxtQkFBVztBQUZKO0FBSnlCLEtBQXBCLENBQWhCO0FBU0FwZixVQUFNcWYsZUFBTixDQUFzQlAsT0FBdEIsRUFBOEIsQ0FBQyxPQUFELEVBQVMsU0FBVCxFQUFtQixNQUFuQixFQUEwQixZQUExQixDQUE5QjtBQUVBM2QsWUFBUUMsR0FBUixDQUFZLDJCQUFaO0FBQ0EsVUFBTWtlLFVBQVVQLFNBQVNDLFVBQVQsQ0FBb0I7QUFDaENkLGdCQUFVLE9BRHNCO0FBRWhDM1AsYUFBTyxnQkFGeUI7QUFHaEMwUSxnQkFBVSxPQUhzQjtBQUloQ0MsZUFBUztBQUNMQyxvQkFBWSxPQURQO0FBRUxDLG1CQUFXO0FBRk47QUFKdUIsS0FBcEIsQ0FBaEI7QUFTQXBmLFVBQU1xZixlQUFOLENBQXNCQyxPQUF0QixFQUE4QixDQUFDLE1BQUQsRUFBUSxZQUFSLENBQTlCO0FBQ0QsR0F6Qm1CLENBMEJwQjs7O0FBQ0EsUUFBTUMsc0JBQXNCLENBQzFCO0FBQ0VuZixVQUFNLFNBRFI7QUFFRTRDLFdBQU87QUFGVCxHQUQwQixFQUsxQjtBQUNFNUMsVUFBTSxTQURSO0FBRUU0QyxXQUFPO0FBRlQsR0FMMEIsRUFTMUI7QUFDRTVDLFVBQU0sWUFEUjtBQUVFNEMsV0FBTztBQUZULEdBVDBCLEVBYTFCO0FBQ0U1QyxVQUFNLGlCQURSO0FBRUU0QyxXQUFPO0FBRlQsR0FiMEIsQ0FBNUI7QUFpQkF1YyxzQkFBb0JoWixPQUFwQixDQUE2QmlaLGFBQWE7QUFDeENyZSxZQUFRQyxHQUFSLENBQWEsaUNBQWdDb2UsVUFBVXBmLElBQUssRUFBNUQ7QUFDQXFJLGVBQVd3SSxhQUFYLENBQXlCO0FBQ3ZCak8sYUFBTztBQUNMNUMsY0FBTW9mLFVBQVVwZjtBQURYLE9BRGdCO0FBSXZCaUMsY0FBUTtBQUNOK08sc0JBQWM7QUFDWmhSLGdCQUFNb2YsVUFBVXBmLElBREo7QUFFWjRDLGlCQUFPd2MsVUFBVXhjLEtBRkw7QUFHWnFPLGdCQUFNLElBSE07QUFJWkMsbUJBQVMsS0FKRztBQUtaQyxvQkFBVSxJQUxFO0FBTVowTSx5QkFBZTtBQU5IO0FBRFIsT0FKZTtBQWN2QnpNLFdBQUssSUFka0I7QUFldkJDLGNBQVE7QUFmZSxLQUF6QjtBQWlCRCxHQW5CRDtBQXFCQXZQLFNBQU9nRyxJQUFQLENBQVk7QUFDVnlNLGNBQVU7QUFDUjhLLGVBQVM7QUFERDtBQURBLEdBQVosRUFJR2pTLEtBSkgsR0FJV2xCLE1BSlgsQ0FJa0JuSyxTQUFTO0FBQ3pCLFVBQU11ZCxXQUFXaGMsR0FBR3ZELFVBQUgsQ0FBY2dDLE1BQU13UyxRQUFOLENBQWVuSixHQUE3QixDQUFqQjtBQUNBLFVBQU1tVSxZQUFZamMsR0FBR3ZELFVBQUgsQ0FBY2dDLE1BQU13UyxRQUFOLENBQWVpTCxJQUE3QixDQUFsQjtBQUNBLFdBQU8sQ0FBQ0QsU0FBRCxJQUFjLENBQUNELFFBQXRCO0FBQ0QsR0FSRCxFQVFHdGIsR0FSSCxDQVFPakMsU0FBUztBQUNkRCxXQUFPRyxNQUFQLENBQWM7QUFDWjJULFdBQUs3VCxNQUFNNlQ7QUFEQyxLQUFkLEVBRUU7QUFDQTFULGNBQVE7QUFDTnFTLGtCQUFVO0FBREo7QUFEUixLQUZGO0FBT0QsR0FoQkQsRUFqRW9CLENBb0ZwQjs7QUFDQWxULFdBQVNvZSxLQUFULENBQWU7QUFDYjtBQUNBQyxXQUFPLFVBQVVqZixNQUFWLEVBQWtCa2YsTUFBbEIsRUFBMEJDLE1BQTFCLEVBQWtDO0FBQ3ZDLGFBQU9oZ0IsTUFBTWUsWUFBTixDQUFtQkYsTUFBbkIsRUFBMEIsT0FBMUIsQ0FBUDtBQUNEO0FBSlksR0FBZjtBQU1BLFNBQU9ZLFNBQVN3ZSxjQUFULEVBQVA7QUFDRCxDQTVGRCxFOzs7Ozs7Ozs7OztBQ1JBLElBQUl0Z0IsTUFBSjtBQUFXSCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFNBQU9HLENBQVAsRUFBUztBQUFDSCxhQUFPRyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlpZixRQUFKO0FBQWF2ZixPQUFPSSxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFQUE2QztBQUFDa2YsV0FBU2pmLENBQVQsRUFBVztBQUFDaWYsZUFBU2pmLENBQVQ7QUFBVzs7QUFBeEIsQ0FBN0MsRUFBdUUsQ0FBdkU7QUFBMEUsSUFBSUUsS0FBSjtBQUFVUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDRyxRQUFNRixDQUFOLEVBQVE7QUFBQ0UsWUFBTUYsQ0FBTjtBQUFROztBQUFsQixDQUE5QyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJNkIsS0FBSjtBQUFVbkMsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHVDQUFSLENBQWIsRUFBOEQ7QUFBQ0ssVUFBUUosQ0FBUixFQUFVO0FBQUM2QixZQUFNN0IsQ0FBTjtBQUFROztBQUFwQixDQUE5RCxFQUFvRixDQUFwRjtBQU0xUGlmLFNBQVNtQixZQUFULENBQXVCLENBQUNySixPQUFELEVBQVMvVSxJQUFULEtBQWtCO0FBQ3ZDWCxVQUFRQyxHQUFSLENBQVksY0FBWjtBQUNBVSxPQUFLaWMsS0FBTCxHQUFhLENBQUMsWUFBRCxDQUFiOztBQUNBLE1BQUksT0FBT2pjLEtBQUtvZCxPQUFaLEtBQXdCLFdBQTVCLEVBQXdDO0FBQ3RDcGQsU0FBS29kLE9BQUwsR0FBZTtBQUNiQyxrQkFBWSxFQURDO0FBRWJDLGlCQUFXO0FBRkUsS0FBZjtBQUlEOztBQUNELFNBQU90ZCxJQUFQO0FBQ0QsQ0FWRDtBQVlBaWQsU0FBU29CLFFBQVQsQ0FBb0J0SixPQUFELElBQWE7QUFDOUIxVixVQUFRQyxHQUFSLENBQVksUUFBWixFQUFxQnlWLE9BQXJCO0FBQ0FsWCxTQUFPbWEsS0FBUCxDQUFhelgsTUFBYixDQUFvQjtBQUNsQjJULFNBQUthLFFBQVEvVSxJQUFSLENBQWFrVSxHQURBO0FBRWxCLHVCQUFtQjtBQUZELEdBQXBCLEVBR0U7QUFDQTVOLFVBQU07QUFDSix5QkFBbUI7QUFEZjtBQUROLEdBSEY7QUFTQXpHLFFBQU1VLE1BQU4sQ0FBYTtBQUNYLGVBQVd3VSxRQUFRL1UsSUFBUixDQUFha1U7QUFEYixHQUFiLEVBRUU7QUFDQXVELFdBQU87QUFDTCxpQkFBVzFDLFFBQVEvVSxJQUFSLENBQWFrVTtBQURuQjtBQURQLEdBRkYsRUFNRyxDQUFDeE8sR0FBRCxFQUFLZ1MsR0FBTCxLQUFhO0FBQ2Q3WCxVQUFNVSxNQUFOLENBQWE7QUFDWCxpQkFBVztBQUNUb2QsaUJBQVMsSUFEQTtBQUVUVyxlQUFPO0FBRkU7QUFEQSxLQUFiLEVBS0U7QUFDQTlkLGNBQVE7QUFDTixtQkFBVztBQURMO0FBRFIsS0FMRjtBQVVELEdBakJELEVBWDhCLENBOEI5QjtBQUNBO0FBQ0QsQ0FoQ0Q7QUFrQ0EzQyxPQUFPbWEsS0FBUCxDQUFhK0YsS0FBYixDQUFtQjtBQUNqQnhkLFNBQU94QixNQUFQLEVBQWV3ZixHQUFmLEVBQW9CM00sTUFBcEIsRUFBNEI0TSxRQUE1QixFQUFxQztBQUNuQ25mLFlBQVFDLEdBQVIsQ0FBWSxhQUFaO0FBQ0FELFlBQVFDLEdBQVIsQ0FBWWlmLEdBQVo7QUFDQWxmLFlBQVFDLEdBQVIsQ0FBWXNTLE1BQVo7QUFDQXZTLFlBQVFDLEdBQVIsQ0FBWWtmLFFBQVo7O0FBQ0EsUUFBSXpmLFVBQVViLE1BQU1lLFlBQU4sQ0FBbUJGLE1BQW5CLEVBQTJCLE9BQTNCLENBQWQsRUFBa0Q7QUFDaEQsYUFBTyxJQUFQO0FBQ0Q7QUFDRjs7QUFUZ0IsQ0FBbkIsRTs7Ozs7Ozs7Ozs7QUNwREE7QUFFQTs7QUFFbUI7QUFDbEIsUUFBTStRLFNBQVMvUixJQUFmOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUVBO0FBRUEwZ0IsWUFDRUMsU0FERixDQUNZLElBS1c7QUFDckI5YixlQUFXK2IsS0FBS0MsT0FBTCxDQUFhcGIsSUFBYixDQUFYO0FBQ0EsR0FSRixFQVNFTCxLQVRGLENBU1FnUyxRQUFRMEosSUFUaEI7O0FBY3lCO0FBQ3hCSixjQUFVSyxJQUFWO0FBQ0E7O0FBRUQ7QUFFQSxRQUFNL0osVUFBVTtBQUNmblMsY0FBVUEsS0FESztBQUVmOE4sbUJBQWUrTixJQUZBO0FBR2ZqZ0IsZUFBV0E7QUFISSxHQUFoQjtBQU1BYSxJQUFBO0FBQ0FBLFVBQVFDLEdBQVIsQ0FBWXlWLE9BQVo7QUFFQSxRQUFNZ0ssYUFBYUMsRUFBbkI7QUFFQSxRQUFNQyxTQUFTLElBQUlGLFVBQUosQ0FBZTtBQUM3QkcsY0FBVSxtQkFEbUI7QUFFN0JDLHVCQUFtQkM7QUFGVSxHQUFmLENBQWY7QUFLQUgsS0FBeUI7QUFDeEI3QyxjQUFVcUMsVUFBVXJDLElBREk7QUFFeEJlLGNBQVVzQixVQUFVdEI7QUFGSSxHQUF6QixFQUdHbE8sSUFISCxDQUdRQyxVQUFVO0FBQ2pCK1AsV0FBT3ZOLElBQVAsQ0FBWSxLQUNJO0FBQ2ZyUyxjQUFRQyxHQUFSLENBQVk0UCxNQUFaO0FBQ0ErUCxhQUFPSSxVQUFQO0FBQ0EsS0FKRCxFQUtDelAsS0FMRCxDQUtPck0sU0FBUztBQUNmbEUsY0FBUUMsR0FBUixDQUFZaUUsS0FBWjtBQUNBMGIsYUFBT0ksVUFBUDtBQUNBLEtBUkQ7QUFTQSxHQWJEO0FBY0E7Ozs7Ozs7Ozs7OztBQ2pFRDtBQUVBOztBQUVtQjtBQUNqQixRQUFNdlAsU0FBUy9SLElBQWY7O0FBRUE7OztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUVBO0FBRUEwZ0IsWUFDR0MsR0FJcUI7QUFDcEI5YixlQUFXK2IsS0FBS0MsT0FBTCxDQUFhcGIsSUFBYixDQUFYO0FBQ0QsR0FQSCxFQVFHTCxLQVJILENBUVNnUyxRQUFRMEosSUFSakI7O0FBYTBCO0FBQ3hCSixjQUFVSyxJQUFWO0FBQ0Q7O0FBRWU7QUFDZGxjLGNBQVVBLEtBREk7QUFFZHBFLGVBQVdpZ0IsUUFBVWE7QUFGUCxHQUFoQjtBQUtBamdCLElBQUE7QUFDQUEsVUFBUUMsR0FBUixDQUFZeVYsT0FBWjtBQUVBLFFBQU1nSyxhQUFhQyxFQUFuQjtBQUVBLFFBQU1DLFNBQVMsSUFBSUYsVUFBSixDQUFlO0FBQzVCRyxjQUFVLG1CQURrQjtBQUU1QkMsdUJBQW1CQztBQUZTLEdBQWYsQ0FBZjtBQUtBSCxLQUF5QjtBQUN2QjdDLGNBQVVxQyxVQUFVckMsSUFERztBQUV2QmUsY0FBVXNCLFVBQVV0QjtBQUZHLEdBQXpCLEVBR0dsTyxJQUhILENBR1FDLFVBQVU7QUFDaEIrUCxXQUFPdk4sSUFBUCxDQUFZLEtBQ0k7QUFDZHJTLGNBQVFDLEdBQVIsQ0FBWTRQLE1BQVo7QUFDQStQLGFBQU9JLFVBQVA7QUFDRCxLQUpELEVBS0N6UCxLQUxELENBS09yTSxTQUFTO0FBQ2RsRSxjQUFRQyxHQUFSLENBQVlpRSxLQUFaO0FBQ0EwYixhQUFPSSxVQUFQO0FBQ0QsS0FSRDtBQVNELEdBYkQ7QUFjRDs7Ozs7Ozs7Ozs7O0FDN0REO0FBRUE7O0FBRW1CO0FBQ2pCLFFBQU1aLFlBQVkxZ0IsQ0FBbEI7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBRUE7QUFFQTBnQixZQUNHQyxDQUdxQjtBQUNwQnJaLGFBQVNzWixLQUFLQyxPQUFMLENBQWFwYixJQUFiLENBQVQ7QUFDRCxHQU5ILEVBT0dMLEtBUEgsQ0FPU2dTLFFBQVEwSixJQVBqQjs7QUFXd0I7QUFDdEJKLGNBQVVLLElBQVY7QUFDRDs7QUFFZTtBQUNkelosWUFBUUE7QUFETSxHQUFoQjtBQUlBaEcsSUFBQTtBQUNBQSxVQUFRQyxHQUFSLENBQVl5VixPQUFaO0FBRUEsUUFBTWdLLGFBQWFDLEVBQW5CO0FBRUEsUUFBTUMsU0FBUyxJQUFJRixVQUFKLENBQWU7QUFDNUJHLGNBQVUsbUJBRGtCO0FBRTVCQyx1QkFBbUJDO0FBRlMsR0FBZixDQUFmO0FBS0FILEtBQXlCO0FBQ3ZCN0MsY0FBVXFDLFVBQVVyQyxJQURHO0FBRXZCZSxjQUFVc0IsVUFBVXRCO0FBRkcsR0FBekIsRUFHR2xPLElBSEgsQ0FHUUMsVUFBVTtBQUNoQitQLFdBQU92TixJQUFQLENBQVksS0FDSTtBQUNkclMsY0FBUUMsR0FBUixDQUFZNFAsTUFBWjtBQUNBK1AsYUFBT0ksVUFBUDtBQUNELEtBSkQsRUFLQ3pQLEtBTEQsQ0FLT3JNLFNBQVM7QUFDZGxFLGNBQVFDLEdBQVIsQ0FBWWlFLEtBQVo7QUFDQTBiLGFBQU9JLFVBQVA7QUFDRCxLQVJEO0FBU0QsR0FiRDtBQWNEOzs7Ozs7Ozs7Ozs7QUN2REQ7QUFFQTs7QUFFbUI7QUFDbEIsUUFBTXZQLFNBQVMvUixJQUFmOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUVBO0FBRUEwZ0IsWUFDRUMsU0FERixDQUNZLElBSVc7QUFDckI5YixlQUFXK2IsS0FBS0MsT0FBTCxDQUFhcGIsSUFBYixDQUFYO0FBQ0EsR0FQRixFQVFFTCxLQVJGLENBUVFnUyxRQUFRMEosSUFSaEI7O0FBWXlCO0FBQ3hCSixjQUFVSyxJQUFWO0FBQ0E7O0FBRUQ7QUFFQSxRQUFNL0osVUFBVTtBQUNmblMsY0FBVUEsS0FESztBQUVmOE4sbUJBQWVBO0FBRkEsR0FBaEI7QUFLQXJSLElBQUE7QUFDQUEsVUFBUUMsR0FBUixDQUFZeVYsT0FBWjtBQUVBLFFBQU1nSyxhQUFhQyxFQUFuQjtBQUVBLFFBQU1DLFNBQVMsSUFBSUYsVUFBSixDQUFlO0FBQzdCRyxjQUFVLG1CQURtQjtBQUU3QkMsdUJBQW1CQztBQUZVLEdBQWYsQ0FBZjtBQUtBSCxLQUF5QjtBQUN4QjdDLGNBQVVxQyxVQUFVckMsSUFESTtBQUV4QmUsY0FBVXNCLFVBQVV0QjtBQUZJLEdBQXpCLEVBR0dsTyxJQUhILENBR1FDLFVBQVU7QUFDakIrUCxXQUFPdk4sSUFBUCxDQUFZLEtBQ0k7QUFDZnJTLGNBQVFDLEdBQVIsQ0FBWTRQLE1BQVo7QUFDQStQLGFBQU9JLFVBQVA7QUFDQSxLQUpELEVBS0N6UCxLQUxELENBS09yTSxTQUFTO0FBQ2ZsRSxjQUFRQyxHQUFSLENBQVlpRSxLQUFaO0FBQ0E0UixjQUFRb0ssSUFBUixDQUFhLENBQWI7QUFDQU4sYUFBT0ksU0FBUDtBQUNBLEtBVEQ7QUFVQSxHQWRELEVBY0d6UCxFQUFlO0FBQ2pCdlEsWUFBUUMsR0FBUixDQUFZaUUsS0FBWjtBQUNBLEdBaEJEO0FBaUJBOzs7Ozs7Ozs7Ozs7QUNoRUQ7QUFFQTs7QUFHbUI7QUFDbEIsUUFBTXVNLFNBQVMvUixJQUFmOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUVBO0FBRUEwZ0IsWUFDRUMsU0FERixDQUNZLElBUVc7QUFDckI5YixlQUFXK2IsS0FBS0MsT0FBTCxDQUFhcGIsSUFBYixDQUFYO0FBQ0EsR0FYRixFQVlFTCxLQVpGLENBWVFnUyxRQUFRMEosSUFaaEI7O0FBa0J5QjtBQUN4QkosY0FBVUssSUFBVjtBQUNBOztBQUVEO0FBRUEsUUFBTXBGLFNBQVM7QUFDZDlXLGNBQVVBLElBREk7QUFFZHBFLGVBQVdpZ0IsUUFGRztBQUdkM0UsZ0JBQVkyRSxVQUFVZSxTQUhSO0FBSWR6RixxQkFBaUIwRSxVQUFVZ0IsTUFKYjtBQUtkekYsa0JBQWN5RSxVQUFVaUIsWUFBVixHQUF5QmpCLFVBQVVpQixZQUFuQyxHQUFrRGpCLFVBQVVlLFVBTDVEO0FBTWRoTixpQkFBYSxhQU5DLENBTVk7O0FBTjNCO0FBU0FuVCxJQUFBO0FBRUEsUUFBTTBmLGFBQWFDLENBQW5CO0FBRUEsUUFBTUMsU0FBUyxJQUFJRixVQUFKLENBQWU7QUFDN0JHLGNBQVUsbUJBRG1CO0FBRTdCQyx1QkFBbUJDO0FBRlUsR0FBZixDQUFmO0FBS0FILEtBQXlCO0FBQ3hCN0MsY0FBVXFDLFVBQVVyQyxJQURJO0FBRXhCZSxjQUFVc0IsVUFBVXRCO0FBRkksR0FBekIsRUFHR2xPLElBSEgsQ0FHUUMsVUFBVTtBQUNqQixXQUFPK1AsT0FBT3ZOLEdBQWQ7QUFDQSxHQUxELEVBS0d6QyxJQUxILENBS1FDLFVBQVU7QUFDakI3UCxZQUFRQyxHQUFSLENBQVk0UCxLQUFaO0FBQ0ErUCxXQUFPSSxVQUFQLEdBQ0E7QUFDQSxHQVRELEVBVUN6UCxLQVZELENBVU9yTSxTQUFTO0FBQ2ZsRSxZQUFRQyxHQUFSLENBQVlpRSxLQUFaO0FBQ0EwYixXQUFPSSxVQUFQLEVBQ0E7QUFDQSxHQWREO0FBZUE7Ozs7Ozs7Ozs7OztBQ3pFRDtBQUVBLElBQUksQ0FBQzNoQixPQUFPeVQsTUFBWixDQUFtQjtBQUNsQixRQUFNc04sWUFBWTFnQixDQUFsQjs7QUFDQTs7QUFDQTs7QUFFQTtBQUVBMGdCLFdBSXdCO0FBQ3RCOUgsV0FBT3ZVLEtBQVA7QUFDQSxHQU5GLEVBT0VlLEtBUEYsQ0FPUWdTLE1BUFI7O0FBV3FCO0FBQ3BCc0osY0FBVUssSUFBVjtBQUNBOztBQUVEO0FBRUEsUUFBTUMsYUFBYUMsU0FBU1csV0FBVCxFQUFuQjtBQUVBLFFBQU1WLFNBQVMsSUFBSUYsVUFBSixDQUFlO0FBQzdCRyxjQUFVLG1CQURtQjtBQUU3QkMsdUJBQW1CQztBQUZVLEdBQWYsQ0FBZjtBQUtBSCxLQUF5QjtBQUN4QjdDLGNBQVVxQyxVQUFVckMsSUFESTtBQUV4QmUsY0FBVXNCLFVBQVV0QjtBQUZJLEdBQXpCO0FBS0E4QixLQUNpQjtBQUNmNWYsWUFBUUMsR0FBUixDQUFZNFAsTUFBWjtBQUNBK1AsV0FBT0ksVUFBUDtBQUNBLEdBSkYsRUFLRXpQLEtBTEYsQ0FLUXJNLFNBQVM7QUFDZmxFLFlBQVFDLEdBQVIsQ0FBWWlFLEtBQVo7QUFDQTBiLFdBQU9JLFVBQVA7QUFDQSxHQVJGO0FBU0E7Ozs7Ozs7Ozs7OztBQy9DRDtBQUVBOztBQUVtQjtBQUNqQixRQUFNNUssUUFBUTFXLEtBQWQ7O0FBRUE7QUFFQTBXLFFBQU0sS0FBTixFQUFZLEVBQVosRUFBZTtBQUFDbUwsYUFBUyxDQUFDLE1BQUQ7QUFBVixHQUFmLEVBQ0d4SixRQURILENBQ2F5SixnQkFBZ0I7QUFDekIsUUFBSUMsUUFBUUQsYUFBYUMsRUFBekI7O0FBQ2lDO0FBQy9CLFVBQUlDLFNBQVNsVSxLQUFLbVUsTUFBTCxHQUFjaEwsTUFBM0I7QUFDQThLLFlBQU1qSyxLQUFOLENBQVlrSyxNQUFaO0FBQ0Q7O0FBQ0Q7QUFDRCxHQVJILEVBU0c5USxJQVRILENBU1FDLE1BQVU7QUFDZDdQLFlBQVFDLEdBQVIsQ0FBWTRQLEtBQVo7QUFDRCxHQVhILEVBWUdVLEtBWkgsQ0FZU3JNLFNBQVM7QUFDZGxFLFlBQVFrRSxLQUFSLENBQWNBLEdBQWQ7QUFDRCxHQWRIO0FBZUQ7Ozs7Ozs7Ozs7OztBQ3hCRDdGLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSx5QkFBUixDQUFiLEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgVmFsaWRhdGVkTWV0aG9kIH0gZnJvbSAnbWV0ZW9yL21kZzp2YWxpZGF0ZWQtbWV0aG9kJztcbmltcG9ydCB7IFJvbGVzIH0gZnJvbSAnbWV0ZW9yL2FsYW5uaW5nOnJvbGVzJztcblxuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuaW1wb3J0IHsgZXhpc3RzU3luYyB9IGZyb20gJ2ZzJztcblxuLyoqXG4gKiBoYXNCbGFzdERiIHZhbGlkYXRlZCBtZXRob2Q6IGNoZWNrcyB3aGV0aGVyIGJsYXN0IGRhdGFiYXNlcyBleGlzdCBmb3IgYSBnaXZlbiBhbm5vdGF0aW9uIHRyYWNrXG4gKiBAcGFyYW0gIHtTdHJpbmd9IG9wdGlvbnMudHJhY2tOYW1lIE5hbWUgb2YgdGhlIGFubm90YXRpb24gdHJhY2tcbiAqIEByZXR1cm4ge0Jvb2x9ICAgICAgICAgICAgICAgICAgICAgam9icXVldWVcbiAqL1xuZXhwb3J0IGNvbnN0IGhhc0JsYXN0RGIgPSBuZXcgVmFsaWRhdGVkTWV0aG9kKHtcbiAgbmFtZTogJ2hhc0JsYXN0RGInLFxuICB2YWxpZGF0ZTogbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgdHJhY2tOYW1lOiB7IHR5cGU6IFN0cmluZyB9XG4gIH0pLnZhbGlkYXRvcigpLFxuICBhcHBseU9wdGlvbnM6IHtcbiAgICBub1JldHJ5OiB0cnVlXG4gIH0sXG4gIHJ1bih7IHRyYWNrTmFtZX0pe1xuICAgIGlmICghIHRoaXMudXNlcklkKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgIH1cbiAgICBpZiAoISBSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsJ2N1cmF0b3InKSl7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgIH1cblxuICAgIGNvbnN0IGNsZWFuZWRUcmFja05hbWUgPSB0cmFja05hbWUucmVwbGFjZSgvIHxcXC4vZywnXycpXG5cbiAgICBjb25zdCBmaWxlbmFtZXMgPSBbXG4gICAgICBgJHtjbGVhbmVkVHJhY2tOYW1lfS5udWNsLm5ocmAsXG4gICAgICBgJHtjbGVhbmVkVHJhY2tOYW1lfS5wcm90LnBocmBcbiAgICBdXG5cbiAgICBjb25zb2xlLmxvZyhmaWxlbmFtZXMpXG5cbiAgICBpZiAoIXRoaXMuaXNTaW11bGF0aW9uKXtcbiAgICAgIGNvbnNvbGUubG9nKGZpbGVuYW1lcylcbiAgICAgIGNvbnNvbGUubG9nKGZpbGVuYW1lcy5ldmVyeShleGlzdHNTeW5jKSlcbiAgICAgIHJldHVybiBmaWxlbmFtZXMuZXZlcnkoZXhpc3RzU3luYylcbiAgICB9XG4gIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFZhbGlkYXRlZE1ldGhvZCB9IGZyb20gJ21ldGVvci9tZGc6dmFsaWRhdGVkLW1ldGhvZCc7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5cbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCBoYXNoIGZyb20gJ29iamVjdC1oYXNoJztcblxuaW1wb3J0IGpvYlF1ZXVlIGZyb20gJy9pbXBvcnRzL2FwaS9qb2JxdWV1ZS9qb2JxdWV1ZS5qcyc7XG5pbXBvcnQgeyBKb2IgfSBmcm9tICdtZXRlb3IvdnNpdnNpOmpvYi1jb2xsZWN0aW9uJ1xuXG5pbXBvcnQgeyBHZW5lcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9nZW5lX2NvbGxlY3Rpb24uanMnO1xuXG4vKipcbiAqIG1ha2VCbGFzdERiIHZhbGlkYXRlZCBtZXRob2Q6IHN1Ym1pdHMgbWFrZWJsYXN0ZGIgam9iIHRvIGpvYnF1ZXVlLCBjYWxsIHRoaXMgZnJvbSB0aGUgY2xpZW50XG4gKiBAcGFyYW0gIHtTdHJpbmd9IG9wdGlvbnMudHJhY2tOYW1lIE5hbWUgb2YgdGhlIGFubm90YXRpb24gdHJhY2tcbiAqIEBwYXJhbSAge1N0cmluZ30gb3B0aW9ucy5kYlR5cGUgICAgRWl0aGVyIG51Y2wgb3IgcHJvdFxuICogQHJldHVybiB7U3RyaW5nfSAgICAgICAgICAgICAgICAgICBqb2JJZCBvZiB0aGUgbWFrZWJsYXN0ZGIgam9iXG4gKi9cbmV4cG9ydCBjb25zdCBtYWtlQmxhc3REYiA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnbWFrZUJsYXN0RGInLFxuICB2YWxpZGF0ZTogbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgdHJhY2tOYW1lOiB7IHR5cGU6IFN0cmluZyB9LFxuICAgIGRiVHlwZTogeyB0eXBlOiBTdHJpbmcgfVxuICB9KS52YWxpZGF0b3IoKSxcbiAgYXBwbHlPcHRpb25zOiB7XG4gICAgbm9SZXRyeTogdHJ1ZVxuICB9LFxuICBydW4oeyB0cmFja05hbWUsIGRiVHlwZSB9KXtcbiAgICBpZiAoISB0aGlzLnVzZXJJZCkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9XG4gICAgaWYgKCEgUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCdjdXJhdG9yJykpe1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9XG5cbiAgICBpZiAoIXRoaXMuaXNTaW11bGF0aW9uKXtcbiAgICAgIGNvbnN0IGpvYklkID0gbmV3IEpvYihqb2JRdWV1ZSwgJ21ha2VCbGFzdERiJywge1xuICAgICAgICB0cmFja05hbWU6IHRyYWNrTmFtZSxcbiAgICAgICAgZGJUeXBlOiBkYlR5cGUsXG4gICAgICAgIHVzZXI6IE1ldGVvci51c2VySWQoKVxuICAgICAgfSkucHJpb3JpdHkoJ25vcm1hbCcpLnNhdmUoKVxuXG4gICAgICByZXR1cm4gam9iSWRcbiAgICB9XG4gIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFZhbGlkYXRlZE1ldGhvZCB9IGZyb20gJ21ldGVvci9tZGc6dmFsaWRhdGVkLW1ldGhvZCc7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5cbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuaW1wb3J0IHsgVHJhY2tzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2dlbm9tZXMvdHJhY2tfY29sbGVjdGlvbi5qcyc7XG5cbi8qKlxuICogaGFzQmxhc3REYiB2YWxpZGF0ZWQgbWV0aG9kOiBjaGVja3Mgd2hldGhlciBibGFzdCBkYXRhYmFzZXMgZXhpc3QgZm9yIGEgZ2l2ZW4gYW5ub3RhdGlvbiB0cmFja1xuICogQHBhcmFtICB7U3RyaW5nfSBvcHRpb25zLnRyYWNrTmFtZSBOYW1lIG9mIHRoZSBhbm5vdGF0aW9uIHRyYWNrXG4gKiBAcmV0dXJuIHtCb29sfSAgICAgICAgICAgICAgICAgICAgIGpvYnF1ZXVlXG4gKi9cbmV4cG9ydCBjb25zdCByZW1vdmVCbGFzdERiID0gbmV3IFZhbGlkYXRlZE1ldGhvZCh7XG4gIG5hbWU6ICdyZW1vdmVCbGFzdERiJyxcbiAgdmFsaWRhdGU6IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIHRyYWNrTmFtZTogeyB0eXBlOiBTdHJpbmcgfVxuICB9KS52YWxpZGF0b3IoKSxcbiAgYXBwbHlPcHRpb25zOiB7XG4gICAgbm9SZXRyeTogdHJ1ZVxuICB9LFxuICBydW4oeyB0cmFja05hbWV9KXtcbiAgICBpZiAoISB0aGlzLnVzZXJJZCkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9XG4gICAgaWYgKCEgUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCdhZG1pbicpKXtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coYHJlbW92ZSAke3RyYWNrTmFtZX1gKVxuXG4gICAgaWYgKCF0aGlzLmlzU2ltdWxhdGlvbil7XG4gICAgICBjb25zdCB0cmFjayA9IFRyYWNrcy5maW5kT25lKHt0cmFja05hbWU6IHRyYWNrTmFtZX0pXG4gICAgICBjb25zb2xlLmxvZyh0cmFjaylcbiAgICAgIFRyYWNrcy51cGRhdGUoe1xuICAgICAgICB0cmFja05hbWU6IHRyYWNrTmFtZVxuICAgICAgfSx7XG4gICAgICAgICR1bnNldDoge1xuICAgICAgICAgICdibGFzdGRicyc6IDFcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG4gIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFZhbGlkYXRlZE1ldGhvZCB9IGZyb20gJ21ldGVvci9tZGc6dmFsaWRhdGVkLW1ldGhvZCc7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5cbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuaW1wb3J0IGpvYlF1ZXVlIGZyb20gJy9pbXBvcnRzL2FwaS9qb2JxdWV1ZS9qb2JxdWV1ZS5qcyc7XG5pbXBvcnQgeyBKb2IgfSBmcm9tICdtZXRlb3IvdnNpdnNpOmpvYi1jb2xsZWN0aW9uJztcblxuLyoqXG4gKiBzdWJtaXRCbGFzdEpvYiB2YWxpZGF0ZWQgbWV0aG9kOiBzdWJtaXRzIG1ha2VibGFzdGRiIGpvYiB0byBqb2JxdWV1ZSwgY2FsbCB0aGlzIGZyb20gdGhlIGNsaWVudFxuICogQHBhcmFtICB7U3RyaW5nfSBvcHRpb25zLnRyYWNrTmFtZSBOYW1lIG9mIHRoZSBhbm5vdGF0aW9uIHRyYWNrXG4gKiBAcGFyYW0gIHtTdHJpbmd9IG9wdGlvbnMuZGJUeXBlICAgIEVpdGhlciBudWNsIG9yIHByb3RcbiAqIEByZXR1cm4ge1N0cmluZ30gICAgICAgICAgICAgICAgICAgam9iSWQgb2YgdGhlIG1ha2VibGFzdGRiIGpvYlxuICovXG5leHBvcnQgY29uc3Qgc3VibWl0Qmxhc3RKb2IgPSBuZXcgVmFsaWRhdGVkTWV0aG9kKHtcbiAgbmFtZTogJ3N1Ym1pdEJsYXN0Sm9iJyxcbiAgdmFsaWRhdGU6IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIGJsYXN0VHlwZTogeyB0eXBlOiBTdHJpbmcgfSxcbiAgICBpbnB1dDogeyB0eXBlOiBTdHJpbmcgfSxcbiAgICB0cmFja05hbWVzOiB7IHR5cGU6IEFycmF5IH0sXG4gICAgJ3RyYWNrTmFtZXMuJCc6IHsgdHlwZTogU3RyaW5nIH1cbiAgfSkudmFsaWRhdG9yKCksXG4gIGFwcGx5T3B0aW9uczoge1xuICAgIG5vUmV0cnk6IHRydWVcbiAgfSxcbiAgcnVuKHsgYmxhc3RUeXBlLCBpbnB1dCwgdHJhY2tOYW1lcyB9KXtcbiAgICBpZiAoISB0aGlzLnVzZXJJZCkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9XG4gICAgaWYgKCEgUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCd1c2VyJykpe1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZygnc3VibWl0IGJsYXN0IGpvYicpXG4gICAgXG4gICAgY29uc3Qgam9iSWQgPSBuZXcgSm9iKGpvYlF1ZXVlLCAnYmxhc3QnLCB7XG4gICAgICBibGFzdFR5cGU6IGJsYXN0VHlwZSxcbiAgICAgIGlucHV0OiBpbnB1dCxcbiAgICAgIHRyYWNrTmFtZXM6IHRyYWNrTmFtZXMsXG4gICAgICB1c2VyOiBNZXRlb3IudXNlcklkKClcbiAgICB9KS5wcmlvcml0eSgnbm9ybWFsJykuc2F2ZSgpXG5cbiAgICBjb25zb2xlLmxvZyhqb2JJZClcblxuICAgIHJldHVybiBqb2JJZFxuICBcbiAgfVxufSlcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuLy9ERVNJR04gU0NIRU1BXG5cbmNvbnN0IERvd25sb2FkcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdkb3dubG9hZHMnKTtcblxuY29uc3QgRG93bmxvYWRTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgcXVlcnk6IHtcbiAgICB0eXBlOiBPYmplY3QsXG4gICAgYmxhY2tib3g6IHRydWVcbiAgfSxcbiAgcXVlcnlIYXNoOiB7XG4gICAgdHlwZTogU3RyaW5nXG4gIH0sXG4gIGNvdW50czoge1xuICAgIHR5cGU6IE51bWJlclxuICB9LFxuICBhY2Nlc3NlZDoge1xuICAgIHR5cGU6IERhdGVcbiAgfVxufSlcblxuZXhwb3J0IHsgRG93bmxvYWRzIH07IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBWYWxpZGF0ZWRNZXRob2QgfSBmcm9tICdtZXRlb3IvbWRnOnZhbGlkYXRlZC1tZXRob2QnO1xuXG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5pbXBvcnQgUGFwYSBmcm9tICdwYXBhcGFyc2UnO1xuXG5pbXBvcnQgeyBHZW5lcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9nZW5lX2NvbGxlY3Rpb24uanMnO1xuaW1wb3J0IGZzIGZyb20gJ2ZzJztcblxuLyoqXG4gKiBbZGVzY3JpcHRpb25dXG4gKiBAcGFyYW0gIHtbdHlwZV19IGF0dHJpYnV0ZVN0cmluZyBbZGVzY3JpcHRpb25dXG4gKiBAcmV0dXJuIHtbdHlwZV19ICAgICAgICAgICAgICAgICBbZGVzY3JpcHRpb25dXG4gKi9cbmNvbnN0IGZvcm1hdEF0dHJpYnV0ZXMgPSBhdHRyaWJ1dGVTdHJpbmcgPT4ge1xuICByZXR1cm4gYXR0cmlidXRlU3RyaW5nLnNwbGl0KCc7JykucmVkdWNlKChhdHRyaWJ1dGVzLCBzdHJpbmdQYXJ0KSA9PiB7XG4gICAgY29uc3QgW2tleSwgdmFsdWVdID0gc3RyaW5nUGFydC5zcGxpdCgnPScpXG4gICAgaWYgKHR5cGVvZiBrZXkgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB2YWx1ZSAhPT0gJ3VuZGVmaW5lZCcpe1xuICAgICAgYXR0cmlidXRlc1trZXldID0gdmFsdWUuc3BsaXQoJ1wiJykuam9pbignJykuc3BsaXQoJywnKS5tYXAoZGVjb2RlVVJJQ29tcG9uZW50KVxuICAgIH1cbiAgICByZXR1cm4gYXR0cmlidXRlcztcbiAgfSwge30pXG59XG5cbmNvbnN0IGRlYnVnRm9ybWF0QXR0cmlidXRlcyA9IGF0dHJpYnV0ZVN0cmluZyA9PiB7XG4gIGFyciA9IGF0dHJpYnV0ZVN0cmluZy5zcGxpdCgnOycpO1xuICBjb25zb2xlLmxvZyhhcnIpXG4gIGNvbnN0IGF0dHJpYnV0ZXMgPSBhcnIucmVkdWNlKChhdHRyLCBzdHJpbmdQYXJ0KSA9PiB7XG4gICAgY29uc3QgW2tleSwgdmFsdWVdID0gc3RyaW5nUGFydC5zcGxpdCgnPScpXG4gICAgY29uc29sZS5sb2coa2V5LHZhbHVlKVxuICAgIGNvbnN0IHZhbHVlcyA9IHZhbHVlLnNwbGl0KCdcIicpLmpvaW4oJycpLnNwbGl0KCcsJykubWFwKGRlY29kZVVSSUNvbXBvbmVudClcbiAgICBjb25zb2xlLmxvZyh2YWx1ZXMpXG4gICAgYXR0cltrZXldID0gdmFsdWVzXG4gICAgcmV0dXJuIGF0dHJcbiAgfSwge30pXG4gIGNvbnNvbGUubG9nKGF0dHJpYnV0ZXMpXG4gIHJldHVybiBhdHRyaWJ1dGVzXG59XG5cbmV4cG9ydCBjb25zdCBhZGRJbnRlcnByb3NjYW4gPSBuZXcgVmFsaWRhdGVkTWV0aG9kKHtcbiAgbmFtZTogJ2FkZEludGVycHJvc2NhbicsXG4gIHZhbGlkYXRlOiBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICBmaWxlTmFtZTogeyB0eXBlOiBTdHJpbmcgfSxcbiAgICB0cmFja05hbWU6IHsgdHlwZTogU3RyaW5nIH1cbiAgfSkudmFsaWRhdG9yKCksXG4gIGFwcGx5T3B0aW9uczoge1xuICAgIG5vUmV0cnk6IHRydWVcbiAgfSxcbiAgcnVuKHsgZmlsZU5hbWUsIHRyYWNrTmFtZSB9KXtcbiAgICBjb25zb2xlLmxvZygnYWRkSW50ZXJwcm9zY2FuJywgdHJhY2tOYW1lLCBmaWxlTmFtZSlcblxuICAgIGxldCBsaW5lTnVtYmVyID0gMDtcblxuICAgIGNvbnN0IGZpbGVIYW5kbGUgPSBmcy5yZWFkRmlsZVN5bmMoZmlsZU5hbWUsIHsgZW5jb2Rpbmc6J2JpbmFyeScgfSk7XG5cbiAgICBjb25zdCBpbnRlcnByb0lkcyA9IG5ldyBTZXQoKTtcblxuICAgIFBhcGEucGFyc2UoZmlsZUhhbmRsZSwge1xuICAgICAgZGVsaW1pdGVyOiAnXFx0JyxcbiAgICAgIGR5bmFtaWNUeXBpbmc6IHRydWUsXG4gICAgICBza2lwRW1wdHlMaW5lczogdHJ1ZSxcbiAgICAgIC8vY29tbWVudHM6ICcjJyxcbiAgICAgIGVycm9yKGVycm9yLGZpbGUpIHtcbiAgICAgICAgY29uc29sZS5sb2coZXJyb3IpXG4gICAgICB9LFxuICAgICAgc3RlcChsaW5lLCBwYXJzZXIpe1xuICAgICAgICBsaW5lTnVtYmVyICs9IDE7XG4gICAgICAgIGlmIChsaW5lTnVtYmVyICUgMTAwID09PSAwKXtcbiAgICAgICAgICBjb25zb2xlLmxvZyhgUHJvY2Vzc2VkICR7bGluZU51bWJlcn0gbGluZXNgKVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGRhdGEgPSBsaW5lLmRhdGFbMF07XG4gICAgICAgIGlmIChkYXRhWzBdWzBdID09PSAnIycpe1xuICAgICAgICAgIGlmICgvZmFzdGEvaS50ZXN0KGRhdGFbMF0pKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdFbmNvdW50ZXJlZCBmYXN0YSBzZWN0aW9uLCBzdG9wcGVkIHBhcnNpbmcnKVxuICAgICAgICAgICAgcGFyc2VyLmFib3J0KClcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3QgW1xuICAgICAgICAgICAgc2VxSWQsXG4gICAgICAgICAgICBzb3VyY2UsXG4gICAgICAgICAgICB0eXBlLFxuICAgICAgICAgICAgc3RhcnQsXG4gICAgICAgICAgICBlbmQsXG4gICAgICAgICAgICBzY29yZSxcbiAgICAgICAgICAgIHN0cmFuZCxcbiAgICAgICAgICAgIHBoYXNlLFxuICAgICAgICAgICAgYXR0cmlidXRlU3RyaW5nXG4gICAgICAgICAgXSA9IGRhdGE7XG5cbiAgICAgICAgICBpZiAodHlwZSA9PT0gJ3Byb3RlaW5fbWF0Y2gnKXtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgYXR0cmlidXRlU3RyaW5nICE9PSAndW5kZWZpbmVkJyl7XG4gICAgICAgICAgICAgIGxldCBhdHRyaWJ1dGVzO1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGF0dHJpYnV0ZXMgPSBmb3JtYXRBdHRyaWJ1dGVzKGF0dHJpYnV0ZVN0cmluZyk7XG4gICAgICAgICAgICAgIH0gY2F0Y2goZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgRXJyb3IgbGluZSAke2xpbmVOdW1iZXJ9YClcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhLmpvaW4oJ1xcdCcpKVxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGF0dHJpYnV0ZVN0cmluZylcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkZWJ1Z0Zvcm1hdEF0dHJpYnV0ZXMoYXR0cmlidXRlU3RyaW5nKSlcbiAgICAgICAgICAgICAgICB0aHJvdyBlcnJvclxuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgY29uc3QgbmFtZSA9IGF0dHJpYnV0ZXNbJ05hbWUnXVswXTtcbiAgICAgICAgICAgICAgY29uc3QgcHJvdGVpbkRvbWFpbiA9IHtcbiAgICAgICAgICAgICAgICBzdGFydCxcbiAgICAgICAgICAgICAgICBlbmQsXG4gICAgICAgICAgICAgICAgc291cmNlLFxuICAgICAgICAgICAgICAgIHNjb3JlLFxuICAgICAgICAgICAgICAgIG5hbWVcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBjb25zdCBkYnhyZWYgPSBhdHRyaWJ1dGVzWydEYnhyZWYnXTtcbiAgICAgICAgICAgICAgaWYgKHR5cGVvZiBkYnhyZWYgIT09ICd1bmRlZmluZWQnKXtcbiAgICAgICAgICAgICAgICBwcm90ZWluRG9tYWluWydkYnhyZWYnXSA9IGRieHJlZjtcbiAgICAgICAgICAgICAgICBsZXQgaGFzSW50ZXJwcm8gPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBkYnhyZWYuZm9yRWFjaChjcm9zc3JlZiA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBbZGIsIGlkXSA9IGNyb3NzcmVmLnNwbGl0KCc6JylcbiAgICAgICAgICAgICAgICAgIGlmICgvSW50ZXJQcm8vLnRlc3QoZGIpKXtcbiAgICAgICAgICAgICAgICAgICAgaGFzSW50ZXJwcm8gPSB0cnVlXG4gICAgICAgICAgICAgICAgICAgIHByb3RlaW5Eb21haW5bJ2ludGVycHJvJ10gPSBpZDtcbiAgICAgICAgICAgICAgICAgICAgaW50ZXJwcm9JZHMuYWRkKGlkKVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgaWYgKCFoYXNJbnRlcnBybykge1xuICAgICAgICAgICAgICAgICAgcHJvdGVpbkRvbWFpblsnaW50ZXJwcm8nXSA9ICdVbmludGVncmF0ZWQgc2lnbmF0dXJlJztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcHJvdGVpbkRvbWFpblsnaW50ZXJwcm8nXSA9ICdVbmludGVncmF0ZWQgc2lnbmF0dXJlJztcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGlmICh0eXBlb2YgYXR0cmlidXRlc1snc2lnbmF0dXJlX2Rlc2MnXSAhPT0gJ3VuZGVmaW5lZCcpe1xuICAgICAgICAgICAgICAgIHByb3RlaW5Eb21haW5bJ3NpZ25hdHVyZV9kZXNjJ10gPSBhdHRyaWJ1dGVzWydzaWduYXR1cmVfZGVzYyddWzBdO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIEdlbmVzLnVwZGF0ZSh7XG4gICAgICAgICAgICAgICAgJ3N1YmZlYXR1cmVzLklEJzogc2VxSWRcbiAgICAgICAgICAgICAgfSx7IFxuICAgICAgICAgICAgICAgICRhZGRUb1NldDogeyBcbiAgICAgICAgICAgICAgICAgICdzdWJmZWF0dXJlcy4kLnByb3RlaW5fZG9tYWlucyc6IHByb3RlaW5Eb21haW5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZygnVW5kZWZpbmVkIGF0dHJpYnV0ZXM6JylcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YS5qb2luKCdcXHQnKSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgfSxcbiAgICAgIGNvbXBsZXRlKHJlc3VsdHMsZmlsZSkge1xuICAgICAgICBjb25zb2xlLmxvZygnRmluaXNoZWQnKVxuICAgICAgICAvL2NvbnNvbGUubG9nKGludGVycHJvSWRzKVxuICAgICAgfVxuICAgIH0pXG4gIH1cbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBWYWxpZGF0ZWRNZXRob2QgfSBmcm9tICdtZXRlb3IvbWRnOnZhbGlkYXRlZC1tZXRob2QnO1xuXG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5pbXBvcnQgUGFwYSBmcm9tICdwYXBhcGFyc2UnO1xuaW1wb3J0IGdsb2IgZnJvbSAnZ2xvYic7XG5cbmltcG9ydCB7IE9ydGhvZ3JvdXBzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2dlbmVzL29ydGhvZ3JvdXBfY29sbGVjdGlvbi5qcyc7XG5pbXBvcnQgeyBHZW5lcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9nZW5lX2NvbGxlY3Rpb24uanMnO1xuaW1wb3J0IHsgcGFyc2VOZXdpY2sgfSBmcm9tICcvaW1wb3J0cy9hcGkvdXRpbC91dGlsLmpzJztcbmltcG9ydCBmcyBmcm9tICdmcyc7XG5cbmV4cG9ydCBjb25zdCBhZGRPcnRob2dyb3VwVHJlZXMgPSBuZXcgVmFsaWRhdGVkTWV0aG9kKHtcbiAgbmFtZTogJ2FkZE9ydGhvZ3JvdXBUcmVlcycsXG4gIHZhbGlkYXRlOiBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICBmb2xkZXI6IHsgdHlwZTogU3RyaW5nIH1cbiAgfSkudmFsaWRhdG9yKCksXG4gIGFwcGx5T3B0aW9uczoge1xuICAgIG5vUmV0cnk6IHRydWVcbiAgfSxcbiAgcnVuKHsgZm9sZGVyIH0pe1xuICAgIGNvbnNvbGUubG9nKCdhZGRPcnRob2dyb3VwVHJlZXMnLCBmb2xkZXIpXG4gICAgY29uc3QgZ2VuZUJ1bGtPcCA9IEdlbmVzLnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG4gICAgY29uc3Qgb3J0aG9CdWxrT3AgPSBPcnRob2dyb3Vwcy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgIGdsb2IoYCR7Zm9sZGVyfS8qYCwgKGVyciwgZmlsZU5hbWVzKSA9PiB7XG4gICAgICBmaWxlTmFtZXMuZm9yRWFjaChmaWxlTmFtZSA9PiB7XG4gICAgICAgIC8vY29uc29sZS5sb2coZmlsZU5hbWUpXG4gICAgICAgIGNvbnN0IG9ydGhvZ3JvdXBJZCA9IGZpbGVOYW1lLnNwbGl0KCcvJykucG9wKCkuc3BsaXQoJ18nKVswXTtcbiAgICAgICAgXG4gICAgICAgIGNvbnN0IGRhdGEgPSBmcy5yZWFkRmlsZVN5bmMoZmlsZU5hbWUsICd1dGY4JykvLywgKGVyciwgZGF0YSkgPT4ge1xuICAgICAgICAgIGNvbnN0IHRyZWUgPSBwYXJzZU5ld2ljayhkYXRhKTtcbiAgICAgICAgICBvcnRob0J1bGtPcC5pbnNlcnQoe1xuICAgICAgICAgICAgSUQ6IG9ydGhvZ3JvdXBJZCxcbiAgICAgICAgICAgIHNpemU6IHRyZWUuc2l6ZSxcbiAgICAgICAgICAgIHRyZWU6IHRyZWUudHJlZSxcbiAgICAgICAgICAgIGdlbmVzOiB0cmVlLmdlbmVJZHNcbiAgICAgICAgICB9KVxuICAgICAgICAgIGdlbmVCdWxrT3AuZmluZCh7SUQ6IHskaW46IHRyZWUuZ2VuZUlkc319KS51cGRhdGUoeyRzZXQ6IHtvcnRob2dyb3VwOiBvcnRob2dyb3VwSWR9fSlcbiAgICAgICAgICAvL2NvbnNvbGUubG9nKG9ydGhvZ3JvdXBJZCwgdHJlZS5zaXplLCB0cmVlLmdlbmVJZHMpO1xuICAgICAgICAvL30pO1xuICAgICAgfSlcbiAgICBjb25zb2xlLmxvZygnZ2VuZUJ1bGtPcCBleGVjdXRlJylcbiAgICBjb25zdCBnZW5lQnVsa09wUmVzdWx0cyA9IGdlbmVCdWxrT3AuZXhlY3V0ZSgpO1xuICAgIGNvbnNvbGUubG9nKGdlbmVCdWxrT3BSZXN1bHRzKVxuICAgIFxuICAgIGNvbnNvbGUubG9nKCdvcnRob0J1bGtPcCBleGVjdXRlJylcbiAgICBjb25zdCBvcnRob0J1bGtPcFJlc3VsdHMgPSBvcnRob0J1bGtPcC5leGVjdXRlKCk7XG4gICAgY29uc29sZS5sb2cob3J0aG9CdWxrT3BSZXN1bHRzKVxuICAgIH0pXG5cblxuICB9XG59KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuLy9ERVNJR04gU0NIRU1BXG5cbmNvbnN0IEF0dHJpYnV0ZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYXR0cmlidXRlcycpO1xuXG5leHBvcnQgeyBBdHRyaWJ1dGVzIH07IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBWYWxpZGF0ZWRNZXRob2QgfSBmcm9tICdtZXRlb3IvbWRnOnZhbGlkYXRlZC1tZXRob2QnO1xuXG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5pbXBvcnQgaGFzaCBmcm9tICdvYmplY3QtaGFzaCc7XG4vL2ltcG9ydCBGdXR1cmUgZnJvbSAnZmliZXJzL2Z1dHVyZSc7XG5cbmltcG9ydCBqb2JRdWV1ZSBmcm9tICcvaW1wb3J0cy9hcGkvam9icXVldWUvam9icXVldWUuanMnO1xuaW1wb3J0IHsgSm9iIH0gZnJvbSAnbWV0ZW9yL3ZzaXZzaTpqb2ItY29sbGVjdGlvbic7XG5cbmltcG9ydCB7IEdlbmVzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2dlbmVzL2dlbmVfY29sbGVjdGlvbi5qcyc7XG5pbXBvcnQgeyBEb3dubG9hZHMgfSBmcm9tICcvaW1wb3J0cy9hcGkvZG93bmxvYWRzL2Rvd25sb2FkX2NvbGxlY3Rpb24uanMnO1xuXG5leHBvcnQgY29uc3QgZG93bmxvYWRHZW5lcyA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAnZG93bmxvYWRHZW5lcycsXG4gIHZhbGlkYXRlOiBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICBxdWVyeTogeyBcbiAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgIGJsYWNrYm94OiB0cnVlIFxuICAgIH0sXG4gICAgZGF0YVR5cGU6IHsgdHlwZTogU3RyaW5nIH1cbiAgfSkudmFsaWRhdG9yKCksXG4gIGFwcGx5T3B0aW9uczoge1xuICAgIG5vUmV0cnk6IHRydWVcbiAgfSxcbiAgcnVuKHsgcXVlcnksIGRhdGFUeXBlIH0pe1xuICAgIC8qKlxuICAgICAqIElmIHRoZSBxdWVyeSBoYXMgbm90IGJlZW4gdXNlZCBiZWZvcmUsIGNyZWF0ZSBhIGZpbGUgZnJvbSBpdC4gXG4gICAgICogT3RoZXJ3aXNlIHVzZSB0aGUgY2FjaGVkIGZpbGUgYW5kIGluY3JlbWVudCB0aGUgZG93bmxvYWQgY291bnQuXG4gICAgICogUmV0dXJuIG1kNSBoYXNoIG9mIGRvd25sb2FkIHF1ZXJ5IGFzIGRvd25sb2FkIHVybFxuICAgICAqL1xuICAgIGNvbnNvbGUubG9nKGBkb3dubG9hZGluZyAke2RhdGFUeXBlfWApXG4gICAgY29uc29sZS5sb2cocXVlcnkpO1xuICAgIFxuICAgIGNvbnN0IHF1ZXJ5U3RyaW5nID0gSlNPTi5zdHJpbmdpZnkocXVlcnkpO1xuXG4gICAgY29uc3QgcXVlcnlIYXNoID0gaGFzaChgJHtxdWVyeVN0cmluZ30ke2RhdGFUeXBlfWApO1xuXG5cbiAgICBjb25zb2xlLmxvZyhxdWVyeUhhc2gpXG4gICAgaWYgKCEgdGhpcy51c2VySWQpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgfVxuICAgIGNvbnN0IGV4aXN0aW5nSm9iID0gam9iUXVldWUuZmluZE9uZSh7ICdkYXRhLnF1ZXJ5SGFzaCc6IHF1ZXJ5SGFzaCB9KTtcblxuICAgIGlmICh0eXBlb2YgZXhpc3RpbmdKb2IgPT09ICd1bmRlZmluZWQnKXtcbiAgICAgIGNvbnNvbGUubG9nKCdpbml0aWF0aW5nIG5ldyBkb3dubG9hZCBqb2InKVxuICAgICAgY29uc3Qgam9iID0gbmV3IEpvYihqb2JRdWV1ZSwgJ2Rvd25sb2FkJywge1xuICAgICAgICBxdWVyeVN0cmluZzogcXVlcnlTdHJpbmcsXG4gICAgICAgIHF1ZXJ5SGFzaDogcXVlcnlIYXNoLFxuICAgICAgICBkYXRhVHlwZTogZGF0YVR5cGVcbiAgICAgIH0pO1xuICAgICAgam9iLnByaW9yaXR5KCdoaWdoJykuc2F2ZSgpO1xuICAgIH1cblxuICAgIHJldHVybiBxdWVyeUhhc2hcbiAgfVxufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5cbi8vREVTSUdOIFNDSEVNQVxuXG5jb25zdCBFZGl0SGlzdG9yeSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdlZGl0SGlzdG9yeScpO1xuXG5leHBvcnQgeyBFZGl0SGlzdG9yeSB9OyIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuY29uc3QgR2VuZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZ2VuZXMnKTtcblxuLy9jcmVhdGUgYSBiYXNlIHNjaGVtYSBzbyB3ZSBjYW4gYWRkIGl0IGF0IG11bHRpcGxlIHBsYWNlc1xuY29uc3QgSW50ZXJ2YWxCYXNlU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIElEOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIHVuaXF1ZTogdHJ1ZSxcbiAgICBpbmRleDogdHJ1ZSxcbiAgICAvL2RlbnlVcGRhdGU6IHRydWUsXG4gICAgbGFiZWw6ICdVbmlxdWUgZ2VuZSBJRCdcbiAgfSxcbiAgdHlwZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ2dlbmUnLCdtUk5BJywnQ0RTJywnZXhvbicsJ3RocmVlX3ByaW1lX1VUUicsJ2ZpdmVfcHJpbWVfVVRSJ10sXG4gICAgbGFiZWw6ICdJbnRlcnZhbCB0eXBlJ1xuICB9LFxuICBzZXE6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdSZWZlcmVuY2Ugc2VxdWVuY2Ugb2YgdGhpcyBmZWF0dXJlJ1xuICB9LFxuICBzdGFydDoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgICBsYWJlbDogJ1N0YXJ0IGNvb3JkaW5hdGUnXG4gIH0sXG4gIGVuZDoge1xuICAgIHR5cGU6IE51bWJlcixcbiAgICBsYWJlbDogJ0VuZCBjb29yZGluYXRlJ1xuICB9LFxuICBzY29yZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1Njb3JlJyxcbiAgICBjdXN0b206IGZ1bmN0aW9uKCl7XG4gICAgICBpZiAoIXRoaXMuaXNTZXQpe1xuICAgICAgICByZXR1cm4gJ3JlcXVpcmVkJ1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMudmFsdWUgPT09ICcuJyl7XG4gICAgICAgIHJldHVybiB0cnVlXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsZXQgcGFyc2VkVmFsdWUgPSBwYXJzZUZsb2F0KHRoaXMudmFsdWUpO1xuICAgICAgICBpZiAoaXNOYU4ocGFyc2VkVmFsdWUpKXtcbiAgICAgICAgICByZXR1cm4gJ3Njb3JlRXJyb3InXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfSxcbiAgYXR0cmlidXRlczoge1xuICAgIHR5cGU6IE9iamVjdCxcbiAgICBibGFja2JveDogdHJ1ZSxcbiAgICBpbmRleDogdHJ1ZSxcbiAgICBsYWJlbDogJ0FueSBhdHRyaWJ1dGVzJ1xuICB9LFxuICBjaGlsZHJlbjoge1xuICAgIHR5cGU6IEFycmF5LC8vW1N0cmluZ10sXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gICAgbGFiZWw6ICdDaGlsZCBzdWJmZWF0dXJlcydcbiAgfSxcbiAgJ2NoaWxkcmVuLiQnOiB7XG4gICAgdHlwZTogU3RyaW5nXG4gIH1cbn0pO1xuXG5cbi8vRGVmaW5lIHN1YmZlYXR1cmUgc2NoZW1hIGZpcnN0IHNvIHdlIGNhbiB0aGVuIGFkZCBpdCB0byB0aGUgZ2VuZSBzY2hlbWFcbmNvbnN0IFN1YmZlYXR1cmVTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgcGhhc2U6IHtcbiAgICB0eXBlOiBTaW1wbGVTY2hlbWEub25lT2YoTnVtYmVyLFN0cmluZyksXG4gICAgYWxsb3dlZFZhbHVlczogWzAsMSwyLCcuJ10sXG4gICAgbGFiZWw6ICdwaGFzZSdcbiAgfSxcbiAgdHlwZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ0NEUycsJ2V4b24nLCdtUk5BJywnZml2ZV9wcmltZV9VVFInLCd0aHJlZV9wcmltZV9VVFInXSxcbiAgICBsYWJlbDogJ1N1YmZlYXR1cmUgdHlwZXMnXG4gIH0sXG4gIHBhcmVudHM6IHtcbiAgICB0eXBlOiBBcnJheSwvL1tTdHJpbmddLFxuICAgIGxhYmVsOiAnUGFyZW50IHN1YmZlYXR1cmVzJ1xuICB9LFxuICAncGFyZW50cy4kJzoge1xuICAgIHR5cGU6IFN0cmluZ1xuICB9LFxuICBwcm90ZWluX2RvbWFpbnM6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBsYWJlbDogJ0ludGVycHJvc2NhbiBwcm90ZWluIGRvbWFpbnMnLFxuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0sXG4gICdwcm90ZWluX2RvbWFpbnMuJCc6IHtcbiAgICB0eXBlOiBPYmplY3QsXG4gICAgbGFiZWw6ICdJbnRlcnByb3NjYW4gcHJvdGVpbiBkb21haW4nLFxuICAgIGJsYWNrYm94OiB0cnVlXG4gIH1cbn0pO1xuXG4vL2V4dGVuZCB0aGUgc3ViZmVhdHVyZSBzY2hlbWEgd2l0aCBiYXNlIHN1YmZlYXR1cmVzXG5TdWJmZWF0dXJlU2NoZW1hLmV4dGVuZChJbnRlcnZhbEJhc2VTY2hlbWEpO1xuXG5jb25zdCBHZW5lU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIHR5cGU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgYWxsb3dlZFZhbHVlczogWydnZW5lJ10sXG4gICAgbGFiZWw6ICdHZW5lIHR5cGUnXG4gIH0sXG4gIGVkaXRpbmc6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgdmlld2luZzoge1xuICAgIHR5cGU6IEFycmF5LC8vW1N0cmluZ10sXG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgJ3ZpZXdpbmcuJCc6IHtcbiAgICB0eXBlOiBTdHJpbmdcbiAgfSxcbiAgY2hhbmdlZDoge1xuICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgZXhwcmVzc2lvbjoge1xuICAgIHR5cGU6IEFycmF5LC8vW09iamVjdF0sXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gICAgbGFiZWw6ICdUcmFuc2NyaXB0b21lIGNvdW50cyBhbmQgVFBNJ1xuICB9LFxuICAnZXhwcmVzc2lvbi4kJzoge1xuICAgIHR5cGU6IE9iamVjdCxcbiAgICBibGFja2JveDogdHJ1ZVxuICB9LFxuICBzdWJmZWF0dXJlczoge1xuICAgIHR5cGU6IEFycmF5LC8vW1N1YmZlYXR1cmVTY2hlbWFdLFxuICAgIC8vYmxhY2tib3g6IHRydWUsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gICAgbGFiZWw6ICdBcnJheSBvZiBzdWJmZWF0dXJlcydcbiAgfSxcbiAgJ3N1YmZlYXR1cmVzLiQnOiB7XG4gICAgdHlwZTogT2JqZWN0LFxuICAgIGJsYWNrYm94OiB0cnVlXG4gIH0sXG4gIHJlZmVyZW5jZTogeyBcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgLy9kZW55VXBkYXRlOiB0cnVlLFxuICAgIGxhYmVsOiAnUmVmZXJlbmNlIGdlbm9tZSdcbiAgfSxcbiAgc2VxaWQ6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgLy9kZW55VXBkYXRlOiB0cnVlLFxuICAgIGxhYmVsOiAnSUQgb2YgdGhlIHNlcXVlbmNlIG9uIHdoaWNoIHRoZSBnZW5lIGlzLCBlLmcuIGNocjEnXG4gIH0sXG4gIHNvdXJjZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1NvdXJjZSBvZiB0aGUgYW5ub3RhdGlvbidcbiAgfSxcbiAgdHlwZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ2dlbmUnXSxcbiAgICBsYWJlbDogJ1R5cGUgb2YgdGhlIHRvcCBsZXZlbCBhbm5vdGF0aW9uIChjdXJyZW50bHkgb25seSBcImdlbmVcIiBpcyBhbGxvd2VkKSdcbiAgfSxcbiAgc3RyYW5kOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGFsbG93ZWRWYWx1ZXM6IFsnKycsICctJ10sXG4gICAgbGFiZWw6ICdTdHJhbmQnXG4gIH0sXG4gIHRyYWNrOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnVHJhY2sgbmFtZSdcbiAgfSxcbiAgcGVybWlzc2lvbnM6IHtcbiAgICB0eXBlOiBBcnJheSwvL1tTdHJpbmddLFxuICAgIGxhYmVsOiAnUGVybWlzc2lvbiBsZXZlbCdcbiAgfSxcbiAgJ3Blcm1pc3Npb25zLiQnOiB7XG4gICAgdHlwZTogU3RyaW5nXG4gIH1cbn0pO1xuXG4vL2V4dGVuZCB0aGUgZ2VuZSBzY2hlbWEgd2l0aCBiYXNlIGZlYXR1cmVzXG5HZW5lU2NoZW1hLmV4dGVuZChJbnRlcnZhbEJhc2VTY2hlbWEpO1xuXG5HZW5lcy5hdHRhY2hTY2hlbWEoR2VuZVNjaGVtYSk7XG5cbmV4cG9ydCB7IEdlbmVzLCBHZW5lU2NoZW1hLCBTdWJmZWF0dXJlU2NoZW1hIH07IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuXG4vL0RFU0lHTiBTQ0hFTUFcblxuY29uc3QgSW50ZXJwcm8gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignaW50ZXJwcm8nKTtcblxuZXhwb3J0IHsgSW50ZXJwcm8gfSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgUm9sZXMgfSBmcm9tICdtZXRlb3IvYWxhbm5pbmc6cm9sZXMnO1xuXG5pbXBvcnQgcmVxdWVzdCBmcm9tICdyZXF1ZXN0JztcbmltcG9ydCBGdXR1cmUgZnJvbSAnZmliZXJzL2Z1dHVyZSc7XG5cbmltcG9ydCB7IGdldEdlbmVTZXF1ZW5jZXMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdXRpbC91dGlsLmpzJztcblxuaW1wb3J0IHsgR2VuZXMgfSBmcm9tICcvaW1wb3J0cy9hcGkvZ2VuZXMvZ2VuZV9jb2xsZWN0aW9uLmpzJzsgXG4vKipcbiAqIFJldmVyc2UgY29tcGxlbWVudCBhIEROQSBzdHJpbmdcbiAqIEBwYXJhbSAge1tTdHJpbmddfSBzZXEgW1N0cmluZyByZXByZXNlbnRpbmcgRE5BIGNvbnN0aXN0aW5nIG9mIGFscGhhYmV0IEFhQ2NHZ1R0Tm5dXG4gKiBAcmV0dXJuIHtbU3RyaW5nXX0gICAgIFtTdHJpbmcgcmVwcmVzZW50aW5nIEROQSBjb25zdGlzdGluZyBvZiBhbHBoYWJldCBBYUNjR2dUdE5uLCByZXZlcnNlIGNvbXBsZW1lbnQgb2YgaW5wdXRdXG4gKi9cbmNvbnN0IHJldmNvbXAgPSAoc2VxKSA9PiB7XG4gIGNvbnN0IGNvbXAgPSB7ICBcbiAgICAnQSc6J1QnLCdhJzondCcsXG4gICAgJ1QnOidBJywndCc6J2EnLFxuICAgICdDJzonRycsJ2MnOidnJyxcbiAgICAnRyc6J0MnLCdnJzonYycsXG4gICAgJ04nOidOJywnbic6J24nXG4gIH1cbiAgY29uc3QgcmV2U2VxQXJyYXkgPSBzZXEuc3BsaXQoJycpLnJldmVyc2UoKVxuICBjb25zdCByZXZDb21wU2VxQXJyYXkgPSByZXZTZXFBcnJheS5tYXAoIChudWMpID0+IHtcbiAgICByZXR1cm4gY29tcFtudWNdXG4gIH0pXG4gIGNvbnN0IHJldkNvbXBTZXEgPSByZXZDb21wU2VxQXJyYXkuam9pbignJylcbiAgcmV0dXJuIHJldkNvbXBTZXFcbn1cblxuLyoqXG4gKiBDb252ZXJ0IGEgRE5BIHN0cmluZyBpbnRvIGEgYW1pbm8gYWNpZCBzdHJpbmdcbiAqIEBwYXJhbSAge1tTdHJpbmddfSBzZXEgW1N0cmluZyByZXByZXNlbnRpbmcgRE5BIGNvbnN0aXN0aW5nIG9mIGFscGhhYmV0IEFDR1ROXVxuICogQHJldHVybiB7W1N0cmluZ119ICAgICBbU3RyaW5nIHJlcHJlc2VudGluZyB0aGUgYW1pbm8gYWNpZCBjb21wbGVtZW50IG9mIGlucHV0IHN0cmluZ11cbiAqL1xuY29uc3QgdHJhbnNsYXRlID0gKHNlcSkgPT4ge1xuICBjb25zdCB0cmFucyA9IHtcbiAgICAnQUNDJzogJ1QnLCAnQUNBJzogJ1QnLCAnQUNHJzogJ1QnLFxuICAgICdBR0cnOiAnUicsICdBR0MnOiAnUycsICdHVEEnOiAnVicsXG4gICAgJ0FHQSc6ICdSJywgJ0FDVCc6ICdUJywgJ0dURyc6ICdWJyxcbiAgICAnQUdUJzogJ1MnLCAnQ0NBJzogJ1AnLCAnQ0NDJzogJ1AnLFxuICAgICdHR1QnOiAnRycsICdDR0EnOiAnUicsICdDR0MnOiAnUicsXG4gICAgJ1RBVCc6ICdZJywgJ0NHRyc6ICdSJywgJ0NDVCc6ICdQJyxcbiAgICAnR0dHJzogJ0cnLCAnR0dBJzogJ0cnLCAnR0dDJzogJ0cnLFxuICAgICdUQUEnOiAnKicsICdUQUMnOiAnWScsICdDR1QnOiAnUicsXG4gICAgJ1RBRyc6ICcqJywgJ0FUQSc6ICdJJywgJ0NUVCc6ICdMJyxcbiAgICAnQVRHJzogJ00nLCAnQ1RHJzogJ0wnLCAnQVRUJzogJ0knLFxuICAgICdDVEEnOiAnTCcsICdUVFQnOiAnRicsICdHQUEnOiAnRScsXG4gICAgJ1RURyc6ICdMJywgJ1RUQSc6ICdMJywgJ1RUQyc6ICdGJyxcbiAgICAnR1RDJzogJ1YnLCAnQUFHJzogJ0snLCAnQUFBJzogJ0snLFxuICAgICdBQUMnOiAnTicsICdBVEMnOiAnSScsICdDQVQnOiAnSCcsXG4gICAgJ0FBVCc6ICdOJywgJ0dUVCc6ICdWJywgJ0NBQyc6ICdIJyxcbiAgICAnQ0FBJzogJ1EnLCAnQ0FHJzogJ1EnLCAnQ0NHJzogJ1AnLFxuICAgICdUQ1QnOiAnUycsICdUR0MnOiAnQycsICdUR0EnOiAnKicsXG4gICAgJ1RHRyc6ICdXJywgJ1RDRyc6ICdTJywgJ1RDQyc6ICdTJyxcbiAgICAnVENBJzogJ1MnLCAnR0FHJzogJ0UnLCAnR0FDJzogJ0QnLFxuICAgICdUR1QnOiAnQycsICdHQ0EnOiAnQScsICdHQ0MnOiAnQScsXG4gICAgJ0dDRyc6ICdBJywgJ0dDVCc6ICdBJywgJ0NUQyc6ICdMJyxcbiAgICAnR0FUJzogJ0QnfVxuICBjb25zdCBjb2RvbkFycmF5ID0gc2VxLm1hdGNoKC8uezEsM30vZylcbiAgY29uc3QgcGVwQXJyYXkgPSBjb2RvbkFycmF5Lm1hcCggKGNvZG9uKSA9PiB7XG4gICAgbGV0IGFtaW5vQWNpZCA9ICdYJ1xuICAgIGlmIChjb2Rvbi5pbmRleE9mKCdOJykgPCAwKXtcbiAgICAgIGFtaW5vQWNpZCA9IHRyYW5zW2NvZG9uXVxuICAgIH1cbiAgICByZXR1cm4gYW1pbm9BY2lkXG4gIH0pXG4gIGNvbnN0IHBlcCA9IHBlcEFycmF5LmpvaW4oJycpXG4gIHJldHVybiBwZXBcbn1cblxuY29uc3QgbWFrZUZhc3RhID0gKGdlbmUpID0+IHtcbiAgbGV0IHRyYW5zY3JpcHRzID0gZ2VuZS5zdWJmZWF0dXJlcy5maWx0ZXIoIChzdWJmZWF0dXJlKSA9PiB7IHJldHVybiBzdWJmZWF0dXJlLnR5cGUgPT09ICdtUk5BJyB9KVxuICBsZXQgc2VxdWVuY2VzID0gdHJhbnNjcmlwdHMubWFwKCAodHJhbnNjcmlwdCkgPT4ge1xuICAgIGxldCB0cmFuc2NyaXB0U2VxID0gYD4ke3RyYW5zY3JpcHQuSUR9XFxuYDtcbiAgICBsZXQgdHJhbnNjcmlwdFBlcCA9IGA+JHt0cmFuc2NyaXB0LklEfVxcbmA7XG4gICAgbGV0IGNkc0FycmF5ID0gZ2VuZS5zdWJmZWF0dXJlcy5maWx0ZXIoIChzdWIpID0+IHsgXG4gICAgICByZXR1cm4gc3ViLnBhcmVudHMuaW5kZXhPZih0cmFuc2NyaXB0LklEKSA+PSAwICYmIHN1Yi50eXBlID09PSAnQ0RTJ1xuICAgIH0pLnNvcnQoIChhLGIpID0+IHtcbiAgICAgIHJldHVybiBhLnN0YXJ0IC0gYi5zdGFydFxuICAgIH0pXG5cbiAgICBsZXQgcmVmU3RhcnQgPSAxMGU5OTtcbiAgICAvL2xldCByZWZlcmVuY2VTdWJzY3JpcHRpb24gPSBNZXRlb3Iuc3Vic2NyaWJlKCdyZWZlcmVuY2VzJyxnZW5lLnNlcWlkKVxuICAgIFxuICAgIC8vZmluZCBhbGwgcmVmZXJlbmNlIGZyYWdtZW50cyBvdmVybGFwcGluZyB0aGUgbVJOQSBmZWF0dXJlXG4gICAgbGV0IHJlZmVyZW5jZUFycmF5ID0gUmVmZXJlbmNlcy5maW5kKHsgXG4gICAgICBoZWFkZXI6IGdlbmUuc2VxaWQsIFxuICAgICAgJGFuZDogWyBcbiAgICAgICAgeyBzdGFydDogeyRsdGU6IGdlbmUuZW5kfSB9LCBcbiAgICAgICAgeyBlbmQ6IHskZ3RlOiBnZW5lLnN0YXJ0fSB9XG4gICAgICBdIFxuICAgIH0pLmZldGNoKClcblxuICAgIGlmIChyZWZlcmVuY2VBcnJheS5sZW5ndGgpe1xuICAgICAgbGV0IHJlZmVyZW5jZSA9IHJlZmVyZW5jZUFycmF5LnNvcnQoIChhLGIpID0+IHtcbiAgICAgICAgLy9zb3J0IG9uIHN0YXJ0IGNvb3JkaW5hdGVcbiAgICAgICAgcmV0dXJuIGEuc3RhcnQgLSBiLnN0YXJ0XG4gICAgICB9KS5tYXAoIChyZWYpID0+IHtcbiAgICAgICAgLy9maW5kIHN0YXJ0aW5nIHBvc2l0aW9uIG9mIGZpcnN0IHJlZmVyZW5jZSBmcmFnbWVudFxuICAgICAgICByZWZTdGFydCA9IE1hdGgubWluKHJlZlN0YXJ0LHJlZi5zdGFydClcbiAgICAgICAgcmV0dXJuIHJlZi5zZXFcbiAgICAgIH0pLmpvaW4oJycpXG5cbiAgICAgIHNlcSA9IGNkc0FycmF5Lm1hcCggKGNkcywgaW5kZXgpID0+IHtcbiAgICAgICAgbGV0IHN0YXJ0ID0gY2RzLnN0YXJ0IC0gcmVmU3RhcnQgLSAxO1xuICAgICAgICBsZXQgZW5kID0gY2RzLmVuZCAtIHJlZlN0YXJ0O1xuICAgICAgICByZXR1cm4gcmVmZXJlbmNlLnNsaWNlKHN0YXJ0LGVuZClcbiAgICAgIH0pLmpvaW4oJycpXG5cbiAgICAgIGxldCBwaGFzZTtcbiAgICAgIGlmICh0aGlzLnN0cmFuZCA9PT0gJy0nKXtcbiAgICAgICAgc2VxID0gcmV2Y29tcChzZXEpXG4gICAgICAgIHBoYXNlID0gY2RzQXJyYXlbY2RzQXJyYXkubGVuZ3RoIC0xXS5waGFzZVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcGhhc2UgPSBjZHNBcnJheVswXS5waGFzZVxuICAgICAgfVxuICAgXG4gICAgICBpZiAoWzEsMl0uaW5kZXhPZihwaGFzZSkgPj0gMCl7XG4gICAgICAgIHNlcSA9IHNlcS5zbGljZShwaGFzZSlcbiAgICAgIH1cblxuICAgICAgbGV0IHBlcCA9IHRyYW5zbGF0ZShzZXEudG9VcHBlckNhc2UoKSk7XG5cbiAgICAgIHRyYW5zY3JpcHRTZXEgKz0gc2VxO1xuICAgICAgXG4gICAgICB0cmFuc2NyaXB0UGVwICs9IHBlcDtcbiAgICAgIHRyYW5zY3JpcHRQZXAgPSB0cmFuc2NyaXB0UGVwLnNwbGl0KCcqJykuam9pbignWCcpXG4gICAgfVxuICAgIHJldHVybiB7SUQ6dHJhbnNjcmlwdC5JRCwgc2VxOiB0cmFuc2NyaXB0U2VxLCBwZXA6IHRyYW5zY3JpcHRQZXB9XG4gIH0pXG4gIHJldHVybiBzZXF1ZW5jZXNcbn1cblxuZnVuY3Rpb24gc3VibWl0SW50ZXJwcm8oc2VxdWVuY2VJZCxwZXB0aWRlKXtcbiAgY29uc3Qgc3VibWl0Sm9iID0gbmV3IEZ1dHVyZSgpO1xuXG4gIHJlcXVlc3QucG9zdCh7XG4gICAgdXJsOiAnaHR0cDovL3d3dy5lYmkuYWMudWsvVG9vbHMvc2VydmljZXMvcmVzdC9pcHJzY2FuNS9ydW4vJyxcbiAgICBmb3JtOiB7XG4gICAgICBlbWFpbDogJ3JlbnMuaG9sbWVyQGdtYWlsLmNvbScsXG4gICAgICB0aXRsZTogYGdlbmVib29rIHByb3RlaW4gJHtzZXF1ZW5jZUlkfWAsXG4gICAgICBzZXF1ZW5jZTogcGVwdGlkZVxuICAgIH1cbiAgfSwgKGVycm9yLCByZXNwb25zZSwgam9iSWQpID0+IHtcbiAgICBjb25zb2xlLmxvZygnZXJyb3I6JywgZXJyb3IpOyAvLyBQcmludCB0aGUgZXJyb3IgaWYgb25lIG9jY3VycmVkIFxuICAgIGNvbnNvbGUubG9nKCdzdGF0dXNDb2RlOicsIHJlc3BvbnNlICYmIHJlc3BvbnNlLnN0YXR1c0NvZGUpOyAvLyBQcmludCB0aGUgcmVzcG9uc2Ugc3RhdHVzIGNvZGUgaWYgYSByZXNwb25zZSB3YXMgcmVjZWl2ZWQgXG4gICAgY29uc29sZS5sb2coJ3JlcXVlc3RJZDonLCBqb2JJZCk7XG4gICAgc3VibWl0Sm9iLnJldHVybihqb2JJZClcbiAgfSlcblxuICBjb25zdCBqb2JJZCA9IHN1Ym1pdEpvYi53YWl0KClcblxuICByZXR1cm4gam9iSWRcbn1cblxuZnVuY3Rpb24gcG9sbEludGVycHJvKGpvYklkLGNiKXtcbiAgY29uc3Qgc3RhdHVzUmVxdWVzdCA9IG5ldyBGdXR1cmUoKTtcbiAgY29uc3QgdXJsID0gYGh0dHA6Ly93d3cuZWJpLmFjLnVrL1Rvb2xzL3NlcnZpY2VzL3Jlc3QvaXByc2NhbjUvc3RhdHVzLyR7am9iSWR9YDtcbiAgY29uc29sZS5sb2coYFRyeWluZyAke3VybH1gKVxuICByZXF1ZXN0LmdldCh1cmwsIChlcnJvcixyZXNwb25zZSxib2R5KSA9PiB7XG4gICAgY29uc29sZS5sb2coZXJyb3IpXG4gICAgY29uc29sZS5sb2coYm9keSlcbiAgICBzdGF0dXNSZXF1ZXN0LnJldHVybihib2R5KVxuICB9KVxuICBjb25zdCBzdGF0dXMgPSBzdGF0dXNSZXF1ZXN0LndhaXQoKVxuICBpZiAoc3RhdHVzID09PSAnUlVOTklORycpe1xuICAgIC8vZmlndXJlIG91dCBhIHdheSB0byBjYWxsIHRoZSBmdW5jdGlvbiB3aXRoIGEgcGFyYW1ldGVyXG4gICAgTWV0ZW9yLnNldFRpbWVvdXQoZnVuY3Rpb24oKXtyZXR1cm4gcG9sbEludGVycHJvKGpvYklkLGNiKX0sIDEwMDAwMClcbiAgfSBlbHNlIHtcbiAgICBjYihzdGF0dXMpXG4gIH1cbn1cblxuZnVuY3Rpb24gZ2V0SW50ZXJwcm9SZXN1bHRzKGpvYklkKXtcbiAgY29uc3QgZnV0dXJlID0gbmV3IEZ1dHVyZSgpO1xuICBjb25zdCB1cmwgPSBgaHR0cDovL3d3dy5lYmkuYWMudWsvVG9vbHMvc2VydmljZXMvcmVzdC9pcHJzY2FuNS9yZXN1bHQvJHtqb2JJZH0vanNvbmBcbiAgY29uc29sZS5sb2coYFRyeWluZyAke3VybH1gKVxuICByZXF1ZXN0LmdldCh1cmwsIChlcnJvcixyZXNwb25zZSxib2R5KSA9PiB7XG4gICAgbGV0IGludGVycHJvQW5ub3RhdGlvbiA9IEpTT04ucGFyc2UoYm9keSlcbiAgICBmdXR1cmUucmV0dXJuKGludGVycHJvQW5ub3RhdGlvbilcbiAgfSlcbiAgY29uc3QgcmVzdWx0cyA9IGZ1dHVyZS53YWl0KClcbiAgcmV0dXJuIHJlc3VsdHNcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBpbnRlcnByb3NjYW4oZ2VuZUlkKXtcbiAgICBpZiAoISB0aGlzLnVzZXJJZCkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9XG4gICAgaWYgKCEgUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCdhZG1pbicpKXtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG4gICAgfVxuXG4gICAgLy90aGlzLnVuYmxvY2soKTtcbiAgICBjb25zdCBnZW5lID0gR2VuZXMuZmluZE9uZSh7SUQ6IGdlbmVJZH0pXG4gICAgY29uc3Qgc2VxdWVuY2VzID0gZ2V0R2VuZVNlcXVlbmNlcyhnZW5lKVxuICAgIGNvbnN0IHJlc3VsdHMgPSBzZXF1ZW5jZXMubWFwKChzZXF1ZW5jZSkgPT4geyBcblxuICAgICAgLy8gaW50ZXJwcm9zY2FuIGRvZXMgbm90IGxpa2Ugc3RvcCBjb2RvbnMsIGp1c3QgcmVwbGFjZSBhbGwgd2l0aCBYXG4gICAgICBsZXQgcGVwID0gc2VxdWVuY2UucGVwLnNwbGl0KCcqJykuam9pbignWCcpXG5cbiAgICAgIGNvbnN0IGpvYklkID0gc3VibWl0SW50ZXJwcm8oc2VxdWVuY2UuSUQsIHBlcCk7XG5cbiAgICAgIGNvbnN0IGZ1dCA9IG5ldyBGdXR1cmUoKTtcbiAgICAgIHBvbGxJbnRlcnBybyhqb2JJZCwgKHN0YXR1cykgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhgcG9sbEludGVycHJvOiAke3N0YXR1c31gKVxuICAgICAgICBmdXQucmV0dXJuKHN0YXR1cylcbiAgICAgIH0pXG5cbiAgICAgIGNvbnN0IGZpbmlzaGVkID0gZnV0LndhaXQoKTtcbiAgICAgIFxuICAgICAgbGV0IHJlc3VsdHM7XG5cbiAgICAgIGlmIChmaW5pc2hlZCA9PT0gJ0ZJTklTSEVEJyl7XG4gICAgICAgIHJlc3VsdHMgPSBnZXRJbnRlcnByb1Jlc3VsdHMoam9iSWQpXG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3VsdHMpXG4gICAgICAgIEdlbmVzLnVwZGF0ZSh7J3N1YmZlYXR1cmVzLklEJzpzZXF1ZW5jZS5JRH0seyRzZXQ6e2ludGVycHJvc2NhbjpyZXN1bHRzWzBdLm1hdGNoZXN9fSlcbiAgICAgIH0gXG5cbiAgICAgIHJldHVybiByZXN1bHRzXG4gICAgfSlcbiAgICBcblxuICAgIHJldHVybiByZXN1bHRzXG4gIH1cbn0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuXG4vL0RFU0lHTiBTQ0hFTUFcblxuY29uc3QgT3J0aG9ncm91cHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignb3J0aG9ncm91cHMnKTtcblxuZXhwb3J0IHsgT3J0aG9ncm91cHMgfSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgVmFsaWRhdGVkTWV0aG9kIH0gZnJvbSAnbWV0ZW9yL21kZzp2YWxpZGF0ZWQtbWV0aG9kJztcblxuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuLy9pbXBvcnQgRnV0dXJlIGZyb20gJ2ZpYmVycy9mdXR1cmUnO1xuXG5pbXBvcnQgeyBHZW5lcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9nZW5lX2NvbGxlY3Rpb24uanMnO1xuaW1wb3J0IHsgQXR0cmlidXRlcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9hdHRyaWJ1dGVfY29sbGVjdGlvbi5qcyc7XG5pbXBvcnQgeyBUcmFja3MgfSBmcm9tICcvaW1wb3J0cy9hcGkvZ2Vub21lcy90cmFja19jb2xsZWN0aW9uLmpzJztcblxuLyoqXG4gKiBNYXAgZnVuY3Rpb24gZm9yIG1vbmdvZGIgbWFwcmVkdWNlXG4gKiBAcmV0dXJuIHtbdHlwZV19IFtkZXNjcmlwdGlvbl1cbiAqL1xuY29uc3QgbWFwRnVuY3Rpb24gPSBmdW5jdGlvbigpe1xuXHRwcmludGpzb24oJ21hcCBmdW5jdGlvbicpO1xuXHQvL1VzZSAndmFyJyBpbnN0ZWFkIG9mICdsZXQnISBUaGlzIHdpbGwgYmUgZXhlY3V0ZWQgaW4gbW9uZ29kYiwgd2hpY2ggZG9lcyBub3Qga25vdyAnY29uc3QvbGV0J1xuXHR2YXIgZ2VuZSA9IHRoaXM7XG5cdGlmICh0eXBlb2YgZ2VuZS5hdHRyaWJ1dGVzICE9PSAndW5kZWZpbmVkJyl7XG5cdFx0ZW1pdChudWxsLCB7IGF0dHJpYnV0ZUtleXM6IE9iamVjdC5rZXlzKGdlbmUuYXR0cmlidXRlcykgfSlcblx0fVxufVxuXG4vKipcbiAqIFJlZHVjZSBmdW5jdGlvbiBmb3IgbW9uZ29kYiBtYXByZWR1Y2VcbiAqIEBwYXJhbSAge1t0eXBlXX0gX2tleSAgICBbZGVzY3JpcHRpb25dXG4gKiBAcGFyYW0gIHtbdHlwZV19IHZhbHVlcyBbZGVzY3JpcHRpb25dXG4gKiBAcmV0dXJuIHtbdHlwZV19ICAgICAgICBbZGVzY3JpcHRpb25dXG4gKi9cbmNvbnN0IHJlZHVjZUZ1bmN0aW9uID0gZnVuY3Rpb24oX2tleSwgdmFsdWVzKXtcblx0cHJpbnRqc29uKCdyZWR1Y2UgZnVuY3Rpb24nKVxuXHQvL1VzZSAndmFyJyBpbnN0ZWFkIG9mICdsZXQnISBUaGlzIHdpbGwgYmUgZXhlY3V0ZWQgaW4gbW9uZ29kYiwgd2hpY2ggZG9lcyBub3Qga25vdyAnY29uc3QvbGV0J1xuXHRjb25zdCBhdHRyaWJ1dGVLZXlTZXQgPSBuZXcgU2V0KClcblx0dmFsdWVzLmZvckVhY2godmFsdWUgPT4ge1xuXHRcdHZhbHVlLmF0dHJpYnV0ZUtleXMuZm9yRWFjaChhdHRyaWJ1dGVLZXkgPT4ge1xuXHRcdFx0YXR0cmlidXRlS2V5U2V0LmFkZChhdHRyaWJ1dGVLZXkpXG5cdFx0fSlcblx0fSlcblx0Ly9Vc2UgJ3ZhcicgaW5zdGVhZCBvZiAnbGV0JyEgVGhpcyB3aWxsIGJlIGV4ZWN1dGVkIGluIG1vbmdvZGIsIHdoaWNoIGRvZXMgbm90IGtub3cgJ2NvbnN0L2xldCdcblx0Y29uc3QgYXR0cmlidXRlS2V5cyA9IEFycmF5LmZyb20oYXR0cmlidXRlS2V5U2V0KVxuXHRyZXR1cm4geyBhdHRyaWJ1dGVLZXlzOiBhdHRyaWJ1dGVLZXlzIH1cbn1cblxuZXhwb3J0IGNvbnN0IHNjYW5HZW5lQXR0cmlidXRlcyA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuXHRuYW1lOiAnc2NhbkF0dHJpYnV0ZXMnLFxuXHR2YWxpZGF0ZTogbmV3IFNpbXBsZVNjaGVtYSh7XG5cdFx0dHJhY2tOYW1lOiB7IHR5cGU6IFN0cmluZyB9XG5cdH0pLnZhbGlkYXRvcigpLFxuXHRhcHBseU9wdGlvbnM6IHtcblx0XHRub1JldHJ5OiB0cnVlXG5cdH0sXG5cdHJ1bih7IHRyYWNrTmFtZSB9KXtcblx0XHRjb25zb2xlLmxvZyhgc2NhbkdlbmVBdHRyaWJ1dGVzOiAke3RyYWNrTmFtZX1gKVxuXHRcdGlmICghIHRoaXMudXNlcklkKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblx0XHRpZiAoISBSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsJ2N1cmF0b3InKSl7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblxuXHRcdGNvbnN0IHRyYWNrID0gVHJhY2tzLmZpbmRPbmUoe3RyYWNrTmFtZTogdHJhY2tOYW1lfSlcblxuXHRcdC8vY2hlY2sgaWYgdGhlIHRyYWNrIGV4aXN0c1xuXHRcdGlmICh0eXBlb2YgdHJhY2sgPT09ICd1bmRlZmluZWQnKXtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoYFVua25vd24gdHJhY2s6ICR7dHJhY2tOYW1lfWApXG5cdFx0fVxuXG5cdFx0Ly9jaGVjayB0aGF0IGl0IGlzIHJ1bm5pbmcgb24gdGhlIHNlcnZlclxuXHRcdGlmICggIXRoaXMuaXNTaW11bGF0aW9uICl7XG5cdFx0XHR0aGlzLnVuYmxvY2soKTtcblx0XHRcdGNvbnN0IG1hcFJlZHVjZU9wdGlvbnMgPSB7IFxuXHRcdFx0XHRcdG91dDogeyBpbmxpbmU6IDEgfSxcblx0XHRcdFx0XHRxdWVyeTogeyB0cmFjazogdHJhY2tOYW1lIH1cblx0XHRcdFx0fVxuXHRcdFx0Ly9tYXByZWR1Y2UgdG8gZmluZCBhbGwga2V5cyBmb3IgYWxsIGdlbmVzLCB0aGlzIHRha2VzIGEgd2hpbGVcblx0XHRcdGNvbnNvbGUubG9nKCdtYXByZWR1Y2luZycpXG5cdFx0XHRjb25zdCBhdHRyaWJ1dGVTY2FuID0gR2VuZXMucmF3Q29sbGVjdGlvbigpXG5cdFx0XHRcdC5tYXBSZWR1Y2UobWFwRnVuY3Rpb24sIHJlZHVjZUZ1bmN0aW9uLCBtYXBSZWR1Y2VPcHRpb25zKVxuXHRcdFx0XHQudGhlbihyZXN1bHRzID0+IHtcblx0XHRcdFx0XHRjb25zb2xlLmxvZygnbWFwcmVkdWNlIGZpbmlzaGVkJylcblx0XHRcdFx0XHRyZXN1bHRzLmZvckVhY2goIHJlc3VsdCA9PiB7XG5cdFx0XHRcdFx0XHRjb25zdCBhdHRyaWJ1dGVLZXlzID0gcmVzdWx0LnZhbHVlLmF0dHJpYnV0ZUtleXM7XG5cdFx0XHRcdFx0XHRhdHRyaWJ1dGVLZXlzLmZvckVhY2goYXR0cmlidXRlS2V5ID0+IHtcblx0XHRcdFx0XHRcdFx0QXR0cmlidXRlcy5maW5kQW5kTW9kaWZ5KHsgXG5cdFx0XHRcdFx0XHRcdFx0cXVlcnk6IHsgXG5cdFx0XHRcdFx0XHRcdFx0XHRuYW1lOiBhdHRyaWJ1dGVLZXkgXG5cdFx0XHRcdFx0XHRcdFx0fSwgXG5cdFx0XHRcdFx0XHRcdFx0dXBkYXRlOiB7XG5cdFx0XHRcdFx0XHRcdFx0XHQkYWRkVG9TZXQ6IHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0dHJhY2tzOiB0cmFja05hbWUsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdHJlZmVyZW5jZXM6IHRyYWNrLnJlZmVyZW5jZVxuXHRcdFx0XHRcdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRcdFx0XHRcdCRzZXRPbkluc2VydDogeyBcblx0XHRcdFx0XHRcdFx0XHRcdFx0bmFtZTogYXR0cmlidXRlS2V5LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRxdWVyeTogYGF0dHJpYnV0ZXMuJHthdHRyaWJ1dGVLZXl9YCxcblx0XHRcdFx0XHRcdFx0XHRcdFx0c2hvdzogdHJ1ZSwgXG5cdFx0XHRcdFx0XHRcdFx0XHRcdGNhbkVkaXQ6IGZhbHNlLCBcblx0XHRcdFx0XHRcdFx0XHRcdFx0cmVzZXJ2ZWQ6IGZhbHNlIFxuXHRcdFx0XHRcdFx0XHRcdFx0fSBcblx0XHRcdFx0XHRcdFx0XHR9LCBcblx0XHRcdFx0XHRcdFx0XHRuZXc6IHRydWUsIFxuXHRcdFx0XHRcdFx0XHRcdHVwc2VydDogdHJ1ZSBcblx0XHRcdFx0XHRcdFx0fSkgXG5cdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdH0pXG5cdFx0XHRcdC5jYXRjaChlcnIgPT4ge1xuXHRcdFx0XHRcdGNvbnNvbGUubG9nKGVycilcblx0XHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKGVycilcblx0XHRcdFx0fSlcblx0XHRcdHJldHVybiB0cnVlXG5cdFx0fVxuXHR9XG59KVxuXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFZhbGlkYXRlZE1ldGhvZCB9IGZyb20gJ21ldGVvci9tZGc6dmFsaWRhdGVkLW1ldGhvZCc7XG5cbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCBhc3NlcnQgZnJvbSAnYXNzZXJ0JztcbmltcG9ydCBCYWJ5IGZyb20gJ2JhYnlwYXJzZSc7XG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xuaW1wb3J0IGZpbmRJbmRleCBmcm9tICdsb2Rhc2gvZmluZEluZGV4JztcbmltcG9ydCBpc0VxdWFsIGZyb20gJ2xvZGFzaC9pc0VxdWFsJztcbmltcG9ydCBpc0VtcHR5IGZyb20gJ2xvZGFzaC9pc0VtcHR5JztcbmltcG9ydCBtYXBWYWx1ZXMgZnJvbSAnbG9kYXNoL21hcFZhbHVlcyc7XG5pbXBvcnQgcXVlcnlzdHJpbmcgZnJvbSAncXVlcnlzdHJpbmcnO1xuXG5pbXBvcnQgeyBHZW5lcywgR2VuZVNjaGVtYSwgU3ViZmVhdHVyZVNjaGVtYSB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9nZW5lX2NvbGxlY3Rpb24uanMnO1xuaW1wb3J0IHsgUmVmZXJlbmNlcywgUmVmZXJlbmNlSW5mbyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5vbWVzL3JlZmVyZW5jZV9jb2xsZWN0aW9uLmpzJztcbmltcG9ydCB7IFRyYWNrcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5vbWVzL3RyYWNrX2NvbGxlY3Rpb24uanMnO1xuXG5pbXBvcnQgeyBzY2FuR2VuZUF0dHJpYnV0ZXMgfSBmcm9tICcvaW1wb3J0cy9hcGkvZ2VuZXMvc2Nhbl9hdHRyaWJ1dGVzLmpzJztcblxuLyoqXG4gKiBPdmVycmlkZSB0aGUgZGVmYXVsdCBxdWVyeXN0cmluZyB1bmVzY2FwZSBmdW5jdGlvbiB0byBiZSBhYmxlIHRvIHBhcnNlIGNvbW1hcyBjb3JyZWN0bHkgaW4gZ2ZmIGF0dHJpYnV0ZXNcbiAqIEBwYXJhbSAge1t0eXBlXX1cbiAqIEByZXR1cm4ge1t0eXBlXX1cbiAqL1xucXVlcnlzdHJpbmcudW5lc2NhcGUgPSB1cmkgPT4gdXJpO1xuXG4vKipcbiAqIFtJbnRlcnZhbCBkZXNjcmlwdGlvbl1cbiAqIEB0eXBlIHtbdHlwZV19XG4gKi9cbmNvbnN0IEludGVydmFsID0gY2xhc3MgSW50ZXJ2YWx7XG5cdGNvbnN0cnVjdG9yKHsgbGluZSwgdHJhY2tOYW1lLCByZWZlcmVuY2VOYW1lICwgcmVmZXJlbmNlU2VxdWVuY2VzIH0pe1xuXHRcdGFzc2VydC5lcXVhbChsaW5lLmxlbmd0aCw5KVxuXHRcdGNvbnN0IFtcblx0XHRcdHNlcWlkLFxuXHRcdFx0c291cmNlLFxuXHRcdFx0dHlwZSxcblx0XHRcdHN0YXJ0LFxuXHRcdFx0ZW5kLFxuXHRcdFx0c2NvcmUsXG5cdFx0XHRzdHJhbmQsXG5cdFx0XHRwaGFzZSxcblx0XHRcdGF0dHJpYnV0ZXNcblx0XHRdID0gbGluZVxuXHRcdFxuXHRcdHRoaXMudHlwZSA9IHR5cGU7XG5cdFx0dGhpcy5zdGFydCA9IHN0YXJ0O1xuXHRcdHRoaXMuZW5kID0gZW5kO1xuXHRcdHRoaXMuc2NvcmUgPSBTdHJpbmcoc2NvcmUpO1xuXHRcdHRoaXMuYXR0cmlidXRlcyA9IGZvcm1hdEF0dHJpYnV0ZXMoYXR0cmlidXRlcyk7XG5cblx0XHR0aGlzLklEID0gdGhpcy5hdHRyaWJ1dGVzLklEWzBdO1xuXHRcdGRlbGV0ZSB0aGlzLmF0dHJpYnV0ZXMuSUQ7XG5cblx0XHRpZiAodGhpcy5hdHRyaWJ1dGVzLlBhcmVudCAhPT0gdW5kZWZpbmVkKXtcblx0XHRcdHRoaXMucGFyZW50cyA9IHRoaXMuYXR0cmlidXRlcy5QYXJlbnQ7XG5cdFx0XHRkZWxldGUgdGhpcy5hdHRyaWJ1dGVzLlBhcmVudDtcblx0XHR9XG5cdFxuXHRcdHRoaXMuc2VxID0gcmVmZXJlbmNlU2VxdWVuY2VzW3NlcWlkXS5zbGljZShzdGFydCAtIDEsIGVuZClcblx0XHRpZiAodGhpcy50eXBlID09PSAnZ2VuZScpe1xuXHRcdFx0XHR0aGlzLnNlcWlkID0gc2VxaWQ7XG5cdFx0XHRcdHRoaXMuc291cmNlID0gc291cmNlO1xuXHRcdFx0XHR0aGlzLnN0cmFuZCA9IHN0cmFuZDtcblx0XHRcdFx0dGhpcy5yZWZlcmVuY2UgPSByZWZlcmVuY2VOYW1lO1xuXHRcdFx0XHR0aGlzLnRyYWNrID0gdHJhY2tOYW1lO1xuXHRcdFx0XHR0aGlzLnBlcm1pc3Npb25zPSBbJ2FkbWluJ107XG5cdFx0XHRHZW5lU2NoZW1hLnZhbGlkYXRlKHRoaXMpXG5cdFx0fSBlbHNlIHtcblx0XHRcdHRoaXMucGhhc2UgPSBwaGFzZVxuXHRcdFx0U3ViZmVhdHVyZVNjaGVtYS52YWxpZGF0ZSh0aGlzKVxuXHRcdH1cblx0fVxufVxuXG4vKipcbiAqIFtHZW5lTW9kZWwgZGVzY3JpcHRpb25dXG4gKiBAdHlwZSB7W3R5cGVdfVxuICovXG5jb25zdCBHZW5lTW9kZWwgPSBjbGFzcyBHZW5lTW9kZWx7XG5cdGNvbnN0cnVjdG9yKGludGVydmFscyl7XG5cdFx0Y29uc29sZS5sb2coJ2NvbnN0cnVjdGluZyBnZW5lbW9kZWwnKVxuXHRcdE9iamVjdC52YWx1ZXMoaW50ZXJ2YWxzKS5mb3JFYWNoKCBpbnRlcnZhbCA9PiB7XG5cdFx0XHRpZiAoaW50ZXJ2YWwucGFyZW50cyAhPT0gdW5kZWZpbmVkKXtcblx0XHRcdFx0aW50ZXJ2YWwucGFyZW50cy5mb3JFYWNoKCBwYXJlbnRJZCA9PiB7XG5cdFx0XHRcdFx0bGV0IHBhcmVudCA9IGludGVydmFsc1twYXJlbnRJZF1cblx0XHRcdFx0XHRpZiAocGFyZW50LmNoaWxkcmVuID09PSB1bmRlZmluZWQpe1xuXHRcdFx0XHRcdFx0aW50ZXJ2YWxzW3BhcmVudElkXS5jaGlsZHJlbiA9IFtdXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGludGVydmFsc1twYXJlbnRJZF0uY2hpbGRyZW4ucHVzaChpbnRlcnZhbC5JRClcblx0XHRcdFx0fSlcblx0XHRcdH1cblx0XHR9KVxuXHRcdGNvbnN0IGdlbmVzID0gT2JqZWN0LnZhbHVlcyhpbnRlcnZhbHMpLmZpbHRlciggaW50ZXJ2YWwgPT4ge1xuXHRcdFx0cmV0dXJuIGludGVydmFsLnR5cGUgPT09ICdnZW5lJztcblx0XHR9KVxuXHRcdGFzc2VydC5lcXVhbChnZW5lcy5sZW5ndGgsIDEpXG5cdFx0Y29uc3QgZ2VuZSA9IGdlbmVzWzBdXG5cblx0XHRjb25zb2xlLmxvZyhnZW5lLklEKVxuXG5cdFx0T2JqZWN0LmtleXMoZ2VuZSkuZm9yRWFjaChrZXkgPT4ge1xuXHRcdFx0dGhpc1trZXldID0gZ2VuZVtrZXldXG5cdFx0fSlcblxuXHRcdHRoaXMuc3ViZmVhdHVyZXMgPSBPYmplY3QudmFsdWVzKGludGVydmFscykuZmlsdGVyKCBpbnRlcnZhbCA9PiB7XG5cdFx0XHRyZXR1cm4gaW50ZXJ2YWwudHlwZSAhPT0gJ2dlbmUnO1xuXHRcdH0pXG5cdH1cbn1cblxuLyoqXG4gKiBbVmFsaWRhdGVkTWV0aG9kIGRlc2NyaXB0aW9uXVxuICogQHBhcmFtIHtbdHlwZV19IG9wdGlvbnMubmFtZTogICAgICdhZGRHZmYnICAgICBbZGVzY3JpcHRpb25dXG4gKiBAcGFyYW0ge1t0eXBlXX0gb3B0aW9ucy52YWxpZGF0ZTogbmV3ICAgICAgICAgIFNpbXBsZVNjaGVtYSh7XHRcdGZpbGVOYW1lOiB7ICAgICAgICAgICAgdHlwZTogICAgICAgICAgICAgIFN0cmluZyAgICAgICAgW2Rlc2NyaXB0aW9uXVxuICogQHBhcmFtIHtbdHlwZV19IHJlZmVyZW5jZU5hbWU6ICAgIHsgICAgICAgICAgIHR5cGU6ICAgICAgICAgICAgICAgICAgICAgIFN0cmluZyAgICAgICAgfSAgICAgICAgICAgICAgICAgW2Rlc2NyaXB0aW9uXVxuICogQHBhcmFtIHtbdHlwZV19IHRyYWNrTmFtZTogICAgICAgIHsgICAgICAgICAgIHR5cGU6ICAgICAgICAgICAgICAgICAgICAgIFN0cmluZyAgICAgICAgfVx0fSkudmFsaWRhdG9yKCkgW2Rlc2NyaXB0aW9uXVxuICogQHBhcmFtIHtbdHlwZV19IGFwcGx5T3B0aW9uczogICAgIHtcdFx0bm9SZXRyeTogdHJ1ZVx0fSAgICAgICAgICAgICAgICAgICAgW2Rlc2NyaXB0aW9uXVxuICogQHBhcmFtIHtbdHlwZV19IHJ1bih7ICAgICAgICAgICAgZmlsZU5hbWUsICAgIHJlZmVyZW5jZU5hbWUsICAgICAgICAgICAgIHRyYWNrTmFtZSAgICAgfSl7XHRcdGlmICAgICAgICAgICghICAgICAgICAgICAgdGhpcy51c2VySWQpICB7XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcdFx0fVx0XHRpZiAoISBSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsJ2N1cmF0b3InKSl7XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcdFx0fVx0XHRjb25zdCBleGlzdGluZ1RyYWNrIFtkZXNjcmlwdGlvbl1cbiAqL1xuZXhwb3J0IGNvbnN0IGFkZEdmZiA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuXHRuYW1lOiAnYWRkR2ZmJyxcblx0dmFsaWRhdGU6IG5ldyBTaW1wbGVTY2hlbWEoe1xuXHRcdGZpbGVOYW1lOiB7IHR5cGU6IFN0cmluZyB9LFxuXHRcdHJlZmVyZW5jZU5hbWU6IHsgdHlwZTogU3RyaW5nIH0sXG5cdFx0dHJhY2tOYW1lOiB7IHR5cGU6IFN0cmluZyB9XG5cdH0pLnZhbGlkYXRvcigpLFxuXHRhcHBseU9wdGlvbnM6IHtcblx0XHRub1JldHJ5OiB0cnVlXG5cdH0sXG5cdHJ1bih7IGZpbGVOYW1lLCByZWZlcmVuY2VOYW1lLCB0cmFja05hbWUgfSl7XG5cdFx0aWYgKCEgdGhpcy51c2VySWQpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG5cdFx0fVxuXHRcdGlmICghIFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwnY3VyYXRvcicpKXtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG5cdFx0fVxuXG5cdFx0Y29uc3QgZXhpc3RpbmdUcmFjayA9IFRyYWNrcy5maW5kKHsgdHJhY2tOYW1lOiB0cmFja05hbWUgfSkuZmV0Y2goKS5sZW5ndGhcblx0XHRpZiAoZXhpc3RpbmdUcmFjayl7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdUcmFjayBleGlzdHM6ICcgKyB0cmFja05hbWUpO1xuXHRcdH1cblxuXHRcdGNvbnN0IGV4aXN0aW5nUmVmZXJlbmNlID0gUmVmZXJlbmNlcy5maW5kKHsgcmVmZXJlbmNlTmFtZTogcmVmZXJlbmNlTmFtZSB9KS5mZXRjaCgpLmxlbmd0aFxuXHRcdGlmICghZXhpc3RpbmdSZWZlcmVuY2Upe1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcignSW52YWxpZCByZWZlcmVuY2U6ICcgKyByZWZlcmVuY2VOYW1lKVxuXHRcdH1cblxuXHRcdGNvbnN0IGZpbGVIYW5kbGUgPSBmcy5yZWFkRmlsZVN5bmMoZmlsZU5hbWUse2VuY29kaW5nOidiaW5hcnknfSk7XG5cblx0XHRsZXQgaW50ZXJ2YWxzID0ge307XG5cdFx0bGV0IGdlbmVDb3VudCA9IDA7XG5cblx0XHRjb25zb2xlLmxvZyhgR2F0aGVyaW5nIHJlZmVyZW5jZSBzZXF1ZW5jZXMgZm9yICR7cmVmZXJlbmNlTmFtZX1gKVxuXHRcdGNvbnN0IHJlZmVyZW5jZVNlcXVlbmNlcyA9IGdldFJlZmVyZW5jZVNlcXVlbmNlcyhyZWZlcmVuY2VOYW1lKTtcblxuXHRcdGNvbnNvbGUubG9nKCdzdGFydCByZWFkaW5nJylcblx0XHRCYWJ5LnBhcnNlKGZpbGVIYW5kbGUsIHtcblx0XHRcdGRlbGltaXRlcjogJ1xcdCcsXG5cdFx0XHRkeW5hbWljVHlwaW5nOiB0cnVlLFxuXHRcdFx0c2tpcEVtcHR5TGluZXM6IHRydWUsXG5cdFx0XHRjb21tZW50czogJyMnLFxuXHRcdFx0ZXJyb3IoZXJyb3IsZmlsZSkge1xuXHRcdFx0XHRjb25zb2xlLmxvZyhlcnJvcilcblx0XHRcdH0sXG5cdFx0XHRzdGVwKGxpbmUpe1xuXHRcdFx0XHRsZXQgaW50ZXJ2YWwgPSBuZXcgSW50ZXJ2YWwoe1xuXHRcdFx0XHRcdGxpbmU6IGxpbmUuZGF0YVswXSwgXG5cdFx0XHRcdFx0cmVmZXJlbmNlTmFtZTogcmVmZXJlbmNlTmFtZSwgXG5cdFx0XHRcdFx0dHJhY2tOYW1lOiB0cmFja05hbWUsXG5cdFx0XHRcdFx0cmVmZXJlbmNlU2VxdWVuY2VzOiByZWZlcmVuY2VTZXF1ZW5jZXNcblx0XHRcdFx0fSlcblxuXHRcdFx0XHRpZiAoaW50ZXJ2YWwucGFyZW50cyA9PT0gdW5kZWZpbmVkKXtcblx0XHRcdFx0XHRhc3NlcnQuZXF1YWwoaW50ZXJ2YWwudHlwZSwgJ2dlbmUnKTtcblx0XHRcdFx0XHRpZiAoICFpc0VtcHR5KGludGVydmFscykgKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBnZW5lID0gbmV3IEdlbmVNb2RlbChpbnRlcnZhbHMpO1xuXHRcdFx0XHRcdFx0R2VuZVNjaGVtYS52YWxpZGF0ZShnZW5lKTtcblx0XHRcdFx0XHRcdEdlbmVzLmluc2VydChnZW5lKTtcblx0XHRcdFx0XHRcdGdlbmVDb3VudCArPSAxO1xuXHRcdFx0XHRcdFx0aW50ZXJ2YWxzID0ge31cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0aW50ZXJ2YWxzW2ludGVydmFsLklEXSA9IGludGVydmFsO1xuXHRcdFx0fSxcblx0XHRcdGNvbXBsZXRlKHJlc3VsdHMsZmlsZSkge1xuXHRcdFx0XHRcblx0XHRcdFx0aWYgKCAhaXNFbXB0eShpbnRlcnZhbHMpICkge1xuXHRcdFx0XHRcdGNvbnNvbGUubG9nKCdjb25zdHJ1Y3RpbmcgZmluYWwgZ2VuZScpXG5cdFx0XHRcdFx0Y29uc3QgZ2VuZSA9IG5ldyBHZW5lTW9kZWwoaW50ZXJ2YWxzKTtcblx0XHRcdFx0XHRHZW5lU2NoZW1hLnZhbGlkYXRlKGdlbmUpO1xuXHRcdFx0XHRcdEdlbmVzLmluc2VydChnZW5lKTtcblx0XHRcdFx0XHRnZW5lQ291bnQgKz0gMTtcblx0XHRcdFx0XHRpbnRlcnZhbHMgPSB7fVxuXHRcdFx0XHR9XG5cdFx0XHRcdFxuXHRcdFx0XHRUcmFja3MuaW5zZXJ0KHtcblx0XHRcdFx0XHR0cmFja05hbWU6IHRyYWNrTmFtZSxcblx0XHRcdFx0XHRyZWZlcmVuY2U6IHJlZmVyZW5jZU5hbWUsXG5cdFx0XHRcdFx0Z2VuZUNvdW50OiBnZW5lQ291bnQsXG5cdFx0XHRcdFx0cGVybWlzc2lvbnM6IFsnYWRtaW4nXVxuXHRcdFx0XHR9KTtcblxuXHRcdFx0XHRzY2FuR2VuZUF0dHJpYnV0ZXMuY2FsbCh7IHRyYWNrTmFtZTogdHJhY2tOYW1lIH0pO1xuXHRcdFx0fVxuXHRcdH0pXG5cdFx0cmV0dXJuIHRydWVcblx0fVxufSlcblxuLyoqXG4gKiBbZGVzY3JpcHRpb25dXG4gKiBAcGFyYW0gIHtbdHlwZV19IHJlZmVyZW5jZU5hbWUgW2Rlc2NyaXB0aW9uXVxuICogQHJldHVybiB7W3R5cGVdfSAgICAgICAgICAgICAgIFtkZXNjcmlwdGlvbl1cbiAqL1xuY29uc3QgZ2V0UmVmZXJlbmNlU2VxdWVuY2VzID0gKHJlZmVyZW5jZU5hbWUpID0+IHtcblx0Y29uc3QgaGVhZGVycyA9IFJlZmVyZW5jZXMuZmluZCh7XG5cdFx0cmVmZXJlbmNlTmFtZTogcmVmZXJlbmNlTmFtZVxuXHR9LHtcblx0XHRmaWVsZHM6IHtcblx0XHRcdGhlYWRlcjogMVxuXHRcdH1cblx0fSkubWFwKHJlZmVyZW5jZSA9PiByZWZlcmVuY2UuaGVhZGVyKS5yZWR1Y2UoKGhlYWRlcnMsIGhlYWRlcikgPT4ge1xuXHRcdGlmIChoZWFkZXJzLmluZGV4T2YoaGVhZGVyKSA8IDApe1xuXHRcdFx0aGVhZGVycy5wdXNoKGhlYWRlcilcblx0XHR9XG5cdFx0cmV0dXJuIGhlYWRlcnNcblx0fSxbXSlcblxuXHRjb25zdCByZWZlcmVuY2VTZXF1ZW5jZXMgPSBoZWFkZXJzLnJlZHVjZSgoc2VxdWVuY2VzLCBoZWFkZXIpID0+IHtcblx0XHRjb25zdCBzZXF1ZW5jZSA9IFJlZmVyZW5jZXMuZmluZCh7XG5cdFx0XHRyZWZlcmVuY2VOYW1lOiByZWZlcmVuY2VOYW1lLFxuXHRcdFx0aGVhZGVyOiBoZWFkZXJcblx0XHR9LHtcblx0XHRcdHNvcnQ6IHtcblx0XHRcdFx0c3RhcnQ6IDFcblx0XHRcdH1cblx0XHR9KS5tYXAoIHJlZiA9PiByZWYuc2VxKS5qb2luKCcnKVxuXHRcdHNlcXVlbmNlc1toZWFkZXJdID0gc2VxdWVuY2U7XG5cdFx0cmV0dXJuIHNlcXVlbmNlc1xuXHR9LHt9KVxuXHRyZXR1cm4gcmVmZXJlbmNlU2VxdWVuY2VzXG59XG5cbi8qKlxuICogW2Rlc2NyaXB0aW9uXVxuICogQHBhcmFtICB7W3R5cGVdfSBhdHRyaWJ1dGVTdHJpbmcgW2Rlc2NyaXB0aW9uXVxuICogQHJldHVybiB7W3R5cGVdfSAgICAgICAgICAgICAgICAgW2Rlc2NyaXB0aW9uXVxuICovXG5jb25zdCBmb3JtYXRBdHRyaWJ1dGVzID0gKGF0dHJpYnV0ZVN0cmluZykgPT4ge1xuXHRyZXR1cm4gYXR0cmlidXRlU3RyaW5nLnNwbGl0KCc7JykucmVkdWNlKChhdHRyaWJ1dGVzLCBzdHJpbmdQYXJ0KSA9PiB7XG5cdFx0Y29uc3QgW2tleSwgdmFsdWVdID0gc3RyaW5nUGFydC5zcGxpdCgnPScpXG5cdFx0YXR0cmlidXRlc1trZXldID0gdmFsdWUuc3BsaXQoJywnKS5tYXAoZGVjb2RlVVJJQ29tcG9uZW50KVxuXHRcdHJldHVybiBhdHRyaWJ1dGVzO1xuXHR9LCB7fSlcbn1cbiIsImltcG9ydCB7IFZhbGlkYXRlZE1ldGhvZCB9IGZyb20gJ21ldGVvci9tZGc6dmFsaWRhdGVkLW1ldGhvZCc7XG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuaW1wb3J0IGZzIGZyb20gJ2ZzJztcbmltcG9ydCByZWFkbGluZSBmcm9tICdyZWFkbGluZSc7XG5pbXBvcnQgRmliZXIgZnJvbSAnZmliZXJzJztcbmltcG9ydCBGdXR1cmUgZnJvbSAnZmliZXJzL2Z1dHVyZSc7XG5cbmltcG9ydCB7IFJlZmVyZW5jZUluZm8sIFJlZmVyZW5jZXMgfSBmcm9tICcvaW1wb3J0cy9hcGkvZ2Vub21lcy9yZWZlcmVuY2VfY29sbGVjdGlvbi5qcyc7XG5cbmNvbnN0IHBhcmFtZXRlclNjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuXHRmaWxlTmFtZTogeyB0eXBlOiBTdHJpbmcgfSxcblx0cmVmZXJlbmNlTmFtZTogeyB0eXBlOiBTdHJpbmcgfVxufSlcblxuZXhwb3J0IGNvbnN0IGFkZFJlZmVyZW5jZSA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuXHRuYW1lOiAnYWRkUmVmZXJlbmNlJyxcblx0dmFsaWRhdGU6IHBhcmFtZXRlclNjaGVtYS52YWxpZGF0b3IoKSxcblx0YXBwbHlPcHRpb25zOiB7XG5cdFx0bm9SZXRyeTogdHJ1ZVxuXHR9LFxuXHRydW4oeyBmaWxlTmFtZSwgcmVmZXJlbmNlTmFtZSB9KSB7XG5cdFx0aWYgKCEgdGhpcy51c2VySWQpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG5cdFx0fVxuXHRcdGlmICghIFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwnY3VyYXRvcicpKXtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG5cdFx0fVxuXG5cdFx0Y29uc3QgZXhpc3RpbmdSZWZlcmVuY2UgPSBSZWZlcmVuY2VJbmZvLmZpbmQoe3JlZmVyZW5jZU5hbWU6IHJlZmVyZW5jZU5hbWV9KS5mZXRjaCgpLmxlbmd0aFxuXHRcdGlmIChleGlzdGluZ1JlZmVyZW5jZSl7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdFeGlzdGluZyByZWZlcmVuY2U6ICcgKyByZWZlcmVuY2VOYW1lKVxuXHRcdH1cblxuXHRcdGNvbnN0IGxpbmVSZWFkZXIgPSByZWFkbGluZS5jcmVhdGVJbnRlcmZhY2Uoe1xuXHRcdFx0aW5wdXQ6IGZzLmNyZWF0ZVJlYWRTdHJlYW0oZmlsZU5hbWUsICd1dGY4Jylcblx0XHR9KVxuXG5cdFx0Y29uc3QgYnVsa09wID0gUmVmZXJlbmNlcy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuXG5cdFx0bGV0IHNlcSA9ICcnO1xuXHRcdGxldCBoZWFkZXI7XG5cdFx0bGV0IHN0YXJ0ID0gMDtcblx0XHRsZXQgZW5kID0gMDtcblx0XHRjb25zdCBjaHVua1NpemUgPSAxMDAwMDtcblx0XHRcblx0XHRjb25zdCBmdXQgPSBuZXcgRnV0dXJlKCk7XG5cdFx0Y29uc29sZS5sb2coJ3N0YXJ0IHBhcnNpbmcnKVxuXHRcdGxpbmVSZWFkZXIub24oJ2xpbmUnLCAobGluZSkgPT4ge1xuXHRcdFx0aWYgKGxpbmVbMF0gPT09ICc+Jyl7XG5cdFx0XHRcdGlmIChoZWFkZXIgIT09IHVuZGVmaW5lZCl7XG5cdFx0XHRcdFx0Y29uc29sZS5sb2coaGVhZGVyKVxuXHRcdFx0XHRcdGlmIChzZXEubGVuZ3RoID4gMCl7XG5cdFx0XHRcdFx0XHRlbmQgKz0gc2VxLmxlbmd0aDtcblx0XHRcdFx0XHRcdG5ldyBGaWJlcigoKT0+e1xuXHRcdFx0XHRcdFx0XHRSZWZlcmVuY2VzLmluc2VydCh7XG5cdFx0XHRcdFx0XHRcdFx0aGVhZGVyOiBoZWFkZXIsXG5cdFx0XHRcdFx0XHRcdFx0c2VxOiBzZXEsXG5cdFx0XHRcdFx0XHRcdFx0c3RhcnQ6IHN0YXJ0LFxuXHRcdFx0XHRcdFx0XHRcdGVuZDogZW5kLFxuXHRcdFx0XHRcdFx0XHRcdHJlZmVyZW5jZU5hbWU6IHJlZmVyZW5jZU5hbWUsXG5cdFx0XHRcdFx0XHRcdFx0cGVybWlzc2lvbnM6IFsnYWRtaW4nXVxuXHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0fSkucnVuKClcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0aGVhZGVyID0gbGluZS5zcGxpdCgnPicpWzFdLnNwbGl0KCcgJylbMF07XG5cdFx0XHRcdHNlcSA9ICcnO1xuXHRcdFx0XHRzdGFydCA9IDA7XG5cdFx0XHRcdGVuZCA9IDA7XG5cdFx0XHRcdFxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0c2VxICs9IGxpbmU7XG5cdFx0XHRcdGlmICggc2VxLmxlbmd0aCA+IGNodW5rU2l6ZSApe1xuXHRcdFx0XHRcdGVuZCArPSBjaHVua1NpemVcblx0XHRcdFx0XHRuZXcgRmliZXIoKCk9Pntcblx0XHRcdFx0XHRcdFJlZmVyZW5jZXMuaW5zZXJ0KHtcblx0XHRcdFx0XHRcdFx0aGVhZGVyOiBoZWFkZXIsXG5cdFx0XHRcdFx0XHRcdHNlcTogc2VxLnN1YnN0cmluZygwLGNodW5rU2l6ZSksXG5cdFx0XHRcdFx0XHRcdHN0YXJ0OiBzdGFydCxcblx0XHRcdFx0XHRcdFx0ZW5kOiBlbmQsXG5cdFx0XHRcdFx0XHRcdHJlZmVyZW5jZU5hbWU6IHJlZmVyZW5jZU5hbWUsXG5cdFx0XHRcdFx0XHRcdHBlcm1pc3Npb25zOiBbJ2FkbWluJ11cblx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0fSkucnVuKClcblx0XHRcdFx0XHRzZXEgPSBzZXEuc3Vic3RyaW5nKGNodW5rU2l6ZSk7XG5cdFx0XHRcdFx0c3RhcnQgKz0gY2h1bmtTaXplO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSlcblxuXHRcdGxpbmVSZWFkZXIub24oJ2Nsb3NlJywgKCkgPT4ge1xuXHRcdFx0ZW5kICs9IHNlcS5sZW5ndGg7XG5cdFx0XHRuZXcgRmliZXIoKCk9Pntcblx0XHRcdFx0UmVmZXJlbmNlcy5pbnNlcnQoe1xuXHRcdFx0XHRcdGhlYWRlcjogaGVhZGVyLFxuXHRcdFx0XHRcdHNlcTogc2VxLFxuXHRcdFx0XHRcdHN0YXJ0OiBzdGFydCxcblx0XHRcdFx0XHRlbmQ6IGVuZCxcblx0XHRcdFx0XHRyZWZlcmVuY2VOYW1lOiByZWZlcmVuY2VOYW1lLFxuXHRcdFx0XHRcdHBlcm1pc3Npb25zOiBbJ2FkbWluJ11cblx0XHRcdFx0fSlcblx0XHRcdFx0UmVmZXJlbmNlSW5mby5pbnNlcnQoe1xuXHRcdFx0XHRcdHJlZmVyZW5jZU5hbWU6IHJlZmVyZW5jZU5hbWUsXG5cdFx0XHRcdFx0cGVybWlzc2lvbnM6IFsnYWRtaW4nXSxcblx0XHRcdFx0XHRkZXNjcmlwdGlvbjogJ2Rlc2NyaXB0aW9uJyxcblx0XHRcdFx0XHRvcmdhbmlzbTogJ29yZ2FuaXNtJ1xuXHRcdFx0XHR9KVxuXHRcdFx0XHRjb25zb2xlLmxvZygnZmluaXNoZWQgcGFyc2luZycpXG5cblx0XHRcdFx0ZnV0LnJldHVybigxKVxuXHRcdFx0fSkucnVuKClcblx0XHRcdFxuXG5cdFx0fSlcblx0XHRyZXR1cm4gZnV0LndhaXQoKVxuXHR9XG59KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuY29uc3QgUmVmZXJlbmNlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdyZWZlcmVuY2VzJyk7XG5cbmNvbnN0IFJlZmVyZW5jZVNjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuXHRoZWFkZXI6IHtcblx0XHR0eXBlOiBTdHJpbmcsXG5cdFx0aW5kZXg6IHRydWUsXG5cdFx0bGFiZWw6ICdGYXN0YSBzdHlsZSBzZXF1ZW5jZSBoZWFkZXInXG5cdH0sXG5cdHNlcToge1xuXHRcdHR5cGU6IFN0cmluZyxcblx0XHRsYWJlbDogJ051Y2xlb3RpZGUgc2VxdWVuY2UnXG5cdH0sXG5cdHJlZmVyZW5jZU5hbWU6IHtcblx0XHR0eXBlOiBTdHJpbmcsXG5cdFx0aW5kZXg6IHRydWUsXG5cdFx0bGFiZWw6ICdSZWZlcmVuY2UgbmFtZSdcblx0fSxcblx0c3RhcnQ6IHtcblx0XHR0eXBlOiBOdW1iZXIsXG5cdFx0aW5kZXg6IHRydWUsXG5cdFx0bGFiZWw6ICdTdGFydCBwb3NpdGlvbiBvZiBzZXF1ZW5jZSBmcmFnbWVudCBvbiBvcmlnaW5hbCBzZXF1ZW5jZSdcblx0fSxcblx0ZW5kOiB7XG5cdFx0dHlwZTogTnVtYmVyLFxuXHRcdGluZGV4OiB0cnVlLFxuXHRcdGxhYmVsOiAnRW5kIHBvc2l0aW9uIG9mIHNlcXVlbmNlIGZyYWdtZW50IG9uIG9yaWdpbmFsIHNlcXVlbmNlJ1xuXHR9LFxuXHRwZXJtaXNzaW9uczoge1xuXHRcdHR5cGU6IEFycmF5LC8vW1N0cmluZ10sXG5cdFx0bGFiZWw6ICdVc2VyIGdyb3VwcyB0aGF0IGFyZSBhbGxvd2VkIHRvIHNlZSB0aGlzIHJlZmVyZW5jZSdcblx0fSxcblx0J3Blcm1pc3Npb25zLiQnIDoge1xuXHRcdHR5cGU6IFN0cmluZ1xuXHR9XG59KVxuXG5SZWZlcmVuY2VzLmF0dGFjaFNjaGVtYShSZWZlcmVuY2VTY2hlbWEpXG5cbmNvbnN0IFJlZmVyZW5jZUluZm8gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncmVmZXJlbmNlSW5mbycpXG5cbmNvbnN0IFJlZmVyZW5jZUluZm9TY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcblx0cmVmZXJlbmNlTmFtZToge1xuXHRcdHR5cGU6IFN0cmluZyxcblx0XHRsYWJlbDogJ1JlZmVyZW5jZSBuYW1lJyxcblx0XHRpbmRleDogdHJ1ZSxcblx0XHR1bmlxdWU6IHRydWVcblx0fSxcblx0cGVybWlzc2lvbnM6IHtcblx0XHR0eXBlOiBBcnJheSwvL1tTdHJpbmddLFxuXHRcdGxhYmVsOiAnVXNlciBncm91cHMgdGhhdCBhcmUgYWxsb3dlZCB0byBzZWUgdGhpcyByZWZlcmVuY2UnXG5cdH0sXG5cdCdwZXJtaXNzaW9ucy4kJzoge1xuXHRcdHR5cGU6IFN0cmluZ1xuXHR9LFxuXHRkZXNjcmlwdGlvbjoge1xuXHRcdHR5cGU6IFN0cmluZyxcblx0XHRsYWJlbDogJ1JlZmVyZW5jZSBzZXF1ZW5jZSBkZXNjcmlwdGlvbidcblx0fSxcblx0b3JnYW5pc206IHtcblx0XHR0eXBlOiBTdHJpbmcsXG5cdFx0bGFiZWw6ICdPcmdhbmlzbSBuYW1lJ1xuXHR9XG59KVxuXG5SZWZlcmVuY2VJbmZvLmF0dGFjaFNjaGVtYShSZWZlcmVuY2VJbmZvU2NoZW1hKVxuXG5leHBvcnQgeyBSZWZlcmVuY2VzLCBSZWZlcmVuY2VTY2hlbWEsIFJlZmVyZW5jZUluZm8sIFJlZmVyZW5jZUluZm9TY2hlbWEgfTsiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5cbmNvbnN0IFRyYWNrcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd0cmFja3MnKTtcblxuY29uc3QgdHJhY2tTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcblx0dHJhY2tOYW1lOiB7XG5cdFx0dHlwZTogU3RyaW5nLFxuICAgIGxhYmVsOiAnQW5ub3RhdGlvbiB0cmFjayBuYW1lJ1xuXHR9LFxuXHRyZWZlcmVuY2U6IHtcblx0XHR0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdSZWZlcmVuY2Ugc2VxdWVuY2UgdG8gd2hpY2ggdGhlIGFubm90YXRpb24gYmVsb25ncydcblx0fSxcbiAgYmxhc3RkYnM6IHtcbiAgICB0eXBlOiBPYmplY3QsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sXG4gICdibGFzdGRicy5udWNsJzoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgICBsYWJlbDogJ051Y2xlb3RpZGUgYmxhc3QgZGF0YWJhc2UgbmFtZSdcbiAgfSxcbiAgJ2JsYXN0ZGJzLnByb3QnOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICAgIGxhYmVsOiAnUGVwdGlkZSBibGFzdCBkYXRhYmFzZSBuYW1lJ1xuICB9LFxuICBwZXJtaXNzaW9uczoge1xuICAgIHR5cGU6IEFycmF5LC8vW1N0cmluZ10sXG4gICAgbGFiZWw6ICdUcmFjayBwZXJtaXNzaW9ucydcbiAgfSxcbiAgJ3Blcm1pc3Npb25zLiQnOiB7XG4gICAgdHlwZTogU3RyaW5nXG4gIH1cbn0pO1xuXG5UcmFja3MuYXR0YWNoU2NoZW1hKHRyYWNrU2NoZW1hKTtcblxuZXhwb3J0IHsgVHJhY2tzLCB0cmFja1NjaGVtYSB9OyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgVmFsaWRhdGVkTWV0aG9kIH0gZnJvbSAnbWV0ZW9yL21kZzp2YWxpZGF0ZWQtbWV0aG9kJztcbmltcG9ydCB7IFJvbGVzIH0gZnJvbSAnbWV0ZW9yL2FsYW5uaW5nOnJvbGVzJztcblxuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuXG5pbXBvcnQgeyBUcmFja3MgfSBmcm9tICcvaW1wb3J0cy9hcGkvZ2Vub21lcy90cmFja19jb2xsZWN0aW9uLmpzJztcblxuLyoqXG4gKiBzdWJtaXRCbGFzdEpvYiB2YWxpZGF0ZWQgbWV0aG9kOiBzdWJtaXRzIG1ha2VibGFzdGRiIGpvYiB0byBqb2JxdWV1ZSwgY2FsbCB0aGlzIGZyb20gdGhlIGNsaWVudFxuICogQHBhcmFtICB7U3RyaW5nfSBvcHRpb25zLnRyYWNrTmFtZSBOYW1lIG9mIHRoZSBhbm5vdGF0aW9uIHRyYWNrXG4gKiBAcGFyYW0gIHtTdHJpbmd9IG9wdGlvbnMuZGJUeXBlICAgIEVpdGhlciBudWNsIG9yIHByb3RcbiAqIEByZXR1cm4ge1N0cmluZ30gICAgICAgICAgICAgICAgICAgam9iSWQgb2YgdGhlIG1ha2VibGFzdGRiIGpvYlxuICovXG5leHBvcnQgY29uc3QgdXBkYXRlVHJhY2tQZXJtaXNzaW9ucyA9IG5ldyBWYWxpZGF0ZWRNZXRob2Qoe1xuICBuYW1lOiAndXBkYXRlVHJhY2tQZXJtaXNzaW9ucycsXG4gIHZhbGlkYXRlOiBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICB0cmFja05hbWU6IHsgdHlwZTogU3RyaW5nIH0sXG4gICAgcGVybWlzc2lvbnM6IHsgdHlwZTogQXJyYXkgfSxcbiAgICAncGVybWlzc2lvbnMuJCc6IHsgdHlwZTogU3RyaW5nIH1cbiAgfSkudmFsaWRhdG9yKCksXG4gIGFwcGx5T3B0aW9uczoge1xuICAgIG5vUmV0cnk6IHRydWVcbiAgfSxcbiAgcnVuKHsgdHJhY2tOYW1lLCBwZXJtaXNzaW9ucyB9KXtcbiAgICBpZiAoISB0aGlzLnVzZXJJZCkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9XG4gICAgaWYgKCEgUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCd1c2VyJykpe1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9XG5cbiAgICBpZiAocGVybWlzc2lvbnMubGVuZ3RoID09PSAwKXtcbiAgICAgIHBlcm1pc3Npb25zLnB1c2goJ2FkbWluJylcbiAgICB9XG5cbiAgICBUcmFja3MudXBkYXRlKHtcbiAgICAgIHRyYWNrTmFtZTogdHJhY2tOYW1lXG4gICAgfSx7XG4gICAgICAkc2V0OiB7XG4gICAgICAgIHBlcm1pc3Npb25zOiBwZXJtaXNzaW9uc1xuICAgICAgfVxuICAgIH0pXG4gIFxuICB9XG59KVxuIiwiY29uc3Qgam9iUXVldWUgPSBuZXcgSm9iQ29sbGVjdGlvbignam9iUXVldWUnLCB7IG5vQ29sbGVjdGlvblN1ZmZpeDogdHJ1ZSB9KTtcblxuLy9pbW1lZGlhdGVseSBidWlsZCBhICdqb2IgY2xlYW5pbmcgam9iJyBzbyB0aGF0IHRoZSBqb2Jjb2xsZWN0aW9uIGRvZXMgbm90IGZpbGwgdXAgZW5kbGVzc2x5XG5uZXcgSm9iKGpvYlF1ZXVlLCAnY2xlYW51cCcse30pXG4gIC5yZXBlYXQoeyBzY2hlZHVsZTogam9iUXVldWUubGF0ZXIucGFyc2UudGV4dCgnZXZlcnkgMjAgbWludXRlcycpIH0pXG4gIC5zYXZlKHsgY2FuY2VsUmVwZWF0czogdHJ1ZSB9KVxuXG5jb25zdCBjbGVhbnVwID0gam9iUXVldWUucHJvY2Vzc0pvYnMoXG4gICdjbGVhbnVwJyxcbiAge1xuICAgIHBvbGxJbnRlcnZhbDogZmFsc2UsXG4gICAgd29ya1RpbWVvdXQ6IDYwICogMTAwMFxuICB9LFxuICAoam9iLGNhbGxiYWNrKSA9PiB7XG4gICAgbGV0IGN1cnJlbnQgPSBuZXcgRGF0ZSgpXG4gICAgY3VycmVudC5zZXRNaW51dGVzKGN1cnJlbnQuZ2V0TWludXRlcygpIC0gMjAgKVxuICAgIGlkcyA9IGpvYlF1ZXVlLmZpbmQoe1xuICAgICAgc3RhdHVzOiB7XG4gICAgICAgICRpbjogSm9iLmpvYlN0YXR1c1JlbW92YWJsZVxuICAgICAgfSxcbiAgICAgIHVwZGF0ZWQ6IHtcbiAgICAgICAgJGx0OiBjdXJyZW50XG4gICAgICB9XG4gICAgfSx7XG4gICAgICBmaWVsZHM6IHtcbiAgICAgICAgX2lkOiAxXG4gICAgICB9XG4gICAgfSkubWFwKGpvYiA9PiBqb2IuX2lkKVxuXG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKXtcbiAgICAgIGpvYlF1ZXVlLnJlbW92ZUpvYnMoaWRzKVxuICAgIH1cbiAgICBqb2IuZG9uZShgcmVtb3ZlZCAke2lkcy5sZW5ndGh9IG9sZCBqb2JzYClcbiAgICBjYWxsYmFjaygpXG4gIH0pXG5cbmpvYlF1ZXVlLmZpbmQoe1xuICB0eXBlOiAnY2xlYW51cCcsXG4gIHN0YXR1czogJ3JlYWR5J1xufSkub2JzZXJ2ZSh7XG4gIGFkZGVkKCl7XG4gICAgcmV0dXJuIGNsZWFudXAudHJpZ2dlcigpXG4gIH1cbn0pXG5cbmV4cG9ydCBkZWZhdWx0IGpvYlF1ZXVlXG5cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IGpvYlF1ZXVlIGZyb20gJy4vam9icXVldWUuanMnO1xuaW1wb3J0ICBzcGF3biAgZnJvbSAnc3Bhd24tcHJvbWlzZSc7Ly9jaGlsZC1wcm9jZXNzLXByb21pc2UnO1xuXG5pbXBvcnQgeG1sMmpzIGZyb20gJ3htbDJqcy1lczYtcHJvbWlzZSc7XG5cbmltcG9ydCB7IFRyYWNrcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5vbWVzL3RyYWNrX2NvbGxlY3Rpb24uanMnO1xuXG5cbi8qKlxuICogS2VlcCB0cmFjayBvZiB3aGF0IGJsYXN0IGNvbW1hbmRzIHNob3VsZCB1c2Ugd2hpY2ggZGF0YWJhc2VzXG4gKiBAdHlwZSB7T2JqZWN0fVxuICovXG5jb25zdCBEQl9UWVBFUyA9IHsgIFxuICAnYmxhc3RuJzonbnVjbCcsXG4gICd0Ymxhc3RuJzonbnVjbCcsXG4gICd0Ymxhc3R4JzonbnVjbCcsXG4gICdibGFzdHAnOidwcm90JyxcbiAgJ2JsYXN0eCc6J3Byb3QnXG59XG5cbmpvYlF1ZXVlLnByb2Nlc3NKb2JzKFxuICAnYmxhc3QnLFxuICB7XG4gICAgY29uY3VycmVuY3k6IDEsXG4gICAgcGF5bG9hZDogMVxuICB9LFxuICAoam9iLCBjYWxsYmFjaykgPT4ge1xuICAgIGNvbnNvbGUubG9nKGpvYi5kYXRhKVxuXG4gICAgY29uc3Qge1xuICAgICAgYmxhc3RUeXBlLFxuICAgICAgaW5wdXQsXG4gICAgICB0cmFja05hbWVzLFxuICAgICAgdXNlclxuICAgIH0gPSAgam9iLmRhdGFcblxuICAgIGNvbnN0IGRiVHlwZSA9IERCX1RZUEVTW2JsYXN0VHlwZV1cblxuICAgIGNvbnN0IGRicyA9IFRyYWNrcy5maW5kKHtcbiAgICAgIHRyYWNrTmFtZToge1xuICAgICAgICAkaW46IHRyYWNrTmFtZXNcbiAgICAgIH0gXG4gICAgfSx7XG4gICAgICBmaWVsZHM6IHtcbiAgICAgICAgYmxhc3RkYnM6IDFcbiAgICAgIH1cbiAgICB9KS5tYXAodHJhY2sgPT4geyBcbiAgICAgIHJldHVybiB0cmFjay5ibGFzdGRic1tkYlR5cGVdXG4gICAgfSkuam9pbignICcpXG5cbiAgICBjb25zdCBvcHRpb25zID0gWyctZGInLGRicywnLW91dGZtdCcsJzUnLCctbnVtX2FsaWdubWVudHMnLCcyMCddXG5cbiAgICBjb25zb2xlLmxvZyhgJHtibGFzdFR5cGV9ICR7b3B0aW9ucy5qb2luKCcgJyl9ICR7aW5wdXQuc3Vic3RyaW5nKDAsMyl9Li4uJHtpbnB1dC5zdWJzdHJpbmcoaW5wdXQubGVuZ3RoIC0gMywgaW5wdXQubGVuZ3RoKX1gKVxuXG4gICAgc3Bhd24oYmxhc3RUeXBlLCBvcHRpb25zLCBpbnB1dClcbiAgICAgIC50aGVuKCByZXN1bHQgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZygnYmxhc3QgZmluaXNoZWQnKVxuICAgICAgICByZXR1cm4geG1sMmpzKHJlc3VsdC50b1N0cmluZygpKVxuICAgICAgfSlcbiAgICAgIC50aGVuKCByZXN1bHRKc29uID0+IHtcbiAgICAgICAgam9iLmRvbmUocmVzdWx0SnNvbilcbiAgICAgICAgY2FsbGJhY2soKVxuICAgICAgfSlcbiAgICAgIC5jYXRjaCggZXJyb3IgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyhlcnJvcilcbiAgICAgICAgam9iLmZhaWwoZXJyb3IucHJvY2VzcylcbiAgICAgICAgY2FsbGJhY2soKVxuICAgICAgfSlcbiAgICAvL2pvYi5kb25lKGJsYXN0UmVzdWx0KVxuICAgIC8vY2FsbGJhY2soKVxuICB9XG4pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgam9iUXVldWUgZnJvbSAnLi9qb2JxdWV1ZS5qcyc7XG5cbmltcG9ydCBmcyBmcm9tICdmcyc7XG5pbXBvcnQgemxpYiBmcm9tICd6bGliJztcblxuaW1wb3J0IHsgR2VuZXMgfSBmcm9tICcvaW1wb3J0cy9hcGkvZ2VuZXMvZ2VuZV9jb2xsZWN0aW9uLmpzJztcblxuY29uc3QgREFUQVRZUEVfRVhURU5TSU9OUyA9IHtcbiAgJ0Fubm90YXRpb25zJzogJ2Fubm90YXRpb25zLmdmZidcbn1cblxuY29uc3QgcXVldWUgPSBqb2JRdWV1ZS5wcm9jZXNzSm9icyhcbiAgJ2Rvd25sb2FkJyxcbiAge1xuICAgIGNvbmN1cnJlbmN5OiAxLFxuICAgIHBheWxvYWQ6IDFcbiAgfSxcbiAgKGpvYiwgY2FsbGJhY2spID0+IHtcbiAgICBjb25zb2xlLmxvZyhqb2IuZGF0YSlcbiAgICBjb25zdCB7IHF1ZXJ5SGFzaCwgcXVlcnlTdHJpbmcsIGRhdGFUeXBlIH0gPSBqb2IuZGF0YTtcbiAgICBjb25zdCBxdWVyeSA9IEpTT04ucGFyc2UocXVlcnlTdHJpbmcpO1xuICAgIGNvbnN0IGV4dGVuc2lvbiA9IERBVEFUWVBFX0VYVEVOU0lPTlNbZGF0YVR5cGVdXG5cbiAgICBjb25zdCBmaWxlTmFtZSA9IGBHZW5lYm9va19kb3dubG9hZF8ke3F1ZXJ5SGFzaH0uJHtleHRlbnNpb259Lmd6YDtcblxuICAgIGNvbnN0IHdyaXRlU3RyZWFtID0gZnMuY3JlYXRlV3JpdGVTdHJlYW0oZmlsZU5hbWUpO1xuICAgIGNvbnN0IGNvbXByZXNzID0gemxpYi5jcmVhdGVHemlwKCk7XG4gICAgY29tcHJlc3MucGlwZSh3cml0ZVN0cmVhbSk7XG5cbiAgICAvLyB0aGUgZmluaXNoIGV2ZW50IGlzIGVtaXR0ZWQgd2hlbiBhbGwgZGF0YSBoYXMgYmVlbiBmbHVzaGVkIGZyb20gdGhlIHN0cmVhbVxuICAgIGNvbXByZXNzLm9uKCdmaW5pc2gnLCAoKSA9PiB7ICBcbiAgICAgICAgY29uc29sZS5sb2coJ3dyb3RlIGFsbCBkYXRhIHRvIGZpbGUnKTtcbiAgICB9KTtcblxuICAgIEdlbmVzLmZpbmQocXVlcnkpLmZvckVhY2goZ2VuZSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhnZW5lLklEKVxuICAgICAgY29tcHJlc3Mud3JpdGUoZ2VuZS5JRClcbiAgICB9KVxuXG4gICAgLy8gY2xvc2UgdGhlIHN0cmVhbVxuICAgIGNvbXByZXNzLmVuZCgpO1xuXG4gICAgLy9NZXRlb3IuY2FsbCgnaW50ZXJwcm9zY2FuJyxqb2IuZGF0YS5nZW5lSWQpXG4gICAgam9iLmRvbmUoZmlsZU5hbWUpXG4gICAgY2FsbGJhY2soKVxuICB9KVxuXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBqb2JRdWV1ZSBmcm9tICcuL2pvYnF1ZXVlLmpzJztcblxuY29uc3QgcXVldWUgPSBqb2JRdWV1ZS5wcm9jZXNzSm9icyhcbiAgJ2ludGVycHJvc2NhbicsXG4gIHtcbiAgICBjb25jdXJyZW5jeTogNCxcbiAgICBwYXlsb2FkOiAxXG4gIH0sXG4gIGZ1bmN0aW9uKGpvYiwgY2FsbGJhY2spe1xuICAgIGNvbnNvbGUubG9nKGpvYi5kYXRhLmdlbmVJZClcbiAgICAvL01ldGVvci5jYWxsKCdpbnRlcnByb3NjYW4nLGpvYi5kYXRhLmdlbmVJZClcbiAgICBqb2IuZG9uZSgpXG4gICAgY2FsbGJhY2soKVxuICB9KVxuXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBqb2JRdWV1ZSBmcm9tICcuL2pvYnF1ZXVlLmpzJztcbmltcG9ydCAgc3Bhd24gIGZyb20gJ3NwYXduLXByb21pc2UnO1xuXG5pbXBvcnQgeyBHZW5lcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9nZW5lX2NvbGxlY3Rpb24uanMnO1xuaW1wb3J0IHsgVHJhY2tzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2dlbm9tZXMvdHJhY2tfY29sbGVjdGlvbi5qcyc7XG5cbmltcG9ydCB7IGdldEdlbmVTZXF1ZW5jZXMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdXRpbC91dGlsLmpzJztcblxuXG5qb2JRdWV1ZS5wcm9jZXNzSm9icyhcbiAgJ21ha2VCbGFzdERiJyxcbiAge1xuICAgIGNvbmN1cnJlbmN5OiAyLFxuICAgIHBheWxvYWQ6IDFcbiAgfSxcbiAgYXN5bmMgZnVuY3Rpb24oam9iLCBjYWxsYmFjayl7XG4gICAgY29uc29sZS5sb2coJ3Byb2Nlc3NpbmcgbWFrZWJsYXN0ZGInKVxuICAgIGNvbnNvbGUubG9nKGpvYi5kYXRhKVxuICAgIGNvbnN0IHsgdHJhY2tOYW1lLCBkYlR5cGUgfSA9IGpvYi5kYXRhO1xuXG5cbiAgICBjb25zdCB0cmFja0lkID0gdHJhY2tOYW1lLnNwbGl0KC8gfFxcLi8pLmpvaW4oJ18nKVxuXG4gICAgY29uc3QgZ2VuZU51bWJlciA9IEdlbmVzLmZpbmQoeyB0cmFjazogdHJhY2tOYW1lIH0pLmNvdW50KClcbiAgICBjb25zdCBzdGVwU2l6ZSA9IE1hdGgucm91bmQoZ2VuZU51bWJlciAvIDEwKTtcbiAgICBjb25zb2xlLmxvZyhgc2Nhbm5pbmcgJHtnZW5lTnVtYmVyfSBnZW5lc2ApXG4gICAgXG4gICAgXG4gICAgY29uc3QgZmFzdGEgPSBHZW5lcy5maW5kKHsgdHJhY2s6IHRyYWNrTmFtZSB9KS5tYXAoIChnZW5lLCBpbmRleCkgPT4ge1xuXG4gICAgICBpZiAoaW5kZXggJSBzdGVwU2l6ZSA9PT0gMCl7XG4gICAgICAgIGpvYi5wcm9ncmVzcyhpbmRleCwgZ2VuZU51bWJlciwgeyBlY2hvOiB0cnVlIH0pXG4gICAgICB9XG4gICAgICBcbiAgICAgIGxldCB0cmFuc2NyaXB0RmFzdGEgPSBnZXRHZW5lU2VxdWVuY2VzKGdlbmUpLm1hcCh0cmFuc2NyaXB0ID0+IHtcbiAgICAgICAgbGV0IHNlcXVlbmNlID0gZGJUeXBlID09PSAncHJvdCcgPyB0cmFuc2NyaXB0LnBlcCA6IHRyYW5zY3JpcHQuc2VxXG4gICAgICAgIC8va2VlcCB0cmFjayBvZiBnZW5lIElEIGFuZCB0cmFuc2NyaXB0IElEIGZvciBsYXRlciBwcm9jZXNzaW5nXG4gICAgICAgIHJldHVybiBgPiR7Z2VuZS5JRH0gJHt0cmFuc2NyaXB0LklEfVxcbiR7c2VxdWVuY2V9YFxuICAgICAgfSkuam9pbignXFxuJylcbiAgICAgIHJldHVybiB0cmFuc2NyaXB0RmFzdGFcbiAgICB9KS5qb2luKCdcXG4nKVxuICAgIFxuICAgIGNvbnN0IG91dEZpbGUgPSBgJHt0cmFja0lkfS4ke2RiVHlwZX1gXG4gICAgY29uc3Qgb3B0aW9ucyA9IFsnLWRidHlwZScsIGRiVHlwZSwgJy10aXRsZScsIHRyYWNrSWQsICctb3V0Jywgb3V0RmlsZV07XG4gICAgY29uc29sZS5sb2cob3B0aW9ucylcblxuICAgIGNvbnN0IGRiRmlsZSA9ICBhd2FpdCBzcGF3bignbWFrZWJsYXN0ZGInLCBvcHRpb25zLCBmYXN0YSlcbiAgICAgIC50aGVuKCByZXN1bHQgPT4ge1xuICAgICAgICBsZXQgc3Rkb3V0ID0gcmVzdWx0LnRvU3RyaW5nKCk7XG4gICAgICAgIGlmIChzdGRvdXQpe1xuICAgICAgICAgIGNvbnNvbGUubG9nKGBtYWtlYmxhc3RkYiBzdGRvdXQ6JHtzdGRvdXR9YClcbiAgICAgICAgfVxuXG4gICAgICAgIFRyYWNrcy5maW5kQW5kTW9kaWZ5KHtcbiAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgdHJhY2tOYW1lOiB0cmFja05hbWUgXG4gICAgICAgICAgfSxcbiAgICAgICAgICB1cGRhdGU6IHsgXG4gICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgIFtgYmxhc3RkYnMuJHtkYlR5cGV9YF06IGAke3RyYWNrSWR9LiR7ZGJUeXBlfWAgXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBcbiAgICAgICAgfSlcbiAgICAgICAgcmV0dXJuIGAke3RyYWNrSWR9LiR7ZGJUeXBlfWAgXG4gICAgICB9KS5jYXRjaChlcnJvciA9PiB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpXG4gICAgICB9KVxuICAgIGNvbnNvbGUubG9nKGAke2RiRmlsZX0gZG9uZWApXG4gICAgXG4gICAgam9iLmRvbmUoZGJGaWxlKVxuICAgIGNhbGxiYWNrKClcbiAgfVxuKVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5cbmltcG9ydCB7IFRyYWNrcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5vbWVzL3RyYWNrX2NvbGxlY3Rpb24uanMnO1xuXG5cbk1ldGVvci5tZXRob2RzKHtcblx0bGlzdDogZnVuY3Rpb24od2hhdCl7XG5cdFx0aWYgKCEgdGhpcy51c2VySWQpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG5cdFx0fVxuXHRcdGlmICghIFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwnY3VyYXRvcicpKXtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG5cdFx0fVxuXHRcdGxldCByZXR2YWw7XG5cdFx0c3dpdGNoKCB3aGF0ICl7XG5cdFx0XHRjYXNlICd0cmFja3MnOlxuXHRcdFx0XHRyZXR2YWwgPSBUcmFja3MuZmluZCh7fSx7IGZpZWxkczogeyBfaWQ6IDB9fSkuZmV0Y2goKTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRjYXNlICdyZWZlcmVuY2VzJzpcblx0XHRcdFx0cmV0dmFsID0gUmVmZXJlbmNlcy5maW5kKFxuXHRcdFx0XHRcdHt9LFxuXHRcdFx0XHRcdHsgZmllbGRzOiB7IF9pZDogMCwgcmVmZXJlbmNlOiAxIH19XG5cdFx0XHRcdFx0KS5mZXRjaCgpLm1hcChmdW5jdGlvbihyZXQpe1xuXHRcdFx0XHRcdFx0cmV0dXJuIHJldC5yZWZlcmVuY2Vcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRkZWZhdWx0OlxuXHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdDYW4gbm90IGxpc3Q6ICcgKyB3aGF0KSBcblx0XHR9XG5cdFx0cmV0dXJuIFsuLi5uZXcgU2V0KHJldHZhbCldO1xuXHR9XG59KSIsImltcG9ydCB7IHNwYXduIH0gZnJvbSAnY2hpbGRfcHJvY2Vzcyc7XG5pbXBvcnQgRnV0dXJlIGZyb20gJ2ZpYmVycy9mdXR1cmUnO1xuXG5pbXBvcnQgeyBHZW5lcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9nZW5lX2NvbGxlY3Rpb24uanMnO1xuaW1wb3J0IHsgQXR0cmlidXRlcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9hdHRyaWJ1dGVfY29sbGVjdGlvbi5qcyc7XG5pbXBvcnQgeyBFZGl0SGlzdG9yeSB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9lZGl0aGlzdG9yeV9jb2xsZWN0aW9uLmpzJztcblxuaW1wb3J0IHsgcmV2ZXJzZUNvbXBsZW1lbnQsIHRyYW5zbGF0ZSwgZ2V0R2VuZVNlcXVlbmNlcyB9IGZyb20gJy9pbXBvcnRzL2FwaS91dGlsL3V0aWwuanMnO1xuXG5pbXBvcnQgaGFzaCBmcm9tICdvYmplY3QtaGFzaCc7XG5cblxuXG5NZXRlb3IubWV0aG9kcyh7XG5cdC8qKlxuXHQgKiBbZm9ybWF0RmFzdGEgZGVzY3JpcHRpb25dXG5cdCAqIEBwYXJhbSAge1tPYmplY3RdfSBxdWVyeSAgICAgICAgW0RhdGFiYXNlIHF1ZXJ5IHRvIHNlbGVjdCBnZW5lc11cblx0ICogQHBhcmFtICB7W1N0cmluZ119IHNlcXVlbmNlVHlwZSBbT25lIG9mICdwcm90ZWluJyBvciAnbnVjbGVvdGlkZSddXG5cdCAqIEByZXR1cm4ge1tBcnJheV19ICAgICAgICAgICAgICAgW0FycmF5IG9mIGZhc3RhIGZvcm1hdHRlZCBjb2Rpbmcgc2VxdWVuY2VzXVxuXHQgKi9cblx0Zm9ybWF0RmFzdGEgKHF1ZXJ5LCBzZXF1ZW5jZVR5cGUpe1xuXHRcdGlmICghIHRoaXMudXNlcklkKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblx0XHRjb25zb2xlLmxvZygnZm9ybWF0RmFzdGEnKVxuXHRcdGNvbnNvbGUubG9nKHF1ZXJ5KVxuXG5cdFx0Y29uc3QgZmFzdGEgPSBHZW5lcy5maW5kKHF1ZXJ5KS5tYXAoIChnZW5lLCBpbmRleCkgPT4ge1xuICAgICAgY29uc3QgdHJhbnNjcmlwdEZhc3RhID0gZ2V0R2VuZVNlcXVlbmNlcyhnZW5lKS5tYXAodHJhbnNjcmlwdCA9PiB7XG4gICAgICAgIGNvbnN0IHNlcXVlbmNlID0gc2VxdWVuY2VUeXBlID09PSAncHJvdGVpbicgPyB0cmFuc2NyaXB0LnBlcCA6IHRyYW5zY3JpcHQuc2VxO1xuICAgICAgICBjb25zdCB3cmFwcGVkU2VxdWVuY2UgPSBzZXF1ZW5jZS5tYXRjaCgvLnsxLDYwfS9nKS5qb2luKCdcXG4nKTtcbiAgICAgICAgcmV0dXJuIGA+JHt0cmFuc2NyaXB0LklEfVxcbiR7d3JhcHBlZFNlcXVlbmNlfVxcbmBcbiAgICAgIH0pLmpvaW4oJycpXG4gICAgICByZXR1cm4gdHJhbnNjcmlwdEZhc3RhXG4gICAgfSlcblxuXHRcdHJldHVybiBmYXN0YVxuXHR9LFxuXHRxdWVyeUNvdW50IChzZWFyY2gscXVlcnkpe1xuXHRcdGlmICghIHRoaXMudXNlcklkKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblx0XHRpZiAoISBSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsJ2N1cmF0b3InKSl7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblx0XHRpZiAoc2VhcmNoKSB7XG5cdFx0XHRxdWVyeS4kb3IgPSBbeyAnSUQnOiB7ICRyZWdleDogc2VhcmNoICwgJG9wdGlvbnM6ICdpJyB9IH0seyAnTmFtZSc6IHsgJHJlZ2V4OiBzZWFyY2ggLCAkb3B0aW9uczogJ2knIH0gfV07XG5cdFx0XHRpZiAoIXF1ZXJ5Lmhhc093blByb3BlcnR5KCdQcm9kdWN0bmFtZScpKXtcblx0XHRcdFx0cXVlcnkuJG9yLnB1c2goeyAnUHJvZHVjdG5hbWUnOiB7ICRyZWdleDogc2VhcmNoICwgJG9wdGlvbnM6ICdpJyB9IH0pXG5cdFx0XHR9XG5cdFx0fVxuXHRcdGNvbnN0IGNvdW50ID0gR2VuZXMuZmluZChxdWVyeSkuY291bnQoKVxuXHRcdHJldHVybiBjb3VudFxuXHR9LFxuXHRyZW1vdmVGcm9tVmlld2luZyAoZ2VuZUlkKXtcblx0XHRpZiAoISB0aGlzLnVzZXJJZCkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcblx0XHR9XG5cdFx0R2VuZXMudXBkYXRlKHsgJ0lEJzogZ2VuZUlkIH0seyAkcHVsbDogeyAndmlld2luZyc6IHRoaXMudXNlcklkIH0gfSwgKGVycixyZXMpID0+IHtcblx0XHRcdGlmIChlcnIpIHtcblx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcigncmVtb3ZlRnJvbVZpZXdpbmcgc2VydmVyIG1ldGhvZCBlcnJvcicpXG5cdFx0XHR9XG5cdFx0XHRjb25zdCBnZW5lID0gR2VuZXMuZmluZE9uZSh7J0lEJzogZ2VuZUlkfSlcblx0XHRcdGNvbnNvbGUubG9nKGdlbmUpXG5cdFx0XHQvL2lmICggdmlld2luZy5sZW5ndGggPT09IDAgKXtcblx0XHRcdFx0Ly9HZW5lcy51cGRhdGUoeyAnSUQnOiBnZW5lSWQgfSx7ICR1bnNldDogeyAndmlld2luZyc6IDEgfSB9IClcblx0XHRcdC8vfSBcblx0XHR9KVxuXHRcdFxuXHR9LFxuXHQvKipcblx0ICogQmxvY2sgYSBnZW5lIGZyb20gYmVpbmcgZWRpdGVkLCB0aGlzIHNob3VsZCBoYXBwZW4gd2hlbiBzb21lb25lIGlzIGVkaXRpbmcgYSBnZW5lIHRvIHByZXZlbnQgc2ltdWx0YW5lb3VzIGVkaXRzXG5cdCAqIEBwYXJhbSAge1t0eXBlXX1cblx0ICogQHJldHVybiB7W3R5cGVdfVxuXHQgKi9cblx0bG9ja0dlbmUgKGdlbmVJZCkge1xuXHRcdGlmICghIHRoaXMudXNlcklkKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblx0XHRpZiAoISBSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsJ2N1cmF0b3InKSl7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblx0XHRHZW5lcy51cGRhdGUoeyAnSUQnOiBnZW5lSWQgfSx7ICRzZXQ6IHsgZWRpdGluZzogdGhpcy51c2VySWQgfSB9LCAoZXJyLHJlcykgPT4ge1xuXHRcdFx0aWYgKGVycil7XG5cdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ0xvY2tpbmcgZ2VuZSBmYWlsZWQnKVxuXHRcdFx0fVxuXHRcdFx0Y29uc29sZS5sb2coYCR7dGhpcy51c2VySWR9IGlzIGVkaXRpbmcgZ2VuZSAke2dlbmVJZH1gKVxuXHRcdH0pXG5cdH0sXG5cdC8qKlxuXHQgKiBUaGlzIHVubG9ja3MgYSBnZW5lIGZyb20gYmVpbmcgYmxvY2tlZCBkdXJpbmcgZWRpdGluZy4gXG5cdCAqIEEgZ2VuZSBzaG91bGQgb25seSBiZSB1bmxvY2tlZCBieSB0aGUgcGVyc29uIHRoYXQgbG9ja2VkIGl0XG5cdCAqIEBwYXJhbSAge1t0eXBlXX1cblx0ICogQHJldHVybiB7W3R5cGVdfVxuXHQgKi9cblx0dW5sb2NrR2VuZSAoZ2VuZUlkKSB7XG5cdFx0aWYgKCEgdGhpcy51c2VySWQpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG5cdFx0fVxuXHRcdGlmICghIFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwnY3VyYXRvcicpKXtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG5cdFx0fVxuXHRcdGNvbnN0IGdlbmUgPSBHZW5lcy5maW5kT25lKHsgSUQ6IGdlbmVJZCB9KVxuXHRcdGlmICghZ2VuZSl7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpXG5cdFx0fVxuXG5cdFx0aWYgKCFnZW5lLmVkaXRpbmcpe1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKVxuXHRcdH1cblxuXHRcdGlmICghKGdlbmUuZWRpdGluZyA9PT0gdGhpcy51c2VySWQpKXtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJylcblx0XHR9XG5cblx0XHRjb25zb2xlLmxvZygnYWxsb3cgdW5sb2NrID09PScsZ2VuZS5lZGl0aW5nID09PSB0aGlzLnVzZXJJZClcblx0XHRpZiAoZ2VuZS5lZGl0aW5nID09PSB0aGlzLnVzZXJJZCl7XG5cdFx0XHRjb25zb2xlLmxvZyhgJHt0aGlzLnVzZXJJZH0gaXMgbm8gbG9uZ2VyIGVkaXRpbmcgZ2VuZSAke2dlbmVJZH1gKVxuXHRcdFx0R2VuZXMudXBkYXRlKHsgSUQ6IGdlbmVJZH0sIHsgJHNldDogeyBlZGl0aW5nOiAnVW5sb2NraW5nJyB9IH0sIChlcnIscmVzKSA9PiB7XG5cdFx0XHRcdGlmIChlcnIpe1xuXHRcdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ1VubG9ja2luZyBmYWlsZWQnKVxuXHRcdFx0XHR9XG5cdFx0XHRcdEdlbmVzLnVwZGF0ZSh7IElEOiBnZW5lSWQgfSx7ICR1bnNldDogeyBlZGl0aW5nOiAxIH0gfSlcblx0XHRcdH0gKVxuXHRcdH1cblx0fVxufSlcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXHR1cGRhdGVFeHBlcmltZW50cyAoX2lkLGZpZWxkcyl7XG5cdFx0aWYgKCEgdGhpcy51c2VySWQpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG5cdFx0fTtcblx0XHRpZiAoISBSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsJ2FkbWluJykpe1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcblx0XHR9XG5cdFx0RXhwZXJpbWVudHMudXBkYXRlKHsnX2lkJzpfaWR9LHskc2V0OmZpZWxkc30pO1xuXHR9LFxuXHQgdXBkYXRlVXNlcnMgKF9pZCxmaWVsZHMpe1xuXHRcdGlmICghIHRoaXMudXNlcklkKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblx0XHRNZXRlb3IudXNlcnMudXBkYXRlKHsnX2lkJzpfaWR9LHskc2V0OmZpZWxkc30pXG5cdH0sXG5cdHVwZGF0ZUdlbmVJbmZvIChnZW5lSWQsdXBkYXRlLHJldmVydCl7XG5cdFx0Y29uc3QgdXNlcklkID0gdGhpcy51c2VySWQ7XG5cdFx0aWYgKCEgdXNlcklkKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblx0XHRpZiAoISBSb2xlcy51c2VySXNJblJvbGUodXNlcklkLCdjdXJhdG9yJykpe1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcblx0XHR9XG5cdFx0Y29uc29sZS5sb2coYFVwZGF0aW5nIGdlbmUgJHtnZW5lSWR9YClcblx0XHRjb25zb2xlLmxvZygnVXBkYXRlOicsdXBkYXRlKVxuXHRcdGNvbnNvbGUubG9nKCdSZXZlcnQ6JyxyZXZlcnQpXG5cblx0XHRsZXQgbmV3QXR0cmlidXRlcyA9IFtdO1xuXG5cdFx0aWYgKHVwZGF0ZS5oYXNPd25Qcm9wZXJ0eSgnJHNldCcpKXtcblx0XHRcdG5ld0F0dHJpYnV0ZXMgPSBPYmplY3Qua2V5cyh1cGRhdGVbJyRzZXQnXSkuZmlsdGVyKCBrZXkgPT4ge1xuXHRcdFx0XHRyZXR1cm4ga2V5LnN0YXJ0c1dpdGgoJ2F0dHJpYnV0ZXMuJylcblx0XHRcdH0pLm1hcCgga2V5ID0+IHtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRxdWVyeToga2V5LFxuXHRcdFx0XHRcdG5hbWU6IGtleS5yZXBsYWNlKCdhdHRyaWJ1dGVzLicsJycpXG5cdFx0XHRcdH1cblx0XHRcdH0pXG5cdFx0fVxuXHRcdFx0XG5cdFx0Y29uc29sZS5sb2coJ05ldyBhdHRyaWJ1dGVzOicsIG5ld0F0dHJpYnV0ZXMpXG5cblx0XHRjb25zdCByZXZlcnRTdHJpbmcgPSBKU09OLnN0cmluZ2lmeShyZXZlcnQpO1xuXG5cdFx0Y29uc3QgZ2VuZSA9IEdlbmVzLmZpbmRPbmUoe0lEOiBnZW5lSWR9KVxuXG5cdFx0R2VuZXMudXBkYXRlKHsgSUQ6IGdlbmVJZCB9LCB1cGRhdGUsIChlcnIscmVzKSA9PiB7XG5cdFx0XHRpZiAoIWVycil7XG5cdFx0XHRcdEVkaXRIaXN0b3J5Lmluc2VydCh7IFxuXHRcdFx0XHRcdElEOiBnZW5lSWQsIFxuXHRcdFx0XHRcdGRhdGU6IG5ldyBEYXRlKCksIFxuXHRcdFx0XHRcdHVzZXI6IHVzZXJJZCwgXG5cdFx0XHRcdFx0cmV2ZXJ0OiByZXZlcnRTdHJpbmdcblx0XHRcdFx0fSlcblx0XHRcdFx0bmV3QXR0cmlidXRlcy5mb3JFYWNoKCBuZXdBdHRyaWJ1dGUgPT4ge1xuXHRcdFx0XHRcdEF0dHJpYnV0ZXMuZmluZEFuZE1vZGlmeSh7XG5cdFx0XHRcdFx0XHRxdWVyeToge1xuXHRcdFx0XHRcdFx0XHRuYW1lOiBuZXdBdHRyaWJ1dGUubmFtZVxuXHRcdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRcdHVwZGF0ZToge1xuXHRcdFx0XHRcdFx0XHQkc2V0T25JbnNlcnQ6IHtcblx0XHRcdFx0XHRcdFx0XHRuYW1lOiBuZXdBdHRyaWJ1dGUubmFtZSxcblx0XHRcdFx0XHRcdFx0XHRxdWVyeTogbmV3QXR0cmlidXRlLnF1ZXJ5LFxuXHRcdFx0XHRcdFx0XHRcdHNob3c6IHRydWUsXG5cdFx0XHRcdFx0XHRcdFx0cmVzZXJ2ZWQ6IGZhbHNlLFxuXHRcdFx0XHRcdFx0XHRcdGNhbkVkaXQ6IGZhbHNlXG5cdFx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0XHRcdCRwdXNoOiB7XG5cdFx0XHRcdFx0XHRcdFx0cmVmZXJlbmNlczogZ2VuZS5yZWZlcmVuY2UsXG5cdFx0XHRcdFx0XHRcdFx0dHJhY2tzOiBnZW5lLnRyYWNrXG5cdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0XHR1cHNlcnQ6IHRydWUsXG5cdFx0XHRcdFx0XHRuZXc6IHRydWVcblx0XHRcdFx0XHR9KVxuXHRcdFx0XHR9KVxuXHRcdFx0fVxuXHRcdH0pXG5cdH0sXG5cdHVwZGF0ZUF0dHJpYnV0ZXMgKF9pZCxmaWVsZHMpe1xuXHRcdGlmICghIHRoaXMudXNlcklkKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblx0XHRpZiAoISBSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsJ2FkbWluJykpe1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcblx0XHR9XG5cdFx0QXR0cmlidXRlcy51cGRhdGUoeydfaWQnOl9pZH0seyRzZXQ6ZmllbGRzfSlcblx0fSxcblx0LyoqXG5cdCAqIFtmb3JtYXRHZmYzIGRlc2NyaXB0aW9uXVxuXHQgKiBAcGFyYW0gIHtbT2JqZWN0XX0gcXVlcnkgW2Rlc2NyaXB0aW9uXVxuXHQgKiBAcmV0dXJuIHtbQXJyYXldfSAgICAgICAgW0FycmF5IHdpdGggZ2ZmMyBmb3JtYXR0ZWQgXVxuXHQgKi9cblx0Zm9ybWF0R2ZmMyAocXVlcnkpe1xuXHRcdGlmICghIHRoaXMudXNlcklkKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblx0XHRcblx0XHRjb25zdCBnZW5lcyA9IEdlbmVzLmZpbmQocXVlcnkpXG5cdFx0Y29uc3QgdG90YWwgPSBnZW5lcy5jb3VudCgpO1xuXHRcdGxldCBjb3VudGVyID0gMDtcblx0XHRjb25zdCBnZmYgPSBnZW5lcy5tYXAoZnVuY3Rpb24oZ2VuZSl7XG5cdFx0XHRjb3VudGVyICs9IDE7XG5cdFx0XHRsZXQgc3ViTGluZXMgPSBnZW5lLnN1YmZlYXR1cmVzLm1hcChmdW5jdGlvbihzdWIpe1xuXHRcdFx0XHRsZXQgc3ViRmllbGRzID0gW1xuXHRcdFx0XHRcdGdlbmUuc2VxaWQsXG5cdFx0XHRcdFx0Z2VuZS5zb3VyY2UsXG5cdFx0XHRcdFx0c3ViLnR5cGUsXG5cdFx0XHRcdFx0c3ViLnN0YXJ0LFxuXHRcdFx0XHRcdHN1Yi5lbmQsXG5cdFx0XHRcdFx0c3ViLnNjb3JlLFxuXHRcdFx0XHRcdGdlbmUuc3RyYW5kLFxuXHRcdFx0XHRcdHN1Yi5waGFzZSxcblx0XHRcdFx0XHQnSUQ9JytzdWIuSUQrJztQYXJlbnRzPScrc3ViLnBhcmVudHMuam9pbigpXG5cdFx0XHRcdF1cblx0XHRcdFx0cmV0dXJuIHN1YkZpZWxkcy5qb2luKCdcXHQnKSArICdcXG4nO1xuXHRcdFx0fSlcblx0XHRcdGxldCBnZW5lRmllbGRzID0gW1xuXHRcdFx0XHRnZW5lLnNlcWlkLFxuXHRcdFx0XHRnZW5lLnNvdXJjZSxcblx0XHRcdFx0Z2VuZS50eXBlLFxuXHRcdFx0XHRnZW5lLnN0YXJ0LFxuXHRcdFx0XHRnZW5lLmVuZCxcblx0XHRcdFx0Z2VuZS5zY29yZSxcblx0XHRcdFx0Z2VuZS5zdHJhbmQsXG5cdFx0XHRcdGdlbmUucGhhc2UsXG5cdFx0XHRcdCdJRD0nK2dlbmUuSURcblx0XHRcdF1cblx0XHRcdGxldCBnZW5lTGluZSA9IGdlbmVGaWVsZHMuam9pbignXFx0JykgKyAnXFxuJztcblx0XHRcdFxuXHRcdFx0Ly91bnNoaWZ0IGFkZHMgdG8gdGhlIGJlZ2lubmluZyBvZiB0aGUgYXJyYXlcblx0XHRcdHN1YkxpbmVzLnVuc2hpZnQoZ2VuZUxpbmUpO1xuXG5cdFx0XHRyZXR1cm4gc3ViTGluZXMuam9pbignJylcblx0XHR9KVxuXHRcdHJldHVybiBnZmZcblx0fSxcblx0aW5pdGlhbGl6ZURvd25sb2FkIChxdWVyeSxmb3JtYXQpe1xuXHRcdHF1ZXJ5SGFzaCA9IGhhc2gocXVlcnkpO1xuXHRcdHF1ZXJ5U3RyaW5nID0gSlNPTi5zdHJpbmdpZnkocXVlcnkpO1xuXHRcdGV4aXN0aW5nID0gRG93bmxvYWRzLmZpbmRPbmUoe3F1ZXJ5OnF1ZXJ5SGFzaCxmb3JtYXQ6Zm9ybWF0fSlcblx0XHRsZXQgZG93bmxvYWRJZDtcblx0XHRpZiAoZXhpc3RpbmcgPT09IHVuZGVmaW5lZCl7XG5cdFx0XHRkb3dubG9hZElkID0gRG93bmxvYWRzLmluc2VydCh7cXVlcnk6cXVlcnlIYXNoLHF1ZXJ5U3RyaW5nOnF1ZXJ5U3RyaW5nLGZvcm1hdDpmb3JtYXR9KVxuXHRcdFx0Ly9yZXR1cm4gZG93bmxvYWRJZFxuXHRcdH0gZWxzZSB7XG5cdFx0XHRkb3dubG9hZElkID0gZXhpc3RpbmcuX2lkXG5cdFx0XHQvL3JldHVybiBleGlzdGluZy5faWRcblx0XHR9XG5cdH1cbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5cbmltcG9ydCBhc3NlcnQgZnJvbSAnYXNzZXJ0JztcbmltcG9ydCBCYWJ5IGZyb20gJ2JhYnlwYXJzZSc7XG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xuXG5pbXBvcnQgeyBUcmFja3MgfSBmcm9tICcvaW1wb3J0cy9hcGkvZ2Vub21lcy90cmFja19jb2xsZWN0aW9uLmpzJztcbmltcG9ydCB7IEdlbmVzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2dlbmVzL2dlbmVfY29sbGVjdGlvbi5qcyc7XG5pbXBvcnQgeyBFeHBlcmltZW50SW5mbywgVHJhbnNjcmlwdG9tZXMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdHJhbnNjcmlwdG9tZXMvdHJhbnNjcmlwdG9tZV9jb2xsZWN0aW9uLmpzJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXHRhZGRUcmFuc2NyaXB0b21lKGNvbmZpZyl7XG5cdFx0Y29uc29sZS5sb2coJ3RyeWluZyB0byBpbnNlcnQnLGNvbmZpZylcdFxuXHRcdGlmICghIHRoaXMudXNlcklkKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblx0XHRpZiAoISBSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsJ2N1cmF0b3InKSl7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblxuXHRcdGNvbnN0IGV4aXN0aW5nVHJhY2sgPSBUcmFja3MuZmluZCh7IHRyYWNrTmFtZTogY29uZmlnLnRyYWNrTmFtZSB9KS5mZXRjaCgpLmxlbmd0aFxuXHRcdGlmICghZXhpc3RpbmdUcmFjayl7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKGBUcmFjayBkb2VzIG5vdCBleGlzdDogJHtjb25maWcudHJhY2tOYW1lfWApO1xuXHRcdH1cblxuXHRcdGNvbnN0IGZpbGVIYW5kbGUgPSBmcy5yZWFkRmlsZVN5bmMoY29uZmlnLmZpbGVOYW1lLCB7IGVuY29kaW5nOiAnYmluYXJ5JyB9KTtcblxuXHRcdGNvbnNvbGUubG9nKGBTdGFydCByZWFkaW5nICR7Y29uZmlnLmZpbGVOYW1lfWApXG5cblx0XHRCYWJ5LnBhcnNlKGZpbGVIYW5kbGUsIHtcblx0XHRcdGRlbGltaXRlcjogJ1xcdCcsXG5cdFx0XHRkeW5hbWljVHlwaW5nOiB0cnVlLFxuXHRcdFx0c2tpcEVtcHR5TGluZXM6IHRydWUsXG5cdFx0XHRjb21tZW50czogJyMnLFxuXHRcdFx0aGVhZGVyOiB0cnVlLFxuXHRcdFx0ZXJyb3IoZXJyb3IsZmlsZSkge1xuXHRcdFx0XHRjb25zb2xlLmxvZyhlcnJvcilcblx0XHRcdH0sXG5cdFx0XHRjb21wbGV0ZShyZXN1bHRzLGZpbGUpIHtcblx0XHRcdFx0Y29uc3QgbWlzc2luZ0dlbmVzID0gbmV3IFNldCgpO1xuXHRcdFx0XHRjb25zdCB0cmFja3MgPSBuZXcgU2V0KCk7XG5cblx0XHRcdFx0Y29uc29sZS5sb2coJ1JlYWRpbmcgZmluaXNoZWQsIHN0YXJ0IHZhbGlkYXRpbmcnKVxuXG5cdFx0XHRcdHJlc3VsdHMuZGF0YS5mb3JFYWNoKHJlc3VsdCA9PiB7XG5cdFx0XHRcdFx0Y29uc3QgZ2VuZSA9IEdlbmVzLmZpbmRPbmUoe0lEOiByZXN1bHQudGFyZ2V0X2lkfSk7XG5cdFx0XHRcdFx0aWYgKGdlbmUgPT09IHVuZGVmaW5lZCl7XG5cdFx0XHRcdFx0XHRtaXNzaW5nR2VuZXMuYWRkKHJlc3VsdC50YXJnZXRfaWQpXG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdHRyYWNrcy5hZGQoZ2VuZS50cmFjaylcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0pXG5cblx0XHRcdFx0aWYgKG1pc3NpbmdHZW5lcy5zaXplID4gMCl7XG5cdFx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihgJHttaXNzaW5nR2VuZXMubGVuZ3RofSBnZW5lcyBjb3VsZCBub3QgYmUgZm91bmRgKVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0aWYgKHRyYWNrcy5zaXplID4gMSl7XG5cdFx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcihgR2VuZSBJRHMgYXJlIGxpbmtlZCB0byBtb3JlIHRoYW4gb25lIHRyYWNrOiAke0FycmF5LmZyb20odHJhY2tzKX1gKVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0Y29uc29sZS5sb2coJ1ZhbGlkYXRpb24gZmluaXNoZWQsIHN0YXJ0IGluc2VydGluZyBleHBlcmltZW50IGluZm8nKVxuXHRcdFx0XHRjb25zdCBleHBlcmltZW50SWQgPSBFeHBlcmltZW50SW5mby5pbnNlcnQoe1xuXHRcdFx0XHRcdHRyYWNrOiBjb25maWcudHJhY2tOYW1lLFxuXHRcdFx0XHRcdHNhbXBsZU5hbWU6IGNvbmZpZy5zYW1wbGVOYW1lLFxuXHRcdFx0XHRcdGV4cGVyaW1lbnRHcm91cDogY29uZmlnLmV4cGVyaW1lbnRHcm91cCxcblx0XHRcdFx0XHRyZXBsaWNhR3JvdXA6IGNvbmZpZy5yZXBsaWNhR3JvdXAsXG5cdFx0XHRcdFx0ZGVzY3JpcHRpb246IGNvbmZpZy5kZXNjcmlwdGlvbixcblx0XHRcdFx0XHRwZXJtaXNzaW9uczogWydhZG1pbiddLFxuXHRcdFx0XHR9KVxuXG5cdFx0XHRcdC8qXG5cdFx0XHRcdGZvcm1hdHRlZFJlc3VsdHMgPSByZXN1bHRzLm1hcChyZXN1bHQgPT4ge1xuXHRcdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0XHRnZW5lSWQ6IHJlc3VsdC50YXJnZXRfaWQsXG5cdFx0XHRcdFx0XHRleHBlcmltZW50SWQ6IGV4cGVyaW1lbnRJZCxcblx0XHRcdFx0XHRcdHBlcm1pc3Npb25zOiBbJ2FkbWluJ10sXG5cdFx0XHRcdFx0XHRyYXdfY291bnRzOiByZXN1bHQuZXN0X2NvdW50cyxcblx0XHRcdFx0XHRcdHRwbTogcmVzdWx0LnRwbVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSlcblx0XHRcdFx0Ki9cblx0XHRcdFx0Y29uc29sZS5sb2coJ1N0YXJ0IGluc2VydGluZyBleHByZXNzaW9uIGRhdGEnKVxuXHRcdFx0XHRyZXN1bHRzLmRhdGEuZm9yRWFjaCggKGdlbmUpID0+IHtcblx0XHRcdFx0XHRUcmFuc2NyaXB0b21lcy5pbnNlcnQoe1xuXHRcdFx0XHRcdFx0Z2VuZUlkOiBnZW5lLnRhcmdldF9pZCxcblx0XHRcdFx0XHRcdGV4cGVyaW1lbnRJZDogZXhwZXJpbWVudElkLFxuXHRcdFx0XHRcdFx0cGVybWlzc2lvbnM6IFsnYWRtaW4nXSxcblx0XHRcdFx0XHRcdHJhd19jb3VudHM6IGdlbmUuZXN0X2NvdW50cyxcblx0XHRcdFx0XHRcdHRwbTogZ2VuZS50cG1cblx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFxuXHRcdFx0XHR9KVxuXHRcdFx0XHRcblxuXHRcdFx0fVxuXHRcdH0pXG5cdFx0cmV0dXJuIGBTdWNjZXNmdWxseSBpbnNlcnRlZCAke2NvbmZpZy5zYW1wbGVOYW1lfWBcblx0fVxufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5cbmNvbnN0IEV4cGVyaW1lbnRJbmZvID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2V4cGVyaW1lbnRzJyk7XG5cbmNvbnN0IEV4cGVyaW1lbnRJbmZvU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG5cdHNhbXBsZU5hbWU6IHtcblx0XHR0eXBlOiBTdHJpbmcsXG5cdFx0bGFiZWw6ICdTaG9ydCBuYW1lIGZvciB0aGUgc2FtcGxlJyxcblx0fSxcblx0ZXhwZXJpbWVudEdyb3VwOiB7XG5cdFx0dHlwZTogU3RyaW5nLFxuXHRcdGxhYmVsOiAnSWRlbnRpZmllciB0byBncm91cCB0b2dldGhlciBzYW1wbGVzIGZyb20gdGhlIHNhbWUgZXhwZXJpbWVudCdcblx0fSxcblx0cmVwbGljYUdyb3VwOiB7XG5cdFx0dHlwZTogU3RyaW5nLFxuXHRcdGxhYmVsOiAnSWRlbnRpZmllciB0byBncm91cCB0b2dldGhlciBzYW1wbGVzIGZyb20gdGhlIHNhbWUgcmVwbGljYSdcblx0fSxcblx0dHJhY2s6IHtcblx0XHR0eXBlOiBTdHJpbmcsXG5cdFx0bGFiZWw6ICdBbm5vdGF0aW9uIHRyYWNrIHRvIHdoaWNoIHRoZSB0cmFuc2NyaXB0b21lIGlzIG1hcHBlZCdcblx0fSxcblx0ZGVzY3JpcHRpb246IHtcblx0XHR0eXBlOiBTdHJpbmcsXG5cdFx0bGFiZWw6ICdFeHBlcmltZW50IGRlc2NyaXB0aW9uJ1xuXHR9LFxuXHRwZXJtaXNzaW9uczoge1xuXHRcdHR5cGU6IEFycmF5LFxuXHRcdGxhYmVsOiAnVXNlciBncm91cHMgdGhhdCBjYW4gYWNjZXNzIHRoaXMgZXhwZXJpbWVudCdcblx0fSxcblx0J3Blcm1pc3Npb25zLiQnOiB7XG5cdFx0dHlwZTogU3RyaW5nXG5cdH1cbn0pXG5cbkV4cGVyaW1lbnRJbmZvLmF0dGFjaFNjaGVtYShFeHBlcmltZW50SW5mb1NjaGVtYSk7XG5cbmNvbnN0IFRyYW5zY3JpcHRvbWVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3RyYW5zY3JpcHRvbWVzJyk7XG5cbmNvbnN0IFRyYW5zY3JpcHRvbWVTY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcblx0Z2VuZUlkOiB7XG5cdFx0dHlwZTogU3RyaW5nLFxuXHRcdGxhYmVsOiAnR2VuZSBJRCcsXG5cdFx0Ly9pbmRleDogdHJ1ZVxuXHR9LFxuXHRleHBlcmltZW50SWQ6IHtcblx0XHR0eXBlOiBTdHJpbmcsXG5cdFx0bGFiZWw6ICdFeHBlcmltZW50IElEJyxcblx0XHQvL2luZGV4OiB0cnVlXG5cdH0sXG5cdHBlcm1pc3Npb25zOntcblx0XHR0eXBlOiBBcnJheSwvL1tTdHJpbmddLFxuXHRcdGxhYmVsOiAnVXNlciBncm91cHMgdGhhdCBjYW4gYWNjZXNzIHRoaXMgZXhwZXJpbWVudCdcblx0fSxcblx0J3Blcm1pc3Npb25zLiQnOiB7XG5cdFx0dHlwZTogU3RyaW5nXG5cdH0sXG5cdHJhd19jb3VudHM6IHtcblx0XHR0eXBlOiBOdW1iZXIsXG5cdFx0Ly9kZWNpbWFsOiB0cnVlLFxuXHRcdGxhYmVsOiAnUmF3IHJlYWQgY291bnRzJ1xuXHR9LFxuXHR0cG06IHtcblx0XHR0eXBlOiBOdW1iZXIsXG5cdFx0Ly9kZWNpbWFsOiB0cnVlLFxuXHRcdGxhYmVsOiAnVFBNIG5vcm1hbGl6ZWQgcmVhZCBjb3VudHMnXG5cdH1cbn0pXG5cblRyYW5zY3JpcHRvbWVzLmF0dGFjaFNjaGVtYShUcmFuc2NyaXB0b21lU2NoZW1hKVxuXG5leHBvcnQgeyBFeHBlcmltZW50SW5mbywgRXhwZXJpbWVudEluZm9TY2hlbWEsIFRyYW5zY3JpcHRvbWVzLCBUcmFuc2NyaXB0b21lU2NoZW1hIH1cblxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBWYWxpZGF0ZWRNZXRob2QgfSBmcm9tICdtZXRlb3IvbWRnOnZhbGlkYXRlZC1tZXRob2QnO1xuaW1wb3J0IHsgUm9sZXMgfSBmcm9tICdtZXRlb3IvYWxhbm5pbmc6cm9sZXMnO1xuXG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5cbmltcG9ydCB7IEV4cGVyaW1lbnRJbmZvIH0gZnJvbSAnL2ltcG9ydHMvYXBpL3RyYW5zY3JpcHRvbWVzL3RyYW5zY3JpcHRvbWVfY29sbGVjdGlvbi5qcyc7XG5cbi8qKlxuICogdXBkYXRlU2FtcGxlSW5mbyB2YWxpZGF0ZWQgbWV0aG9kOiBVcGRhdGUgdHJhbnNjcmlwdG9tZSBpbmZvcm1hdGlvbiBhbmQgZ3JvdXBzXG4gKiBAcGFyYW0gIHtTdHJpbmd9IG9wdGlvbnMudHJhY2tOYW1lIE5hbWUgb2YgdGhlIGFubm90YXRpb24gdHJhY2tcbiAqIEBwYXJhbSAge1N0cmluZ30gb3B0aW9ucy5kYlR5cGUgICAgRWl0aGVyIG51Y2wgb3IgcHJvdFxuICogQHJldHVybiB7U3RyaW5nfSAgICAgICAgICAgICAgICAgICBqb2JJZCBvZiB0aGUgbWFrZWJsYXN0ZGIgam9iXG4gKi9cbmV4cG9ydCBjb25zdCB1cGRhdGVTYW1wbGVJbmZvID0gbmV3IFZhbGlkYXRlZE1ldGhvZCh7XG4gIG5hbWU6ICd1cGRhdGVTYW1wbGVJbmZvJyxcbiAgdmFsaWRhdGU6IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIF9pZDogeyB0eXBlOiBTdHJpbmcgfSxcbiAgICBzYW1wbGVOYW1lOiB7IHR5cGU6IFN0cmluZyB9LFxuICAgIGV4cGVyaW1lbnRHcm91cDogeyB0eXBlOiBTdHJpbmcgfSxcbiAgICByZXBsaWNhR3JvdXA6IHsgdHlwZTogU3RyaW5nIH0sXG4gICAgZGVzY3JpcHRpb246IHsgdHlwZTogU3RyaW5nIH0sXG4gICAgcGVybWlzc2lvbnM6IHsgdHlwZTogQXJyYXkgfSxcbiAgICAncGVybWlzc2lvbnMuJCc6IHsgdHlwZTogU3RyaW5nIH1cbiAgfSkudmFsaWRhdG9yKCksXG4gIGFwcGx5T3B0aW9uczoge1xuICAgIG5vUmV0cnk6IHRydWVcbiAgfSxcbiAgcnVuKHsgX2lkLCBzYW1wbGVOYW1lLCBleHBlcmltZW50R3JvdXAsIHJlcGxpY2FHcm91cCwgZGVzY3JpcHRpb24sIHBlcm1pc3Npb25zIH0pe1xuICAgIGlmICghIHRoaXMudXNlcklkKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgIH1cbiAgICBpZiAoISBSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsJ2FkbWluJykpe1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9XG5cbiAgICBpZiAocGVybWlzc2lvbnMubGVuZ3RoID09PSAwKXtcbiAgICAgIHBlcm1pc3Npb25zLnB1c2goJ2FkbWluJylcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyh7XG4gICAgICBfaWQsc2FtcGxlTmFtZSxleHBlcmltZW50R3JvdXAscmVwbGljYUdyb3VwLGRlc2NyaXB0aW9uLHBlcm1pc3Npb25zXG4gICAgfSlcblxuICAgIEV4cGVyaW1lbnRJbmZvLnVwZGF0ZSh7XG4gICAgICBfaWQ6IF9pZFxuICAgIH0se1xuICAgICAgJHNldDoge1xuICAgICAgICBzYW1wbGVOYW1lLFxuICAgICAgICBleHBlcmltZW50R3JvdXAsXG4gICAgICAgIHJlcGxpY2FHcm91cCxcbiAgICAgICAgZGVzY3JpcHRpb24sXG4gICAgICAgIHBlcm1pc3Npb25zXG4gICAgICB9XG4gICAgfSlcbiAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgVmFsaWRhdGVkTWV0aG9kIH0gZnJvbSAnbWV0ZW9yL21kZzp2YWxpZGF0ZWQtbWV0aG9kJztcblxuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuLy9pbXBvcnQgRnV0dXJlIGZyb20gJ2ZpYmVycy9mdXR1cmUnO1xuXG5leHBvcnQgY29uc3QgdXBkYXRlVXNlckluZm8gPSBuZXcgVmFsaWRhdGVkTWV0aG9kKHtcbiAgbmFtZTogJ3VwZGF0ZVVzZXJJbmZvJyxcbiAgdmFsaWRhdGU6IG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgIHVzZXJJZDogeyB0eXBlOiBTdHJpbmcgfSxcbiAgICB1cGRhdGU6IHsgdHlwZTogT2JqZWN0LCBibGFja2JveDogdHJ1ZSB9XG4gIH0pLnZhbGlkYXRvcigpLFxuICBhcHBseU9wdGlvbnM6IHtcbiAgICBub1JldHJ5OiB0cnVlXG4gIH0sXG4gIHJ1bih7IHVzZXJJZCwgdXBkYXRlIH0pe1xuICAgIGlmICghIHRoaXMudXNlcklkKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgIH1cbiAgICBpZiAoISBSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsJ2FkbWluJykpe1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9XG5cbiAgICBNZXRlb3IudXNlcnMudXBkYXRlKHtfaWQ6IHVzZXJJZH0sdXBkYXRlKTtcbiAgfVxufSkiLCJpbXBvcnQgeyBSZWZlcmVuY2VzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2dlbm9tZXMvcmVmZXJlbmNlX2NvbGxlY3Rpb24uanMnO1xuXG4vKipcbiAqIFJldmVyc2UgY29tcGxlbWVudCBhIEROQSBzdHJpbmdcbiAqIEBwYXJhbSAge1tTdHJpbmddfSBzZXEgW1N0cmluZyByZXByZXNlbnRpbmcgRE5BIGNvbnN0aXN0aW5nIG9mIGFscGhhYmV0IEFhQ2NHZ1R0Tm5dXG4gKiBAcmV0dXJuIHtbU3RyaW5nXX0gICAgIFtTdHJpbmcgcmVwcmVzZW50aW5nIEROQSBjb25zdGlzdGluZyBvZiBhbHBoYWJldCBBYUNjR2dUdE5uLCByZXZlcnNlIGNvbXBsZW1lbnQgb2YgaW5wdXRdXG4gKi9cbmV4cG9ydCBjb25zdCByZXZlcnNlQ29tcGxlbWVudCA9IChzZXEpID0+IHtcbiAgY29uc3QgY29tcCA9IHsgIFxuICAgICdBJzonVCcsJ2EnOid0JyxcbiAgICAnVCc6J0EnLCd0JzonYScsXG4gICAgJ0MnOidHJywnYyc6J2cnLFxuICAgICdHJzonQycsJ2cnOidjJyxcbiAgICAnTic6J04nLCduJzonbidcbiAgfVxuICBjb25zdCByZXZTZXFBcnJheSA9IHNlcS5zcGxpdCgnJykucmV2ZXJzZSgpXG4gIGNvbnN0IHJldkNvbXBTZXFBcnJheSA9IHJldlNlcUFycmF5Lm1hcCggKG51YykgPT4ge1xuICAgIHJldHVybiBjb21wW251Y11cbiAgfSlcbiAgY29uc3QgcmV2Q29tcFNlcSA9IHJldkNvbXBTZXFBcnJheS5qb2luKCcnKVxuICByZXR1cm4gcmV2Q29tcFNlcVxufVxuXG4vKipcbiAqIENvbnZlcnQgYSBETkEgc3RyaW5nIGludG8gYSBhbWlubyBhY2lkIHN0cmluZ1xuICogQHBhcmFtICB7W1N0cmluZ119IHNlcSBbU3RyaW5nIHJlcHJlc2VudGluZyBETkEgY29uc3Rpc3Rpbmcgb2YgYWxwaGFiZXQgQUNHVE5dXG4gKiBAcmV0dXJuIHtbU3RyaW5nXX0gICAgIFtTdHJpbmcgcmVwcmVzZW50aW5nIHRoZSBhbWlubyBhY2lkIGNvbXBsZW1lbnQgb2YgaW5wdXQgc3RyaW5nXVxuICovXG5leHBvcnQgY29uc3QgdHJhbnNsYXRlID0gKHNlcSkgPT4ge1xuICBjb25zdCB0cmFucyA9IHtcbiAgICAnQUNDJzogJ1QnLCAnQUNBJzogJ1QnLCAnQUNHJzogJ1QnLFxuICAgICdBR0cnOiAnUicsICdBR0MnOiAnUycsICdHVEEnOiAnVicsXG4gICAgJ0FHQSc6ICdSJywgJ0FDVCc6ICdUJywgJ0dURyc6ICdWJyxcbiAgICAnQUdUJzogJ1MnLCAnQ0NBJzogJ1AnLCAnQ0NDJzogJ1AnLFxuICAgICdHR1QnOiAnRycsICdDR0EnOiAnUicsICdDR0MnOiAnUicsXG4gICAgJ1RBVCc6ICdZJywgJ0NHRyc6ICdSJywgJ0NDVCc6ICdQJyxcbiAgICAnR0dHJzogJ0cnLCAnR0dBJzogJ0cnLCAnR0dDJzogJ0cnLFxuICAgICdUQUEnOiAnKicsICdUQUMnOiAnWScsICdDR1QnOiAnUicsXG4gICAgJ1RBRyc6ICcqJywgJ0FUQSc6ICdJJywgJ0NUVCc6ICdMJyxcbiAgICAnQVRHJzogJ00nLCAnQ1RHJzogJ0wnLCAnQVRUJzogJ0knLFxuICAgICdDVEEnOiAnTCcsICdUVFQnOiAnRicsICdHQUEnOiAnRScsXG4gICAgJ1RURyc6ICdMJywgJ1RUQSc6ICdMJywgJ1RUQyc6ICdGJyxcbiAgICAnR1RDJzogJ1YnLCAnQUFHJzogJ0snLCAnQUFBJzogJ0snLFxuICAgICdBQUMnOiAnTicsICdBVEMnOiAnSScsICdDQVQnOiAnSCcsXG4gICAgJ0FBVCc6ICdOJywgJ0dUVCc6ICdWJywgJ0NBQyc6ICdIJyxcbiAgICAnQ0FBJzogJ1EnLCAnQ0FHJzogJ1EnLCAnQ0NHJzogJ1AnLFxuICAgICdUQ1QnOiAnUycsICdUR0MnOiAnQycsICdUR0EnOiAnKicsXG4gICAgJ1RHRyc6ICdXJywgJ1RDRyc6ICdTJywgJ1RDQyc6ICdTJyxcbiAgICAnVENBJzogJ1MnLCAnR0FHJzogJ0UnLCAnR0FDJzogJ0QnLFxuICAgICdUR1QnOiAnQycsICdHQ0EnOiAnQScsICdHQ0MnOiAnQScsXG4gICAgJ0dDRyc6ICdBJywgJ0dDVCc6ICdBJywgJ0NUQyc6ICdMJyxcbiAgICAnR0FUJzogJ0QnfVxuICBjb25zdCBjb2RvbkFycmF5ID0gc2VxLm1hdGNoKC8uezEsM30vZylcbiAgY29uc3QgcGVwQXJyYXkgPSBjb2RvbkFycmF5Lm1hcCggKGNvZG9uKSA9PiB7XG4gICAgbGV0IGFtaW5vQWNpZCA9ICdYJ1xuICAgIGlmIChjb2Rvbi5pbmRleE9mKCdOJykgPCAwKXtcbiAgICAgIGFtaW5vQWNpZCA9IHRyYW5zW2NvZG9uXVxuICAgIH1cbiAgICByZXR1cm4gYW1pbm9BY2lkXG4gIH0pXG4gIGNvbnN0IHBlcCA9IHBlcEFycmF5LmpvaW4oJycpXG4gIHJldHVybiBwZXBcbn1cblxuLyoqXG4gKiBHZXQgbnVjbGVvdGlkZSBhbmQgcHJvdGVpbiBzZXF1ZW5jZXMgb2YgYWxsIHRyYW5zY3JpcHRzIGZvciBhIG11bHRpcGxlIGdlbmVzICh1c2luZyBDRFMgc3ViZmVhdHVyZXMpXG4gKiBAcGFyYW0gIHtbQXJyYXldPGdlbmU+fSBnZW5lcyBbQXJyYXkgb2YgT2JqZWN0IHJlcHJlc2VudGluZyBnZW5lLW1vZGVsc11cbiAqIEByZXR1cm4ge1tBcnJheV19ICAgICBbQXJyYXkgd2l0aCBvYmplY3RzLCB3aGVyZSBlYWNoIG9iamVjdCBoYXMgYSB0cmFuc2NyaXB0SWQsIFxuICogICAgICAgICAgICAgICAgICAgICAgICBudWNsZW90aWRlIHNlcXVlbmNlIGFuZCBwcm90ZWluIHNlcXVlbmNlIGZpZWxkXVxuICovXG5jb25zdCBnZXRNdWx0aXBsZUdlbmVTZXF1ZW5jZXMgPSAoZ2VuZXMpID0+IHtcbiAgY29uc3Qgc2VxaWRzID0gZ2VuZXMubWFwKGdlbmUgPT4ge1xuICAgIHJldHVybiBnZW5lLnNlcWlkXG4gIH0pXG4gIGNvbnN0IHVuaXF1ZVNlcWlkcyA9IFsuLi5uZXcgU2V0KHNlcWlkcyldXG5cbiAgY29uc29sZS5sb2codW5pcXVlU2VxaWRzKVxuXG4gIGNvbnN0IHJlZlNlcXMgPSB1bmlxdWVTZXFpZHMucmVkdWNlKChvYmosc2VxaWQsaSkgPT4ge1xuICAgIG9ialtzZXFpZF0gPSBSZWZlcmVuY2VzLmZpbmQoe1xuICAgICAgaGVhZGVyOiBzZXFpZFxuICAgIH0se1xuICAgICAgc29ydDogeyBzdGFydDogMSB9XG4gICAgfSkubWFwKHJlZiA9PiB7XG4gICAgICByZXR1cm4gcmVmLnNlcVxuICAgIH0pLmpvaW4oJycpXG4gICAgcmV0dXJuIG9ialxuICB9LHt9KTsgLy90aGlzIHBhcnQgaXMgaW1wb3J0LCBpbml0aWFsaXplIHJlZHVjZSB3aXRoIGVtcHR5IG9iamVjdFxuICBjb25zb2xlLmxvZyhyZWZTZXFzKVxufVxuXG5cbi8qKlxuICogR2V0IG51Y2xlb3RpZGUgYW5kIHByb3RlaW4gc2VxdWVuY2VzIG9mIGFsbCB0cmFuc2NyaXB0cyBmb3IgYSBzaW5nbGUgZ2VuZSAodXNpbmcgQ0RTIHN1YmZlYXR1cmVzKVxuICogQHBhcmFtICB7W09iamVjdF19IGdlbmUgW09iamVjdCByZXByZXNlbnRpbmcgYSBnZW5lLW1vZGVsXVxuICogQHJldHVybiB7W0FycmF5XX0gICAgIFtBcnJheSB3aXRoIG9iamVjdHMsIHdoZXJlIGVhY2ggb2JqZWN0IGhhcyBhIHRyYW5zY3JpcHRJZCwgXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIG51Y2xlb3RpZGUgc2VxdWVuY2UgYW5kIHByb3RlaW4gc2VxdWVuY2UgZmllbGRdXG4gKi9cbmV4cG9ydCBjb25zdCBnZXRHZW5lU2VxdWVuY2VzID0gKGdlbmUpID0+IHtcbiAgLy9jb25zb2xlLmxvZyhgZ2V0R2VuZVNlcXVlbmNlcyAke2dlbmUuSUR9YClcbiAgY29uc3QgdHJhbnNjcmlwdHMgPSBnZW5lLnN1YmZlYXR1cmVzLmZpbHRlciggc3ViZmVhdHVyZSA9PiB7IFxuICAgIHJldHVybiBzdWJmZWF0dXJlLnR5cGUgPT09ICdtUk5BJyBcbiAgfSlcbiAgY29uc3Qgc2VxdWVuY2VzID0gdHJhbnNjcmlwdHMubWFwKCB0cmFuc2NyaXB0ID0+IHtcbiAgICBsZXQgY2RzQXJyYXkgPSBnZW5lLnN1YmZlYXR1cmVzLmZpbHRlciggc3ViZmVhdHVyZSA9PiB7IFxuICAgICAgcmV0dXJuIHN1YmZlYXR1cmUucGFyZW50cy5pbmRleE9mKHRyYW5zY3JpcHQuSUQpID49IDAgJiYgc3ViZmVhdHVyZS50eXBlID09PSAnQ0RTJ1xuICAgIH0pLnNvcnQoIChhLGIpID0+IHtcbiAgICAgIC8vc29ydCBDRFMgc3ViZmVhdHVyZXMgb24gc3RhcnQgcG9zaXRpb25cbiAgICAgIHJldHVybiBhLnN0YXJ0IC0gYi5zdGFydFxuICAgIH0pXG5cbiAgICBsZXQgcmF3U2VxID0gY2RzQXJyYXkubWFwKCAoY2RzLCBpbmRleCkgPT4ge1xuICAgICAgcmV0dXJuIGNkcy5zZXFcbiAgICB9KS5qb2luKCcnKVxuXG4gICAgY29uc3QgZm9yd2FyZCA9IGdlbmUuc3RyYW5kID09PSAnKyc7XG4gICAgY29uc3QgcGhhc2UgPSBmb3J3YXJkID8gY2RzQXJyYXlbMF0ucGhhc2UgOiBjZHNBcnJheVtjZHNBcnJheS5sZW5ndGggLSAxXS5waGFzZTtcbiAgICBjb25zdCB0cmFuc2NyaXB0U2VxID0gZm9yd2FyZCA/IHJhd1NlcSA6IHJldmVyc2VDb21wbGVtZW50KHJhd1NlcSk7XG5cbiAgICBjb25zdCBpc1BoYXNlZCA9IHBoYXNlID09PSAxIHwgcGhhc2UgPT09IDI7XG4gICAgY29uc3QgY29kaW5nU2VxID0gaXNQaGFzZWQgPyB0cmFuc2NyaXB0U2VxLnNsaWNlKHBoYXNlKSA6IHRyYW5zY3JpcHRTZXE7XG5cbiAgICBjb25zdCBjb2RpbmdQZXAgPSB0cmFuc2xhdGUoY29kaW5nU2VxLnRvVXBwZXJDYXNlKCkpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIElEOiB0cmFuc2NyaXB0LklELFxuICAgICAgc2VxOiBjb2RpbmdTZXEsXG4gICAgICBwZXA6IGNvZGluZ1BlcFxuICAgIH1cbiAgfSlcbiAgcmV0dXJuIHNlcXVlbmNlc1xufVxuXG5leHBvcnQgY29uc3QgcGFyc2VOZXdpY2sgPSAobmV3aWNrU3RyaW5nKSA9PiB7XG4gIC8vQWRhcHRlZCBmcm9tIEphc29uIERhdmllcyBodHRwczovL2dpdGh1Yi5jb20vamFzb25kYXZpZXMvbmV3aWNrLmpzXG4gIGNvbnN0IGFuY2VzdG9ycyA9IFtdO1xuICBjb25zdCB0b2tlbnMgPSBuZXdpY2tTdHJpbmcuc3BsaXQoL1xccyooO3xcXCh8XFwpfCx8OilcXHMqLyk7XG4gIGNvbnN0IGdlbmVJZHMgPSBbXVxuICBsZXQgdHJlZSA9IHt9O1xuICBsZXQgc3VidHJlZSA9IHt9O1xuICB0b2tlbnMuZm9yRWFjaCgodG9rZW4sIHRva2VuSW5kZXgpID0+IHtcbiAgICBzd2l0Y2godG9rZW4pe1xuICAgICAgY2FzZSAnKCc6IC8vbmV3IGJyYW5jaHNldFxuICAgICAgICBzdWJ0cmVlID0ge307XG4gICAgICAgIHRyZWUuYnJhbmNoc2V0ID0gW3N1YnRyZWVdO1xuICAgICAgICBhbmNlc3RvcnMucHVzaCh0cmVlKTtcbiAgICAgICAgdHJlZSA9IHN1YnRyZWU7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnLCc6IC8vYW5vdGhlciBicmFuY2hcbiAgICAgICAgc3VidHJlZSA9IHt9O1xuICAgICAgICBhbmNlc3RvcnNbYW5jZXN0b3JzLmxlbmd0aCAtIDFdLmJyYW5jaHNldC5wdXNoKHN1YnRyZWUpO1xuICAgICAgICB0cmVlID0gc3VidHJlZTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICcpJzogLy9vcHRpb25hbCBuYW1lIG5leHRcbiAgICAgICAgdHJlZSA9IGFuY2VzdG9ycy5wb3AoKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICc6JzogLy9vcHRpb25hbCBsZW5ndGggbmV4dFxuICAgICAgICBicmVhaztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIGxldCBwcmV2aW91c1Rva2VuID0gdG9rZW5zW3Rva2VuSW5kZXggLSAxXTtcbiAgICAgICAgaWYgKFxuICAgICAgICAgIHByZXZpb3VzVG9rZW4gPT09ICcoJyB8fFxuICAgICAgICAgIHByZXZpb3VzVG9rZW4gPT09ICcpJyB8fFxuICAgICAgICAgIHByZXZpb3VzVG9rZW4gPT09ICcsJ1xuICAgICAgICApe1xuICAgICAgICAgIHRyZWUubmFtZSA9IHRva2VuO1xuICAgICAgICAgIGNvbnN0IGdlbmVJZCA9IHRva2VuLnNwbGl0KCcuJykuc2xpY2UoMCwtMSkuam9pbignLicpO1xuICAgICAgICAgIGlmIChnZW5lSWQubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICBnZW5lSWRzLnB1c2goZ2VuZUlkKVxuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmIChwcmV2aW91c1Rva2VuID09PSAnOicpe1xuICAgICAgICAgIHRyZWUuYnJhbmNoTGVuZ3RoID0gcGFyc2VGbG9hdCh0b2tlbik7XG4gICAgICAgIH1cbiAgICB9XG4gIH0pXG4gIHJldHVybiB7XG4gICAgdHJlZTogdHJlZSxcbiAgICBnZW5lSWRzOiBnZW5lSWRzLFxuICAgIHNpemU6IGdlbmVJZHMubGVuZ3RoXG4gIH07XG59XG5cblxuIiwiaW1wb3J0ICcuL3B1YmxpY2F0aW9ucy5qcyc7XG5cbi8vSW1wb3J0IHRoZXNlIG1ldGhvZHMgaGVyZSBzbyB0aGV5IGNhbiBiZSB1c2VkIHdpdGggdGhlIE1ldGVvci5jYWxsKCdtZXRob2ROYW1lJykgc3ludGF4LlxuLy9UaGlzIGlzIGNydWNpYWwgdG8gYmUgYWJsZSB0byBjYWxsIHRoZW0gd2l0aCB0aGUgYXN0ZXJvaWQgZGRwIGNvbm5lY3Rpb24gaW4gdGhlIGRhdGEtbG9hZGluZyBzY3JpcHRzXG5pbXBvcnQgJy4vdHJhbnNjcmlwdG9tZXMvYWRkX3RyYW5zY3JpcHRvbWUuanMnO1xuaW1wb3J0ICcuL3RyYW5zY3JpcHRvbWVzL3VwZGF0ZVNhbXBsZUluZm8uanMnO1xuXG5pbXBvcnQgJy4vZ2Vub21lcy9hZGRfcmVmZXJlbmNlLmpzJztcbmltcG9ydCAnLi9nZW5vbWVzL2FkZF9nZmYuanMnO1xuaW1wb3J0ICcuL2dlbm9tZXMvdXBkYXRlVHJhY2tQZXJtaXNzaW9ucy5qcyc7XG5cbmltcG9ydCAnLi9nZW5lcy9pbnRlcnByb3NjYW4uanMnO1xuaW1wb3J0ICcuL2dlbmVzL2FkZF9pbnRlcnByb3NjYW4uanMnO1xuaW1wb3J0ICcuL2dlbmVzL2FkZF9vcnRob2dyb3VwX3RyZWVzLmpzJztcbmltcG9ydCAnLi9nZW5lcy9kb3dubG9hZF9nZW5lcy5qcyc7XG5cbmltcG9ydCAnLi9ibGFzdC9tYWtlYmxhc3RkYi5qcyc7XG5pbXBvcnQgJy4vYmxhc3QvaGFzYmxhc3RkYi5qcyc7XG5pbXBvcnQgJy4vYmxhc3QvcmVtb3ZlYmxhc3RkYi5qcyc7XG5pbXBvcnQgJy4vYmxhc3Qvc3VibWl0Ymxhc3Rqb2IuanMnO1xuaW1wb3J0ICcuL3VzZXJzL3VzZXJzLmpzJztcblxuaW1wb3J0ICcuL21ldGhvZHMvbWV0aG9kcy5qcyc7XG4vL2ltcG9ydCAnLi9tZXRob2RzL2JsYXN0LmpzJztcbmltcG9ydCAnLi9tZXRob2RzL2xpc3QuanMnO1xuXG4vL2ltcG9ydCB0aGUgZm9sbG93aW5nIHNvIHRoYXQgam9icyBjYW4gc3RhcnQgcnVubmluZ1xuaW1wb3J0ICcuL2pvYnF1ZXVlL3Byb2Nlc3MtaW50ZXJwcm9zY2FuLmpzJztcbmltcG9ydCAnLi9qb2JxdWV1ZS9wcm9jZXNzLW1ha2VCbGFzdERiLmpzJztcbmltcG9ydCAnLi9qb2JxdWV1ZS9wcm9jZXNzLWJsYXN0LmpzJztcbmltcG9ydCAnLi9qb2JxdWV1ZS9wcm9jZXNzLWRvd25sb2FkLmpzJzsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IHB1Ymxpc2hDb21wb3NpdGUgfSBmcm9tICdtZXRlb3IvcmV5d29vZDpwdWJsaXNoLWNvbXBvc2l0ZSc7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5cbmltcG9ydCBqb2JRdWV1ZSBmcm9tICcvaW1wb3J0cy9hcGkvam9icXVldWUvam9icXVldWUuanMnO1xuXG5pbXBvcnQgeyBHZW5lcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9nZW5lX2NvbGxlY3Rpb24uanMnO1xuaW1wb3J0IHsgQXR0cmlidXRlcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9hdHRyaWJ1dGVfY29sbGVjdGlvbi5qcyc7XG5pbXBvcnQgeyBJbnRlcnBybyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9pbnRlcnByb19jb2xsZWN0aW9uLmpzJztcbmltcG9ydCB7IE9ydGhvZ3JvdXBzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2dlbmVzL29ydGhvZ3JvdXBfY29sbGVjdGlvbi5qcyc7XG5pbXBvcnQgeyBFZGl0SGlzdG9yeSB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9lZGl0aGlzdG9yeV9jb2xsZWN0aW9uLmpzJztcbmltcG9ydCB7IFRyYWNrcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5vbWVzL3RyYWNrX2NvbGxlY3Rpb24uanMnO1xuaW1wb3J0IHsgUmVmZXJlbmNlcywgUmVmZXJlbmNlSW5mbyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5vbWVzL3JlZmVyZW5jZV9jb2xsZWN0aW9uLmpzJztcbmltcG9ydCB7IEV4cGVyaW1lbnRJbmZvLCBUcmFuc2NyaXB0b21lcyB9IGZyb20gJy9pbXBvcnRzL2FwaS90cmFuc2NyaXB0b21lcy90cmFuc2NyaXB0b21lX2NvbGxlY3Rpb24uanMnO1xuXG5NZXRlb3IucHVibGlzaCgnZ2VuZXMnLCBmdW5jdGlvbihsaW1pdCwgc2VhcmNoLCBxdWVyeSkge1xuICBjb25zb2xlLmxvZygncHVibGlzaGluZyBnZW5lIGxpc3QnKVxuICBjb25zb2xlLmxvZygnbGltaXQnLGxpbWl0KVxuICBjb25zb2xlLmxvZygnc2VhcmNoJyxzZWFyY2gpXG4gIGNvbnNvbGUubG9nKCdxdWVyeScscXVlcnkpXG4gIGNvbnN0IHB1YmxpY2F0aW9uID0gdGhpcztcbiAgaWYgKCFwdWJsaWNhdGlvbi51c2VySWQpe1xuICAgIHB1YmxpY2F0aW9uLnN0b3AoKVxuICB9XG5cbiAgbGltaXQgPSBsaW1pdCB8fCA0MDtcbiAgcXVlcnkgPSBxdWVyeSB8fCB7fTtcbiAgaWYgKHNlYXJjaCkge1xuICAgIHF1ZXJ5LiRvciA9IFt7ICdJRCc6IHsgJHJlZ2V4OiBzZWFyY2ggLCAkb3B0aW9uczogJ2knIH0gfSx7ICdOYW1lJzogeyAkcmVnZXg6IHNlYXJjaCAsICRvcHRpb25zOiAnaScgfSB9XTtcbiAgICBpZiAoIXF1ZXJ5Lmhhc093blByb3BlcnR5KCdQcm9kdWN0bmFtZScpKXtcbiAgICAgIHF1ZXJ5LiRvci5wdXNoKHsgJ1Byb2R1Y3RuYW1lJzogeyAkcmVnZXg6IHNlYXJjaCAsICRvcHRpb25zOiAnaScgfSB9KVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHJvbGVzID0gUm9sZXMuZ2V0Um9sZXNGb3JVc2VyKHB1YmxpY2F0aW9uLnVzZXJJZCk7XG5cbiAgcXVlcnkucGVybWlzc2lvbnMgPSB7ICRpbjogcm9sZXMgfVxuXG4gIHJldHVybiBHZW5lcy5maW5kKHF1ZXJ5LHtsaW1pdDogbGltaXR9KVxufSlcblxuLypcbnB1Ymxpc2hDb21wb3NpdGUoJ3NpbmdsZUdlbmUnLCBmdW5jdGlvbihnZW5lSWQpe1xuICAvL2NvbnNvbGUubG9nKCdwdWJsaXNoaW5nIHNpbmdsZSBnZW5lJylcbiAgY29uc3QgcHVibGljYXRpb24gPSB0aGlzO1xuICBpZiAoIXB1YmxpY2F0aW9uLnVzZXJJZCl7XG4gICAgcHVibGljYXRpb24uc3RvcCgpXG4gIH1cblxuICBjb25zdCByb2xlcyA9IFJvbGVzLmdldFJvbGVzRm9yVXNlcihwdWJsaWNhdGlvbi51c2VySWQpO1xuXG4gIHJldHVybiB7XG4gICAgZmluZCgpe1xuICAgICAgcmV0dXJuIEdlbmVzLmZpbmQoe1xuICAgICAgICBJRDogZ2VuZUlkLFxuICAgICAgICBwZXJtaXNzaW9uczoge1xuICAgICAgICAgICRpbjogcm9sZXNcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9LFxuICAgIGNoaWxkcmVuOiBbXG4gICAgICB7XG4gICAgICAgIGZpbmQoZ2VuZSl7XG4gICAgICAgICAgcmV0dXJuIFRyYW5zY3JpcHRvbWVzLmZpbmQoe1xuICAgICAgICAgICAgZ2VuZUlkOiBnZW5lLklELFxuICAgICAgICAgICAgcGVybWlzc2lvbnM6IHtcbiAgICAgICAgICAgICAgJGluOiByb2xlc1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgIHtcbiAgICAgICAgICBmaW5kKHRyYW5zY3JpcHRvbWUpe1xuICAgICAgICAgICAgcmV0dXJuIEV4cGVyaW1lbnRJbmZvLmZpbmQoe1xuICAgICAgICAgICAgICBfaWQ6IHRyYW5zY3JpcHRvbWUuZXhwZXJpbWVudElkLFxuICAgICAgICAgICAgICBwZXJtaXNzaW9uczoge1xuICAgICAgICAgICAgICAgICRpbjogcm9sZXNcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgXVxuICAgICAgfVxuICAgIF1cbiAgfVxufSlcbiovXG5cbnB1Ymxpc2hDb21wb3NpdGUoJ2F0dHJpYnV0ZXMnLCBmdW5jdGlvbigpe1xuICBjb25zdCBwdWJsaWNhdGlvbiA9IHRoaXM7XG4gIGlmICghcHVibGljYXRpb24udXNlcklkKXtcbiAgICBwdWJsaWNhdGlvbi5zdG9wKClcbiAgfVxuXG4gIGNvbnN0IHJvbGVzID0gUm9sZXMuZ2V0Um9sZXNGb3JVc2VyKHB1YmxpY2F0aW9uLnVzZXJJZCk7XG5cbiAgcmV0dXJuIHtcbiAgICBmaW5kKCl7XG4gICAgICByZXR1cm4gUmVmZXJlbmNlSW5mby5maW5kKHtcbiAgICAgICAgcGVybWlzc2lvbnM6IHtcbiAgICAgICAgICAkaW46IHJvbGVzXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfSxcbiAgICBjaGlsZHJlbjogW1xuICAgICAge1xuICAgICAgICBmaW5kKHJlZmVyZW5jZSl7XG4gICAgICAgICAgcmV0dXJuIEF0dHJpYnV0ZXMuZmluZCh7XG4gICAgICAgICAgICAkb3I6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHJlZmVyZW5jZXM6IHJlZmVyZW5jZS5yZWZlcmVuY2VOYW1lXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBhbGxSZWZlcmVuY2VzOiB0cnVlIFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBdXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgfVxuICAgIF1cbiAgfVxufSlcblxuTWV0ZW9yLnB1Ymxpc2goJ3VzZXJzJywgZnVuY3Rpb24gKCkge1xuICBpZiAoIXRoaXMudXNlcklkKXtcbiAgICB0aGlzLnN0b3AoKVxuICAgIC8vdGhyb3cgbmV3IE1ldGVvci5FcnJvcignVW5hdXRob3JpemVkJylcbiAgfVxuICBpZiAoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCdhZG1pbicpKXtcbiAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoe30pO1xuICB9IGVsc2UgaWYgKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCxbJ3VzZXInLCdjdXJhdG9yJ10pKXtcbiAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoe30se2ZpZWxkczp7dXNlcm5hbWU6MX19KVxuICB9IGVsc2Uge1xuICAgIHRoaXMucmVhZHkoKVxuICAgIC8vdGhyb3cgbmV3IE1ldGVvci5FcnJvcignVW5hdXRob3JpemVkJylcbiAgfVxufSlcblxuTWV0ZW9yLnB1Ymxpc2goe1xuICBzaW5nbGVHZW5lIChnZW5lSWQpIHtcbiAgICBjb25zdCBwdWJsaWNhdGlvbiA9IHRoaXM7XG4gICAgaWYgKCFwdWJsaWNhdGlvbi51c2VySWQpe1xuICAgICAgcHVibGljYXRpb24uc3RvcCgpXG4gICAgfVxuICAgIGNvbnN0IHJvbGVzID0gUm9sZXMuZ2V0Um9sZXNGb3JVc2VyKHB1YmxpY2F0aW9uLnVzZXJJZCk7XG4gICAgcmV0dXJuIEdlbmVzLmZpbmQoe1xuICAgICAgSUQ6IGdlbmVJZCxcbiAgICAgIHBlcm1pc3Npb25zOiB7XG4gICAgICAgICRpbjogcm9sZXNcbiAgICAgIH1cbiAgICB9KVxuICB9LFxuICBnZW5lRXhwcmVzc2lvbiAoZ2VuZUlkKSB7XG4gICAgY29uc3QgcHVibGljYXRpb24gPSB0aGlzO1xuICAgIGlmICghcHVibGljYXRpb24udXNlcklkKXtcbiAgICAgIHB1YmxpY2F0aW9uLnN0b3AoKVxuICAgIH1cbiAgICBjb25zdCByb2xlcyA9IFJvbGVzLmdldFJvbGVzRm9yVXNlcihwdWJsaWNhdGlvbi51c2VySWQpO1xuICAgIHJldHVybiBUcmFuc2NyaXB0b21lcy5maW5kKHtcbiAgICAgIGdlbmVJZDogZ2VuZUlkLFxuICAgICAgcGVybWlzc2lvbnM6IHtcbiAgICAgICAgJGluOiByb2xlc1xuICAgICAgfVxuICAgIH0pXG4gIH0sXG4gIGV4cGVyaW1lbnRJbmZvICgpe1xuICAgIGNvbnN0IHB1YmxpY2F0aW9uID0gdGhpcztcbiAgICBpZiAoIXB1YmxpY2F0aW9uLnVzZXJJZCl7XG4gICAgICBwdWJsaWNhdGlvbi5zdG9wKClcbiAgICB9XG4gICAgY29uc3Qgcm9sZXMgPSBSb2xlcy5nZXRSb2xlc0ZvclVzZXIocHVibGljYXRpb24udXNlcklkKTtcbiAgICByZXR1cm4gRXhwZXJpbWVudEluZm8uZmluZCh7XG4gICAgICBwZXJtaXNzaW9uczoge1xuICAgICAgICAkaW46IHJvbGVzXG4gICAgICB9XG4gICAgfSk7XG4gIH0sXG4gIGRvd25sb2FkcyAoZG93bmxvYWRJZCkge1xuICAgIGNvbnN0IHB1YmxpY2F0aW9uID0gdGhpcztcbiAgICBjb25zdCByb2xlcyA9IHB1YmxpY2F0aW9uLnVzZXJJZCA/IFJvbGVzLmdldFJvbGVzRm9yVXNlcihwdWJsaWNhdGlvbi51c2VySWQpIDogWydwdWJsaWMnXTtcbiAgICByZXR1cm4gRG93bmxvYWRzLmZpbmRPbmUoe0lEOiBkb3dubG9hZElkLCBwZXJtaXNzaW9uOiB7JGluOiByb2xlc30gfSk7XG4gIH0sXG4gIGpvYlF1ZXVlICgpIHtcbiAgICBjb25zdCBwdWJsaWNhdGlvbiA9IHRoaXM7XG4gICAgaWYgKCFwdWJsaWNhdGlvbi51c2VySWQpe1xuICAgICAgcHVibGljYXRpb24uc3RvcCgpXG4gICAgfVxuICAgIHJldHVybiBqb2JRdWV1ZS5maW5kKHt9KTtcbiAgfSxcbiAgcmVmZXJlbmNlSW5mbyAoKSB7XG4gICAgY29uc3QgcHVibGljYXRpb24gPSB0aGlzO1xuICAgIGlmICghcHVibGljYXRpb24udXNlcklkKXtcbiAgICAgIHB1YmxpY2F0aW9uLnN0b3AoKVxuICAgIH1cbiAgICBjb25zdCByb2xlcyA9IFJvbGVzLmdldFJvbGVzRm9yVXNlcihwdWJsaWNhdGlvbi51c2VySWQpO1xuICAgIHJldHVybiBSZWZlcmVuY2VJbmZvLmZpbmQoe1xuICAgICAgcGVybWlzc2lvbnM6IHtcbiAgICAgICAgJGluOiByb2xlc1xuICAgICAgfVxuICAgIH0pXG4gIH0sXG4gIG9ydGhvZ3JvdXBzIChJRCkge1xuICAgIGlmICghdGhpcy51c2VySWQpe1xuICAgICAgdGhpcy5zdG9wKClcbiAgICB9XG4gICAgcmV0dXJuIE9ydGhvZ3JvdXBzLmZpbmQoeyAnSUQnOiBJRCB9KTtcbiAgfSxcbiAgdHJhY2tzICgpe1xuICAgIGNvbnN0IHB1YmxpY2F0aW9uID0gdGhpcztcbiAgICBpZiAoIXB1YmxpY2F0aW9uLnVzZXJJZCl7XG4gICAgICBwdWJsaWNhdGlvbi5zdG9wKClcbiAgICAgIC8vdGhyb3cgbmV3IE1ldGVvci5FcnJvcignVW5hdXRob3JpemVkJylcbiAgICB9XG4gICAgY29uc3Qgcm9sZXMgPSBSb2xlcy5nZXRSb2xlc0ZvclVzZXIocHVibGljYXRpb24udXNlcklkKTtcbiAgICBjb25zb2xlLmxvZyhgdHJhY2tzIHB1YmxpY2F0aW9uIGZvciB1c2VyICR7cHVibGljYXRpb24udXNlcklkfSB3aXRoIHJvbGVzICR7cm9sZXN9YClcbiAgICByZXR1cm4gVHJhY2tzLmZpbmQoe1xuICAgICAgcGVybWlzc2lvbnM6IHtcbiAgICAgICAgJGluOiByb2xlc1xuICAgICAgfVxuICAgIH0pO1xuICB9LFxuICBpbnRlcnBybyAoKXtcbiAgICBpZiAoIXRoaXMudXNlcklkKXtcbiAgICAgIHRoaXMuc3RvcCgpXG4gICAgICAvL3Rocm93IG5ldyBNZXRlb3IuRXJyb3IoJ1VuYXV0aG9yaXplZCcpXG4gICAgfVxuICAgIHJldHVybiBJbnRlcnByby5maW5kKHt9KTtcbiAgfSxcbiAgZWRpdEhpc3RvcnkgKCl7XG4gICAgaWYgKCF0aGlzLnVzZXJJZCl7XG4gICAgICB0aGlzLnN0b3AoKVxuICAgICAgLy90aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdVbmF1dGhvcml6ZWQnKVxuICAgIH1cbiAgICByZXR1cm4gRWRpdEhpc3RvcnkuZmluZCh7fSk7XG4gIH1cbn0pXG5cbi8qXG5NZXRlb3IucHVibGlzaCgnYnJvd3NlcicsZnVuY3Rpb24odHJhY2ssc2VxaWQsc3RhcnQsZW5kKXtcbiAgcmV0dXJuIEdlbmVzLmZpbmQoeyAnc2VxaWQnOiBzZXFpZCwgJ3N0YXJ0JzogeyAkZ3RlOiBzdGFydCB9LCAnZW5kJzogeyAkbHRlOiBlbmQgfSB9KTtcbn0pXG4qL1xuIiwiLy8gVGhpcyBkZWZpbmVzIGEgc3RhcnRpbmcgc2V0IG9mIGRhdGEgdG8gYmUgbG9hZGVkIGlmIHRoZSBhcHAgaXMgbG9hZGVkIHdpdGggYW4gZW1wdHkgZGIuXG5pbXBvcnQgJy4vc2VydmVyLWZpeHR1cmVzLmpzJztcblxuLy8gU2V0IHVwIHNvbWUgY29uZmlndXJhdGlvbiBmb3IgYWNjb3VudCBjcmVhdGlvbjtcbmltcG9ydCAnLi91c2VyYWNjb3VudHMtY29uZmlndXJhdGlvbi5qcyc7IFxuXG4vLyBUaGlzIGZpbGUgY29uZmlndXJlcyB0aGUgQWNjb3VudHMgcGFja2FnZSB0byBkZWZpbmUgdGhlIFVJIG9mIHRoZSByZXNldCBwYXNzd29yZCBlbWFpbC5cbi8vaW1wb3J0ICcuLi9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL3Jlc2V0LXBhc3N3b3JkLWVtYWlsLmpzJztcblxuLy8gU2V0IHVwIHNvbWUgcmF0ZSBsaW1pdGluZyBhbmQgb3RoZXIgaW1wb3J0YW50IHNlY3VyaXR5IHNldHRpbmdzLlxuLy9pbXBvcnQgJy4uL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvc2VjdXJpdHkuanMnO1xuXG4vLyBUaGlzIGRlZmluZXMgYWxsIHRoZSBjb2xsZWN0aW9ucywgcHVibGljYXRpb25zIGFuZCBtZXRob2RzIHRoYXQgdGhlIGFwcGxpY2F0aW9uIHByb3ZpZGVzXG4vLyBhcyBhbiBBUEkgdG8gdGhlIGNsaWVudC5cbmltcG9ydCAnL2ltcG9ydHMvYXBpL2FwaS5qcyc7IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5cbmltcG9ydCBmcyBmcm9tICdmcyc7XG5cbmltcG9ydCBqb2JRdWV1ZSBmcm9tICcvaW1wb3J0cy9hcGkvam9icXVldWUvam9icXVldWUuanMnO1xuaW1wb3J0IHsgQXR0cmlidXRlcyB9IGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9hdHRyaWJ1dGVfY29sbGVjdGlvbi5qcyc7XG5pbXBvcnQgeyBUcmFja3MgfSBmcm9tICcvaW1wb3J0cy9hcGkvZ2Vub21lcy90cmFja19jb2xsZWN0aW9uLmpzJztcblxuTWV0ZW9yLnN0YXJ0dXAoICgpID0+IHtcbiAgaWYgKCBNZXRlb3IudXNlcnMuZmluZCgpLmNvdW50KCkgPT09IDAgKSB7XG4gICAgY29uc29sZS5sb2coJ0FkZGluZyBkZWZhdWx0IGFkbWluIHVzZXInKTtcbiAgICBjb25zdCBhZG1pbklkID0gQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gICAgICB1c2VybmFtZTogJ2FkbWluJyxcbiAgICAgIGVtYWlsOiAnYWRtaW5Abm9uZS5jb20nLFxuICAgICAgcGFzc3dvcmQ6ICdhZG1pbicsXG4gICAgICBwcm9maWxlOiB7XG4gICAgICAgIGZpcnN0X25hbWU6ICdhZG1pbicsXG4gICAgICAgIGxhc3RfbmFtZTogJ2FkbWluJyxcbiAgICAgIH1cbiAgICB9KTtcbiAgICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXMoYWRtaW5JZCxbJ2FkbWluJywnY3VyYXRvcicsJ3VzZXInLCdyZWdpc3RlcmVkJ10pO1xuXG4gICAgY29uc29sZS5sb2coJ0FkZGluZyBkZWZhdWx0IGd1ZXN0IHVzZXInKVxuICAgIGNvbnN0IGd1ZXN0SWQgPSBBY2NvdW50cy5jcmVhdGVVc2VyKHtcbiAgICAgICAgdXNlcm5hbWU6ICdndWVzdCcsXG4gICAgICAgIGVtYWlsOiAnZ3Vlc3RAbm9uZS5jb20nLFxuICAgICAgICBwYXNzd29yZDogJ2d1ZXN0JyxcbiAgICAgICAgcHJvZmlsZToge1xuICAgICAgICAgICAgZmlyc3RfbmFtZTogJ2d1ZXN0JyxcbiAgICAgICAgICAgIGxhc3RfbmFtZTogJ2d1ZXN0JyxcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgUm9sZXMuYWRkVXNlcnNUb1JvbGVzKGd1ZXN0SWQsWyd1c2VyJywncmVnaXN0ZXJlZCddKVxuICB9XG4gIC8vYWRkIHNvbWUgZGVmYXVsdCBhdHRyaWJ1dGVzIHRvIGZpbHRlciBvblxuICBjb25zdCBwZXJtYW5lbnRBdHRyaWJ1dGVzID0gW1xuICAgIHtcbiAgICAgIG5hbWU6ICdWaWV3aW5nJyxcbiAgICAgIHF1ZXJ5OiAndmlld2luZydcbiAgICB9LFxuICAgIHtcbiAgICAgIG5hbWU6ICdFZGl0aW5nJyxcbiAgICAgIHF1ZXJ5OiAnZWRpdGluZydcbiAgICB9LFxuICAgIHtcbiAgICAgIG5hbWU6ICdPcnRob2dyb3VwJyxcbiAgICAgIHF1ZXJ5OiAnb3J0aG9ncm91cCdcbiAgICB9LFxuICAgIHtcbiAgICAgIG5hbWU6ICdQcm90ZWluIGRvbWFpbnMnLFxuICAgICAgcXVlcnk6ICdzdWJmZWF0dXJlcy5wcm90ZWluX2RvbWFpbnMnXG4gICAgfV1cbiAgcGVybWFuZW50QXR0cmlidXRlcy5mb3JFYWNoKCBhdHRyaWJ1dGUgPT4ge1xuICAgIGNvbnNvbGUubG9nKGBBZGRpbmcgZGVmYXVsdCBmaWx0ZXIgb3B0aW9uOiAke2F0dHJpYnV0ZS5uYW1lfWApXG4gICAgQXR0cmlidXRlcy5maW5kQW5kTW9kaWZ5KHtcbiAgICAgIHF1ZXJ5OiB7IFxuICAgICAgICBuYW1lOiBhdHRyaWJ1dGUubmFtZSBcbiAgICAgIH0sXG4gICAgICB1cGRhdGU6IHsgXG4gICAgICAgICRzZXRPbkluc2VydDogeyBcbiAgICAgICAgICBuYW1lOiBhdHRyaWJ1dGUubmFtZSwgXG4gICAgICAgICAgcXVlcnk6IGF0dHJpYnV0ZS5xdWVyeSwgXG4gICAgICAgICAgc2hvdzogdHJ1ZSwgXG4gICAgICAgICAgY2FuRWRpdDogZmFsc2UsIFxuICAgICAgICAgIHJlc2VydmVkOiB0cnVlLFxuICAgICAgICAgIGFsbFJlZmVyZW5jZXM6IHRydWUgXG4gICAgICAgIH0gXG4gICAgICB9LCBcbiAgICAgIG5ldzogdHJ1ZSwgXG4gICAgICB1cHNlcnQ6IHRydWUgXG4gICAgfSlcbiAgfSlcblxuICBUcmFja3MuZmluZCh7IFxuICAgIGJsYXN0ZGJzOiB7IFxuICAgICAgJGV4aXN0czogdHJ1ZVxuICAgIH1cbiAgfSkuZmV0Y2goKS5maWx0ZXIodHJhY2sgPT4ge1xuICAgIGNvbnN0IGhhc051Y0RiID0gZnMuZXhpc3RzU3luYyh0cmFjay5ibGFzdGRicy5udWMpXG4gICAgY29uc3QgaGFzUHJvdERiID0gZnMuZXhpc3RzU3luYyh0cmFjay5ibGFzdGRicy5wcm90KVxuICAgIHJldHVybiAhaGFzUHJvdERiIHx8ICFoYXNOdWNEYlxuICB9KS5tYXAodHJhY2sgPT4ge1xuICAgIFRyYWNrcy51cGRhdGUoe1xuICAgICAgX2lkOiB0cmFjay5faWRcbiAgICB9LHtcbiAgICAgICR1bnNldDoge1xuICAgICAgICBibGFzdGRiczogdHJ1ZVxuICAgICAgfVxuICAgIH0pXG4gIH0pXG5cblxuICAvLyBTdGFydCB0aGUgbXlKb2JzIHF1ZXVlIHJ1bm5pbmdcbiAgam9iUXVldWUuYWxsb3coe1xuICAgIC8vIEdyYW50IHBlcm1pc3Npb24gdG8gYWRtaW4gb25seVxuICAgIGFkbWluOiBmdW5jdGlvbiAodXNlcklkLCBtZXRob2QsIHBhcmFtcykge1xuICAgICAgcmV0dXJuIFJvbGVzLnVzZXJJc0luUm9sZSh1c2VySWQsJ2FkbWluJylcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gam9iUXVldWUuc3RhcnRKb2JTZXJ2ZXIoKTtcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJztcbmltcG9ydCB7IFJvbGVzIH0gZnJvbSAnbWV0ZW9yL2FsYW5uaW5nOnJvbGVzJztcblxuaW1wb3J0IEdlbmVzIGZyb20gJy9pbXBvcnRzL2FwaS9nZW5lcy9nZW5lX2NvbGxlY3Rpb24uanMnO1xuXG5BY2NvdW50cy5vbkNyZWF0ZVVzZXIoIChvcHRpb25zLHVzZXIpID0+IHtcbiAgY29uc29sZS5sb2coJ29uQ3JlYXRlVXNlcicpXG4gIHVzZXIucm9sZXMgPSBbJ3JlZ2lzdGVyZWQnXTtcbiAgaWYgKHR5cGVvZiB1c2VyLnByb2ZpbGUgPT09ICd1bmRlZmluZWQnKXtcbiAgICB1c2VyLnByb2ZpbGUgPSB7XG4gICAgICBmaXJzdF9uYW1lOiAnJyxcbiAgICAgIGxhc3RfbmFtZTogJydcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHVzZXJcbn0pXG5cbkFjY291bnRzLm9uTG9nb3V0KCAob3B0aW9ucykgPT4ge1xuICBjb25zb2xlLmxvZygnbG9nb3V0JyxvcHRpb25zKVxuICBNZXRlb3IudXNlcnMudXBkYXRlKHtcbiAgICBfaWQ6IG9wdGlvbnMudXNlci5faWQsXG4gICAgJ3ByZXNlbmNlLnN0YXR1cyc6ICdvbmxpbmUnXG4gIH0se1xuICAgICRzZXQ6IHtcbiAgICAgICdwcmVzZW5jZS5zdGF0dXMnOiAnb2ZmbGluZSdcbiAgICB9XG4gIH0pXG5cbiAgR2VuZXMudXBkYXRlKHtcbiAgICAndmlld2luZyc6IG9wdGlvbnMudXNlci5faWRcbiAgfSx7XG4gICAgJHB1bGw6IHtcbiAgICAgICd2aWV3aW5nJzogb3B0aW9ucy51c2VyLl9pZFxuICAgIH1cbiAgfSwgKGVycixyZXMpID0+IHtcbiAgICBHZW5lcy51cGRhdGUoe1xuICAgICAgJ3ZpZXdpbmcnOiB7XG4gICAgICAgICRleGlzdHM6IHRydWUsXG4gICAgICAgICRzaXplOiAwXG4gICAgICB9XG4gICAgfSx7XG4gICAgICAkdW5zZXQ6IHtcbiAgICAgICAgJ3ZpZXdpbmcnOiAxXG4gICAgICB9XG4gICAgfSlcbiAgfSlcbiAgXG4gIC8vU2luY2Ugd2UgYXJlIG9uIHRoZSBzZXJ2ZXIsIHRoZSBmb2xsb3dpbmcgZG9lcyBub3Qgd29yay4gTmVlZCB0byBkZXNpZ24gYSAnbG9nZ2VkSW4nIHRlbXBsYXRlIC8gaGlnaCBvcmRlciBjb21wb25lbnRcbiAgLy9GbG93Um91dGVyLnJlZGlyZWN0KCcvbG9naW4nKVxufSlcblxuTWV0ZW9yLnVzZXJzLmFsbG93KHtcbiAgdXBkYXRlKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKXtcbiAgICBjb25zb2xlLmxvZygnVXNlciB1cGRhdGUnKVxuICAgIGNvbnNvbGUubG9nKGRvYylcbiAgICBjb25zb2xlLmxvZyhmaWVsZHMpXG4gICAgY29uc29sZS5sb2cobW9kaWZpZXIpXG4gICAgaWYgKHVzZXJJZCAmJiBSb2xlcy51c2VySXNJblJvbGUodXNlcklkLCAnYWRtaW4nKSl7XG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cbiAgfVxufSkiLCJcblxuXCJ1c2Ugc3RyaWN0XCI7XG5cbmlmICghbW9kdWxlLnBhcmVudCl7XG5cdGNvbnN0IGFzc2VydCA9IHJlcXVpcmUoJ2Fzc2VydCcpO1xuXHRjb25zdCBjb21tYW5kZXIgPSByZXF1aXJlKCdjb21tYW5kZXInKTtcblx0Y29uc3QgQmFieSA9IHJlcXVpcmUoJ2JhYnlwYXJzZScpO1xuXHRjb25zdCBmcyA9IHJlcXVpcmUoJ2ZzJyk7XG5cdGNvbnN0IGFzdGVyb2lkID0gcmVxdWlyZSgnYXN0ZXJvaWQnKTtcblx0Y29uc3QgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKTtcblx0Y29uc3QgV2ViU29ja2V0ID0gcmVxdWlyZSgnd3MnKTtcblxuXHRsZXQgZmlsZU5hbWUsIHJlZmVyZW5jZTtcblxuXHRjb21tYW5kZXJcblx0XHQuYXJndW1lbnRzKCc8Z2Vub21lX2Fubm90YXRpb24uZ2ZmPicpXG5cdFx0Lm9wdGlvbignLXUsIC0tdXNlcm5hbWUgPHVzZXJuYW1lPicsJ1RoZSB1c2VyIHRvIGF1dGhlbnRpY2F0ZSBhcyBbUkVRVUlSRURdJylcblx0XHQub3B0aW9uKCctcCwgLS1wYXNzd29yZCA8cGFzc3dvcmQ+JywnVGhlIHVzZXJcXCdzIHBhc3N3b3JkIFtSRVFVSVJFRF0nKVxuXHRcdC5vcHRpb24oJy1yLCAtLXJlZmVyZW5jZSA8cmVmZXJlbmNlIGdlbm9tZT4nLCdSZWZlcmVuY2UgZ2Vub21lIG9uIHdoaWNoIHRoZSBhbm5vdGF0aW9uIGZpdHMgW1JFUVVJUkVEXScpXG5cdFx0Lm9wdGlvbignLXQsIC0tdHJhY2tuYW1lIDxhbm5vdGF0aW9uIHRyYWNrbmFtZT4nLCdOYW1lIG9mIHRoZSBhbm5vdGF0aW9uIHRyYWNrJylcblx0XHQuYWN0aW9uKGZ1bmN0aW9uKGZpbGUpe1xuXHRcdFx0ZmlsZU5hbWUgPSBwYXRoLnJlc29sdmUoZmlsZSk7XG5cdFx0fSlcblx0XHQucGFyc2UocHJvY2Vzcy5hcmd2KVxuXG5cdGlmICggY29tbWFuZGVyLnVzZXJuYW1lID09PSB1bmRlZmluZWQgfHxcblx0XHRjb21tYW5kZXIucGFzc3dvcmQgPT09IHVuZGVmaW5lZCB8fFxuXHRcdGNvbW1hbmRlci5yZWZlcmVuY2UgPT09IHVuZGVmaW5lZCB8fFxuXHRcdGZpbGVOYW1lID09PSB1bmRlZmluZWQgKXtcblx0XHRjb21tYW5kZXIuaGVscCgpXG5cdH1cblxuXHRjb25zdCB0cmFja05hbWUgPSBjb21tYW5kZXIudHJhY2tuYW1lIHx8IGZpbGVOYW1lO1xuXG5cdGNvbnN0IG9wdGlvbnMgPSB7IFxuXHRcdGZpbGVOYW1lOiBmaWxlTmFtZSwgXG5cdFx0cmVmZXJlbmNlTmFtZTogY29tbWFuZGVyLnJlZmVyZW5jZSxcblx0XHR0cmFja05hbWU6IHRyYWNrTmFtZSBcblx0fVxuXHRcblx0Y29uc29sZS5sb2cocHJvY2Vzcy5hcmd2LmpvaW4oJyAnKSlcblx0Y29uc29sZS5sb2cob3B0aW9ucylcblxuXHRjb25zdCBDb25uZWN0aW9uID0gYXN0ZXJvaWQuY3JlYXRlQ2xhc3MoKVxuXG5cdGNvbnN0IHBvcnRhbCA9IG5ldyBDb25uZWN0aW9uKHtcblx0XHRlbmRwb2ludDogJ3dzOi8vbG9jYWxob3N0OjIwMDAvd2Vic29ja2V0Jyxcblx0XHRTb2NrZXRDb25zdHJ1Y3RvcjogV2ViU29ja2V0XG5cdH0pXG5cblx0cG9ydGFsLmxvZ2luV2l0aFBhc3N3b3JkKHtcblx0XHR1c2VybmFtZTogY29tbWFuZGVyLnVzZXJuYW1lLFxuXHRcdHBhc3N3b3JkOiBjb21tYW5kZXIucGFzc3dvcmRcblx0fSkudGhlbihyZXN1bHQgPT4ge1xuXHRcdHBvcnRhbC5jYWxsKCdhZGRHZmYnLCBvcHRpb25zKVxuXHRcdC50aGVuKHJlc3VsdCA9PiB7XG5cdFx0XHRjb25zb2xlLmxvZyhyZXN1bHQpXG5cdFx0XHRwb3J0YWwuZGlzY29ubmVjdCgpXG5cdFx0fSlcblx0XHQuY2F0Y2goZXJyb3IgPT4ge1xuXHRcdFx0Y29uc29sZS5sb2coZXJyb3IpXG5cdFx0XHRwb3J0YWwuZGlzY29ubmVjdCgpXG5cdFx0fSlcblx0fSlcbn1cblxuIiwiXG5cblwidXNlIHN0cmljdFwiO1xuXG5pZiAoIW1vZHVsZS5wYXJlbnQpe1xuICBjb25zdCBhc3NlcnQgPSByZXF1aXJlKCdhc3NlcnQnKTtcbiAgY29uc3QgY29tbWFuZGVyID0gcmVxdWlyZSgnY29tbWFuZGVyJyk7XG4gIC8vY29uc3QgQmFieSA9IHJlcXVpcmUoJ2JhYnlwYXJzZScpO1xuICBjb25zdCBmcyA9IHJlcXVpcmUoJ2ZzJyk7XG4gIGNvbnN0IGFzdGVyb2lkID0gcmVxdWlyZSgnYXN0ZXJvaWQnKTtcbiAgY29uc3QgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKTtcbiAgY29uc3QgV2ViU29ja2V0ID0gcmVxdWlyZSgnd3MnKTtcblxuICBsZXQgZmlsZU5hbWU7XG5cbiAgY29tbWFuZGVyXG4gICAgLmFyZ3VtZW50cygnPGludGVycHJvc2Nhbl9hbm5vdGF0aW9uLmdmZj4nKVxuICAgIC5vcHRpb24oJy11LCAtLXVzZXJuYW1lIDx1c2VybmFtZT4nLCdUaGUgdXNlciB0byBhdXRoZW50aWNhdGUgYXMgW1JFUVVJUkVEXScpXG4gICAgLm9wdGlvbignLXAsIC0tcGFzc3dvcmQgPHBhc3N3b3JkPicsJ1RoZSB1c2VyXFwncyBwYXNzd29yZCBbUkVRVUlSRURdJylcbiAgICAub3B0aW9uKCctdCwgLS10cmFja25hbWUgPGFubm90YXRpb24gdHJhY2tuYW1lPicsJ05hbWUgb2YgdGhlIGFubm90YXRpb24gdHJhY2snKVxuICAgIC5hY3Rpb24oZnVuY3Rpb24oZmlsZSl7XG4gICAgICBmaWxlTmFtZSA9IHBhdGgucmVzb2x2ZShmaWxlKTtcbiAgICB9KVxuICAgIC5wYXJzZShwcm9jZXNzLmFyZ3YpXG5cbiAgaWYgKCBjb21tYW5kZXIudXNlcm5hbWUgPT09IHVuZGVmaW5lZCB8fFxuICAgIGNvbW1hbmRlci5wYXNzd29yZCA9PT0gdW5kZWZpbmVkIHx8XG4gICAgY29tbWFuZGVyLnRyYWNrbmFtZSA9PT0gdW5kZWZpbmVkIHx8XG4gICAgZmlsZU5hbWUgPT09IHVuZGVmaW5lZCApe1xuICAgIGNvbW1hbmRlci5oZWxwKClcbiAgfVxuXG4gIGNvbnN0IG9wdGlvbnMgPSB7IFxuICAgIGZpbGVOYW1lOiBmaWxlTmFtZSwgXG4gICAgdHJhY2tOYW1lOiBjb21tYW5kZXIudHJhY2tuYW1lIFxuICB9XG4gIFxuICBjb25zb2xlLmxvZyhwcm9jZXNzLmFyZ3Yuam9pbignICcpKVxuICBjb25zb2xlLmxvZyhvcHRpb25zKVxuXG4gIGNvbnN0IENvbm5lY3Rpb24gPSBhc3Rlcm9pZC5jcmVhdGVDbGFzcygpXG5cbiAgY29uc3QgcG9ydGFsID0gbmV3IENvbm5lY3Rpb24oe1xuICAgIGVuZHBvaW50OiAnd3M6Ly9sb2NhbGhvc3Q6MzAwMC93ZWJzb2NrZXQnLFxuICAgIFNvY2tldENvbnN0cnVjdG9yOiBXZWJTb2NrZXRcbiAgfSlcblxuICBwb3J0YWwubG9naW5XaXRoUGFzc3dvcmQoe1xuICAgIHVzZXJuYW1lOiBjb21tYW5kZXIudXNlcm5hbWUsXG4gICAgcGFzc3dvcmQ6IGNvbW1hbmRlci5wYXNzd29yZFxuICB9KS50aGVuKHJlc3VsdCA9PiB7XG4gICAgcG9ydGFsLmNhbGwoJ2FkZEludGVycHJvc2NhbicsIG9wdGlvbnMpXG4gICAgLnRoZW4ocmVzdWx0ID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKHJlc3VsdClcbiAgICAgIHBvcnRhbC5kaXNjb25uZWN0KClcbiAgICB9KVxuICAgIC5jYXRjaChlcnJvciA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhlcnJvcilcbiAgICAgIHBvcnRhbC5kaXNjb25uZWN0KClcbiAgICB9KVxuICB9KVxufVxuXG4iLCJcblxuXCJ1c2Ugc3RyaWN0XCI7XG5cbmlmICghbW9kdWxlLnBhcmVudCl7XG4gIGNvbnN0IGNvbW1hbmRlciA9IHJlcXVpcmUoJ2NvbW1hbmRlcicpO1xuICBjb25zdCBhc3Rlcm9pZCA9IHJlcXVpcmUoJ2FzdGVyb2lkJyk7XG4gIGNvbnN0IHBhdGggPSByZXF1aXJlKCdwYXRoJyk7XG4gIGNvbnN0IFdlYlNvY2tldCA9IHJlcXVpcmUoJ3dzJyk7XG5cbiAgbGV0IGZvbGRlcjtcblxuICBjb21tYW5kZXJcbiAgICAuYXJndW1lbnRzKCc8aW50ZXJwcm9zY2FuX2Fubm90YXRpb24uZ2ZmPicpXG4gICAgLm9wdGlvbignLXUsIC0tdXNlcm5hbWUgPHVzZXJuYW1lPicsJ1RoZSB1c2VyIHRvIGF1dGhlbnRpY2F0ZSBhcyBbUkVRVUlSRURdJylcbiAgICAub3B0aW9uKCctcCwgLS1wYXNzd29yZCA8cGFzc3dvcmQ+JywnVGhlIHVzZXJcXCdzIHBhc3N3b3JkIFtSRVFVSVJFRF0nKVxuICAgIC5hY3Rpb24oZnVuY3Rpb24oZmlsZSl7XG4gICAgICBmb2xkZXIgPSBwYXRoLnJlc29sdmUoZmlsZSk7XG4gICAgfSlcbiAgICAucGFyc2UocHJvY2Vzcy5hcmd2KVxuXG4gIGlmICggY29tbWFuZGVyLnVzZXJuYW1lID09PSB1bmRlZmluZWQgfHxcbiAgICBjb21tYW5kZXIucGFzc3dvcmQgPT09IHVuZGVmaW5lZCB8fFxuICAgIGZvbGRlciA9PT0gdW5kZWZpbmVkICl7XG4gICAgY29tbWFuZGVyLmhlbHAoKVxuICB9XG5cbiAgY29uc3Qgb3B0aW9ucyA9IHsgXG4gICAgZm9sZGVyOiBmb2xkZXIgXG4gIH1cbiAgXG4gIGNvbnNvbGUubG9nKHByb2Nlc3MuYXJndi5qb2luKCcgJykpXG4gIGNvbnNvbGUubG9nKG9wdGlvbnMpXG5cbiAgY29uc3QgQ29ubmVjdGlvbiA9IGFzdGVyb2lkLmNyZWF0ZUNsYXNzKClcblxuICBjb25zdCBwb3J0YWwgPSBuZXcgQ29ubmVjdGlvbih7XG4gICAgZW5kcG9pbnQ6ICd3czovL2xvY2FsaG9zdDozMDAwL3dlYnNvY2tldCcsXG4gICAgU29ja2V0Q29uc3RydWN0b3I6IFdlYlNvY2tldFxuICB9KVxuXG4gIHBvcnRhbC5sb2dpbldpdGhQYXNzd29yZCh7XG4gICAgdXNlcm5hbWU6IGNvbW1hbmRlci51c2VybmFtZSxcbiAgICBwYXNzd29yZDogY29tbWFuZGVyLnBhc3N3b3JkXG4gIH0pLnRoZW4ocmVzdWx0ID0+IHtcbiAgICBwb3J0YWwuY2FsbCgnYWRkT3J0aG9ncm91cFRyZWVzJywgb3B0aW9ucylcbiAgICAudGhlbihyZXN1bHQgPT4ge1xuICAgICAgY29uc29sZS5sb2cocmVzdWx0KVxuICAgICAgcG9ydGFsLmRpc2Nvbm5lY3QoKVxuICAgIH0pXG4gICAgLmNhdGNoKGVycm9yID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKGVycm9yKVxuICAgICAgcG9ydGFsLmRpc2Nvbm5lY3QoKVxuICAgIH0pXG4gIH0pXG59XG5cbiIsIlxuXG5cInVzZSBzdHJpY3RcIjtcblxuaWYgKCFtb2R1bGUucGFyZW50KXtcblx0Y29uc3QgYXNzZXJ0ID0gcmVxdWlyZSgnYXNzZXJ0Jyk7XG5cdGNvbnN0IGNvbW1hbmRlciA9IHJlcXVpcmUoJ2NvbW1hbmRlcicpO1xuXHRjb25zdCBmcyA9IHJlcXVpcmUoJ2ZzJyk7XG5cdGNvbnN0IGFzdGVyb2lkID0gcmVxdWlyZSgnYXN0ZXJvaWQnKTtcblx0Y29uc3QgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKTtcblx0Y29uc3QgV2ViU29ja2V0ID0gcmVxdWlyZSgnd3MnKTtcblxuXHRsZXQgZmlsZU5hbWUsIHJlZmVyZW5jZTtcblxuXHRjb21tYW5kZXJcblx0XHQuYXJndW1lbnRzKCc8cmVmZXJlbmNlLmZhc3RhPicpXG5cdFx0Lm9wdGlvbignLXUsIC0tdXNlcm5hbWUgPHVzZXJuYW1lPicsJ1RoZSB1c2VyIHRvIGF1dGhlbnRpY2F0ZSBhcyBbUkVRVUlSRURdJylcblx0XHQub3B0aW9uKCctcCwgLS1wYXNzd29yZCA8cGFzc3dvcmQ+JywnVGhlIHVzZXJcXCdzIHBhc3N3b3JkIFtSRVFVSVJFRF0nKVxuXHRcdC5vcHRpb24oJy1yLCAtLXJlZmVyZW5jZW5hbWUgPHJlZmVyZW5jZSBuYW1lPicsJ1JlZmVyZW5jZSBuYW1lJylcblx0XHQuYWN0aW9uKGZ1bmN0aW9uKGZpbGUpe1xuXHRcdFx0ZmlsZU5hbWUgPSBwYXRoLnJlc29sdmUoZmlsZSk7XG5cdFx0fSlcblx0XHQucGFyc2UocHJvY2Vzcy5hcmd2KVxuXG5cdGlmICggY29tbWFuZGVyLnVzZXJuYW1lID09PSB1bmRlZmluZWQgfHxcblx0XHRjb21tYW5kZXIucGFzc3dvcmQgPT09IHVuZGVmaW5lZCB8fFxuXHRcdGZpbGVOYW1lID09PSB1bmRlZmluZWQgKXtcblx0XHRjb21tYW5kZXIuaGVscCgpXG5cdH1cblxuXHRjb25zdCByZWZlcmVuY2VOYW1lID0gY29tbWFuZGVyLnJlZmVyZW5jZW5hbWUgfHwgZmlsZU5hbWU7XG5cblx0Y29uc3Qgb3B0aW9ucyA9IHtcblx0XHRmaWxlTmFtZTogZmlsZU5hbWUsIFxuXHRcdHJlZmVyZW5jZU5hbWU6IHJlZmVyZW5jZU5hbWVcblx0fVxuXG5cdGNvbnNvbGUubG9nKHByb2Nlc3MuYXJndi5qb2luKCcgJykpXG5cdGNvbnNvbGUubG9nKG9wdGlvbnMpXG5cblx0Y29uc3QgQ29ubmVjdGlvbiA9IGFzdGVyb2lkLmNyZWF0ZUNsYXNzKClcblxuXHRjb25zdCBwb3J0YWwgPSBuZXcgQ29ubmVjdGlvbih7XG5cdFx0ZW5kcG9pbnQ6ICd3czovL2xvY2FsaG9zdDoyMDAwL3dlYnNvY2tldCcsXG5cdFx0U29ja2V0Q29uc3RydWN0b3I6IFdlYlNvY2tldFxuXHR9KVxuXG5cdHBvcnRhbC5sb2dpbldpdGhQYXNzd29yZCh7XG5cdFx0dXNlcm5hbWU6IGNvbW1hbmRlci51c2VybmFtZSxcblx0XHRwYXNzd29yZDogY29tbWFuZGVyLnBhc3N3b3JkXG5cdH0pLnRoZW4ocmVzdWx0ID0+IHtcblx0XHRwb3J0YWwuY2FsbCgnYWRkUmVmZXJlbmNlJywgb3B0aW9ucylcblx0XHQudGhlbihyZXN1bHQgPT4ge1xuXHRcdFx0Y29uc29sZS5sb2cocmVzdWx0KVxuXHRcdFx0cG9ydGFsLmRpc2Nvbm5lY3QoKVxuXHRcdH0pXG5cdFx0LmNhdGNoKGVycm9yID0+IHtcblx0XHRcdGNvbnNvbGUubG9nKGVycm9yKVxuXHRcdFx0cHJvY2Vzcy5leGl0KDEpXG5cdFx0XHRwb3J0YWwuZGlzY29ubmVjdCgpXG5cdFx0fSlcdFxuXHR9KS5jYXRjaChlcnJvciA9PiB7XG5cdFx0Y29uc29sZS5sb2coZXJyb3IpXG5cdH0pXG59XG5cbiIsIlxuXG5cInVzZSBzdHJpY3RcIjtcblxuXG5pZiAoIW1vZHVsZS5wYXJlbnQpe1xuXHRjb25zdCBhc3NlcnQgPSByZXF1aXJlKCdhc3NlcnQnKTtcblx0Y29uc3QgY29tbWFuZGVyID0gcmVxdWlyZSgnY29tbWFuZGVyJyk7XG5cdGNvbnN0IEJhYnkgPSByZXF1aXJlKCdiYWJ5cGFyc2UnKTtcblx0Y29uc3QgZnMgPSByZXF1aXJlKCdmcycpO1xuXHRjb25zdCBhc3Rlcm9pZCA9IHJlcXVpcmUoJ2FzdGVyb2lkJyk7XG5cdGNvbnN0IHBhdGggPSByZXF1aXJlKCdwYXRoJyk7XG5cdGNvbnN0IFdlYlNvY2tldCA9IHJlcXVpcmUoJ3dzJyk7XG5cblx0bGV0IGZpbGVOYW1lLCByZWZlcmVuY2U7XG5cblx0Y29tbWFuZGVyXG5cdFx0LmFyZ3VtZW50cygnPGthbGxpc3RvX2FidW5kYW5jZS50c3Y+Jylcblx0XHQub3B0aW9uKCctdSwgLS11c2VybmFtZSA8dXNlcm5hbWU+JywnVGhlIHVzZXIgdG8gYXV0aGVudGljYXRlIGFzIFtSRVFVSVJFRF0nKVxuXHRcdC5vcHRpb24oJy1wLCAtLXBhc3N3b3JkIDxwYXNzd29yZD4nLCdUaGUgdXNlclxcJ3MgcGFzc3dvcmQgW1JFUVVJUkVEXScpXG5cdFx0Lm9wdGlvbignLXQsIC0tdHJhY2tuYW1lIDxhbm5vdGF0aW9uIHRyYWNrbmFtZT4nLCdOYW1lIG9mIHRoZSBhbm5vdGF0aW9uIHRyYWNrIHRvIHdoaWNoIHRoZSBnZW5lcyBiZWxvbmcgW1JFUVVJUkVEXScpXG5cdFx0Lm9wdGlvbignLXMsIC0tc2FtcGxlbmFtZSA8c2FtcGxlIG5hbWU+JywnTmFtZSBvZiB0aGUgc2FtcGxlIFtSRVFVSVJFRF0nKVxuXHRcdC5vcHRpb24oJy1lLCAtLWV4cGVyaW1lbnRncm91cCBbZXhwZXJpbWVudCBncm91cCBuYW1lXScsJ05hbWUgb2YgdGhlIGV4cGVyaW1lbnQgdG8gd2hpY2ggdGhlIHNhbXBsZSBiZWxvbmdzJylcblx0XHQub3B0aW9uKCctciwgLS1yZXBsaWNhZ3JvdXAgW3JlcGxpY2EgZ3JvdXAgbmFtZV0nLCdOYW1lIG9mIHRoZSByZXBsaWNhIGdyb3VwIHRvIHdoaWNoIHRoZSBzYW1wbGUgYmVsb25ncycpXG5cdFx0Lm9wdGlvbignLWQsIC0tZGVzY3JpcHRpb24gW3NhbXBsZSBkZXNjcmlwdGlvbl0nLCdEZXNjcmlwdGlvbiBvZiB0aGUgc2FtcGxlJylcblx0XHQuYWN0aW9uKGZ1bmN0aW9uKGZpbGUpe1xuXHRcdFx0ZmlsZU5hbWUgPSBwYXRoLnJlc29sdmUoZmlsZSk7XG5cdFx0fSlcblx0XHQucGFyc2UocHJvY2Vzcy5hcmd2KVxuXG5cdGlmICggY29tbWFuZGVyLnVzZXJuYW1lID09PSB1bmRlZmluZWQgfHxcblx0XHRjb21tYW5kZXIucGFzc3dvcmQgPT09IHVuZGVmaW5lZCB8fFxuXHRcdGNvbW1hbmRlci50cmFja25hbWUgPT09IHVuZGVmaW5lZCB8fFxuXHRcdGNvbW1hbmRlci5zYW1wbGVuYW1lID09PSB1bmRlZmluZWQgfHxcblx0XHRmaWxlTmFtZSA9PT0gdW5kZWZpbmVkICl7XG5cdFx0Y29tbWFuZGVyLmhlbHAoKVxuXHR9XG5cblx0Y29uc29sZS5sb2coY29tbWFuZGVyLnVzZXJuYW1lLGNvbW1hbmRlci5wYXNzd29yZCxmaWxlTmFtZSxjb21tYW5kZXIudHJhY2tuYW1lKVxuXHRcblx0Y29uc3QgY29uZmlnID0ge1xuXHRcdGZpbGVOYW1lOiBmaWxlTmFtZSxcblx0XHR0cmFja05hbWU6IGNvbW1hbmRlci50cmFja25hbWUsXG5cdFx0c2FtcGxlTmFtZTogY29tbWFuZGVyLnNhbXBsZW5hbWUsXG5cdFx0ZXhwZXJpbWVudEdyb3VwOiBjb21tYW5kZXIuZXhwZXJpbWVudGdyb3VwID8gY29tbWFuZGVyLmV4cGVyaW1lbnRncm91cCA6IGNvbW1hbmRlci5zYW1wbGVuYW1lLFxuXHRcdHJlcGxpY2FHcm91cDogY29tbWFuZGVyLnJlcGxpY2Fncm91cCA/IGNvbW1hbmRlci5yZXBsaWNhZ3JvdXAgOiBjb21tYW5kZXIuc2FtcGxlbmFtZSxcblx0XHRkZXNjcmlwdGlvbjogJ2Rlc2NyaXB0aW9uJy8vY29tbWFuZGVyLmRlc2NyaXB0aW9uID8gY29tbWFuZGVyLmRlc2NyaXB0aW9uIDogY29tbWFuZGVyLnNhbXBsZW5hbWUsXG5cdH1cblxuXHRjb25zb2xlLmxvZyhjb25maWcpXG5cblx0Y29uc3QgQ29ubmVjdGlvbiA9IGFzdGVyb2lkLmNyZWF0ZUNsYXNzKClcblxuXHRjb25zdCBwb3J0YWwgPSBuZXcgQ29ubmVjdGlvbih7XG5cdFx0ZW5kcG9pbnQ6ICd3czovL2xvY2FsaG9zdDozMDAwL3dlYnNvY2tldCcsXG5cdFx0U29ja2V0Q29uc3RydWN0b3I6IFdlYlNvY2tldFxuXHR9KVxuXG5cdHBvcnRhbC5sb2dpbldpdGhQYXNzd29yZCh7XG5cdFx0dXNlcm5hbWU6IGNvbW1hbmRlci51c2VybmFtZSxcblx0XHRwYXNzd29yZDogY29tbWFuZGVyLnBhc3N3b3JkXG5cdH0pLnRoZW4ocmVzdWx0ID0+IHtcblx0XHRyZXR1cm4gcG9ydGFsLmNhbGwoJ2FkZFRyYW5zY3JpcHRvbWUnLCBjb25maWcpXG5cdH0pLnRoZW4ocmVzdWx0ID0+IHtcblx0XHRjb25zb2xlLmxvZyhyZXN1bHQpXG5cdFx0cG9ydGFsLmRpc2Nvbm5lY3QoKVxuXHRcdC8vcHJvY2Vzcy5leGl0KDApXG5cdH0pXG5cdC5jYXRjaChlcnJvciA9PiB7XG5cdFx0Y29uc29sZS5sb2coZXJyb3IpXG5cdFx0cG9ydGFsLmRpc2Nvbm5lY3QoKVxuXHRcdC8vcHJvY2Vzcy5leGl0KDEpXG5cdH0pXHRcbn1cblxuIiwiXG5cbmlmICghbW9kdWxlLnBhcmVudCl7XG5cdGNvbnN0IGNvbW1hbmRlciA9IHJlcXVpcmUoJ2NvbW1hbmRlcicpO1xuXHRjb25zdCBhc3Rlcm9pZCA9IHJlcXVpcmUoJ2FzdGVyb2lkJyk7XG5cdGNvbnN0IFdlYlNvY2tldCA9IHJlcXVpcmUoJ3dzJyk7XG5cblx0bGV0IHdoYXQ7XG5cdFxuXHRjb21tYW5kZXJcblx0XHQuYXJndW1lbnRzKCc8d2hhdD4nKVxuXHRcdC5vcHRpb24oJy11LCAtLXVzZXJuYW1lIDx1c2VybmFtZT4nLCdUaGUgdXNlciB0byBhdXRoZW50aWNhdGUgYXMgW1JFUVVJUkVEXScpXG5cdFx0Lm9wdGlvbignLXAsIC0tcGFzc3dvcmQgPHBhc3N3b3JkPicsJ1RoZSB1c2VyXFwncyBwYXNzd29yZCBbUkVRVUlSRURdJylcblx0XHQuYWN0aW9uKGZ1bmN0aW9uKHZhbHVlKXtcblx0XHRcdHdoYXQgPSB2YWx1ZTtcblx0XHR9KVxuXHRcdC5wYXJzZShwcm9jZXNzLmFyZ3YpXG5cblx0aWYgKCBjb21tYW5kZXIudXNlcm5hbWUgPT09IHVuZGVmaW5lZCB8fFxuXHRcdGNvbW1hbmRlci5wYXNzd29yZCA9PT0gdW5kZWZpbmVkIHx8XG5cdFx0d2hhdCA9PT0gdW5kZWZpbmVkICl7XG5cdFx0Y29tbWFuZGVyLmhlbHAoKVxuXHR9XG5cblx0Y29uc29sZS5sb2coY29tbWFuZGVyLnVzZXJuYW1lLGNvbW1hbmRlci5wYXNzd29yZCx3aGF0KVxuXHRcblx0Y29uc3QgQ29ubmVjdGlvbiA9IGFzdGVyb2lkLmNyZWF0ZUNsYXNzKClcblxuXHRjb25zdCBwb3J0YWwgPSBuZXcgQ29ubmVjdGlvbih7XG5cdFx0ZW5kcG9pbnQ6ICd3czovL2xvY2FsaG9zdDozMDAwL3dlYnNvY2tldCcsXG5cdFx0U29ja2V0Q29uc3RydWN0b3I6IFdlYlNvY2tldFxuXHR9KVxuXG5cdHBvcnRhbC5sb2dpbldpdGhQYXNzd29yZCh7XG5cdFx0dXNlcm5hbWU6IGNvbW1hbmRlci51c2VybmFtZSxcblx0XHRwYXNzd29yZDogY29tbWFuZGVyLnBhc3N3b3JkXG5cdH0pXG5cblx0cG9ydGFsLmNhbGwoJ2xpc3QnLCB3aGF0KVxuXHRcdC50aGVuKHJlc3VsdCA9PiB7XG5cdFx0XHRjb25zb2xlLmxvZyhyZXN1bHQpXG5cdFx0XHRwb3J0YWwuZGlzY29ubmVjdCgpXG5cdFx0fSlcblx0XHQuY2F0Y2goZXJyb3IgPT4ge1xuXHRcdFx0Y29uc29sZS5sb2coZXJyb3IpXG5cdFx0XHRwb3J0YWwuZGlzY29ubmVjdCgpXG5cdFx0fSlcdFxufSIsIlxuXG5cInVzZSBzdHJpY3RcIjtcblxuaWYgKCFtb2R1bGUucGFyZW50KXtcbiAgY29uc3Qgc3Bhd24gPSByZXF1aXJlKCdjaGlsZC1wcm9jZXNzLXByb21pc2UnKS5zcGF3bjtcblxuICBjb25zdCByZXBlYXRzID0gMTAwMDAwMDtcblxuICBzcGF3bigndGVlJyxbXSx7Y2FwdHVyZTogWydzdGRvdXQnLCdzdGRlcnInXX0pXG4gICAgLnByb2dyZXNzKCBjaGlsZFByb2Nlc3MgPT4ge1xuICAgICAgbGV0IHN0ZGluID0gY2hpbGRQcm9jZXNzLnN0ZGluO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZXBlYXRzOyBpKyspe1xuICAgICAgICBsZXQgc3RyaW5nID0gTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikgKyAnXFxuJ1xuICAgICAgICBzdGRpbi53cml0ZShzdHJpbmcpXG4gICAgICB9XG4gICAgICBzdGRpbi5lbmQoKVxuICAgIH0pXG4gICAgLnRoZW4ocmVzdWx0ID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKHJlc3VsdC5zdGRvdXQudG9TdHJpbmcoKSlcbiAgICB9KVxuICAgIC5jYXRjaChlcnJvciA9PiB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycm9yKVxuICAgIH0pXG59XG5cblxuIiwiaW1wb3J0ICcvaW1wb3J0cy9zdGFydHVwL3NlcnZlcic7Il19
