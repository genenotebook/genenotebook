(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Random = Package.random.Random;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var UserPresenceSessions, UserPresenceServers;

var require = meteorInstall({"node_modules":{"meteor":{"danimal:userpresence":{"userPresence.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// packages/danimal_userpresence/userPresence.js                                        //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
// serverId - unique per server per restart
var serverId = Random.id(); // user connections

UserPresenceSessions = new Mongo.Collection('userpresencesessions'); // list of servers

UserPresenceServers = new Mongo.Collection('userpresenceservers');

UserPresenceServers._ensureIndex({
  ping: 1
});

UserPresenceServers._ensureIndex({
  serverId: 1
});

Meteor.users._ensureIndex({
  'presence.serverId': 1
});

UserPresenceSessions._ensureIndex({
  userId: 1
}); // keep track of which servers are online


Meteor.setInterval(function () {
  let find = {
    serverId: serverId
  };
  let modifier = {
    $set: {
      ping: new Date()
    }
  };
  UserPresenceServers.upsert(find, modifier);
}, 1000 * 30); // remove old servers and sessions
// update status of users connected to that server

Meteor.setInterval(function () {
  let cutoff = new Date();
  cutoff.setMinutes(new Date().getMinutes() - 5);
  UserPresenceServers.find({
    ping: {
      $lt: cutoff
    }
  }).forEach(function (server) {
    UserPresenceServers.remove(server._id);
    UserPresenceSessions.remove({
      serverId: server.serverId
    });
    Meteor.users.find({
      'presence.serverId': server.serverId
    }).forEach(function (user) {
      trackUserStatus(user._id);
    });
  });
}, 1000 * 10); // track user connection and disconnection

Meteor.publish(null, function () {
  var self = this;

  if (self.userId && self.connection && self.connection.id) {
    userConnected(self.userId, self.connection);
    self.onStop(function () {
      userDisconnected(self.userId, self.connection);
    });
  }

  self.ready();
});

var userConnected = function (userId, connection) {
  UserPresenceSessions.insert({
    serverId: serverId,
    userId: userId,
    connectionId: connection.id,
    createdAt: new Date()
  });
  trackUserStatus(userId, connection);
};

var userDisconnected = function (userId, connection) {
  UserPresenceSessions.remove({
    userId: userId,
    connectionId: connection.id
  });
  trackUserStatus(userId, connection);
};

var trackUserStatus = function (userId, connection) {
  let presence = {
    updatedAt: new Date(),
    serverId: serverId
  };

  if (connection) {
    presence.clientAddress = connection.clientAddress;
    presence.httpHeaders = connection.httpHeaders;
  }

  let isOnline = UserPresenceSessions.find({
    userId: userId
  }).count();

  if (isOnline) {
    presence.status = 'online';
  } else {
    presence.status = 'offline';
  }

  Meteor.users.update(userId, {
    $set: {
      presence: presence
    }
  });
};
//////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/node_modules/meteor/danimal:userpresence/userPresence.js");

/* Exports */
Package._define("danimal:userpresence", {
  UserPresenceSessions: UserPresenceSessions,
  UserPresenceServers: UserPresenceServers
});

})();

//# sourceURL=meteor://💻app/packages/danimal_userpresence.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvZGFuaW1hbDp1c2VycHJlc2VuY2UvdXNlclByZXNlbmNlLmpzIl0sIm5hbWVzIjpbInNlcnZlcklkIiwiUmFuZG9tIiwiaWQiLCJVc2VyUHJlc2VuY2VTZXNzaW9ucyIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsIlVzZXJQcmVzZW5jZVNlcnZlcnMiLCJfZW5zdXJlSW5kZXgiLCJwaW5nIiwiTWV0ZW9yIiwidXNlcnMiLCJ1c2VySWQiLCJzZXRJbnRlcnZhbCIsImZpbmQiLCJtb2RpZmllciIsIiRzZXQiLCJEYXRlIiwidXBzZXJ0IiwiY3V0b2ZmIiwic2V0TWludXRlcyIsImdldE1pbnV0ZXMiLCIkbHQiLCJmb3JFYWNoIiwic2VydmVyIiwicmVtb3ZlIiwiX2lkIiwidXNlciIsInRyYWNrVXNlclN0YXR1cyIsInB1Ymxpc2giLCJzZWxmIiwiY29ubmVjdGlvbiIsInVzZXJDb25uZWN0ZWQiLCJvblN0b3AiLCJ1c2VyRGlzY29ubmVjdGVkIiwicmVhZHkiLCJpbnNlcnQiLCJjb25uZWN0aW9uSWQiLCJjcmVhdGVkQXQiLCJwcmVzZW5jZSIsInVwZGF0ZWRBdCIsImNsaWVudEFkZHJlc3MiLCJodHRwSGVhZGVycyIsImlzT25saW5lIiwiY291bnQiLCJzdGF0dXMiLCJ1cGRhdGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBLElBQUlBLFdBQVdDLE9BQU9DLEVBQVAsRUFBZixDLENBR0E7O0FBQ0FDLHVCQUF1QixJQUFJQyxNQUFNQyxVQUFWLENBQXFCLHNCQUFyQixDQUF2QixDLENBRUE7O0FBQ0FDLHNCQUFzQixJQUFJRixNQUFNQyxVQUFWLENBQXFCLHFCQUFyQixDQUF0Qjs7QUFHQUMsb0JBQW9CQyxZQUFwQixDQUFpQztBQUFDQyxRQUFLO0FBQU4sQ0FBakM7O0FBQ0FGLG9CQUFvQkMsWUFBcEIsQ0FBaUM7QUFBQ1AsWUFBUztBQUFWLENBQWpDOztBQUNBUyxPQUFPQyxLQUFQLENBQWFILFlBQWIsQ0FBMEI7QUFBQyx1QkFBb0I7QUFBckIsQ0FBMUI7O0FBQ0FKLHFCQUFxQkksWUFBckIsQ0FBa0M7QUFBQ0ksVUFBTztBQUFSLENBQWxDLEUsQ0FHQTs7O0FBQ0FGLE9BQU9HLFdBQVAsQ0FBbUIsWUFBVztBQUM1QixNQUFJQyxPQUFPO0FBQUNiLGNBQVNBO0FBQVYsR0FBWDtBQUNBLE1BQUljLFdBQVc7QUFBQ0MsVUFBTTtBQUFDUCxZQUFLLElBQUlRLElBQUo7QUFBTjtBQUFQLEdBQWY7QUFDQVYsc0JBQW9CVyxNQUFwQixDQUEyQkosSUFBM0IsRUFBaUNDLFFBQWpDO0FBQ0QsQ0FKRCxFQUlHLE9BQU8sRUFKVixFLENBT0E7QUFDQTs7QUFDQUwsT0FBT0csV0FBUCxDQUFtQixZQUFXO0FBQzVCLE1BQUlNLFNBQVMsSUFBSUYsSUFBSixFQUFiO0FBQ0FFLFNBQU9DLFVBQVAsQ0FBa0IsSUFBSUgsSUFBSixHQUFXSSxVQUFYLEtBQTBCLENBQTVDO0FBQ0FkLHNCQUFvQk8sSUFBcEIsQ0FBeUI7QUFBQ0wsVUFBTTtBQUFDYSxXQUFJSDtBQUFMO0FBQVAsR0FBekIsRUFBK0NJLE9BQS9DLENBQXVELFVBQVNDLE1BQVQsRUFBaUI7QUFDdEVqQix3QkFBb0JrQixNQUFwQixDQUEyQkQsT0FBT0UsR0FBbEM7QUFDQXRCLHlCQUFxQnFCLE1BQXJCLENBQTRCO0FBQUN4QixnQkFBU3VCLE9BQU92QjtBQUFqQixLQUE1QjtBQUNBUyxXQUFPQyxLQUFQLENBQWFHLElBQWIsQ0FBa0I7QUFBQywyQkFBb0JVLE9BQU92QjtBQUE1QixLQUFsQixFQUF5RHNCLE9BQXpELENBQWlFLFVBQVNJLElBQVQsRUFBZTtBQUM5RUMsc0JBQWdCRCxLQUFLRCxHQUFyQjtBQUNELEtBRkQ7QUFHRCxHQU5EO0FBT0QsQ0FWRCxFQVVHLE9BQU8sRUFWVixFLENBY0E7O0FBQ0FoQixPQUFPbUIsT0FBUCxDQUFlLElBQWYsRUFBcUIsWUFBVTtBQUM3QixNQUFJQyxPQUFPLElBQVg7O0FBRUEsTUFBR0EsS0FBS2xCLE1BQUwsSUFBZWtCLEtBQUtDLFVBQXBCLElBQWtDRCxLQUFLQyxVQUFMLENBQWdCNUIsRUFBckQsRUFBd0Q7QUFDdEQ2QixrQkFBY0YsS0FBS2xCLE1BQW5CLEVBQTJCa0IsS0FBS0MsVUFBaEM7QUFFQUQsU0FBS0csTUFBTCxDQUFZLFlBQVU7QUFDcEJDLHVCQUFpQkosS0FBS2xCLE1BQXRCLEVBQThCa0IsS0FBS0MsVUFBbkM7QUFDRCxLQUZEO0FBR0Q7O0FBRURELE9BQUtLLEtBQUw7QUFDRCxDQVpEOztBQWdCQSxJQUFJSCxnQkFBZ0IsVUFBU3BCLE1BQVQsRUFBaUJtQixVQUFqQixFQUE2QjtBQUMvQzNCLHVCQUFxQmdDLE1BQXJCLENBQTRCO0FBQUNuQyxjQUFTQSxRQUFWO0FBQW9CVyxZQUFPQSxNQUEzQjtBQUFtQ3lCLGtCQUFhTixXQUFXNUIsRUFBM0Q7QUFBK0RtQyxlQUFVLElBQUlyQixJQUFKO0FBQXpFLEdBQTVCO0FBQ0FXLGtCQUFnQmhCLE1BQWhCLEVBQXdCbUIsVUFBeEI7QUFDRCxDQUhEOztBQU9BLElBQUlHLG1CQUFtQixVQUFTdEIsTUFBVCxFQUFpQm1CLFVBQWpCLEVBQTZCO0FBQ2xEM0IsdUJBQXFCcUIsTUFBckIsQ0FBNEI7QUFBQ2IsWUFBT0EsTUFBUjtBQUFnQnlCLGtCQUFhTixXQUFXNUI7QUFBeEMsR0FBNUI7QUFDQXlCLGtCQUFnQmhCLE1BQWhCLEVBQXdCbUIsVUFBeEI7QUFDRCxDQUhEOztBQU9BLElBQUlILGtCQUFrQixVQUFTaEIsTUFBVCxFQUFpQm1CLFVBQWpCLEVBQTZCO0FBQ2pELE1BQUlRLFdBQVc7QUFDYkMsZUFBVyxJQUFJdkIsSUFBSixFQURFO0FBRWJoQixjQUFVQTtBQUZHLEdBQWY7O0FBS0EsTUFBSThCLFVBQUosRUFBZ0I7QUFDZFEsYUFBU0UsYUFBVCxHQUF5QlYsV0FBV1UsYUFBcEM7QUFDQUYsYUFBU0csV0FBVCxHQUF1QlgsV0FBV1csV0FBbEM7QUFDRDs7QUFFRCxNQUFJQyxXQUFXdkMscUJBQXFCVSxJQUFyQixDQUEwQjtBQUFDRixZQUFPQTtBQUFSLEdBQTFCLEVBQTJDZ0MsS0FBM0MsRUFBZjs7QUFFQSxNQUFJRCxRQUFKLEVBQWM7QUFDWkosYUFBU00sTUFBVCxHQUFrQixRQUFsQjtBQUNELEdBRkQsTUFFTztBQUNMTixhQUFTTSxNQUFULEdBQWtCLFNBQWxCO0FBQ0Q7O0FBRURuQyxTQUFPQyxLQUFQLENBQWFtQyxNQUFiLENBQW9CbEMsTUFBcEIsRUFBNEI7QUFBQ0ksVUFBTTtBQUFDdUIsZ0JBQVNBO0FBQVY7QUFBUCxHQUE1QjtBQUNELENBcEJELEMiLCJmaWxlIjoiL3BhY2thZ2VzL2RhbmltYWxfdXNlcnByZXNlbmNlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gc2VydmVySWQgLSB1bmlxdWUgcGVyIHNlcnZlciBwZXIgcmVzdGFydFxudmFyIHNlcnZlcklkID0gUmFuZG9tLmlkKCk7XG5cblxuLy8gdXNlciBjb25uZWN0aW9uc1xuVXNlclByZXNlbmNlU2Vzc2lvbnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXNlcnByZXNlbmNlc2Vzc2lvbnMnKTtcblxuLy8gbGlzdCBvZiBzZXJ2ZXJzXG5Vc2VyUHJlc2VuY2VTZXJ2ZXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3VzZXJwcmVzZW5jZXNlcnZlcnMnKTtcblxuXG5Vc2VyUHJlc2VuY2VTZXJ2ZXJzLl9lbnN1cmVJbmRleCh7cGluZzoxfSk7XG5Vc2VyUHJlc2VuY2VTZXJ2ZXJzLl9lbnN1cmVJbmRleCh7c2VydmVySWQ6MX0pO1xuTWV0ZW9yLnVzZXJzLl9lbnN1cmVJbmRleCh7J3ByZXNlbmNlLnNlcnZlcklkJzoxfSk7XG5Vc2VyUHJlc2VuY2VTZXNzaW9ucy5fZW5zdXJlSW5kZXgoe3VzZXJJZDoxfSk7XG5cblxuLy8ga2VlcCB0cmFjayBvZiB3aGljaCBzZXJ2ZXJzIGFyZSBvbmxpbmVcbk1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpIHtcbiAgbGV0IGZpbmQgPSB7c2VydmVySWQ6c2VydmVySWR9O1xuICBsZXQgbW9kaWZpZXIgPSB7JHNldDoge3Bpbmc6bmV3IERhdGUoKX19O1xuICBVc2VyUHJlc2VuY2VTZXJ2ZXJzLnVwc2VydChmaW5kLCBtb2RpZmllcik7XG59LCAxMDAwICogMzApO1xuXG5cbi8vIHJlbW92ZSBvbGQgc2VydmVycyBhbmQgc2Vzc2lvbnNcbi8vIHVwZGF0ZSBzdGF0dXMgb2YgdXNlcnMgY29ubmVjdGVkIHRvIHRoYXQgc2VydmVyXG5NZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKSB7XG4gIGxldCBjdXRvZmYgPSBuZXcgRGF0ZSgpO1xuICBjdXRvZmYuc2V0TWludXRlcyhuZXcgRGF0ZSgpLmdldE1pbnV0ZXMoKSAtIDUpO1xuICBVc2VyUHJlc2VuY2VTZXJ2ZXJzLmZpbmQoe3Bpbmc6IHskbHQ6Y3V0b2ZmfX0pLmZvckVhY2goZnVuY3Rpb24oc2VydmVyKSB7XG4gICAgVXNlclByZXNlbmNlU2VydmVycy5yZW1vdmUoc2VydmVyLl9pZCk7XG4gICAgVXNlclByZXNlbmNlU2Vzc2lvbnMucmVtb3ZlKHtzZXJ2ZXJJZDpzZXJ2ZXIuc2VydmVySWR9KTtcbiAgICBNZXRlb3IudXNlcnMuZmluZCh7J3ByZXNlbmNlLnNlcnZlcklkJzpzZXJ2ZXIuc2VydmVySWR9KS5mb3JFYWNoKGZ1bmN0aW9uKHVzZXIpIHtcbiAgICAgIHRyYWNrVXNlclN0YXR1cyh1c2VyLl9pZCk7XG4gICAgfSlcbiAgfSlcbn0sIDEwMDAgKiAxMCk7XG5cblxuXG4vLyB0cmFjayB1c2VyIGNvbm5lY3Rpb24gYW5kIGRpc2Nvbm5lY3Rpb25cbk1ldGVvci5wdWJsaXNoKG51bGwsIGZ1bmN0aW9uKCl7XG4gIHZhciBzZWxmID0gdGhpcztcblxuICBpZihzZWxmLnVzZXJJZCAmJiBzZWxmLmNvbm5lY3Rpb24gJiYgc2VsZi5jb25uZWN0aW9uLmlkKXtcbiAgICB1c2VyQ29ubmVjdGVkKHNlbGYudXNlcklkLCBzZWxmLmNvbm5lY3Rpb24pO1xuXG4gICAgc2VsZi5vblN0b3AoZnVuY3Rpb24oKXtcbiAgICAgIHVzZXJEaXNjb25uZWN0ZWQoc2VsZi51c2VySWQsIHNlbGYuY29ubmVjdGlvbik7XG4gICAgfSk7XG4gIH1cblxuICBzZWxmLnJlYWR5KCk7XG59KTtcblxuXG5cbnZhciB1c2VyQ29ubmVjdGVkID0gZnVuY3Rpb24odXNlcklkLCBjb25uZWN0aW9uKSB7XG4gIFVzZXJQcmVzZW5jZVNlc3Npb25zLmluc2VydCh7c2VydmVySWQ6c2VydmVySWQsIHVzZXJJZDp1c2VySWQsIGNvbm5lY3Rpb25JZDpjb25uZWN0aW9uLmlkLCBjcmVhdGVkQXQ6bmV3IERhdGUoKX0pO1xuICB0cmFja1VzZXJTdGF0dXModXNlcklkLCBjb25uZWN0aW9uKTtcbn1cblxuXG5cbnZhciB1c2VyRGlzY29ubmVjdGVkID0gZnVuY3Rpb24odXNlcklkLCBjb25uZWN0aW9uKSB7XG4gIFVzZXJQcmVzZW5jZVNlc3Npb25zLnJlbW92ZSh7dXNlcklkOnVzZXJJZCwgY29ubmVjdGlvbklkOmNvbm5lY3Rpb24uaWR9KTtcbiAgdHJhY2tVc2VyU3RhdHVzKHVzZXJJZCwgY29ubmVjdGlvbik7XG59XG5cblxuXG52YXIgdHJhY2tVc2VyU3RhdHVzID0gZnVuY3Rpb24odXNlcklkLCBjb25uZWN0aW9uKSB7XG4gIGxldCBwcmVzZW5jZSA9IHtcbiAgICB1cGRhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgc2VydmVySWQ6IHNlcnZlcklkXG4gIH1cblxuICBpZiAoY29ubmVjdGlvbikge1xuICAgIHByZXNlbmNlLmNsaWVudEFkZHJlc3MgPSBjb25uZWN0aW9uLmNsaWVudEFkZHJlc3M7XG4gICAgcHJlc2VuY2UuaHR0cEhlYWRlcnMgPSBjb25uZWN0aW9uLmh0dHBIZWFkZXJzO1xuICB9XG5cbiAgbGV0IGlzT25saW5lID0gVXNlclByZXNlbmNlU2Vzc2lvbnMuZmluZCh7dXNlcklkOnVzZXJJZH0pLmNvdW50KCk7XG5cbiAgaWYgKGlzT25saW5lKSB7XG4gICAgcHJlc2VuY2Uuc3RhdHVzID0gJ29ubGluZSc7XG4gIH0gZWxzZSB7XG4gICAgcHJlc2VuY2Uuc3RhdHVzID0gJ29mZmxpbmUnO1xuICB9XG5cbiAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh1c2VySWQsIHskc2V0OiB7cHJlc2VuY2U6cHJlc2VuY2V9fSk7XG59XG4iXX0=
