(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var EJSON = Package.ejson.EJSON;
var _ = Package.underscore._;
var Random = Package.random.Random;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var check = Package.check.check;
var Match = Package.check.Match;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var doc, expected, Tinytest;

var require = meteorInstall({"node_modules":{"meteor":{"tinytest":{"tinytest_server.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/tinytest/tinytest_server.js                                                                   //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({
  Tinytest: () => Tinytest
});
let Tinytest;
module.watch(require("./tinytest.js"), {
  Tinytest(v) {
    Tinytest = v;
  }

}, 0);
let ServerTestResultsSubscription, ServerTestResultsCollection;
module.watch(require("./model.js"), {
  ServerTestResultsSubscription(v) {
    ServerTestResultsSubscription = v;
  },

  ServerTestResultsCollection(v) {
    ServerTestResultsCollection = v;
  }

}, 1);

const Fiber = require('fibers');

const handlesForRun = new Map();
const reportsForRun = new Map();
Meteor.publish(ServerTestResultsSubscription, function (runId) {
  check(runId, String);

  if (!handlesForRun.has(runId)) {
    handlesForRun.set(runId, new Set());
  }

  handlesForRun.get(runId).add(this);
  this.onStop(() => {
    handlesForRun.get(runId).delete(this);
  });

  if (reportsForRun.has(runId)) {
    this.added(ServerTestResultsCollection, runId, reportsForRun.get(runId));
  } else {
    this.added(ServerTestResultsCollection, runId, {});
  }

  this.ready();
});
Meteor.methods({
  'tinytest/run'(runId, pathPrefix) {
    check(runId, String);
    check(pathPrefix, Match.Optional([String]));
    this.unblock();
    reportsForRun.set(runId, Object.create(null));

    function addReport(key, report) {
      var fields = {};
      fields[key] = report;
      const handles = handlesForRun.get(runId);

      if (handles) {
        handles.forEach(handle => {
          handle.changed(ServerTestResultsCollection, runId, fields);
        });
      } // Save for future subscriptions.


      reportsForRun.get(runId)[key] = report;
    }

    function onReport(report) {
      if (!Fiber.current) {
        Meteor._debug("Trying to report a test not in a fiber! " + "You probably forgot to wrap a callback in bindEnvironment.");

        console.trace();
      }

      var dummyKey = Random.id();
      addReport(dummyKey, report);
    }

    function onComplete() {
      // We send an object for current and future compatibility,
      // though we could get away with just sending { complete: true }
      var report = {
        done: true
      };
      var key = 'complete';
      addReport(key, report);
    }

    Tinytest._runTests(onReport, onComplete, pathPrefix);
  },

  'tinytest/clearResults'(runId) {
    check(runId, String);
    handlesForRun.get(runId).forEach(handle => {
      // XXX this doesn't actually notify the client that it has been
      // unsubscribed.
      handle.stop();
    });
    handlesForRun.delete(runId);
    reportsForRun.delete(runId);
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"model.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/tinytest/model.js                                                                             //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({
  ServerTestResultsSubscription: () => ServerTestResultsSubscription,
  ServerTestResultsCollection: () => ServerTestResultsCollection
});
const ServerTestResultsSubscription = "tinytest_results_subscription";
const ServerTestResultsCollection = "tinytest_results_collection";
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tinytest.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/tinytest/tinytest.js                                                                          //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
var _extends = require("@babel/runtime/helpers/builtin/extends");

module.export({
  TestCaseResults: () => TestCaseResults,
  TestCase: () => TestCase,
  TestManager: () => TestManager,
  TestRun: () => TestRun,
  Tinytest: () => Tinytest
});

const Future = Meteor.isServer && require('fibers/future');
/******************************************************************************/

/* TestCaseResults                                                            */

/******************************************************************************/


class TestCaseResults {
  constructor(test_case, onEvent, onException, stop_at_offset) {
    this.test_case = test_case;
    this.onEvent = onEvent;
    this.expecting_failure = false;
    this.current_fail_count = 0;
    this.stop_at_offset = stop_at_offset;
    this.onException = onException;
    this.id = Random.id();
    this.extraDetails = {};
  }

  ok(doc) {
    var ok = {
      type: "ok"
    };
    if (doc) ok.details = doc;

    if (this.expecting_failure) {
      ok.details = ok.details || {};
      ok.details["was_expecting_failure"] = true;
      this.expecting_failure = false;
    }

    this.onEvent(ok);
  }

  expect_fail() {
    this.expecting_failure = true;
  }

  fail(doc) {
    if (typeof doc === "string") {
      // Some very old code still tries to call fail() with a
      // string. Don't do this!
      doc = {
        type: "fail",
        message: doc
      };
    }

    doc = _extends({}, doc, this.extraDetails);

    if (this.stop_at_offset === 0) {
      if (Meteor.isClient) {
        // Only supported on the browser for now..
        var now = +new Date();
        debugger;
        if (+new Date() - now < 100) alert("To use this feature, first enable your browser's debugger.");
      }

      this.stop_at_offset = null;
    }

    if (this.stop_at_offset) this.stop_at_offset--; // Get filename and line number of failure if we're using v8 (Chrome or
    // Node).

    if (Error.captureStackTrace) {
      var savedPrepareStackTrace = Error.prepareStackTrace;

      Error.prepareStackTrace = function (_, stack) {
        return stack;
      };

      var err = new Error();
      Error.captureStackTrace(err);
      var stack = err.stack;
      Error.prepareStackTrace = savedPrepareStackTrace;

      for (var i = stack.length - 1; i >= 0; --i) {
        var frame = stack[i]; // Heuristic: use the OUTERMOST line which is in a :tests.js
        // file (this is less likely to be a test helper function).

        const fileName = frame.getFileName();

        if (fileName && fileName.match(/:tests\.js/)) {
          doc.filename = fileName;
          doc.line = frame.getLineNumber();
          break;
        }
      }
    }

    this.onEvent({
      type: this.expecting_failure ? "expected_fail" : "fail",
      details: doc,
      cookie: {
        name: this.test_case.name,
        offset: this.current_fail_count,
        groupPath: this.test_case.groupPath,
        shortName: this.test_case.shortName
      }
    });
    this.expecting_failure = false;
    this.current_fail_count++;
  } // Call this to fail the test with an exception. Use this to record
  // exceptions that occur inside asynchronous callbacks in tests.
  //
  // It should only be used with asynchronous tests, and if you call
  // this function, you should make sure that (1) the test doesn't
  // call its callback (onComplete function); (2) the test function
  // doesn't directly raise an exception.


  exception(exception) {
    this.onException(exception);
  } // returns a unique ID for this test run, for convenience use by
  // your tests


  runId() {
    return this.id;
  } // === Following patterned after http://vowsjs.org/#reference ===
  // XXX eliminate 'message' and 'not' arguments


  equal(actual, expected, message, not) {
    if (!not && typeof actual === 'string' && typeof expected === 'string') {
      this._stringEqual(actual, expected, message);

      return;
    }
    /* If expected is a DOM node, do a literal '===' comparison with
     * actual. Otherwise do a deep comparison, as implemented by _.isEqual.
     */


    var matched; // XXX remove cruft specific to liverange

    if (typeof expected === "object" && expected && expected.nodeType) {
      matched = expected === actual;
      expected = "[Node]";
      actual = "[Unknown]";
    } else if (typeof Uint8Array !== 'undefined' && expected instanceof Uint8Array) {
      // I have no idea why but _.isEqual on Chrome horks completely on Uint8Arrays.
      // and the symptom is the chrome renderer taking up an entire CPU and freezing
      // your web page, but not pausing anywhere in _.isEqual.  I don't understand it
      // but we fall back to a manual comparison
      if (!(actual instanceof Uint8Array)) this.fail({
        type: "assert_equal",
        message: "found object is not a typed array",
        expected: "A typed array",
        actual: actual.constructor.toString()
      });
      if (expected.length !== actual.length) this.fail({
        type: "assert_equal",
        message: "lengths of typed arrays do not match",
        expected: expected.length,
        actual: actual.length
      });

      for (var i = 0; i < expected.length; i++) {
        this.equal(actual[i], expected[i]);
      }
    } else {
      matched = EJSON.equals(expected, actual);
    }

    if (matched === !!not) {
      this.fail({
        type: "assert_equal",
        message: message,
        expected: JSON.stringify(expected),
        actual: JSON.stringify(actual),
        not: !!not
      });
    } else this.ok();
  }

  notEqual(actual, expected, message) {
    this.equal(actual, expected, message, true);
  }

  instanceOf(obj, klass, message) {
    if (obj instanceof klass) this.ok();else this.fail({
      type: "instanceOf",
      message: message,
      not: false
    }); // XXX what other data?
  }

  notInstanceOf(obj, klass, message) {
    if (obj instanceof klass) this.fail({
      type: "instanceOf",
      message: message,
      not: true
    }); // XXX what other data?
    else this.ok();
  }

  matches(actual, regexp, message) {
    if (regexp.test(actual)) this.ok();else this.fail({
      type: "matches",
      message: message,
      actual: actual,
      regexp: regexp.toString(),
      not: false
    });
  }

  notMatches(actual, regexp, message) {
    if (regexp.test(actual)) this.fail({
      type: "matches",
      message: message,
      actual: actual,
      regexp: regexp.toString(),
      not: true
    });else this.ok();
  } // expected can be:
  //  undefined: accept any exception.
  //  string: pass if the string is a substring of the exception message.
  //  regexp: pass if the exception message passes the regexp.
  //  function: call the function as a predicate with the exception.
  //
  // Note: Node's assert.throws also accepts a constructor to test
  // whether the error is of the expected class.  But since
  // JavaScript can't distinguish between constructors and plain
  // functions and Node's assert.throws also accepts a predicate
  // function, if the error fails the instanceof test with the
  // constructor then the constructor is then treated as a predicate
  // and called (!)
  //
  // The upshot is, if you want to test whether an error is of a
  // particular class, use a predicate function.
  //


  throws(f, expected) {
    var actual, predicate;

    if (expected === undefined) {
      predicate = function (actual) {
        return true;
      };
    } else if (typeof expected === "string") {
      predicate = function (actual) {
        return typeof actual.message === "string" && actual.message.indexOf(expected) !== -1;
      };
    } else if (expected instanceof RegExp) {
      predicate = function (actual) {
        return expected.test(actual.message);
      };
    } else if (typeof expected === 'function') {
      predicate = expected;
    } else {
      throw new Error('expected should be a string, regexp, or predicate function');
    }

    try {
      f();
    } catch (exception) {
      actual = exception;
    }

    if (actual && predicate(actual)) this.ok();else this.fail({
      type: "throws",
      message: actual ? "wrong error thrown: " + actual.message : "did not throw an error as expected"
    });
  }

  isTrue(v, msg) {
    if (v) this.ok();else this.fail({
      type: "true",
      message: msg,
      not: false
    });
  }

  isFalse(v, msg) {
    if (v) this.fail({
      type: "true",
      message: msg,
      not: true
    });else this.ok();
  }

  isNull(v, msg) {
    if (v === null) this.ok();else this.fail({
      type: "null",
      message: msg,
      not: false
    });
  }

  isNotNull(v, msg) {
    if (v === null) this.fail({
      type: "null",
      message: msg,
      not: true
    });else this.ok();
  }

  isUndefined(v, msg) {
    if (v === undefined) this.ok();else this.fail({
      type: "undefined",
      message: msg,
      not: false
    });
  }

  isNotUndefined(v, msg) {
    if (v === undefined) this.fail({
      type: "undefined",
      message: msg,
      not: true
    });else this.ok();
  }

  isNaN(v, msg) {
    if (isNaN(v)) this.ok();else this.fail({
      type: "NaN",
      message: msg,
      not: false
    });
  }

  isNotNaN(v, msg) {
    if (isNaN(v)) this.fail({
      type: "NaN",
      message: msg,
      not: true
    });else this.ok();
  }

  include(s, v, message, not) {
    var pass = false;

    if (s instanceof Array) {
      pass = s.some(it => _.isEqual(v, it));
    } else if (s && typeof s === "object") {
      pass = v in s;
    } else if (typeof s === "string") {
      if (s.indexOf(v) > -1) {
        pass = true;
      }
    } else {
      /* fail -- not something that contains other things */
      ;
    }

    if (pass === !not) {
      this.ok();
    } else {
      this.fail({
        type: "include",
        message,
        sequence: s,
        should_contain_value: v,
        not: !!not
      });
    }
  }

  notInclude(s, v, message) {
    this.include(s, v, message, true);
  } // XXX should change to lengthOf to match vowsjs


  length(obj, expected_length, msg) {
    if (obj.length === expected_length) {
      this.ok();
    } else {
      this.fail({
        type: "length",
        expected: expected_length,
        actual: obj.length,
        message: msg
      });
    }
  } // EXPERIMENTAL way to compare two strings that results in
  // a nicer display in the test runner, e.g. for multiline
  // strings


  _stringEqual(actual, expected, message) {
    if (actual !== expected) {
      this.fail({
        type: "string_equal",
        message,
        expected,
        actual
      });
    } else {
      this.ok();
    }
  }

}

class TestCase {
  constructor(name, func) {
    this.name = name;
    this.func = func;
    var nameParts = name.split(" - ").map(s => {
      return s.replace(/^\s*|\s*$/g, ""); // trim
    });
    this.shortName = nameParts.pop();
    nameParts.unshift("tinytest");
    this.groupPath = nameParts;
  } // Run the test asynchronously, delivering results via onEvent;
  // then call onComplete() on success, or else onException(e) if the
  // test raised (or voluntarily reported) an exception.


  run(onEvent, onComplete, onException, stop_at_offset) {
    let completed = false;
    return new Promise((resolve, reject) => {
      const results = new TestCaseResults(this, event => {
        // If this trace prints, it means you ran some test.* function
        // after the test finished! Another symptom will be that the
        // test will display as "waiting" even when it counts as passed
        // or failed.
        if (completed) {
          console.trace("event after complete!");
        }

        return onEvent(event);
      }, reject, stop_at_offset);
      const result = this.func(results, resolve);

      if (result && typeof result.then === "function") {
        result.then(resolve, reject);
      }
    }).then(() => {
      completed = true;
      onComplete();
    }, error => {
      completed = true;
      onException(error);
    });
  }

}

const TestManager = new class TestManager {
  constructor() {
    this.tests = {};
    this.ordered_tests = [];
    this.testQueue = Meteor.isServer && new Meteor._SynchronousQueue();
  }

  addCase(test) {
    if (test.name in this.tests) throw new Error("Every test needs a unique name, but there are two tests named '" + test.name + "'");

    if (__meteor_runtime_config__.tinytestFilter && test.name.indexOf(__meteor_runtime_config__.tinytestFilter) === -1) {
      return;
    }

    this.tests[test.name] = test;
    this.ordered_tests.push(test);
  }

  createRun(onReport, pathPrefix) {
    return new TestRun(this, onReport, pathPrefix);
  }

}();

if (Meteor.isServer && process.env.TINYTEST_FILTER) {
  __meteor_runtime_config__.tinytestFilter = process.env.TINYTEST_FILTER;
}
/******************************************************************************/

/* TestRun                                                                    */

/******************************************************************************/


class TestRun {
  constructor(manager, onReport, pathPrefix) {
    this.manager = manager;
    this.onReport = onReport;
    this.next_sequence_number = 0;
    this._pathPrefix = pathPrefix || [];
    this.manager.ordered_tests.forEach(test => {
      if (this._prefixMatch(test.groupPath)) this._report(test);
    });
  }

  _prefixMatch(testPath) {
    for (var i = 0; i < this._pathPrefix.length; i++) {
      if (!testPath[i] || this._pathPrefix[i] !== testPath[i]) {
        return false;
      }
    }

    return true;
  }

  _runTest(test, onComplete, stop_at_offset) {
    var startTime = +new Date();
    test.run(event => {
      /* onEvent */
      // Ignore result callbacks if the test has already been reported
      // as timed out.
      if (test.timedOut) return;

      this._report(test, event);
    }, () => {
      /* onComplete */
      if (test.timedOut) return;
      var totalTime = +new Date() - startTime;

      this._report(test, {
        type: "finish",
        timeMs: totalTime
      });

      onComplete();
    }, exception => {
      /* onException */
      if (test.timedOut) return; // XXX you want the "name" and "message" fields on the
      // exception, to start with..

      this._report(test, {
        type: "exception",
        details: {
          message: exception.message,
          // XXX empty???
          stack: exception.stack // XXX portability

        }
      });

      onComplete();
    }, stop_at_offset);
  } // Run a single test.  On the server, ensure that only one test runs
  // at a time, even with multiple clients submitting tests.  However,
  // time out the test after three minutes to avoid locking up the
  // server if a test fails to complete.
  //


  _runOne(test, onComplete, stop_at_offset) {
    if (!this._prefixMatch(test.groupPath)) {
      onComplete && onComplete();
      return;
    }

    if (Meteor.isServer) {
      // On the server, ensure that only one test runs at a time, even
      // with multiple clients.
      this.manager.testQueue.queueTask(() => {
        // The future resolves when the test completes or times out.
        var future = new Future();
        Meteor.setTimeout(() => {
          if (future.isResolved()) // If the future has resolved the test has completed.
            return;
          test.timedOut = true;

          this._report(test, {
            type: "exception",
            details: {
              message: "test timed out"
            }
          });

          future['return']();
        }, 3 * 60 * 1000 // 3 minutes
        );

        this._runTest(test, () => {
          // The test can complete after it has timed out (it might
          // just be slow), so only resolve the future if the test
          // hasn't timed out.
          if (!future.isResolved()) future['return']();
        }, stop_at_offset); // Wait for the test to complete or time out.


        future.wait();
        onComplete && onComplete();
      });
    } else {
      // client
      this._runTest(test, () => {
        onComplete && onComplete();
      }, stop_at_offset);
    }
  }

  run(onComplete) {
    var tests = this.manager.ordered_tests.slice(0);

    var reportCurrent = function (name) {
      if (Meteor.isClient) Tinytest._onCurrentClientTest(name);
    };

    const runNext = () => {
      if (tests.length) {
        var t = tests.shift();
        reportCurrent(t.name);

        this._runOne(t, runNext);
      } else {
        reportCurrent(null);
        onComplete && onComplete();
      }
    };

    runNext();
  } // An alternative to run(). Given the 'cookie' attribute of a
  // failure record, try to rerun that particular test up to that
  // failure, and then open the debugger.


  debug(cookie, onComplete) {
    var test = this.manager.tests[cookie.name];
    if (!test) throw new Error("No such test '" + cookie.name + "'");

    this._runOne(test, onComplete, cookie.offset);
  }

  _report(test, event) {
    let events;

    if (event) {
      events = [_extends({
        sequence: this.next_sequence_number++
      }, event)];
    } else {
      events = [];
    }

    this.onReport({
      groupPath: test.groupPath,
      test: test.shortName,
      events
    });
  }

}

const Tinytest = {};

Tinytest.addAsync = function (name, func) {
  TestManager.addCase(new TestCase(name, func));
};

Tinytest.add = function (name, func) {
  Tinytest.addAsync(name, function (test, onComplete) {
    func(test);
    onComplete();
  });
}; // Run every test, asynchronously. Runs the test in the current
// process only (if called on the server, runs the tests on the
// server, and likewise for the client.) Report results via
// onReport. Call onComplete when it's done.
//


Tinytest._runTests = function (onReport, onComplete, pathPrefix) {
  var testRun = TestManager.createRun(onReport, pathPrefix);
  testRun.run(onComplete);
}; // Run just one test case, and stop the debugger at a particular
// error, all as indicated by 'cookie', which will have come from a
// failure event output by _runTests.
//


Tinytest._debugTest = function (cookie, onReport, onComplete) {
  var testRun = TestManager.createRun(onReport);
  testRun.debug(cookie, onComplete);
}; // Replace this callback to get called when we run a client test,
// and then called with `null` when the client tests are
// done.  This is used to provide a live display of the current
// running client test on the test results page.


Tinytest._onCurrentClientTest = function (name) {};

Tinytest._TestCaseResults = TestCaseResults;
Tinytest._TestCase = TestCase;
Tinytest._TestManager = TestManager;
Tinytest._TestRun = TestRun;
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("/node_modules/meteor/tinytest/tinytest_server.js");

/* Exports */
Package._define("tinytest", exports, {
  Tinytest: Tinytest
});

})();

//# sourceURL=meteor://💻app/packages/tinytest.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvdGlueXRlc3QvdGlueXRlc3Rfc2VydmVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy90aW55dGVzdC9tb2RlbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvdGlueXRlc3QvdGlueXRlc3QuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiVGlueXRlc3QiLCJ3YXRjaCIsInJlcXVpcmUiLCJ2IiwiU2VydmVyVGVzdFJlc3VsdHNTdWJzY3JpcHRpb24iLCJTZXJ2ZXJUZXN0UmVzdWx0c0NvbGxlY3Rpb24iLCJGaWJlciIsImhhbmRsZXNGb3JSdW4iLCJNYXAiLCJyZXBvcnRzRm9yUnVuIiwiTWV0ZW9yIiwicHVibGlzaCIsInJ1bklkIiwiY2hlY2siLCJTdHJpbmciLCJoYXMiLCJzZXQiLCJTZXQiLCJnZXQiLCJhZGQiLCJvblN0b3AiLCJkZWxldGUiLCJhZGRlZCIsInJlYWR5IiwibWV0aG9kcyIsInBhdGhQcmVmaXgiLCJNYXRjaCIsIk9wdGlvbmFsIiwidW5ibG9jayIsIk9iamVjdCIsImNyZWF0ZSIsImFkZFJlcG9ydCIsImtleSIsInJlcG9ydCIsImZpZWxkcyIsImhhbmRsZXMiLCJmb3JFYWNoIiwiaGFuZGxlIiwiY2hhbmdlZCIsIm9uUmVwb3J0IiwiY3VycmVudCIsIl9kZWJ1ZyIsImNvbnNvbGUiLCJ0cmFjZSIsImR1bW15S2V5IiwiUmFuZG9tIiwiaWQiLCJvbkNvbXBsZXRlIiwiZG9uZSIsIl9ydW5UZXN0cyIsInN0b3AiLCJUZXN0Q2FzZVJlc3VsdHMiLCJUZXN0Q2FzZSIsIlRlc3RNYW5hZ2VyIiwiVGVzdFJ1biIsIkZ1dHVyZSIsImlzU2VydmVyIiwiY29uc3RydWN0b3IiLCJ0ZXN0X2Nhc2UiLCJvbkV2ZW50Iiwib25FeGNlcHRpb24iLCJzdG9wX2F0X29mZnNldCIsImV4cGVjdGluZ19mYWlsdXJlIiwiY3VycmVudF9mYWlsX2NvdW50IiwiZXh0cmFEZXRhaWxzIiwib2siLCJkb2MiLCJ0eXBlIiwiZGV0YWlscyIsImV4cGVjdF9mYWlsIiwiZmFpbCIsIm1lc3NhZ2UiLCJpc0NsaWVudCIsIm5vdyIsIkRhdGUiLCJhbGVydCIsIkVycm9yIiwiY2FwdHVyZVN0YWNrVHJhY2UiLCJzYXZlZFByZXBhcmVTdGFja1RyYWNlIiwicHJlcGFyZVN0YWNrVHJhY2UiLCJfIiwic3RhY2siLCJlcnIiLCJpIiwibGVuZ3RoIiwiZnJhbWUiLCJmaWxlTmFtZSIsImdldEZpbGVOYW1lIiwibWF0Y2giLCJmaWxlbmFtZSIsImxpbmUiLCJnZXRMaW5lTnVtYmVyIiwiY29va2llIiwibmFtZSIsIm9mZnNldCIsImdyb3VwUGF0aCIsInNob3J0TmFtZSIsImV4Y2VwdGlvbiIsImVxdWFsIiwiYWN0dWFsIiwiZXhwZWN0ZWQiLCJub3QiLCJfc3RyaW5nRXF1YWwiLCJtYXRjaGVkIiwibm9kZVR5cGUiLCJVaW50OEFycmF5IiwidG9TdHJpbmciLCJFSlNPTiIsImVxdWFscyIsIkpTT04iLCJzdHJpbmdpZnkiLCJub3RFcXVhbCIsImluc3RhbmNlT2YiLCJvYmoiLCJrbGFzcyIsIm5vdEluc3RhbmNlT2YiLCJtYXRjaGVzIiwicmVnZXhwIiwidGVzdCIsIm5vdE1hdGNoZXMiLCJ0aHJvd3MiLCJmIiwicHJlZGljYXRlIiwidW5kZWZpbmVkIiwiaW5kZXhPZiIsIlJlZ0V4cCIsImlzVHJ1ZSIsIm1zZyIsImlzRmFsc2UiLCJpc051bGwiLCJpc05vdE51bGwiLCJpc1VuZGVmaW5lZCIsImlzTm90VW5kZWZpbmVkIiwiaXNOYU4iLCJpc05vdE5hTiIsImluY2x1ZGUiLCJzIiwicGFzcyIsIkFycmF5Iiwic29tZSIsIml0IiwiaXNFcXVhbCIsInNlcXVlbmNlIiwic2hvdWxkX2NvbnRhaW5fdmFsdWUiLCJub3RJbmNsdWRlIiwiZXhwZWN0ZWRfbGVuZ3RoIiwiZnVuYyIsIm5hbWVQYXJ0cyIsInNwbGl0IiwibWFwIiwicmVwbGFjZSIsInBvcCIsInVuc2hpZnQiLCJydW4iLCJjb21wbGV0ZWQiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsInJlc3VsdHMiLCJldmVudCIsInJlc3VsdCIsInRoZW4iLCJlcnJvciIsInRlc3RzIiwib3JkZXJlZF90ZXN0cyIsInRlc3RRdWV1ZSIsIl9TeW5jaHJvbm91c1F1ZXVlIiwiYWRkQ2FzZSIsIl9fbWV0ZW9yX3J1bnRpbWVfY29uZmlnX18iLCJ0aW55dGVzdEZpbHRlciIsInB1c2giLCJjcmVhdGVSdW4iLCJwcm9jZXNzIiwiZW52IiwiVElOWVRFU1RfRklMVEVSIiwibWFuYWdlciIsIm5leHRfc2VxdWVuY2VfbnVtYmVyIiwiX3BhdGhQcmVmaXgiLCJfcHJlZml4TWF0Y2giLCJfcmVwb3J0IiwidGVzdFBhdGgiLCJfcnVuVGVzdCIsInN0YXJ0VGltZSIsInRpbWVkT3V0IiwidG90YWxUaW1lIiwidGltZU1zIiwiX3J1bk9uZSIsInF1ZXVlVGFzayIsImZ1dHVyZSIsInNldFRpbWVvdXQiLCJpc1Jlc29sdmVkIiwid2FpdCIsInNsaWNlIiwicmVwb3J0Q3VycmVudCIsIl9vbkN1cnJlbnRDbGllbnRUZXN0IiwicnVuTmV4dCIsInQiLCJzaGlmdCIsImRlYnVnIiwiZXZlbnRzIiwiYWRkQXN5bmMiLCJ0ZXN0UnVuIiwiX2RlYnVnVGVzdCIsIl9UZXN0Q2FzZVJlc3VsdHMiLCJfVGVzdENhc2UiLCJfVGVzdE1hbmFnZXIiLCJfVGVzdFJ1biJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxPQUFPQyxNQUFQLENBQWM7QUFBQ0MsWUFBUyxNQUFJQTtBQUFkLENBQWQ7QUFBdUMsSUFBSUEsUUFBSjtBQUFhRixPQUFPRyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNGLFdBQVNHLENBQVQsRUFBVztBQUFDSCxlQUFTRyxDQUFUO0FBQVc7O0FBQXhCLENBQXRDLEVBQWdFLENBQWhFO0FBQW1FLElBQUlDLDZCQUFKLEVBQWtDQywyQkFBbEM7QUFBOERQLE9BQU9HLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ0UsZ0NBQThCRCxDQUE5QixFQUFnQztBQUFDQyxvQ0FBOEJELENBQTlCO0FBQWdDLEdBQWxFOztBQUFtRUUsOEJBQTRCRixDQUE1QixFQUE4QjtBQUFDRSxrQ0FBNEJGLENBQTVCO0FBQThCOztBQUFoSSxDQUFuQyxFQUFxSyxDQUFySzs7QUFRckwsTUFBTUcsUUFBUUosUUFBUSxRQUFSLENBQWQ7O0FBQ0EsTUFBTUssZ0JBQWdCLElBQUlDLEdBQUosRUFBdEI7QUFDQSxNQUFNQyxnQkFBZ0IsSUFBSUQsR0FBSixFQUF0QjtBQUVBRSxPQUFPQyxPQUFQLENBQWVQLDZCQUFmLEVBQThDLFVBQVVRLEtBQVYsRUFBaUI7QUFDN0RDLFFBQU1ELEtBQU4sRUFBYUUsTUFBYjs7QUFFQSxNQUFJLENBQUVQLGNBQWNRLEdBQWQsQ0FBa0JILEtBQWxCLENBQU4sRUFBZ0M7QUFDOUJMLGtCQUFjUyxHQUFkLENBQWtCSixLQUFsQixFQUF5QixJQUFJSyxHQUFKLEVBQXpCO0FBQ0Q7O0FBRURWLGdCQUFjVyxHQUFkLENBQWtCTixLQUFsQixFQUF5Qk8sR0FBekIsQ0FBNkIsSUFBN0I7QUFFQSxPQUFLQyxNQUFMLENBQVksTUFBTTtBQUNoQmIsa0JBQWNXLEdBQWQsQ0FBa0JOLEtBQWxCLEVBQXlCUyxNQUF6QixDQUFnQyxJQUFoQztBQUNELEdBRkQ7O0FBSUEsTUFBSVosY0FBY00sR0FBZCxDQUFrQkgsS0FBbEIsQ0FBSixFQUE4QjtBQUM1QixTQUFLVSxLQUFMLENBQVdqQiwyQkFBWCxFQUF3Q08sS0FBeEMsRUFDV0gsY0FBY1MsR0FBZCxDQUFrQk4sS0FBbEIsQ0FEWDtBQUVELEdBSEQsTUFHTztBQUNMLFNBQUtVLEtBQUwsQ0FBV2pCLDJCQUFYLEVBQXdDTyxLQUF4QyxFQUErQyxFQUEvQztBQUNEOztBQUVELE9BQUtXLEtBQUw7QUFDRCxDQXJCRDtBQXVCQWIsT0FBT2MsT0FBUCxDQUFlO0FBQ2IsaUJBQWVaLEtBQWYsRUFBc0JhLFVBQXRCLEVBQWtDO0FBQ2hDWixVQUFNRCxLQUFOLEVBQWFFLE1BQWI7QUFDQUQsVUFBTVksVUFBTixFQUFrQkMsTUFBTUMsUUFBTixDQUFlLENBQUNiLE1BQUQsQ0FBZixDQUFsQjtBQUNBLFNBQUtjLE9BQUw7QUFFQW5CLGtCQUFjTyxHQUFkLENBQWtCSixLQUFsQixFQUF5QmlCLE9BQU9DLE1BQVAsQ0FBYyxJQUFkLENBQXpCOztBQUVBLGFBQVNDLFNBQVQsQ0FBbUJDLEdBQW5CLEVBQXdCQyxNQUF4QixFQUFnQztBQUM5QixVQUFJQyxTQUFTLEVBQWI7QUFDQUEsYUFBT0YsR0FBUCxJQUFjQyxNQUFkO0FBQ0EsWUFBTUUsVUFBVTVCLGNBQWNXLEdBQWQsQ0FBa0JOLEtBQWxCLENBQWhCOztBQUNBLFVBQUl1QixPQUFKLEVBQWE7QUFDWEEsZ0JBQVFDLE9BQVIsQ0FBZ0JDLFVBQVU7QUFDeEJBLGlCQUFPQyxPQUFQLENBQWVqQywyQkFBZixFQUE0Q08sS0FBNUMsRUFBbURzQixNQUFuRDtBQUNELFNBRkQ7QUFHRCxPQVI2QixDQVM5Qjs7O0FBQ0F6QixvQkFBY1MsR0FBZCxDQUFrQk4sS0FBbEIsRUFBeUJvQixHQUF6QixJQUFnQ0MsTUFBaEM7QUFDRDs7QUFFRCxhQUFTTSxRQUFULENBQWtCTixNQUFsQixFQUEwQjtBQUN4QixVQUFJLENBQUUzQixNQUFNa0MsT0FBWixFQUFxQjtBQUNuQjlCLGVBQU8rQixNQUFQLENBQWMsNkNBQ0EsNERBRGQ7O0FBRUFDLGdCQUFRQyxLQUFSO0FBQ0Q7O0FBQ0QsVUFBSUMsV0FBV0MsT0FBT0MsRUFBUCxFQUFmO0FBQ0FmLGdCQUFVYSxRQUFWLEVBQW9CWCxNQUFwQjtBQUNEOztBQUVELGFBQVNjLFVBQVQsR0FBc0I7QUFDcEI7QUFDQTtBQUNBLFVBQUlkLFNBQVM7QUFBRWUsY0FBTTtBQUFSLE9BQWI7QUFDQSxVQUFJaEIsTUFBTSxVQUFWO0FBQ0FELGdCQUFVQyxHQUFWLEVBQWVDLE1BQWY7QUFDRDs7QUFFRGpDLGFBQVNpRCxTQUFULENBQW1CVixRQUFuQixFQUE2QlEsVUFBN0IsRUFBeUN0QixVQUF6QztBQUNELEdBeENZOztBQTBDYiwwQkFBd0JiLEtBQXhCLEVBQStCO0FBQzdCQyxVQUFNRCxLQUFOLEVBQWFFLE1BQWI7QUFFQVAsa0JBQWNXLEdBQWQsQ0FBa0JOLEtBQWxCLEVBQXlCd0IsT0FBekIsQ0FBaUNDLFVBQVU7QUFDekM7QUFDQTtBQUNBQSxhQUFPYSxJQUFQO0FBQ0QsS0FKRDtBQU1BM0Msa0JBQWNjLE1BQWQsQ0FBcUJULEtBQXJCO0FBQ0FILGtCQUFjWSxNQUFkLENBQXFCVCxLQUFyQjtBQUNEOztBQXJEWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDbkNBZCxPQUFPQyxNQUFQLENBQWM7QUFBQ0ssaUNBQThCLE1BQUlBLDZCQUFuQztBQUFpRUMsK0JBQTRCLE1BQUlBO0FBQWpHLENBQWQ7QUFBTyxNQUFNRCxnQ0FDWCwrQkFESztBQUdBLE1BQU1DLDhCQUNYLDZCQURLLEM7Ozs7Ozs7Ozs7Ozs7QUNIUFAsT0FBT0MsTUFBUCxDQUFjO0FBQUNvRCxtQkFBZ0IsTUFBSUEsZUFBckI7QUFBcUNDLFlBQVMsTUFBSUEsUUFBbEQ7QUFBMkRDLGVBQVksTUFBSUEsV0FBM0U7QUFBdUZDLFdBQVEsTUFBSUEsT0FBbkc7QUFBMkd0RCxZQUFTLE1BQUlBO0FBQXhILENBQWQ7O0FBQUEsTUFBTXVELFNBQVM3QyxPQUFPOEMsUUFBUCxJQUFtQnRELFFBQVEsZUFBUixDQUFsQztBQUVBOztBQUNBOztBQUNBOzs7QUFFTyxNQUFNaUQsZUFBTixDQUFzQjtBQUMzQk0sY0FBWUMsU0FBWixFQUF1QkMsT0FBdkIsRUFBZ0NDLFdBQWhDLEVBQTZDQyxjQUE3QyxFQUE2RDtBQUMzRCxTQUFLSCxTQUFMLEdBQWlCQSxTQUFqQjtBQUNBLFNBQUtDLE9BQUwsR0FBZUEsT0FBZjtBQUNBLFNBQUtHLGlCQUFMLEdBQXlCLEtBQXpCO0FBQ0EsU0FBS0Msa0JBQUwsR0FBMEIsQ0FBMUI7QUFDQSxTQUFLRixjQUFMLEdBQXNCQSxjQUF0QjtBQUNBLFNBQUtELFdBQUwsR0FBbUJBLFdBQW5CO0FBQ0EsU0FBS2QsRUFBTCxHQUFVRCxPQUFPQyxFQUFQLEVBQVY7QUFDQSxTQUFLa0IsWUFBTCxHQUFvQixFQUFwQjtBQUNEOztBQUVEQyxLQUFHQyxHQUFILEVBQVE7QUFDTixRQUFJRCxLQUFLO0FBQUNFLFlBQU07QUFBUCxLQUFUO0FBQ0EsUUFBSUQsR0FBSixFQUNFRCxHQUFHRyxPQUFILEdBQWFGLEdBQWI7O0FBQ0YsUUFBSSxLQUFLSixpQkFBVCxFQUE0QjtBQUMxQkcsU0FBR0csT0FBSCxHQUFhSCxHQUFHRyxPQUFILElBQWMsRUFBM0I7QUFDQUgsU0FBR0csT0FBSCxDQUFXLHVCQUFYLElBQXNDLElBQXRDO0FBQ0EsV0FBS04saUJBQUwsR0FBeUIsS0FBekI7QUFDRDs7QUFDRCxTQUFLSCxPQUFMLENBQWFNLEVBQWI7QUFDRDs7QUFFREksZ0JBQWM7QUFDWixTQUFLUCxpQkFBTCxHQUF5QixJQUF6QjtBQUNEOztBQUVEUSxPQUFLSixHQUFMLEVBQVU7QUFDUixRQUFJLE9BQU9BLEdBQVAsS0FBZSxRQUFuQixFQUE2QjtBQUMzQjtBQUNBO0FBQ0FBLFlBQU07QUFBRUMsY0FBTSxNQUFSO0FBQWdCSSxpQkFBU0w7QUFBekIsT0FBTjtBQUNEOztBQUVEQSx1QkFDS0EsR0FETCxFQUVLLEtBQUtGLFlBRlY7O0FBS0EsUUFBSSxLQUFLSCxjQUFMLEtBQXdCLENBQTVCLEVBQStCO0FBQzdCLFVBQUluRCxPQUFPOEQsUUFBWCxFQUFxQjtBQUNuQjtBQUNBLFlBQUlDLE1BQU8sQ0FBQyxJQUFJQyxJQUFKLEVBQVo7QUFDQTtBQUNBLFlBQUssQ0FBQyxJQUFJQSxJQUFKLEVBQUYsR0FBY0QsR0FBZCxHQUFvQixHQUF4QixFQUNFRSxNQUFNLDREQUFOO0FBQ0g7O0FBQ0QsV0FBS2QsY0FBTCxHQUFzQixJQUF0QjtBQUNEOztBQUNELFFBQUksS0FBS0EsY0FBVCxFQUNFLEtBQUtBLGNBQUwsR0F2Qk0sQ0F5QlI7QUFDQTs7QUFDQSxRQUFJZSxNQUFNQyxpQkFBVixFQUE2QjtBQUMzQixVQUFJQyx5QkFBeUJGLE1BQU1HLGlCQUFuQzs7QUFDQUgsWUFBTUcsaUJBQU4sR0FBMEIsVUFBU0MsQ0FBVCxFQUFZQyxLQUFaLEVBQWtCO0FBQUUsZUFBT0EsS0FBUDtBQUFlLE9BQTdEOztBQUNBLFVBQUlDLE1BQU0sSUFBSU4sS0FBSixFQUFWO0FBQ0FBLFlBQU1DLGlCQUFOLENBQXdCSyxHQUF4QjtBQUNBLFVBQUlELFFBQVFDLElBQUlELEtBQWhCO0FBQ0FMLFlBQU1HLGlCQUFOLEdBQTBCRCxzQkFBMUI7O0FBQ0EsV0FBSyxJQUFJSyxJQUFJRixNQUFNRyxNQUFOLEdBQWUsQ0FBNUIsRUFBK0JELEtBQUssQ0FBcEMsRUFBdUMsRUFBRUEsQ0FBekMsRUFBNEM7QUFDMUMsWUFBSUUsUUFBUUosTUFBTUUsQ0FBTixDQUFaLENBRDBDLENBRTFDO0FBQ0E7O0FBQ0EsY0FBTUcsV0FBV0QsTUFBTUUsV0FBTixFQUFqQjs7QUFDQSxZQUFJRCxZQUFZQSxTQUFTRSxLQUFULENBQWUsWUFBZixDQUFoQixFQUE4QztBQUM1Q3RCLGNBQUl1QixRQUFKLEdBQWVILFFBQWY7QUFDQXBCLGNBQUl3QixJQUFKLEdBQVdMLE1BQU1NLGFBQU4sRUFBWDtBQUNBO0FBQ0Q7QUFDRjtBQUNGOztBQUVELFNBQUtoQyxPQUFMLENBQWE7QUFDVFEsWUFBTyxLQUFLTCxpQkFBTCxHQUF5QixlQUF6QixHQUEyQyxNQUR6QztBQUVUTSxlQUFTRixHQUZBO0FBR1QwQixjQUFRO0FBQUNDLGNBQU0sS0FBS25DLFNBQUwsQ0FBZW1DLElBQXRCO0FBQTRCQyxnQkFBUSxLQUFLL0Isa0JBQXpDO0FBQ0NnQyxtQkFBVyxLQUFLckMsU0FBTCxDQUFlcUMsU0FEM0I7QUFFQ0MsbUJBQVcsS0FBS3RDLFNBQUwsQ0FBZXNDO0FBRjNCO0FBSEMsS0FBYjtBQU9BLFNBQUtsQyxpQkFBTCxHQUF5QixLQUF6QjtBQUNBLFNBQUtDLGtCQUFMO0FBQ0QsR0FwRjBCLENBc0YzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0FrQyxZQUFVQSxTQUFWLEVBQXFCO0FBQ25CLFNBQUtyQyxXQUFMLENBQWlCcUMsU0FBakI7QUFDRCxHQS9GMEIsQ0FpRzNCO0FBQ0E7OztBQUNBckYsVUFBUTtBQUNOLFdBQU8sS0FBS2tDLEVBQVo7QUFDRCxHQXJHMEIsQ0F1RzNCO0FBRUE7OztBQUNBb0QsUUFBTUMsTUFBTixFQUFjQyxRQUFkLEVBQXdCN0IsT0FBeEIsRUFBaUM4QixHQUFqQyxFQUFzQztBQUNwQyxRQUFLLENBQUVBLEdBQUgsSUFBWSxPQUFPRixNQUFQLEtBQWtCLFFBQTlCLElBQ0MsT0FBT0MsUUFBUCxLQUFvQixRQUR6QixFQUNvQztBQUNsQyxXQUFLRSxZQUFMLENBQWtCSCxNQUFsQixFQUEwQkMsUUFBMUIsRUFBb0M3QixPQUFwQzs7QUFDQTtBQUNEO0FBRUQ7Ozs7O0FBSUEsUUFBSWdDLE9BQUosQ0FYb0MsQ0FZcEM7O0FBQ0EsUUFBSSxPQUFPSCxRQUFQLEtBQW9CLFFBQXBCLElBQWdDQSxRQUFoQyxJQUE0Q0EsU0FBU0ksUUFBekQsRUFBbUU7QUFDakVELGdCQUFVSCxhQUFhRCxNQUF2QjtBQUNBQyxpQkFBVyxRQUFYO0FBQ0FELGVBQVMsV0FBVDtBQUNELEtBSkQsTUFJTyxJQUFJLE9BQU9NLFVBQVAsS0FBc0IsV0FBdEIsSUFBcUNMLG9CQUFvQkssVUFBN0QsRUFBeUU7QUFDOUU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFJLEVBQUVOLGtCQUFrQk0sVUFBcEIsQ0FBSixFQUNFLEtBQUtuQyxJQUFMLENBQVU7QUFBQ0gsY0FBTSxjQUFQO0FBQXVCSSxpQkFBUyxtQ0FBaEM7QUFDQzZCLGtCQUFVLGVBRFg7QUFDNEJELGdCQUFRQSxPQUFPMUMsV0FBUCxDQUFtQmlELFFBQW5CO0FBRHBDLE9BQVY7QUFFRixVQUFJTixTQUFTaEIsTUFBVCxLQUFvQmUsT0FBT2YsTUFBL0IsRUFDRSxLQUFLZCxJQUFMLENBQVU7QUFBQ0gsY0FBTSxjQUFQO0FBQXVCSSxpQkFBUyxzQ0FBaEM7QUFDQzZCLGtCQUFVQSxTQUFTaEIsTUFEcEI7QUFDNEJlLGdCQUFRQSxPQUFPZjtBQUQzQyxPQUFWOztBQUVGLFdBQUssSUFBSUQsSUFBSSxDQUFiLEVBQWdCQSxJQUFJaUIsU0FBU2hCLE1BQTdCLEVBQXFDRCxHQUFyQyxFQUEwQztBQUN4QyxhQUFLZSxLQUFMLENBQVdDLE9BQU9oQixDQUFQLENBQVgsRUFBc0JpQixTQUFTakIsQ0FBVCxDQUF0QjtBQUNEO0FBQ0YsS0FkTSxNQWNBO0FBQ0xvQixnQkFBVUksTUFBTUMsTUFBTixDQUFhUixRQUFiLEVBQXVCRCxNQUF2QixDQUFWO0FBQ0Q7O0FBRUQsUUFBSUksWUFBWSxDQUFDLENBQUNGLEdBQWxCLEVBQXVCO0FBQ3JCLFdBQUsvQixJQUFMLENBQVU7QUFBQ0gsY0FBTSxjQUFQO0FBQXVCSSxpQkFBU0EsT0FBaEM7QUFDQzZCLGtCQUFVUyxLQUFLQyxTQUFMLENBQWVWLFFBQWYsQ0FEWDtBQUNxQ0QsZ0JBQVFVLEtBQUtDLFNBQUwsQ0FBZVgsTUFBZixDQUQ3QztBQUNxRUUsYUFBSyxDQUFDLENBQUNBO0FBRDVFLE9BQVY7QUFFRCxLQUhELE1BSUUsS0FBS3BDLEVBQUw7QUFDSDs7QUFFRDhDLFdBQVNaLE1BQVQsRUFBaUJDLFFBQWpCLEVBQTJCN0IsT0FBM0IsRUFBb0M7QUFDbEMsU0FBSzJCLEtBQUwsQ0FBV0MsTUFBWCxFQUFtQkMsUUFBbkIsRUFBNkI3QixPQUE3QixFQUFzQyxJQUF0QztBQUNEOztBQUVEeUMsYUFBV0MsR0FBWCxFQUFnQkMsS0FBaEIsRUFBdUIzQyxPQUF2QixFQUFnQztBQUM5QixRQUFJMEMsZUFBZUMsS0FBbkIsRUFDRSxLQUFLakQsRUFBTCxHQURGLEtBR0UsS0FBS0ssSUFBTCxDQUFVO0FBQUNILFlBQU0sWUFBUDtBQUFxQkksZUFBU0EsT0FBOUI7QUFBdUM4QixXQUFLO0FBQTVDLEtBQVYsRUFKNEIsQ0FJbUM7QUFDbEU7O0FBRURjLGdCQUFjRixHQUFkLEVBQW1CQyxLQUFuQixFQUEwQjNDLE9BQTFCLEVBQW1DO0FBQ2pDLFFBQUkwQyxlQUFlQyxLQUFuQixFQUNFLEtBQUs1QyxJQUFMLENBQVU7QUFBQ0gsWUFBTSxZQUFQO0FBQXFCSSxlQUFTQSxPQUE5QjtBQUF1QzhCLFdBQUs7QUFBNUMsS0FBVixFQURGLENBQ2dFO0FBRGhFLFNBR0UsS0FBS3BDLEVBQUw7QUFDSDs7QUFFRG1ELFVBQVFqQixNQUFSLEVBQWdCa0IsTUFBaEIsRUFBd0I5QyxPQUF4QixFQUFpQztBQUMvQixRQUFJOEMsT0FBT0MsSUFBUCxDQUFZbkIsTUFBWixDQUFKLEVBQ0UsS0FBS2xDLEVBQUwsR0FERixLQUdFLEtBQUtLLElBQUwsQ0FBVTtBQUFDSCxZQUFNLFNBQVA7QUFBa0JJLGVBQVNBLE9BQTNCO0FBQ0M0QixjQUFRQSxNQURUO0FBQ2lCa0IsY0FBUUEsT0FBT1gsUUFBUCxFQUR6QjtBQUM0Q0wsV0FBSztBQURqRCxLQUFWO0FBRUg7O0FBRURrQixhQUFXcEIsTUFBWCxFQUFtQmtCLE1BQW5CLEVBQTJCOUMsT0FBM0IsRUFBb0M7QUFDbEMsUUFBSThDLE9BQU9DLElBQVAsQ0FBWW5CLE1BQVosQ0FBSixFQUNFLEtBQUs3QixJQUFMLENBQVU7QUFBQ0gsWUFBTSxTQUFQO0FBQWtCSSxlQUFTQSxPQUEzQjtBQUNDNEIsY0FBUUEsTUFEVDtBQUNpQmtCLGNBQVFBLE9BQU9YLFFBQVAsRUFEekI7QUFDNENMLFdBQUs7QUFEakQsS0FBVixFQURGLEtBSUUsS0FBS3BDLEVBQUw7QUFDSCxHQXBMMEIsQ0FzTDNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBdUQsU0FBT0MsQ0FBUCxFQUFVckIsUUFBVixFQUFvQjtBQUNsQixRQUFJRCxNQUFKLEVBQVl1QixTQUFaOztBQUVBLFFBQUl0QixhQUFhdUIsU0FBakIsRUFBNEI7QUFDMUJELGtCQUFZLFVBQVV2QixNQUFWLEVBQWtCO0FBQzVCLGVBQU8sSUFBUDtBQUNELE9BRkQ7QUFHRCxLQUpELE1BSU8sSUFBSSxPQUFPQyxRQUFQLEtBQW9CLFFBQXhCLEVBQWtDO0FBQ3ZDc0Isa0JBQVksVUFBVXZCLE1BQVYsRUFBa0I7QUFDNUIsZUFBTyxPQUFPQSxPQUFPNUIsT0FBZCxLQUEwQixRQUExQixJQUNBNEIsT0FBTzVCLE9BQVAsQ0FBZXFELE9BQWYsQ0FBdUJ4QixRQUF2QixNQUFxQyxDQUFDLENBRDdDO0FBRUQsT0FIRDtBQUlELEtBTE0sTUFLQSxJQUFJQSxvQkFBb0J5QixNQUF4QixFQUFnQztBQUNyQ0gsa0JBQVksVUFBVXZCLE1BQVYsRUFBa0I7QUFDNUIsZUFBT0MsU0FBU2tCLElBQVQsQ0FBY25CLE9BQU81QixPQUFyQixDQUFQO0FBQ0QsT0FGRDtBQUdELEtBSk0sTUFJQSxJQUFJLE9BQU82QixRQUFQLEtBQW9CLFVBQXhCLEVBQW9DO0FBQ3pDc0Isa0JBQVl0QixRQUFaO0FBQ0QsS0FGTSxNQUVBO0FBQ0wsWUFBTSxJQUFJeEIsS0FBSixDQUFVLDREQUFWLENBQU47QUFDRDs7QUFFRCxRQUFJO0FBQ0Y2QztBQUNELEtBRkQsQ0FFRSxPQUFPeEIsU0FBUCxFQUFrQjtBQUNsQkUsZUFBU0YsU0FBVDtBQUNEOztBQUVELFFBQUlFLFVBQVV1QixVQUFVdkIsTUFBVixDQUFkLEVBQ0UsS0FBS2xDLEVBQUwsR0FERixLQUdFLEtBQUtLLElBQUwsQ0FBVTtBQUNSSCxZQUFNLFFBREU7QUFFUkksZUFBUzRCLFNBQ1AseUJBQXlCQSxPQUFPNUIsT0FEekIsR0FFUDtBQUpNLEtBQVY7QUFNSDs7QUFFRHVELFNBQU8zSCxDQUFQLEVBQVU0SCxHQUFWLEVBQWU7QUFDYixRQUFJNUgsQ0FBSixFQUNFLEtBQUs4RCxFQUFMLEdBREYsS0FHRSxLQUFLSyxJQUFMLENBQVU7QUFBQ0gsWUFBTSxNQUFQO0FBQWVJLGVBQVN3RCxHQUF4QjtBQUE2QjFCLFdBQUs7QUFBbEMsS0FBVjtBQUNIOztBQUVEMkIsVUFBUTdILENBQVIsRUFBVzRILEdBQVgsRUFBZ0I7QUFDZCxRQUFJNUgsQ0FBSixFQUNFLEtBQUttRSxJQUFMLENBQVU7QUFBQ0gsWUFBTSxNQUFQO0FBQWVJLGVBQVN3RCxHQUF4QjtBQUE2QjFCLFdBQUs7QUFBbEMsS0FBVixFQURGLEtBR0UsS0FBS3BDLEVBQUw7QUFDSDs7QUFFRGdFLFNBQU85SCxDQUFQLEVBQVU0SCxHQUFWLEVBQWU7QUFDYixRQUFJNUgsTUFBTSxJQUFWLEVBQ0UsS0FBSzhELEVBQUwsR0FERixLQUdFLEtBQUtLLElBQUwsQ0FBVTtBQUFDSCxZQUFNLE1BQVA7QUFBZUksZUFBU3dELEdBQXhCO0FBQTZCMUIsV0FBSztBQUFsQyxLQUFWO0FBQ0g7O0FBRUQ2QixZQUFVL0gsQ0FBVixFQUFhNEgsR0FBYixFQUFrQjtBQUNoQixRQUFJNUgsTUFBTSxJQUFWLEVBQ0UsS0FBS21FLElBQUwsQ0FBVTtBQUFDSCxZQUFNLE1BQVA7QUFBZUksZUFBU3dELEdBQXhCO0FBQTZCMUIsV0FBSztBQUFsQyxLQUFWLEVBREYsS0FHRSxLQUFLcEMsRUFBTDtBQUNIOztBQUVEa0UsY0FBWWhJLENBQVosRUFBZTRILEdBQWYsRUFBb0I7QUFDbEIsUUFBSTVILE1BQU13SCxTQUFWLEVBQ0UsS0FBSzFELEVBQUwsR0FERixLQUdFLEtBQUtLLElBQUwsQ0FBVTtBQUFDSCxZQUFNLFdBQVA7QUFBb0JJLGVBQVN3RCxHQUE3QjtBQUFrQzFCLFdBQUs7QUFBdkMsS0FBVjtBQUNIOztBQUVEK0IsaUJBQWVqSSxDQUFmLEVBQWtCNEgsR0FBbEIsRUFBdUI7QUFDckIsUUFBSTVILE1BQU13SCxTQUFWLEVBQ0UsS0FBS3JELElBQUwsQ0FBVTtBQUFDSCxZQUFNLFdBQVA7QUFBb0JJLGVBQVN3RCxHQUE3QjtBQUFrQzFCLFdBQUs7QUFBdkMsS0FBVixFQURGLEtBR0UsS0FBS3BDLEVBQUw7QUFDSDs7QUFFRG9FLFFBQU1sSSxDQUFOLEVBQVM0SCxHQUFULEVBQWM7QUFDWixRQUFJTSxNQUFNbEksQ0FBTixDQUFKLEVBQ0UsS0FBSzhELEVBQUwsR0FERixLQUdFLEtBQUtLLElBQUwsQ0FBVTtBQUFDSCxZQUFNLEtBQVA7QUFBY0ksZUFBU3dELEdBQXZCO0FBQTRCMUIsV0FBSztBQUFqQyxLQUFWO0FBQ0g7O0FBRURpQyxXQUFTbkksQ0FBVCxFQUFZNEgsR0FBWixFQUFpQjtBQUNmLFFBQUlNLE1BQU1sSSxDQUFOLENBQUosRUFDRSxLQUFLbUUsSUFBTCxDQUFVO0FBQUNILFlBQU0sS0FBUDtBQUFjSSxlQUFTd0QsR0FBdkI7QUFBNEIxQixXQUFLO0FBQWpDLEtBQVYsRUFERixLQUdFLEtBQUtwQyxFQUFMO0FBQ0g7O0FBRURzRSxVQUFRQyxDQUFSLEVBQVdySSxDQUFYLEVBQWNvRSxPQUFkLEVBQXVCOEIsR0FBdkIsRUFBNEI7QUFDMUIsUUFBSW9DLE9BQU8sS0FBWDs7QUFDQSxRQUFJRCxhQUFhRSxLQUFqQixFQUF3QjtBQUN0QkQsYUFBT0QsRUFBRUcsSUFBRixDQUFPQyxNQUFNNUQsRUFBRTZELE9BQUYsQ0FBVTFJLENBQVYsRUFBYXlJLEVBQWIsQ0FBYixDQUFQO0FBQ0QsS0FGRCxNQUVPLElBQUlKLEtBQUssT0FBT0EsQ0FBUCxLQUFhLFFBQXRCLEVBQWdDO0FBQ3JDQyxhQUFPdEksS0FBS3FJLENBQVo7QUFDRCxLQUZNLE1BRUEsSUFBSSxPQUFPQSxDQUFQLEtBQWEsUUFBakIsRUFBMkI7QUFDaEMsVUFBSUEsRUFBRVosT0FBRixDQUFVekgsQ0FBVixJQUFlLENBQUMsQ0FBcEIsRUFBdUI7QUFDckJzSSxlQUFPLElBQVA7QUFDRDtBQUNGLEtBSk0sTUFJQTtBQUNMO0FBQXNEO0FBQ3ZEOztBQUVELFFBQUlBLFNBQVMsQ0FBRXBDLEdBQWYsRUFBb0I7QUFDbEIsV0FBS3BDLEVBQUw7QUFDRCxLQUZELE1BRU87QUFDTCxXQUFLSyxJQUFMLENBQVU7QUFDUkgsY0FBTSxTQURFO0FBRVJJLGVBRlE7QUFHUnVFLGtCQUFVTixDQUhGO0FBSVJPLDhCQUFzQjVJLENBSmQ7QUFLUmtHLGFBQUssQ0FBQyxDQUFDQTtBQUxDLE9BQVY7QUFPRDtBQUNGOztBQUVEMkMsYUFBV1IsQ0FBWCxFQUFjckksQ0FBZCxFQUFpQm9FLE9BQWpCLEVBQTBCO0FBQ3hCLFNBQUtnRSxPQUFMLENBQWFDLENBQWIsRUFBZ0JySSxDQUFoQixFQUFtQm9FLE9BQW5CLEVBQTRCLElBQTVCO0FBQ0QsR0FuVTBCLENBcVUzQjs7O0FBQ0FhLFNBQU82QixHQUFQLEVBQVlnQyxlQUFaLEVBQTZCbEIsR0FBN0IsRUFBa0M7QUFDaEMsUUFBSWQsSUFBSTdCLE1BQUosS0FBZTZELGVBQW5CLEVBQW9DO0FBQ2xDLFdBQUtoRixFQUFMO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsV0FBS0ssSUFBTCxDQUFVO0FBQ1JILGNBQU0sUUFERTtBQUVSaUMsa0JBQVU2QyxlQUZGO0FBR1I5QyxnQkFBUWMsSUFBSTdCLE1BSEo7QUFJUmIsaUJBQVN3RDtBQUpELE9BQVY7QUFNRDtBQUNGLEdBalYwQixDQW1WM0I7QUFDQTtBQUNBOzs7QUFDQXpCLGVBQWFILE1BQWIsRUFBcUJDLFFBQXJCLEVBQStCN0IsT0FBL0IsRUFBd0M7QUFDdEMsUUFBSTRCLFdBQVdDLFFBQWYsRUFBeUI7QUFDdkIsV0FBSzlCLElBQUwsQ0FBVTtBQUNSSCxjQUFNLGNBREU7QUFFUkksZUFGUTtBQUdSNkIsZ0JBSFE7QUFJUkQ7QUFKUSxPQUFWO0FBTUQsS0FQRCxNQU9PO0FBQ0wsV0FBS2xDLEVBQUw7QUFDRDtBQUNGOztBQWpXMEI7O0FBd1d0QixNQUFNYixRQUFOLENBQWU7QUFDcEJLLGNBQVlvQyxJQUFaLEVBQWtCcUQsSUFBbEIsRUFBd0I7QUFDdEIsU0FBS3JELElBQUwsR0FBWUEsSUFBWjtBQUNBLFNBQUtxRCxJQUFMLEdBQVlBLElBQVo7QUFFQSxRQUFJQyxZQUFZdEQsS0FBS3VELEtBQUwsQ0FBVyxLQUFYLEVBQWtCQyxHQUFsQixDQUFzQmIsS0FBSztBQUN6QyxhQUFPQSxFQUFFYyxPQUFGLENBQVUsWUFBVixFQUF3QixFQUF4QixDQUFQLENBRHlDLENBQ0w7QUFDckMsS0FGZSxDQUFoQjtBQUdBLFNBQUt0RCxTQUFMLEdBQWlCbUQsVUFBVUksR0FBVixFQUFqQjtBQUNBSixjQUFVSyxPQUFWLENBQWtCLFVBQWxCO0FBQ0EsU0FBS3pELFNBQUwsR0FBaUJvRCxTQUFqQjtBQUNELEdBWG1CLENBYXBCO0FBQ0E7QUFDQTs7O0FBQ0FNLE1BQUk5RixPQUFKLEVBQWFaLFVBQWIsRUFBeUJhLFdBQXpCLEVBQXNDQyxjQUF0QyxFQUFzRDtBQUNwRCxRQUFJNkYsWUFBWSxLQUFoQjtBQUVBLFdBQU8sSUFBSUMsT0FBSixDQUFZLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUN0QyxZQUFNQyxVQUFVLElBQUkzRyxlQUFKLENBQ2QsSUFEYyxFQUVkNEcsU0FBUztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBSUwsU0FBSixFQUFlO0FBQ2JoSCxrQkFBUUMsS0FBUixDQUFjLHVCQUFkO0FBQ0Q7O0FBQ0QsZUFBT2dCLFFBQVFvRyxLQUFSLENBQVA7QUFDRCxPQVhhLEVBWWRGLE1BWmMsRUFhZGhHLGNBYmMsQ0FBaEI7QUFnQkEsWUFBTW1HLFNBQVMsS0FBS2QsSUFBTCxDQUFVWSxPQUFWLEVBQW1CRixPQUFuQixDQUFmOztBQUNBLFVBQUlJLFVBQVUsT0FBT0EsT0FBT0MsSUFBZCxLQUF1QixVQUFyQyxFQUFpRDtBQUMvQ0QsZUFBT0MsSUFBUCxDQUFZTCxPQUFaLEVBQXFCQyxNQUFyQjtBQUNEO0FBRUYsS0F0Qk0sRUFzQkpJLElBdEJJLENBdUJMLE1BQU07QUFDSlAsa0JBQVksSUFBWjtBQUNBM0c7QUFDRCxLQTFCSSxFQTJCTG1ILFNBQVM7QUFDUFIsa0JBQVksSUFBWjtBQUNBOUYsa0JBQVlzRyxLQUFaO0FBQ0QsS0E5QkksQ0FBUDtBQWdDRDs7QUFuRG1COztBQTBEZixNQUFNN0csY0FBYyxJQUFLLE1BQU1BLFdBQU4sQ0FBa0I7QUFDaERJLGdCQUFjO0FBQ1osU0FBSzBHLEtBQUwsR0FBYSxFQUFiO0FBQ0EsU0FBS0MsYUFBTCxHQUFxQixFQUFyQjtBQUNBLFNBQUtDLFNBQUwsR0FBaUIzSixPQUFPOEMsUUFBUCxJQUFtQixJQUFJOUMsT0FBTzRKLGlCQUFYLEVBQXBDO0FBQ0Q7O0FBRURDLFVBQVFqRCxJQUFSLEVBQWM7QUFDWixRQUFJQSxLQUFLekIsSUFBTCxJQUFhLEtBQUtzRSxLQUF0QixFQUNFLE1BQU0sSUFBSXZGLEtBQUosQ0FDSixvRUFDRTBDLEtBQUt6QixJQURQLEdBQ2MsR0FGVixDQUFOOztBQUdGLFFBQUkyRSwwQkFBMEJDLGNBQTFCLElBQ0FuRCxLQUFLekIsSUFBTCxDQUFVK0IsT0FBVixDQUFrQjRDLDBCQUEwQkMsY0FBNUMsTUFBZ0UsQ0FBQyxDQURyRSxFQUN3RTtBQUN0RTtBQUNEOztBQUNELFNBQUtOLEtBQUwsQ0FBVzdDLEtBQUt6QixJQUFoQixJQUF3QnlCLElBQXhCO0FBQ0EsU0FBSzhDLGFBQUwsQ0FBbUJNLElBQW5CLENBQXdCcEQsSUFBeEI7QUFDRDs7QUFFRHFELFlBQVVwSSxRQUFWLEVBQW9CZCxVQUFwQixFQUFnQztBQUM5QixXQUFPLElBQUk2QixPQUFKLENBQVksSUFBWixFQUFrQmYsUUFBbEIsRUFBNEJkLFVBQTVCLENBQVA7QUFDRDs7QUF0QitDLENBQXZCLEVBQXBCOztBQXlCUCxJQUFJZixPQUFPOEMsUUFBUCxJQUFtQm9ILFFBQVFDLEdBQVIsQ0FBWUMsZUFBbkMsRUFBb0Q7QUFDbEROLDRCQUEwQkMsY0FBMUIsR0FBMkNHLFFBQVFDLEdBQVIsQ0FBWUMsZUFBdkQ7QUFDRDtBQUVEOztBQUNBOztBQUNBOzs7QUFFTyxNQUFNeEgsT0FBTixDQUFjO0FBQ25CRyxjQUFZc0gsT0FBWixFQUFxQnhJLFFBQXJCLEVBQStCZCxVQUEvQixFQUEyQztBQUN6QyxTQUFLc0osT0FBTCxHQUFlQSxPQUFmO0FBQ0EsU0FBS3hJLFFBQUwsR0FBZ0JBLFFBQWhCO0FBQ0EsU0FBS3lJLG9CQUFMLEdBQTRCLENBQTVCO0FBQ0EsU0FBS0MsV0FBTCxHQUFtQnhKLGNBQWMsRUFBakM7QUFDQSxTQUFLc0osT0FBTCxDQUFhWCxhQUFiLENBQTJCaEksT0FBM0IsQ0FBbUNrRixRQUFRO0FBQ3pDLFVBQUksS0FBSzRELFlBQUwsQ0FBa0I1RCxLQUFLdkIsU0FBdkIsQ0FBSixFQUNFLEtBQUtvRixPQUFMLENBQWE3RCxJQUFiO0FBQ0gsS0FIRDtBQUlEOztBQUVENEQsZUFBYUUsUUFBYixFQUF1QjtBQUNyQixTQUFLLElBQUlqRyxJQUFJLENBQWIsRUFBZ0JBLElBQUksS0FBSzhGLFdBQUwsQ0FBaUI3RixNQUFyQyxFQUE2Q0QsR0FBN0MsRUFBa0Q7QUFDaEQsVUFBSSxDQUFDaUcsU0FBU2pHLENBQVQsQ0FBRCxJQUFnQixLQUFLOEYsV0FBTCxDQUFpQjlGLENBQWpCLE1BQXdCaUcsU0FBU2pHLENBQVQsQ0FBNUMsRUFBeUQ7QUFDdkQsZUFBTyxLQUFQO0FBQ0Q7QUFDRjs7QUFDRCxXQUFPLElBQVA7QUFDRDs7QUFFRGtHLFdBQVMvRCxJQUFULEVBQWV2RSxVQUFmLEVBQTJCYyxjQUEzQixFQUEyQztBQUN6QyxRQUFJeUgsWUFBYSxDQUFDLElBQUk1RyxJQUFKLEVBQWxCO0FBRUE0QyxTQUFLbUMsR0FBTCxDQUFTTSxTQUFTO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBLFVBQUl6QyxLQUFLaUUsUUFBVCxFQUNFOztBQUNGLFdBQUtKLE9BQUwsQ0FBYTdELElBQWIsRUFBbUJ5QyxLQUFuQjtBQUNELEtBUEQsRUFPRyxNQUFNO0FBQ1A7QUFDQSxVQUFJekMsS0FBS2lFLFFBQVQsRUFDRTtBQUNGLFVBQUlDLFlBQWEsQ0FBQyxJQUFJOUcsSUFBSixFQUFGLEdBQWM0RyxTQUE5Qjs7QUFDQSxXQUFLSCxPQUFMLENBQWE3RCxJQUFiLEVBQW1CO0FBQUNuRCxjQUFNLFFBQVA7QUFBaUJzSCxnQkFBUUQ7QUFBekIsT0FBbkI7O0FBQ0F6STtBQUNELEtBZEQsRUFjR2tELGFBQWE7QUFDZDtBQUNBLFVBQUlxQixLQUFLaUUsUUFBVCxFQUNFLE9BSFksQ0FLZDtBQUNBOztBQUNBLFdBQUtKLE9BQUwsQ0FBYTdELElBQWIsRUFBbUI7QUFDakJuRCxjQUFNLFdBRFc7QUFFakJDLGlCQUFTO0FBQ1BHLG1CQUFTMEIsVUFBVTFCLE9BRFo7QUFDcUI7QUFDNUJVLGlCQUFPZ0IsVUFBVWhCLEtBRlYsQ0FFZ0I7O0FBRmhCO0FBRlEsT0FBbkI7O0FBUUFsQztBQUNELEtBOUJELEVBOEJHYyxjQTlCSDtBQStCRCxHQXZEa0IsQ0F5RG5CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBNkgsVUFBUXBFLElBQVIsRUFBY3ZFLFVBQWQsRUFBMEJjLGNBQTFCLEVBQTBDO0FBQ3hDLFFBQUksQ0FBRSxLQUFLcUgsWUFBTCxDQUFrQjVELEtBQUt2QixTQUF2QixDQUFOLEVBQXlDO0FBQ3ZDaEQsb0JBQWNBLFlBQWQ7QUFDQTtBQUNEOztBQUVELFFBQUlyQyxPQUFPOEMsUUFBWCxFQUFxQjtBQUNuQjtBQUNBO0FBQ0EsV0FBS3VILE9BQUwsQ0FBYVYsU0FBYixDQUF1QnNCLFNBQXZCLENBQWlDLE1BQU07QUFDckM7QUFDQSxZQUFJQyxTQUFTLElBQUlySSxNQUFKLEVBQWI7QUFDQTdDLGVBQU9tTCxVQUFQLENBQ0UsTUFBTTtBQUNKLGNBQUlELE9BQU9FLFVBQVAsRUFBSixFQUNFO0FBQ0E7QUFDRnhFLGVBQUtpRSxRQUFMLEdBQWdCLElBQWhCOztBQUNBLGVBQUtKLE9BQUwsQ0FBYTdELElBQWIsRUFBbUI7QUFDakJuRCxrQkFBTSxXQURXO0FBRWpCQyxxQkFBUztBQUNQRyx1QkFBUztBQURGO0FBRlEsV0FBbkI7O0FBTUFxSCxpQkFBTyxRQUFQO0FBQ0QsU0FiSCxFQWNFLElBQUksRUFBSixHQUFTLElBZFgsQ0FjaUI7QUFkakI7O0FBZ0JBLGFBQUtQLFFBQUwsQ0FBYy9ELElBQWQsRUFBb0IsTUFBTTtBQUN4QjtBQUNBO0FBQ0E7QUFDQSxjQUFJLENBQUVzRSxPQUFPRSxVQUFQLEVBQU4sRUFDRUYsT0FBTyxRQUFQO0FBQ0gsU0FORCxFQU1HL0gsY0FOSCxFQW5CcUMsQ0EwQnJDOzs7QUFDQStILGVBQU9HLElBQVA7QUFDQWhKLHNCQUFjQSxZQUFkO0FBQ0QsT0E3QkQ7QUE4QkQsS0FqQ0QsTUFpQ087QUFDTDtBQUNBLFdBQUtzSSxRQUFMLENBQWMvRCxJQUFkLEVBQW9CLE1BQU07QUFDeEJ2RSxzQkFBY0EsWUFBZDtBQUNELE9BRkQsRUFFR2MsY0FGSDtBQUdEO0FBQ0Y7O0FBRUQ0RixNQUFJMUcsVUFBSixFQUFnQjtBQUNkLFFBQUlvSCxRQUFRLEtBQUtZLE9BQUwsQ0FBYVgsYUFBYixDQUEyQjRCLEtBQTNCLENBQWlDLENBQWpDLENBQVo7O0FBQ0EsUUFBSUMsZ0JBQWdCLFVBQVVwRyxJQUFWLEVBQWdCO0FBQ2xDLFVBQUluRixPQUFPOEQsUUFBWCxFQUNFeEUsU0FBU2tNLG9CQUFULENBQThCckcsSUFBOUI7QUFDSCxLQUhEOztBQUtBLFVBQU1zRyxVQUFVLE1BQU07QUFDcEIsVUFBSWhDLE1BQU0vRSxNQUFWLEVBQWtCO0FBQ2hCLFlBQUlnSCxJQUFJakMsTUFBTWtDLEtBQU4sRUFBUjtBQUNBSixzQkFBY0csRUFBRXZHLElBQWhCOztBQUNBLGFBQUs2RixPQUFMLENBQWFVLENBQWIsRUFBZ0JELE9BQWhCO0FBQ0QsT0FKRCxNQUlPO0FBQ0xGLHNCQUFjLElBQWQ7QUFDQWxKLHNCQUFjQSxZQUFkO0FBQ0Q7QUFDRixLQVREOztBQVdBb0o7QUFDRCxHQWhJa0IsQ0FrSW5CO0FBQ0E7QUFDQTs7O0FBQ0FHLFFBQU0xRyxNQUFOLEVBQWM3QyxVQUFkLEVBQTBCO0FBQ3hCLFFBQUl1RSxPQUFPLEtBQUt5RCxPQUFMLENBQWFaLEtBQWIsQ0FBbUJ2RSxPQUFPQyxJQUExQixDQUFYO0FBQ0EsUUFBSSxDQUFDeUIsSUFBTCxFQUNFLE1BQU0sSUFBSTFDLEtBQUosQ0FBVSxtQkFBbUJnQixPQUFPQyxJQUExQixHQUFpQyxHQUEzQyxDQUFOOztBQUNGLFNBQUs2RixPQUFMLENBQWFwRSxJQUFiLEVBQW1CdkUsVUFBbkIsRUFBK0I2QyxPQUFPRSxNQUF0QztBQUNEOztBQUVEcUYsVUFBUTdELElBQVIsRUFBY3lDLEtBQWQsRUFBcUI7QUFDbkIsUUFBSXdDLE1BQUo7O0FBQ0EsUUFBSXhDLEtBQUosRUFBVztBQUNUd0MsZUFBUztBQUNQekQsa0JBQVUsS0FBS2tDLG9CQUFMO0FBREgsU0FFSmpCLEtBRkksRUFBVDtBQUlELEtBTEQsTUFLTztBQUNMd0MsZUFBUyxFQUFUO0FBQ0Q7O0FBQ0QsU0FBS2hLLFFBQUwsQ0FBYztBQUNad0QsaUJBQVd1QixLQUFLdkIsU0FESjtBQUVadUIsWUFBTUEsS0FBS3RCLFNBRkM7QUFHWnVHO0FBSFksS0FBZDtBQUtEOztBQTNKa0I7O0FBa0tkLE1BQU12TSxXQUFXLEVBQWpCOztBQUVQQSxTQUFTd00sUUFBVCxHQUFvQixVQUFVM0csSUFBVixFQUFnQnFELElBQWhCLEVBQXNCO0FBQ3hDN0YsY0FBWWtILE9BQVosQ0FBb0IsSUFBSW5ILFFBQUosQ0FBYXlDLElBQWIsRUFBbUJxRCxJQUFuQixDQUFwQjtBQUNELENBRkQ7O0FBSUFsSixTQUFTbUIsR0FBVCxHQUFlLFVBQVUwRSxJQUFWLEVBQWdCcUQsSUFBaEIsRUFBc0I7QUFDbkNsSixXQUFTd00sUUFBVCxDQUFrQjNHLElBQWxCLEVBQXdCLFVBQVV5QixJQUFWLEVBQWdCdkUsVUFBaEIsRUFBNEI7QUFDbERtRyxTQUFLNUIsSUFBTDtBQUNBdkU7QUFDRCxHQUhEO0FBSUQsQ0FMRCxDLENBT0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EvQyxTQUFTaUQsU0FBVCxHQUFxQixVQUFVVixRQUFWLEVBQW9CUSxVQUFwQixFQUFnQ3RCLFVBQWhDLEVBQTRDO0FBQy9ELE1BQUlnTCxVQUFVcEosWUFBWXNILFNBQVosQ0FBc0JwSSxRQUF0QixFQUFnQ2QsVUFBaEMsQ0FBZDtBQUNBZ0wsVUFBUWhELEdBQVIsQ0FBWTFHLFVBQVo7QUFDRCxDQUhELEMsQ0FLQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EvQyxTQUFTME0sVUFBVCxHQUFzQixVQUFVOUcsTUFBVixFQUFrQnJELFFBQWxCLEVBQTRCUSxVQUE1QixFQUF3QztBQUM1RCxNQUFJMEosVUFBVXBKLFlBQVlzSCxTQUFaLENBQXNCcEksUUFBdEIsQ0FBZDtBQUNBa0ssVUFBUUgsS0FBUixDQUFjMUcsTUFBZCxFQUFzQjdDLFVBQXRCO0FBQ0QsQ0FIRCxDLENBS0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBL0MsU0FBU2tNLG9CQUFULEdBQWdDLFVBQVVyRyxJQUFWLEVBQWdCLENBQUUsQ0FBbEQ7O0FBRUE3RixTQUFTMk0sZ0JBQVQsR0FBNEJ4SixlQUE1QjtBQUNBbkQsU0FBUzRNLFNBQVQsR0FBcUJ4SixRQUFyQjtBQUNBcEQsU0FBUzZNLFlBQVQsR0FBd0J4SixXQUF4QjtBQUNBckQsU0FBUzhNLFFBQVQsR0FBb0J4SixPQUFwQixDIiwiZmlsZSI6Ii9wYWNrYWdlcy90aW55dGVzdC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFRpbnl0ZXN0IH0gZnJvbSBcIi4vdGlueXRlc3QuanNcIjtcbmltcG9ydCB7XG4gIFNlcnZlclRlc3RSZXN1bHRzU3Vic2NyaXB0aW9uLFxuICBTZXJ2ZXJUZXN0UmVzdWx0c0NvbGxlY3Rpb24sXG59IGZyb20gXCIuL21vZGVsLmpzXCI7XG5cbmV4cG9ydCB7IFRpbnl0ZXN0IH07XG5cbmNvbnN0IEZpYmVyID0gcmVxdWlyZSgnZmliZXJzJyk7XG5jb25zdCBoYW5kbGVzRm9yUnVuID0gbmV3IE1hcDtcbmNvbnN0IHJlcG9ydHNGb3JSdW4gPSBuZXcgTWFwO1xuXG5NZXRlb3IucHVibGlzaChTZXJ2ZXJUZXN0UmVzdWx0c1N1YnNjcmlwdGlvbiwgZnVuY3Rpb24gKHJ1bklkKSB7XG4gIGNoZWNrKHJ1bklkLCBTdHJpbmcpO1xuXG4gIGlmICghIGhhbmRsZXNGb3JSdW4uaGFzKHJ1bklkKSkge1xuICAgIGhhbmRsZXNGb3JSdW4uc2V0KHJ1bklkLCBuZXcgU2V0KTtcbiAgfVxuXG4gIGhhbmRsZXNGb3JSdW4uZ2V0KHJ1bklkKS5hZGQodGhpcyk7XG5cbiAgdGhpcy5vblN0b3AoKCkgPT4ge1xuICAgIGhhbmRsZXNGb3JSdW4uZ2V0KHJ1bklkKS5kZWxldGUodGhpcyk7XG4gIH0pO1xuXG4gIGlmIChyZXBvcnRzRm9yUnVuLmhhcyhydW5JZCkpIHtcbiAgICB0aGlzLmFkZGVkKFNlcnZlclRlc3RSZXN1bHRzQ29sbGVjdGlvbiwgcnVuSWQsXG4gICAgICAgICAgICAgICByZXBvcnRzRm9yUnVuLmdldChydW5JZCkpO1xuICB9IGVsc2Uge1xuICAgIHRoaXMuYWRkZWQoU2VydmVyVGVzdFJlc3VsdHNDb2xsZWN0aW9uLCBydW5JZCwge30pO1xuICB9XG5cbiAgdGhpcy5yZWFkeSgpO1xufSk7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgJ3Rpbnl0ZXN0L3J1bicocnVuSWQsIHBhdGhQcmVmaXgpIHtcbiAgICBjaGVjayhydW5JZCwgU3RyaW5nKTtcbiAgICBjaGVjayhwYXRoUHJlZml4LCBNYXRjaC5PcHRpb25hbChbU3RyaW5nXSkpO1xuICAgIHRoaXMudW5ibG9jaygpO1xuXG4gICAgcmVwb3J0c0ZvclJ1bi5zZXQocnVuSWQsIE9iamVjdC5jcmVhdGUobnVsbCkpO1xuXG4gICAgZnVuY3Rpb24gYWRkUmVwb3J0KGtleSwgcmVwb3J0KSB7XG4gICAgICB2YXIgZmllbGRzID0ge307XG4gICAgICBmaWVsZHNba2V5XSA9IHJlcG9ydDtcbiAgICAgIGNvbnN0IGhhbmRsZXMgPSBoYW5kbGVzRm9yUnVuLmdldChydW5JZCk7XG4gICAgICBpZiAoaGFuZGxlcykge1xuICAgICAgICBoYW5kbGVzLmZvckVhY2goaGFuZGxlID0+IHtcbiAgICAgICAgICBoYW5kbGUuY2hhbmdlZChTZXJ2ZXJUZXN0UmVzdWx0c0NvbGxlY3Rpb24sIHJ1bklkLCBmaWVsZHMpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIC8vIFNhdmUgZm9yIGZ1dHVyZSBzdWJzY3JpcHRpb25zLlxuICAgICAgcmVwb3J0c0ZvclJ1bi5nZXQocnVuSWQpW2tleV0gPSByZXBvcnQ7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gb25SZXBvcnQocmVwb3J0KSB7XG4gICAgICBpZiAoISBGaWJlci5jdXJyZW50KSB7XG4gICAgICAgIE1ldGVvci5fZGVidWcoXCJUcnlpbmcgdG8gcmVwb3J0IGEgdGVzdCBub3QgaW4gYSBmaWJlciEgXCIrXG4gICAgICAgICAgICAgICAgICAgICAgXCJZb3UgcHJvYmFibHkgZm9yZ290IHRvIHdyYXAgYSBjYWxsYmFjayBpbiBiaW5kRW52aXJvbm1lbnQuXCIpO1xuICAgICAgICBjb25zb2xlLnRyYWNlKCk7XG4gICAgICB9XG4gICAgICB2YXIgZHVtbXlLZXkgPSBSYW5kb20uaWQoKTtcbiAgICAgIGFkZFJlcG9ydChkdW1teUtleSwgcmVwb3J0KTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBvbkNvbXBsZXRlKCkge1xuICAgICAgLy8gV2Ugc2VuZCBhbiBvYmplY3QgZm9yIGN1cnJlbnQgYW5kIGZ1dHVyZSBjb21wYXRpYmlsaXR5LFxuICAgICAgLy8gdGhvdWdoIHdlIGNvdWxkIGdldCBhd2F5IHdpdGgganVzdCBzZW5kaW5nIHsgY29tcGxldGU6IHRydWUgfVxuICAgICAgdmFyIHJlcG9ydCA9IHsgZG9uZTogdHJ1ZSB9O1xuICAgICAgdmFyIGtleSA9ICdjb21wbGV0ZSc7XG4gICAgICBhZGRSZXBvcnQoa2V5LCByZXBvcnQpO1xuICAgIH1cblxuICAgIFRpbnl0ZXN0Ll9ydW5UZXN0cyhvblJlcG9ydCwgb25Db21wbGV0ZSwgcGF0aFByZWZpeCk7XG4gIH0sXG5cbiAgJ3Rpbnl0ZXN0L2NsZWFyUmVzdWx0cycocnVuSWQpIHtcbiAgICBjaGVjayhydW5JZCwgU3RyaW5nKTtcblxuICAgIGhhbmRsZXNGb3JSdW4uZ2V0KHJ1bklkKS5mb3JFYWNoKGhhbmRsZSA9PiB7XG4gICAgICAvLyBYWFggdGhpcyBkb2Vzbid0IGFjdHVhbGx5IG5vdGlmeSB0aGUgY2xpZW50IHRoYXQgaXQgaGFzIGJlZW5cbiAgICAgIC8vIHVuc3Vic2NyaWJlZC5cbiAgICAgIGhhbmRsZS5zdG9wKCk7XG4gICAgfSk7XG5cbiAgICBoYW5kbGVzRm9yUnVuLmRlbGV0ZShydW5JZCk7XG4gICAgcmVwb3J0c0ZvclJ1bi5kZWxldGUocnVuSWQpO1xuICB9XG59KTtcbiIsImV4cG9ydCBjb25zdCBTZXJ2ZXJUZXN0UmVzdWx0c1N1YnNjcmlwdGlvbiA9XG4gIFwidGlueXRlc3RfcmVzdWx0c19zdWJzY3JpcHRpb25cIjtcblxuZXhwb3J0IGNvbnN0IFNlcnZlclRlc3RSZXN1bHRzQ29sbGVjdGlvbiA9XG4gIFwidGlueXRlc3RfcmVzdWx0c19jb2xsZWN0aW9uXCI7XG4iLCJjb25zdCBGdXR1cmUgPSBNZXRlb3IuaXNTZXJ2ZXIgJiYgcmVxdWlyZSgnZmliZXJzL2Z1dHVyZScpO1xuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyogVGVzdENhc2VSZXN1bHRzICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKi9cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbmV4cG9ydCBjbGFzcyBUZXN0Q2FzZVJlc3VsdHMge1xuICBjb25zdHJ1Y3Rvcih0ZXN0X2Nhc2UsIG9uRXZlbnQsIG9uRXhjZXB0aW9uLCBzdG9wX2F0X29mZnNldCkge1xuICAgIHRoaXMudGVzdF9jYXNlID0gdGVzdF9jYXNlO1xuICAgIHRoaXMub25FdmVudCA9IG9uRXZlbnQ7XG4gICAgdGhpcy5leHBlY3RpbmdfZmFpbHVyZSA9IGZhbHNlO1xuICAgIHRoaXMuY3VycmVudF9mYWlsX2NvdW50ID0gMDtcbiAgICB0aGlzLnN0b3BfYXRfb2Zmc2V0ID0gc3RvcF9hdF9vZmZzZXQ7XG4gICAgdGhpcy5vbkV4Y2VwdGlvbiA9IG9uRXhjZXB0aW9uO1xuICAgIHRoaXMuaWQgPSBSYW5kb20uaWQoKTtcbiAgICB0aGlzLmV4dHJhRGV0YWlscyA9IHt9O1xuICB9XG5cbiAgb2soZG9jKSB7XG4gICAgdmFyIG9rID0ge3R5cGU6IFwib2tcIn07XG4gICAgaWYgKGRvYylcbiAgICAgIG9rLmRldGFpbHMgPSBkb2M7XG4gICAgaWYgKHRoaXMuZXhwZWN0aW5nX2ZhaWx1cmUpIHtcbiAgICAgIG9rLmRldGFpbHMgPSBvay5kZXRhaWxzIHx8IHt9O1xuICAgICAgb2suZGV0YWlsc1tcIndhc19leHBlY3RpbmdfZmFpbHVyZVwiXSA9IHRydWU7XG4gICAgICB0aGlzLmV4cGVjdGluZ19mYWlsdXJlID0gZmFsc2U7XG4gICAgfVxuICAgIHRoaXMub25FdmVudChvayk7XG4gIH1cblxuICBleHBlY3RfZmFpbCgpIHtcbiAgICB0aGlzLmV4cGVjdGluZ19mYWlsdXJlID0gdHJ1ZTtcbiAgfVxuXG4gIGZhaWwoZG9jKSB7XG4gICAgaWYgKHR5cGVvZiBkb2MgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIC8vIFNvbWUgdmVyeSBvbGQgY29kZSBzdGlsbCB0cmllcyB0byBjYWxsIGZhaWwoKSB3aXRoIGFcbiAgICAgIC8vIHN0cmluZy4gRG9uJ3QgZG8gdGhpcyFcbiAgICAgIGRvYyA9IHsgdHlwZTogXCJmYWlsXCIsIG1lc3NhZ2U6IGRvYyB9O1xuICAgIH1cblxuICAgIGRvYyA9IHtcbiAgICAgIC4uLmRvYyxcbiAgICAgIC4uLnRoaXMuZXh0cmFEZXRhaWxzLFxuICAgIH07XG5cbiAgICBpZiAodGhpcy5zdG9wX2F0X29mZnNldCA9PT0gMCkge1xuICAgICAgaWYgKE1ldGVvci5pc0NsaWVudCkge1xuICAgICAgICAvLyBPbmx5IHN1cHBvcnRlZCBvbiB0aGUgYnJvd3NlciBmb3Igbm93Li5cbiAgICAgICAgdmFyIG5vdyA9ICgrbmV3IERhdGUpO1xuICAgICAgICBkZWJ1Z2dlcjtcbiAgICAgICAgaWYgKCgrbmV3IERhdGUpIC0gbm93IDwgMTAwKVxuICAgICAgICAgIGFsZXJ0KFwiVG8gdXNlIHRoaXMgZmVhdHVyZSwgZmlyc3QgZW5hYmxlIHlvdXIgYnJvd3NlcidzIGRlYnVnZ2VyLlwiKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuc3RvcF9hdF9vZmZzZXQgPSBudWxsO1xuICAgIH1cbiAgICBpZiAodGhpcy5zdG9wX2F0X29mZnNldClcbiAgICAgIHRoaXMuc3RvcF9hdF9vZmZzZXQtLTtcblxuICAgIC8vIEdldCBmaWxlbmFtZSBhbmQgbGluZSBudW1iZXIgb2YgZmFpbHVyZSBpZiB3ZSdyZSB1c2luZyB2OCAoQ2hyb21lIG9yXG4gICAgLy8gTm9kZSkuXG4gICAgaWYgKEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKSB7XG4gICAgICB2YXIgc2F2ZWRQcmVwYXJlU3RhY2tUcmFjZSA9IEVycm9yLnByZXBhcmVTdGFja1RyYWNlO1xuICAgICAgRXJyb3IucHJlcGFyZVN0YWNrVHJhY2UgPSBmdW5jdGlvbihfLCBzdGFjayl7IHJldHVybiBzdGFjazsgfTtcbiAgICAgIHZhciBlcnIgPSBuZXcgRXJyb3I7XG4gICAgICBFcnJvci5jYXB0dXJlU3RhY2tUcmFjZShlcnIpO1xuICAgICAgdmFyIHN0YWNrID0gZXJyLnN0YWNrO1xuICAgICAgRXJyb3IucHJlcGFyZVN0YWNrVHJhY2UgPSBzYXZlZFByZXBhcmVTdGFja1RyYWNlO1xuICAgICAgZm9yICh2YXIgaSA9IHN0YWNrLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XG4gICAgICAgIHZhciBmcmFtZSA9IHN0YWNrW2ldO1xuICAgICAgICAvLyBIZXVyaXN0aWM6IHVzZSB0aGUgT1VURVJNT1NUIGxpbmUgd2hpY2ggaXMgaW4gYSA6dGVzdHMuanNcbiAgICAgICAgLy8gZmlsZSAodGhpcyBpcyBsZXNzIGxpa2VseSB0byBiZSBhIHRlc3QgaGVscGVyIGZ1bmN0aW9uKS5cbiAgICAgICAgY29uc3QgZmlsZU5hbWUgPSBmcmFtZS5nZXRGaWxlTmFtZSgpO1xuICAgICAgICBpZiAoZmlsZU5hbWUgJiYgZmlsZU5hbWUubWF0Y2goLzp0ZXN0c1xcLmpzLykpIHtcbiAgICAgICAgICBkb2MuZmlsZW5hbWUgPSBmaWxlTmFtZTtcbiAgICAgICAgICBkb2MubGluZSA9IGZyYW1lLmdldExpbmVOdW1iZXIoKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMub25FdmVudCh7XG4gICAgICAgIHR5cGU6ICh0aGlzLmV4cGVjdGluZ19mYWlsdXJlID8gXCJleHBlY3RlZF9mYWlsXCIgOiBcImZhaWxcIiksXG4gICAgICAgIGRldGFpbHM6IGRvYyxcbiAgICAgICAgY29va2llOiB7bmFtZTogdGhpcy50ZXN0X2Nhc2UubmFtZSwgb2Zmc2V0OiB0aGlzLmN1cnJlbnRfZmFpbF9jb3VudCxcbiAgICAgICAgICAgICAgICAgZ3JvdXBQYXRoOiB0aGlzLnRlc3RfY2FzZS5ncm91cFBhdGgsXG4gICAgICAgICAgICAgICAgIHNob3J0TmFtZTogdGhpcy50ZXN0X2Nhc2Uuc2hvcnROYW1lfVxuICAgIH0pO1xuICAgIHRoaXMuZXhwZWN0aW5nX2ZhaWx1cmUgPSBmYWxzZTtcbiAgICB0aGlzLmN1cnJlbnRfZmFpbF9jb3VudCsrO1xuICB9XG5cbiAgLy8gQ2FsbCB0aGlzIHRvIGZhaWwgdGhlIHRlc3Qgd2l0aCBhbiBleGNlcHRpb24uIFVzZSB0aGlzIHRvIHJlY29yZFxuICAvLyBleGNlcHRpb25zIHRoYXQgb2NjdXIgaW5zaWRlIGFzeW5jaHJvbm91cyBjYWxsYmFja3MgaW4gdGVzdHMuXG4gIC8vXG4gIC8vIEl0IHNob3VsZCBvbmx5IGJlIHVzZWQgd2l0aCBhc3luY2hyb25vdXMgdGVzdHMsIGFuZCBpZiB5b3UgY2FsbFxuICAvLyB0aGlzIGZ1bmN0aW9uLCB5b3Ugc2hvdWxkIG1ha2Ugc3VyZSB0aGF0ICgxKSB0aGUgdGVzdCBkb2Vzbid0XG4gIC8vIGNhbGwgaXRzIGNhbGxiYWNrIChvbkNvbXBsZXRlIGZ1bmN0aW9uKTsgKDIpIHRoZSB0ZXN0IGZ1bmN0aW9uXG4gIC8vIGRvZXNuJ3QgZGlyZWN0bHkgcmFpc2UgYW4gZXhjZXB0aW9uLlxuICBleGNlcHRpb24oZXhjZXB0aW9uKSB7XG4gICAgdGhpcy5vbkV4Y2VwdGlvbihleGNlcHRpb24pO1xuICB9XG5cbiAgLy8gcmV0dXJucyBhIHVuaXF1ZSBJRCBmb3IgdGhpcyB0ZXN0IHJ1biwgZm9yIGNvbnZlbmllbmNlIHVzZSBieVxuICAvLyB5b3VyIHRlc3RzXG4gIHJ1bklkKCkge1xuICAgIHJldHVybiB0aGlzLmlkO1xuICB9XG5cbiAgLy8gPT09IEZvbGxvd2luZyBwYXR0ZXJuZWQgYWZ0ZXIgaHR0cDovL3Zvd3Nqcy5vcmcvI3JlZmVyZW5jZSA9PT1cblxuICAvLyBYWFggZWxpbWluYXRlICdtZXNzYWdlJyBhbmQgJ25vdCcgYXJndW1lbnRzXG4gIGVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2UsIG5vdCkge1xuICAgIGlmICgoISBub3QpICYmICh0eXBlb2YgYWN0dWFsID09PSAnc3RyaW5nJykgJiZcbiAgICAgICAgKHR5cGVvZiBleHBlY3RlZCA9PT0gJ3N0cmluZycpKSB7XG4gICAgICB0aGlzLl9zdHJpbmdFcXVhbChhY3R1YWwsIGV4cGVjdGVkLCBtZXNzYWdlKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvKiBJZiBleHBlY3RlZCBpcyBhIERPTSBub2RlLCBkbyBhIGxpdGVyYWwgJz09PScgY29tcGFyaXNvbiB3aXRoXG4gICAgICogYWN0dWFsLiBPdGhlcndpc2UgZG8gYSBkZWVwIGNvbXBhcmlzb24sIGFzIGltcGxlbWVudGVkIGJ5IF8uaXNFcXVhbC5cbiAgICAgKi9cblxuICAgIHZhciBtYXRjaGVkO1xuICAgIC8vIFhYWCByZW1vdmUgY3J1ZnQgc3BlY2lmaWMgdG8gbGl2ZXJhbmdlXG4gICAgaWYgKHR5cGVvZiBleHBlY3RlZCA9PT0gXCJvYmplY3RcIiAmJiBleHBlY3RlZCAmJiBleHBlY3RlZC5ub2RlVHlwZSkge1xuICAgICAgbWF0Y2hlZCA9IGV4cGVjdGVkID09PSBhY3R1YWw7XG4gICAgICBleHBlY3RlZCA9IFwiW05vZGVdXCI7XG4gICAgICBhY3R1YWwgPSBcIltVbmtub3duXVwiO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIFVpbnQ4QXJyYXkgIT09ICd1bmRlZmluZWQnICYmIGV4cGVjdGVkIGluc3RhbmNlb2YgVWludDhBcnJheSkge1xuICAgICAgLy8gSSBoYXZlIG5vIGlkZWEgd2h5IGJ1dCBfLmlzRXF1YWwgb24gQ2hyb21lIGhvcmtzIGNvbXBsZXRlbHkgb24gVWludDhBcnJheXMuXG4gICAgICAvLyBhbmQgdGhlIHN5bXB0b20gaXMgdGhlIGNocm9tZSByZW5kZXJlciB0YWtpbmcgdXAgYW4gZW50aXJlIENQVSBhbmQgZnJlZXppbmdcbiAgICAgIC8vIHlvdXIgd2ViIHBhZ2UsIGJ1dCBub3QgcGF1c2luZyBhbnl3aGVyZSBpbiBfLmlzRXF1YWwuICBJIGRvbid0IHVuZGVyc3RhbmQgaXRcbiAgICAgIC8vIGJ1dCB3ZSBmYWxsIGJhY2sgdG8gYSBtYW51YWwgY29tcGFyaXNvblxuICAgICAgaWYgKCEoYWN0dWFsIGluc3RhbmNlb2YgVWludDhBcnJheSkpXG4gICAgICAgIHRoaXMuZmFpbCh7dHlwZTogXCJhc3NlcnRfZXF1YWxcIiwgbWVzc2FnZTogXCJmb3VuZCBvYmplY3QgaXMgbm90IGEgdHlwZWQgYXJyYXlcIixcbiAgICAgICAgICAgICAgICAgICBleHBlY3RlZDogXCJBIHR5cGVkIGFycmF5XCIsIGFjdHVhbDogYWN0dWFsLmNvbnN0cnVjdG9yLnRvU3RyaW5nKCl9KTtcbiAgICAgIGlmIChleHBlY3RlZC5sZW5ndGggIT09IGFjdHVhbC5sZW5ndGgpXG4gICAgICAgIHRoaXMuZmFpbCh7dHlwZTogXCJhc3NlcnRfZXF1YWxcIiwgbWVzc2FnZTogXCJsZW5ndGhzIG9mIHR5cGVkIGFycmF5cyBkbyBub3QgbWF0Y2hcIixcbiAgICAgICAgICAgICAgICAgICBleHBlY3RlZDogZXhwZWN0ZWQubGVuZ3RoLCBhY3R1YWw6IGFjdHVhbC5sZW5ndGh9KTtcbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZXhwZWN0ZWQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgdGhpcy5lcXVhbChhY3R1YWxbaV0sIGV4cGVjdGVkW2ldKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgbWF0Y2hlZCA9IEVKU09OLmVxdWFscyhleHBlY3RlZCwgYWN0dWFsKTtcbiAgICB9XG5cbiAgICBpZiAobWF0Y2hlZCA9PT0gISFub3QpIHtcbiAgICAgIHRoaXMuZmFpbCh7dHlwZTogXCJhc3NlcnRfZXF1YWxcIiwgbWVzc2FnZTogbWVzc2FnZSxcbiAgICAgICAgICAgICAgICAgZXhwZWN0ZWQ6IEpTT04uc3RyaW5naWZ5KGV4cGVjdGVkKSwgYWN0dWFsOiBKU09OLnN0cmluZ2lmeShhY3R1YWwpLCBub3Q6ICEhbm90fSk7XG4gICAgfSBlbHNlXG4gICAgICB0aGlzLm9rKCk7XG4gIH1cblxuICBub3RFcXVhbChhY3R1YWwsIGV4cGVjdGVkLCBtZXNzYWdlKSB7XG4gICAgdGhpcy5lcXVhbChhY3R1YWwsIGV4cGVjdGVkLCBtZXNzYWdlLCB0cnVlKTtcbiAgfVxuXG4gIGluc3RhbmNlT2Yob2JqLCBrbGFzcywgbWVzc2FnZSkge1xuICAgIGlmIChvYmogaW5zdGFuY2VvZiBrbGFzcylcbiAgICAgIHRoaXMub2soKTtcbiAgICBlbHNlXG4gICAgICB0aGlzLmZhaWwoe3R5cGU6IFwiaW5zdGFuY2VPZlwiLCBtZXNzYWdlOiBtZXNzYWdlLCBub3Q6IGZhbHNlfSk7IC8vIFhYWCB3aGF0IG90aGVyIGRhdGE/XG4gIH1cblxuICBub3RJbnN0YW5jZU9mKG9iaiwga2xhc3MsIG1lc3NhZ2UpIHtcbiAgICBpZiAob2JqIGluc3RhbmNlb2Yga2xhc3MpXG4gICAgICB0aGlzLmZhaWwoe3R5cGU6IFwiaW5zdGFuY2VPZlwiLCBtZXNzYWdlOiBtZXNzYWdlLCBub3Q6IHRydWV9KTsgLy8gWFhYIHdoYXQgb3RoZXIgZGF0YT9cbiAgICBlbHNlXG4gICAgICB0aGlzLm9rKCk7XG4gIH1cblxuICBtYXRjaGVzKGFjdHVhbCwgcmVnZXhwLCBtZXNzYWdlKSB7XG4gICAgaWYgKHJlZ2V4cC50ZXN0KGFjdHVhbCkpXG4gICAgICB0aGlzLm9rKCk7XG4gICAgZWxzZVxuICAgICAgdGhpcy5mYWlsKHt0eXBlOiBcIm1hdGNoZXNcIiwgbWVzc2FnZTogbWVzc2FnZSxcbiAgICAgICAgICAgICAgICAgYWN0dWFsOiBhY3R1YWwsIHJlZ2V4cDogcmVnZXhwLnRvU3RyaW5nKCksIG5vdDogZmFsc2V9KTtcbiAgfVxuXG4gIG5vdE1hdGNoZXMoYWN0dWFsLCByZWdleHAsIG1lc3NhZ2UpIHtcbiAgICBpZiAocmVnZXhwLnRlc3QoYWN0dWFsKSlcbiAgICAgIHRoaXMuZmFpbCh7dHlwZTogXCJtYXRjaGVzXCIsIG1lc3NhZ2U6IG1lc3NhZ2UsXG4gICAgICAgICAgICAgICAgIGFjdHVhbDogYWN0dWFsLCByZWdleHA6IHJlZ2V4cC50b1N0cmluZygpLCBub3Q6IHRydWV9KTtcbiAgICBlbHNlXG4gICAgICB0aGlzLm9rKCk7XG4gIH1cblxuICAvLyBleHBlY3RlZCBjYW4gYmU6XG4gIC8vICB1bmRlZmluZWQ6IGFjY2VwdCBhbnkgZXhjZXB0aW9uLlxuICAvLyAgc3RyaW5nOiBwYXNzIGlmIHRoZSBzdHJpbmcgaXMgYSBzdWJzdHJpbmcgb2YgdGhlIGV4Y2VwdGlvbiBtZXNzYWdlLlxuICAvLyAgcmVnZXhwOiBwYXNzIGlmIHRoZSBleGNlcHRpb24gbWVzc2FnZSBwYXNzZXMgdGhlIHJlZ2V4cC5cbiAgLy8gIGZ1bmN0aW9uOiBjYWxsIHRoZSBmdW5jdGlvbiBhcyBhIHByZWRpY2F0ZSB3aXRoIHRoZSBleGNlcHRpb24uXG4gIC8vXG4gIC8vIE5vdGU6IE5vZGUncyBhc3NlcnQudGhyb3dzIGFsc28gYWNjZXB0cyBhIGNvbnN0cnVjdG9yIHRvIHRlc3RcbiAgLy8gd2hldGhlciB0aGUgZXJyb3IgaXMgb2YgdGhlIGV4cGVjdGVkIGNsYXNzLiAgQnV0IHNpbmNlXG4gIC8vIEphdmFTY3JpcHQgY2FuJ3QgZGlzdGluZ3Vpc2ggYmV0d2VlbiBjb25zdHJ1Y3RvcnMgYW5kIHBsYWluXG4gIC8vIGZ1bmN0aW9ucyBhbmQgTm9kZSdzIGFzc2VydC50aHJvd3MgYWxzbyBhY2NlcHRzIGEgcHJlZGljYXRlXG4gIC8vIGZ1bmN0aW9uLCBpZiB0aGUgZXJyb3IgZmFpbHMgdGhlIGluc3RhbmNlb2YgdGVzdCB3aXRoIHRoZVxuICAvLyBjb25zdHJ1Y3RvciB0aGVuIHRoZSBjb25zdHJ1Y3RvciBpcyB0aGVuIHRyZWF0ZWQgYXMgYSBwcmVkaWNhdGVcbiAgLy8gYW5kIGNhbGxlZCAoISlcbiAgLy9cbiAgLy8gVGhlIHVwc2hvdCBpcywgaWYgeW91IHdhbnQgdG8gdGVzdCB3aGV0aGVyIGFuIGVycm9yIGlzIG9mIGFcbiAgLy8gcGFydGljdWxhciBjbGFzcywgdXNlIGEgcHJlZGljYXRlIGZ1bmN0aW9uLlxuICAvL1xuICB0aHJvd3MoZiwgZXhwZWN0ZWQpIHtcbiAgICB2YXIgYWN0dWFsLCBwcmVkaWNhdGU7XG5cbiAgICBpZiAoZXhwZWN0ZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcHJlZGljYXRlID0gZnVuY3Rpb24gKGFjdHVhbCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH07XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgZXhwZWN0ZWQgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHByZWRpY2F0ZSA9IGZ1bmN0aW9uIChhY3R1YWwpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiBhY3R1YWwubWVzc2FnZSA9PT0gXCJzdHJpbmdcIiAmJlxuICAgICAgICAgICAgICAgYWN0dWFsLm1lc3NhZ2UuaW5kZXhPZihleHBlY3RlZCkgIT09IC0xO1xuICAgICAgfTtcbiAgICB9IGVsc2UgaWYgKGV4cGVjdGVkIGluc3RhbmNlb2YgUmVnRXhwKSB7XG4gICAgICBwcmVkaWNhdGUgPSBmdW5jdGlvbiAoYWN0dWFsKSB7XG4gICAgICAgIHJldHVybiBleHBlY3RlZC50ZXN0KGFjdHVhbC5tZXNzYWdlKTtcbiAgICAgIH07XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgZXhwZWN0ZWQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIHByZWRpY2F0ZSA9IGV4cGVjdGVkO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ2V4cGVjdGVkIHNob3VsZCBiZSBhIHN0cmluZywgcmVnZXhwLCBvciBwcmVkaWNhdGUgZnVuY3Rpb24nKTtcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgZigpO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgYWN0dWFsID0gZXhjZXB0aW9uO1xuICAgIH1cblxuICAgIGlmIChhY3R1YWwgJiYgcHJlZGljYXRlKGFjdHVhbCkpXG4gICAgICB0aGlzLm9rKCk7XG4gICAgZWxzZVxuICAgICAgdGhpcy5mYWlsKHtcbiAgICAgICAgdHlwZTogXCJ0aHJvd3NcIixcbiAgICAgICAgbWVzc2FnZTogYWN0dWFsID9cbiAgICAgICAgICBcIndyb25nIGVycm9yIHRocm93bjogXCIgKyBhY3R1YWwubWVzc2FnZSA6XG4gICAgICAgICAgXCJkaWQgbm90IHRocm93IGFuIGVycm9yIGFzIGV4cGVjdGVkXCJcbiAgICAgIH0pO1xuICB9XG5cbiAgaXNUcnVlKHYsIG1zZykge1xuICAgIGlmICh2KVxuICAgICAgdGhpcy5vaygpO1xuICAgIGVsc2VcbiAgICAgIHRoaXMuZmFpbCh7dHlwZTogXCJ0cnVlXCIsIG1lc3NhZ2U6IG1zZywgbm90OiBmYWxzZX0pO1xuICB9XG5cbiAgaXNGYWxzZSh2LCBtc2cpIHtcbiAgICBpZiAodilcbiAgICAgIHRoaXMuZmFpbCh7dHlwZTogXCJ0cnVlXCIsIG1lc3NhZ2U6IG1zZywgbm90OiB0cnVlfSk7XG4gICAgZWxzZVxuICAgICAgdGhpcy5vaygpO1xuICB9XG5cbiAgaXNOdWxsKHYsIG1zZykge1xuICAgIGlmICh2ID09PSBudWxsKVxuICAgICAgdGhpcy5vaygpO1xuICAgIGVsc2VcbiAgICAgIHRoaXMuZmFpbCh7dHlwZTogXCJudWxsXCIsIG1lc3NhZ2U6IG1zZywgbm90OiBmYWxzZX0pO1xuICB9XG5cbiAgaXNOb3ROdWxsKHYsIG1zZykge1xuICAgIGlmICh2ID09PSBudWxsKVxuICAgICAgdGhpcy5mYWlsKHt0eXBlOiBcIm51bGxcIiwgbWVzc2FnZTogbXNnLCBub3Q6IHRydWV9KTtcbiAgICBlbHNlXG4gICAgICB0aGlzLm9rKCk7XG4gIH1cblxuICBpc1VuZGVmaW5lZCh2LCBtc2cpIHtcbiAgICBpZiAodiA9PT0gdW5kZWZpbmVkKVxuICAgICAgdGhpcy5vaygpO1xuICAgIGVsc2VcbiAgICAgIHRoaXMuZmFpbCh7dHlwZTogXCJ1bmRlZmluZWRcIiwgbWVzc2FnZTogbXNnLCBub3Q6IGZhbHNlfSk7XG4gIH1cblxuICBpc05vdFVuZGVmaW5lZCh2LCBtc2cpIHtcbiAgICBpZiAodiA9PT0gdW5kZWZpbmVkKVxuICAgICAgdGhpcy5mYWlsKHt0eXBlOiBcInVuZGVmaW5lZFwiLCBtZXNzYWdlOiBtc2csIG5vdDogdHJ1ZX0pO1xuICAgIGVsc2VcbiAgICAgIHRoaXMub2soKTtcbiAgfVxuXG4gIGlzTmFOKHYsIG1zZykge1xuICAgIGlmIChpc05hTih2KSlcbiAgICAgIHRoaXMub2soKTtcbiAgICBlbHNlXG4gICAgICB0aGlzLmZhaWwoe3R5cGU6IFwiTmFOXCIsIG1lc3NhZ2U6IG1zZywgbm90OiBmYWxzZX0pO1xuICB9XG5cbiAgaXNOb3ROYU4odiwgbXNnKSB7XG4gICAgaWYgKGlzTmFOKHYpKVxuICAgICAgdGhpcy5mYWlsKHt0eXBlOiBcIk5hTlwiLCBtZXNzYWdlOiBtc2csIG5vdDogdHJ1ZX0pO1xuICAgIGVsc2VcbiAgICAgIHRoaXMub2soKTtcbiAgfVxuXG4gIGluY2x1ZGUocywgdiwgbWVzc2FnZSwgbm90KSB7XG4gICAgdmFyIHBhc3MgPSBmYWxzZTtcbiAgICBpZiAocyBpbnN0YW5jZW9mIEFycmF5KSB7XG4gICAgICBwYXNzID0gcy5zb21lKGl0ID0+IF8uaXNFcXVhbCh2LCBpdCkpO1xuICAgIH0gZWxzZSBpZiAocyAmJiB0eXBlb2YgcyA9PT0gXCJvYmplY3RcIikge1xuICAgICAgcGFzcyA9IHYgaW4gcztcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBzID09PSBcInN0cmluZ1wiKSB7XG4gICAgICBpZiAocy5pbmRleE9mKHYpID4gLTEpIHtcbiAgICAgICAgcGFzcyA9IHRydWU7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIC8qIGZhaWwgLS0gbm90IHNvbWV0aGluZyB0aGF0IGNvbnRhaW5zIG90aGVyIHRoaW5ncyAqLztcbiAgICB9XG5cbiAgICBpZiAocGFzcyA9PT0gISBub3QpIHtcbiAgICAgIHRoaXMub2soKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5mYWlsKHtcbiAgICAgICAgdHlwZTogXCJpbmNsdWRlXCIsXG4gICAgICAgIG1lc3NhZ2UsXG4gICAgICAgIHNlcXVlbmNlOiBzLFxuICAgICAgICBzaG91bGRfY29udGFpbl92YWx1ZTogdixcbiAgICAgICAgbm90OiAhIW5vdCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIG5vdEluY2x1ZGUocywgdiwgbWVzc2FnZSkge1xuICAgIHRoaXMuaW5jbHVkZShzLCB2LCBtZXNzYWdlLCB0cnVlKTtcbiAgfVxuXG4gIC8vIFhYWCBzaG91bGQgY2hhbmdlIHRvIGxlbmd0aE9mIHRvIG1hdGNoIHZvd3Nqc1xuICBsZW5ndGgob2JqLCBleHBlY3RlZF9sZW5ndGgsIG1zZykge1xuICAgIGlmIChvYmoubGVuZ3RoID09PSBleHBlY3RlZF9sZW5ndGgpIHtcbiAgICAgIHRoaXMub2soKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5mYWlsKHtcbiAgICAgICAgdHlwZTogXCJsZW5ndGhcIixcbiAgICAgICAgZXhwZWN0ZWQ6IGV4cGVjdGVkX2xlbmd0aCxcbiAgICAgICAgYWN0dWFsOiBvYmoubGVuZ3RoLFxuICAgICAgICBtZXNzYWdlOiBtc2csXG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICAvLyBFWFBFUklNRU5UQUwgd2F5IHRvIGNvbXBhcmUgdHdvIHN0cmluZ3MgdGhhdCByZXN1bHRzIGluXG4gIC8vIGEgbmljZXIgZGlzcGxheSBpbiB0aGUgdGVzdCBydW5uZXIsIGUuZy4gZm9yIG11bHRpbGluZVxuICAvLyBzdHJpbmdzXG4gIF9zdHJpbmdFcXVhbChhY3R1YWwsIGV4cGVjdGVkLCBtZXNzYWdlKSB7XG4gICAgaWYgKGFjdHVhbCAhPT0gZXhwZWN0ZWQpIHtcbiAgICAgIHRoaXMuZmFpbCh7XG4gICAgICAgIHR5cGU6IFwic3RyaW5nX2VxdWFsXCIsXG4gICAgICAgIG1lc3NhZ2UsXG4gICAgICAgIGV4cGVjdGVkLFxuICAgICAgICBhY3R1YWwsXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5vaygpO1xuICAgIH1cbiAgfVxufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyogVGVzdENhc2UgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKi9cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbmV4cG9ydCBjbGFzcyBUZXN0Q2FzZSB7XG4gIGNvbnN0cnVjdG9yKG5hbWUsIGZ1bmMpIHtcbiAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgIHRoaXMuZnVuYyA9IGZ1bmM7XG5cbiAgICB2YXIgbmFtZVBhcnRzID0gbmFtZS5zcGxpdChcIiAtIFwiKS5tYXAocyA9PiB7XG4gICAgICByZXR1cm4gcy5yZXBsYWNlKC9eXFxzKnxcXHMqJC9nLCBcIlwiKTsgLy8gdHJpbVxuICAgIH0pO1xuICAgIHRoaXMuc2hvcnROYW1lID0gbmFtZVBhcnRzLnBvcCgpO1xuICAgIG5hbWVQYXJ0cy51bnNoaWZ0KFwidGlueXRlc3RcIik7XG4gICAgdGhpcy5ncm91cFBhdGggPSBuYW1lUGFydHM7XG4gIH1cblxuICAvLyBSdW4gdGhlIHRlc3QgYXN5bmNocm9ub3VzbHksIGRlbGl2ZXJpbmcgcmVzdWx0cyB2aWEgb25FdmVudDtcbiAgLy8gdGhlbiBjYWxsIG9uQ29tcGxldGUoKSBvbiBzdWNjZXNzLCBvciBlbHNlIG9uRXhjZXB0aW9uKGUpIGlmIHRoZVxuICAvLyB0ZXN0IHJhaXNlZCAob3Igdm9sdW50YXJpbHkgcmVwb3J0ZWQpIGFuIGV4Y2VwdGlvbi5cbiAgcnVuKG9uRXZlbnQsIG9uQ29tcGxldGUsIG9uRXhjZXB0aW9uLCBzdG9wX2F0X29mZnNldCkge1xuICAgIGxldCBjb21wbGV0ZWQgPSBmYWxzZTtcblxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBjb25zdCByZXN1bHRzID0gbmV3IFRlc3RDYXNlUmVzdWx0cyhcbiAgICAgICAgdGhpcyxcbiAgICAgICAgZXZlbnQgPT4ge1xuICAgICAgICAgIC8vIElmIHRoaXMgdHJhY2UgcHJpbnRzLCBpdCBtZWFucyB5b3UgcmFuIHNvbWUgdGVzdC4qIGZ1bmN0aW9uXG4gICAgICAgICAgLy8gYWZ0ZXIgdGhlIHRlc3QgZmluaXNoZWQhIEFub3RoZXIgc3ltcHRvbSB3aWxsIGJlIHRoYXQgdGhlXG4gICAgICAgICAgLy8gdGVzdCB3aWxsIGRpc3BsYXkgYXMgXCJ3YWl0aW5nXCIgZXZlbiB3aGVuIGl0IGNvdW50cyBhcyBwYXNzZWRcbiAgICAgICAgICAvLyBvciBmYWlsZWQuXG4gICAgICAgICAgaWYgKGNvbXBsZXRlZCkge1xuICAgICAgICAgICAgY29uc29sZS50cmFjZShcImV2ZW50IGFmdGVyIGNvbXBsZXRlIVwiKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIG9uRXZlbnQoZXZlbnQpO1xuICAgICAgICB9LFxuICAgICAgICByZWplY3QsXG4gICAgICAgIHN0b3BfYXRfb2Zmc2V0XG4gICAgICApO1xuXG4gICAgICBjb25zdCByZXN1bHQgPSB0aGlzLmZ1bmMocmVzdWx0cywgcmVzb2x2ZSk7XG4gICAgICBpZiAocmVzdWx0ICYmIHR5cGVvZiByZXN1bHQudGhlbiA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgIHJlc3VsdC50aGVuKHJlc29sdmUsIHJlamVjdCk7XG4gICAgICB9XG5cbiAgICB9KS50aGVuKFxuICAgICAgKCkgPT4ge1xuICAgICAgICBjb21wbGV0ZWQgPSB0cnVlO1xuICAgICAgICBvbkNvbXBsZXRlKCk7XG4gICAgICB9LFxuICAgICAgZXJyb3IgPT4ge1xuICAgICAgICBjb21wbGV0ZWQgPSB0cnVlO1xuICAgICAgICBvbkV4Y2VwdGlvbihlcnJvcik7XG4gICAgICB9XG4gICAgKTtcbiAgfVxufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyogVGVzdE1hbmFnZXIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKi9cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbmV4cG9ydCBjb25zdCBUZXN0TWFuYWdlciA9IG5ldyAoY2xhc3MgVGVzdE1hbmFnZXIge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLnRlc3RzID0ge307XG4gICAgdGhpcy5vcmRlcmVkX3Rlc3RzID0gW107XG4gICAgdGhpcy50ZXN0UXVldWUgPSBNZXRlb3IuaXNTZXJ2ZXIgJiYgbmV3IE1ldGVvci5fU3luY2hyb25vdXNRdWV1ZSgpO1xuICB9XG5cbiAgYWRkQ2FzZSh0ZXN0KSB7XG4gICAgaWYgKHRlc3QubmFtZSBpbiB0aGlzLnRlc3RzKVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBcIkV2ZXJ5IHRlc3QgbmVlZHMgYSB1bmlxdWUgbmFtZSwgYnV0IHRoZXJlIGFyZSB0d28gdGVzdHMgbmFtZWQgJ1wiICtcbiAgICAgICAgICB0ZXN0Lm5hbWUgKyBcIidcIik7XG4gICAgaWYgKF9fbWV0ZW9yX3J1bnRpbWVfY29uZmlnX18udGlueXRlc3RGaWx0ZXIgJiZcbiAgICAgICAgdGVzdC5uYW1lLmluZGV4T2YoX19tZXRlb3JfcnVudGltZV9jb25maWdfXy50aW55dGVzdEZpbHRlcikgPT09IC0xKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMudGVzdHNbdGVzdC5uYW1lXSA9IHRlc3Q7XG4gICAgdGhpcy5vcmRlcmVkX3Rlc3RzLnB1c2godGVzdCk7XG4gIH1cblxuICBjcmVhdGVSdW4ob25SZXBvcnQsIHBhdGhQcmVmaXgpIHtcbiAgICByZXR1cm4gbmV3IFRlc3RSdW4odGhpcywgb25SZXBvcnQsIHBhdGhQcmVmaXgpO1xuICB9XG59KTtcblxuaWYgKE1ldGVvci5pc1NlcnZlciAmJiBwcm9jZXNzLmVudi5USU5ZVEVTVF9GSUxURVIpIHtcbiAgX19tZXRlb3JfcnVudGltZV9jb25maWdfXy50aW55dGVzdEZpbHRlciA9IHByb2Nlc3MuZW52LlRJTllURVNUX0ZJTFRFUjtcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qIFRlc3RSdW4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICovXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG5leHBvcnQgY2xhc3MgVGVzdFJ1biB7XG4gIGNvbnN0cnVjdG9yKG1hbmFnZXIsIG9uUmVwb3J0LCBwYXRoUHJlZml4KSB7XG4gICAgdGhpcy5tYW5hZ2VyID0gbWFuYWdlcjtcbiAgICB0aGlzLm9uUmVwb3J0ID0gb25SZXBvcnQ7XG4gICAgdGhpcy5uZXh0X3NlcXVlbmNlX251bWJlciA9IDA7XG4gICAgdGhpcy5fcGF0aFByZWZpeCA9IHBhdGhQcmVmaXggfHwgW107XG4gICAgdGhpcy5tYW5hZ2VyLm9yZGVyZWRfdGVzdHMuZm9yRWFjaCh0ZXN0ID0+IHtcbiAgICAgIGlmICh0aGlzLl9wcmVmaXhNYXRjaCh0ZXN0Lmdyb3VwUGF0aCkpXG4gICAgICAgIHRoaXMuX3JlcG9ydCh0ZXN0KTtcbiAgICB9KTtcbiAgfVxuXG4gIF9wcmVmaXhNYXRjaCh0ZXN0UGF0aCkge1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5fcGF0aFByZWZpeC5sZW5ndGg7IGkrKykge1xuICAgICAgaWYgKCF0ZXN0UGF0aFtpXSB8fCB0aGlzLl9wYXRoUHJlZml4W2ldICE9PSB0ZXN0UGF0aFtpXSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgX3J1blRlc3QodGVzdCwgb25Db21wbGV0ZSwgc3RvcF9hdF9vZmZzZXQpIHtcbiAgICB2YXIgc3RhcnRUaW1lID0gKCtuZXcgRGF0ZSk7XG5cbiAgICB0ZXN0LnJ1bihldmVudCA9PiB7XG4gICAgICAvKiBvbkV2ZW50ICovXG4gICAgICAvLyBJZ25vcmUgcmVzdWx0IGNhbGxiYWNrcyBpZiB0aGUgdGVzdCBoYXMgYWxyZWFkeSBiZWVuIHJlcG9ydGVkXG4gICAgICAvLyBhcyB0aW1lZCBvdXQuXG4gICAgICBpZiAodGVzdC50aW1lZE91dClcbiAgICAgICAgcmV0dXJuO1xuICAgICAgdGhpcy5fcmVwb3J0KHRlc3QsIGV2ZW50KTtcbiAgICB9LCAoKSA9PiB7XG4gICAgICAvKiBvbkNvbXBsZXRlICovXG4gICAgICBpZiAodGVzdC50aW1lZE91dClcbiAgICAgICAgcmV0dXJuO1xuICAgICAgdmFyIHRvdGFsVGltZSA9ICgrbmV3IERhdGUpIC0gc3RhcnRUaW1lO1xuICAgICAgdGhpcy5fcmVwb3J0KHRlc3QsIHt0eXBlOiBcImZpbmlzaFwiLCB0aW1lTXM6IHRvdGFsVGltZX0pO1xuICAgICAgb25Db21wbGV0ZSgpO1xuICAgIH0sIGV4Y2VwdGlvbiA9PiB7XG4gICAgICAvKiBvbkV4Y2VwdGlvbiAqL1xuICAgICAgaWYgKHRlc3QudGltZWRPdXQpXG4gICAgICAgIHJldHVybjtcblxuICAgICAgLy8gWFhYIHlvdSB3YW50IHRoZSBcIm5hbWVcIiBhbmQgXCJtZXNzYWdlXCIgZmllbGRzIG9uIHRoZVxuICAgICAgLy8gZXhjZXB0aW9uLCB0byBzdGFydCB3aXRoLi5cbiAgICAgIHRoaXMuX3JlcG9ydCh0ZXN0LCB7XG4gICAgICAgIHR5cGU6IFwiZXhjZXB0aW9uXCIsXG4gICAgICAgIGRldGFpbHM6IHtcbiAgICAgICAgICBtZXNzYWdlOiBleGNlcHRpb24ubWVzc2FnZSwgLy8gWFhYIGVtcHR5Pz8/XG4gICAgICAgICAgc3RhY2s6IGV4Y2VwdGlvbi5zdGFjayAvLyBYWFggcG9ydGFiaWxpdHlcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIG9uQ29tcGxldGUoKTtcbiAgICB9LCBzdG9wX2F0X29mZnNldCk7XG4gIH1cblxuICAvLyBSdW4gYSBzaW5nbGUgdGVzdC4gIE9uIHRoZSBzZXJ2ZXIsIGVuc3VyZSB0aGF0IG9ubHkgb25lIHRlc3QgcnVuc1xuICAvLyBhdCBhIHRpbWUsIGV2ZW4gd2l0aCBtdWx0aXBsZSBjbGllbnRzIHN1Ym1pdHRpbmcgdGVzdHMuICBIb3dldmVyLFxuICAvLyB0aW1lIG91dCB0aGUgdGVzdCBhZnRlciB0aHJlZSBtaW51dGVzIHRvIGF2b2lkIGxvY2tpbmcgdXAgdGhlXG4gIC8vIHNlcnZlciBpZiBhIHRlc3QgZmFpbHMgdG8gY29tcGxldGUuXG4gIC8vXG4gIF9ydW5PbmUodGVzdCwgb25Db21wbGV0ZSwgc3RvcF9hdF9vZmZzZXQpIHtcbiAgICBpZiAoISB0aGlzLl9wcmVmaXhNYXRjaCh0ZXN0Lmdyb3VwUGF0aCkpIHtcbiAgICAgIG9uQ29tcGxldGUgJiYgb25Db21wbGV0ZSgpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICAgIC8vIE9uIHRoZSBzZXJ2ZXIsIGVuc3VyZSB0aGF0IG9ubHkgb25lIHRlc3QgcnVucyBhdCBhIHRpbWUsIGV2ZW5cbiAgICAgIC8vIHdpdGggbXVsdGlwbGUgY2xpZW50cy5cbiAgICAgIHRoaXMubWFuYWdlci50ZXN0UXVldWUucXVldWVUYXNrKCgpID0+IHtcbiAgICAgICAgLy8gVGhlIGZ1dHVyZSByZXNvbHZlcyB3aGVuIHRoZSB0ZXN0IGNvbXBsZXRlcyBvciB0aW1lcyBvdXQuXG4gICAgICAgIHZhciBmdXR1cmUgPSBuZXcgRnV0dXJlKCk7XG4gICAgICAgIE1ldGVvci5zZXRUaW1lb3V0KFxuICAgICAgICAgICgpID0+IHtcbiAgICAgICAgICAgIGlmIChmdXR1cmUuaXNSZXNvbHZlZCgpKVxuICAgICAgICAgICAgICAvLyBJZiB0aGUgZnV0dXJlIGhhcyByZXNvbHZlZCB0aGUgdGVzdCBoYXMgY29tcGxldGVkLlxuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB0ZXN0LnRpbWVkT3V0ID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMuX3JlcG9ydCh0ZXN0LCB7XG4gICAgICAgICAgICAgIHR5cGU6IFwiZXhjZXB0aW9uXCIsXG4gICAgICAgICAgICAgIGRldGFpbHM6IHtcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcInRlc3QgdGltZWQgb3V0XCJcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBmdXR1cmVbJ3JldHVybiddKCk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICAzICogNjAgKiAxMDAwICAvLyAzIG1pbnV0ZXNcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5fcnVuVGVzdCh0ZXN0LCAoKSA9PiB7XG4gICAgICAgICAgLy8gVGhlIHRlc3QgY2FuIGNvbXBsZXRlIGFmdGVyIGl0IGhhcyB0aW1lZCBvdXQgKGl0IG1pZ2h0XG4gICAgICAgICAgLy8ganVzdCBiZSBzbG93KSwgc28gb25seSByZXNvbHZlIHRoZSBmdXR1cmUgaWYgdGhlIHRlc3RcbiAgICAgICAgICAvLyBoYXNuJ3QgdGltZWQgb3V0LlxuICAgICAgICAgIGlmICghIGZ1dHVyZS5pc1Jlc29sdmVkKCkpXG4gICAgICAgICAgICBmdXR1cmVbJ3JldHVybiddKCk7XG4gICAgICAgIH0sIHN0b3BfYXRfb2Zmc2V0KTtcbiAgICAgICAgLy8gV2FpdCBmb3IgdGhlIHRlc3QgdG8gY29tcGxldGUgb3IgdGltZSBvdXQuXG4gICAgICAgIGZ1dHVyZS53YWl0KCk7XG4gICAgICAgIG9uQ29tcGxldGUgJiYgb25Db21wbGV0ZSgpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIGNsaWVudFxuICAgICAgdGhpcy5fcnVuVGVzdCh0ZXN0LCAoKSA9PiB7XG4gICAgICAgIG9uQ29tcGxldGUgJiYgb25Db21wbGV0ZSgpO1xuICAgICAgfSwgc3RvcF9hdF9vZmZzZXQpO1xuICAgIH1cbiAgfVxuXG4gIHJ1bihvbkNvbXBsZXRlKSB7XG4gICAgdmFyIHRlc3RzID0gdGhpcy5tYW5hZ2VyLm9yZGVyZWRfdGVzdHMuc2xpY2UoMCk7XG4gICAgdmFyIHJlcG9ydEN1cnJlbnQgPSBmdW5jdGlvbiAobmFtZSkge1xuICAgICAgaWYgKE1ldGVvci5pc0NsaWVudClcbiAgICAgICAgVGlueXRlc3QuX29uQ3VycmVudENsaWVudFRlc3QobmFtZSk7XG4gICAgfTtcblxuICAgIGNvbnN0IHJ1bk5leHQgPSAoKSA9PiB7XG4gICAgICBpZiAodGVzdHMubGVuZ3RoKSB7XG4gICAgICAgIHZhciB0ID0gdGVzdHMuc2hpZnQoKTtcbiAgICAgICAgcmVwb3J0Q3VycmVudCh0Lm5hbWUpO1xuICAgICAgICB0aGlzLl9ydW5PbmUodCwgcnVuTmV4dCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXBvcnRDdXJyZW50KG51bGwpO1xuICAgICAgICBvbkNvbXBsZXRlICYmIG9uQ29tcGxldGUoKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgcnVuTmV4dCgpO1xuICB9XG5cbiAgLy8gQW4gYWx0ZXJuYXRpdmUgdG8gcnVuKCkuIEdpdmVuIHRoZSAnY29va2llJyBhdHRyaWJ1dGUgb2YgYVxuICAvLyBmYWlsdXJlIHJlY29yZCwgdHJ5IHRvIHJlcnVuIHRoYXQgcGFydGljdWxhciB0ZXN0IHVwIHRvIHRoYXRcbiAgLy8gZmFpbHVyZSwgYW5kIHRoZW4gb3BlbiB0aGUgZGVidWdnZXIuXG4gIGRlYnVnKGNvb2tpZSwgb25Db21wbGV0ZSkge1xuICAgIHZhciB0ZXN0ID0gdGhpcy5tYW5hZ2VyLnRlc3RzW2Nvb2tpZS5uYW1lXTtcbiAgICBpZiAoIXRlc3QpXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBzdWNoIHRlc3QgJ1wiICsgY29va2llLm5hbWUgKyBcIidcIik7XG4gICAgdGhpcy5fcnVuT25lKHRlc3QsIG9uQ29tcGxldGUsIGNvb2tpZS5vZmZzZXQpO1xuICB9XG5cbiAgX3JlcG9ydCh0ZXN0LCBldmVudCkge1xuICAgIGxldCBldmVudHM7XG4gICAgaWYgKGV2ZW50KSB7XG4gICAgICBldmVudHMgPSBbe1xuICAgICAgICBzZXF1ZW5jZTogdGhpcy5uZXh0X3NlcXVlbmNlX251bWJlcisrLFxuICAgICAgICAuLi5ldmVudFxuICAgICAgfV07XG4gICAgfSBlbHNlIHtcbiAgICAgIGV2ZW50cyA9IFtdO1xuICAgIH1cbiAgICB0aGlzLm9uUmVwb3J0KHtcbiAgICAgIGdyb3VwUGF0aDogdGVzdC5ncm91cFBhdGgsXG4gICAgICB0ZXN0OiB0ZXN0LnNob3J0TmFtZSxcbiAgICAgIGV2ZW50cyxcbiAgICB9KTtcbiAgfVxufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyogUHVibGljIEFQSSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKi9cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbmV4cG9ydCBjb25zdCBUaW55dGVzdCA9IHt9O1xuXG5UaW55dGVzdC5hZGRBc3luYyA9IGZ1bmN0aW9uIChuYW1lLCBmdW5jKSB7XG4gIFRlc3RNYW5hZ2VyLmFkZENhc2UobmV3IFRlc3RDYXNlKG5hbWUsIGZ1bmMpKTtcbn07XG5cblRpbnl0ZXN0LmFkZCA9IGZ1bmN0aW9uIChuYW1lLCBmdW5jKSB7XG4gIFRpbnl0ZXN0LmFkZEFzeW5jKG5hbWUsIGZ1bmN0aW9uICh0ZXN0LCBvbkNvbXBsZXRlKSB7XG4gICAgZnVuYyh0ZXN0KTtcbiAgICBvbkNvbXBsZXRlKCk7XG4gIH0pO1xufTtcblxuLy8gUnVuIGV2ZXJ5IHRlc3QsIGFzeW5jaHJvbm91c2x5LiBSdW5zIHRoZSB0ZXN0IGluIHRoZSBjdXJyZW50XG4vLyBwcm9jZXNzIG9ubHkgKGlmIGNhbGxlZCBvbiB0aGUgc2VydmVyLCBydW5zIHRoZSB0ZXN0cyBvbiB0aGVcbi8vIHNlcnZlciwgYW5kIGxpa2V3aXNlIGZvciB0aGUgY2xpZW50LikgUmVwb3J0IHJlc3VsdHMgdmlhXG4vLyBvblJlcG9ydC4gQ2FsbCBvbkNvbXBsZXRlIHdoZW4gaXQncyBkb25lLlxuLy9cblRpbnl0ZXN0Ll9ydW5UZXN0cyA9IGZ1bmN0aW9uIChvblJlcG9ydCwgb25Db21wbGV0ZSwgcGF0aFByZWZpeCkge1xuICB2YXIgdGVzdFJ1biA9IFRlc3RNYW5hZ2VyLmNyZWF0ZVJ1bihvblJlcG9ydCwgcGF0aFByZWZpeCk7XG4gIHRlc3RSdW4ucnVuKG9uQ29tcGxldGUpO1xufTtcblxuLy8gUnVuIGp1c3Qgb25lIHRlc3QgY2FzZSwgYW5kIHN0b3AgdGhlIGRlYnVnZ2VyIGF0IGEgcGFydGljdWxhclxuLy8gZXJyb3IsIGFsbCBhcyBpbmRpY2F0ZWQgYnkgJ2Nvb2tpZScsIHdoaWNoIHdpbGwgaGF2ZSBjb21lIGZyb20gYVxuLy8gZmFpbHVyZSBldmVudCBvdXRwdXQgYnkgX3J1blRlc3RzLlxuLy9cblRpbnl0ZXN0Ll9kZWJ1Z1Rlc3QgPSBmdW5jdGlvbiAoY29va2llLCBvblJlcG9ydCwgb25Db21wbGV0ZSkge1xuICB2YXIgdGVzdFJ1biA9IFRlc3RNYW5hZ2VyLmNyZWF0ZVJ1bihvblJlcG9ydCk7XG4gIHRlc3RSdW4uZGVidWcoY29va2llLCBvbkNvbXBsZXRlKTtcbn07XG5cbi8vIFJlcGxhY2UgdGhpcyBjYWxsYmFjayB0byBnZXQgY2FsbGVkIHdoZW4gd2UgcnVuIGEgY2xpZW50IHRlc3QsXG4vLyBhbmQgdGhlbiBjYWxsZWQgd2l0aCBgbnVsbGAgd2hlbiB0aGUgY2xpZW50IHRlc3RzIGFyZVxuLy8gZG9uZS4gIFRoaXMgaXMgdXNlZCB0byBwcm92aWRlIGEgbGl2ZSBkaXNwbGF5IG9mIHRoZSBjdXJyZW50XG4vLyBydW5uaW5nIGNsaWVudCB0ZXN0IG9uIHRoZSB0ZXN0IHJlc3VsdHMgcGFnZS5cblRpbnl0ZXN0Ll9vbkN1cnJlbnRDbGllbnRUZXN0ID0gZnVuY3Rpb24gKG5hbWUpIHt9O1xuXG5UaW55dGVzdC5fVGVzdENhc2VSZXN1bHRzID0gVGVzdENhc2VSZXN1bHRzO1xuVGlueXRlc3QuX1Rlc3RDYXNlID0gVGVzdENhc2U7XG5UaW55dGVzdC5fVGVzdE1hbmFnZXIgPSBUZXN0TWFuYWdlcjtcblRpbnl0ZXN0Ll9UZXN0UnVuID0gVGVzdFJ1bjtcbiJdfQ==
