(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Collection2 = Package['aldeed:collection2-core'].Collection2;
var ECMAScript = Package.ecmascript.ECMAScript;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"aldeed:schema-index":{"server.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/aldeed_schema-index/server.js                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Collection2;
module.watch(require("meteor/aldeed:collection2-core"), {
  default(v) {
    Collection2 = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
module.watch(require("./common"));
Collection2.on('schema.attached', function (collection, ss) {
  function ensureIndex(index, indexName, unique, sparse) {
    Meteor.startup(function () {
      collection._collection._ensureIndex(index, {
        background: true,
        name: indexName,
        unique: unique,
        sparse: sparse
      });
    });
  }

  function dropIndex(indexName) {
    Meteor.startup(function () {
      try {
        collection._collection._dropIndex(indexName);
      } catch (err) {// no index with that name, which is what we want
      }
    });
  }

  const propName = ss.version === 2 ? 'mergedSchema' : 'schema'; // Loop over fields definitions and ensure collection indexes (server side only)

  var schema = ss[propName]();
  Object.keys(schema).forEach(function (fieldName) {
    var definition = schema[fieldName];

    if ('index' in definition || definition.unique === true) {
      var index = {},
          indexValue; // If they specified `unique: true` but not `index`,
      // we assume `index: 1` to set up the unique index in mongo

      if ('index' in definition) {
        indexValue = definition.index;
        if (indexValue === true) indexValue = 1;
      } else {
        indexValue = 1;
      }

      var indexName = 'c2_' + fieldName; // In the index object, we want object array keys without the ".$" piece

      var idxFieldName = fieldName.replace(/\.\$\./g, ".");
      index[idxFieldName] = indexValue;
      var unique = !!definition.unique && (indexValue === 1 || indexValue === -1);
      var sparse = definition.sparse || false; // If unique and optional, force sparse to prevent errors

      if (!sparse && unique && definition.optional) sparse = true;

      if (indexValue === false) {
        dropIndex(indexName);
      } else {
        ensureIndex(index, indexName, unique, sparse);
      }
    }
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"common.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/aldeed_schema-index/common.js                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 0);
let Collection2;
module.watch(require("meteor/aldeed:collection2-core"), {
  default(v) {
    Collection2 = v;
  }

}, 1);
// Extend the schema options allowed by SimpleSchema
SimpleSchema.extendOptions(['index', // one of Number, String, Boolean
'unique', // Boolean
'sparse'] // Boolean
);
Collection2.on('schema.attached', function (collection, ss) {
  // Define validation error messages
  if (ss.version >= 2 && ss.messageBox && typeof ss.messageBox.messages === 'function') {
    ss.messageBox.messages({
      en: {
        notUnique: '{{label}} must be unique'
      }
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("/node_modules/meteor/aldeed:schema-index/server.js");

/* Exports */
Package._define("aldeed:schema-index", exports);

})();

//# sourceURL=meteor://💻app/packages/aldeed_schema-index.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYWxkZWVkOnNjaGVtYS1pbmRleC9zZXJ2ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL2FsZGVlZDpzY2hlbWEtaW5kZXgvY29tbW9uLmpzIl0sIm5hbWVzIjpbIkNvbGxlY3Rpb24yIiwibW9kdWxlIiwid2F0Y2giLCJyZXF1aXJlIiwiZGVmYXVsdCIsInYiLCJNZXRlb3IiLCJvbiIsImNvbGxlY3Rpb24iLCJzcyIsImVuc3VyZUluZGV4IiwiaW5kZXgiLCJpbmRleE5hbWUiLCJ1bmlxdWUiLCJzcGFyc2UiLCJzdGFydHVwIiwiX2NvbGxlY3Rpb24iLCJfZW5zdXJlSW5kZXgiLCJiYWNrZ3JvdW5kIiwibmFtZSIsImRyb3BJbmRleCIsIl9kcm9wSW5kZXgiLCJlcnIiLCJwcm9wTmFtZSIsInZlcnNpb24iLCJzY2hlbWEiLCJPYmplY3QiLCJrZXlzIiwiZm9yRWFjaCIsImZpZWxkTmFtZSIsImRlZmluaXRpb24iLCJpbmRleFZhbHVlIiwiaWR4RmllbGROYW1lIiwicmVwbGFjZSIsIm9wdGlvbmFsIiwiU2ltcGxlU2NoZW1hIiwiZXh0ZW5kT3B0aW9ucyIsIm1lc3NhZ2VCb3giLCJtZXNzYWdlcyIsImVuIiwibm90VW5pcXVlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsV0FBSjtBQUFnQkMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGdDQUFSLENBQWIsRUFBdUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNMLGtCQUFZSyxDQUFaO0FBQWM7O0FBQTFCLENBQXZELEVBQW1GLENBQW5GO0FBQXNGLElBQUlDLE1BQUo7QUFBV0wsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRyxTQUFPRCxDQUFQLEVBQVM7QUFBQ0MsYUFBT0QsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErREosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYjtBQUtoTEgsWUFBWU8sRUFBWixDQUFlLGlCQUFmLEVBQWtDLFVBQVVDLFVBQVYsRUFBc0JDLEVBQXRCLEVBQTBCO0FBQzFELFdBQVNDLFdBQVQsQ0FBcUJDLEtBQXJCLEVBQTRCQyxTQUE1QixFQUF1Q0MsTUFBdkMsRUFBK0NDLE1BQS9DLEVBQXVEO0FBQ3JEUixXQUFPUyxPQUFQLENBQWUsWUFBWTtBQUN6QlAsaUJBQVdRLFdBQVgsQ0FBdUJDLFlBQXZCLENBQW9DTixLQUFwQyxFQUEyQztBQUN6Q08sb0JBQVksSUFENkI7QUFFekNDLGNBQU1QLFNBRm1DO0FBR3pDQyxnQkFBUUEsTUFIaUM7QUFJekNDLGdCQUFRQTtBQUppQyxPQUEzQztBQU1ELEtBUEQ7QUFRRDs7QUFFRCxXQUFTTSxTQUFULENBQW1CUixTQUFuQixFQUE4QjtBQUM1Qk4sV0FBT1MsT0FBUCxDQUFlLFlBQVk7QUFDekIsVUFBSTtBQUNGUCxtQkFBV1EsV0FBWCxDQUF1QkssVUFBdkIsQ0FBa0NULFNBQWxDO0FBQ0QsT0FGRCxDQUVFLE9BQU9VLEdBQVAsRUFBWSxDQUNaO0FBQ0Q7QUFDRixLQU5EO0FBT0Q7O0FBRUQsUUFBTUMsV0FBV2QsR0FBR2UsT0FBSCxLQUFlLENBQWYsR0FBbUIsY0FBbkIsR0FBb0MsUUFBckQsQ0F0QjBELENBd0IxRDs7QUFDQSxNQUFJQyxTQUFTaEIsR0FBR2MsUUFBSCxHQUFiO0FBQ0FHLFNBQU9DLElBQVAsQ0FBWUYsTUFBWixFQUFvQkcsT0FBcEIsQ0FBNEIsVUFBVUMsU0FBVixFQUFxQjtBQUMvQyxRQUFJQyxhQUFhTCxPQUFPSSxTQUFQLENBQWpCOztBQUNBLFFBQUksV0FBV0MsVUFBWCxJQUF5QkEsV0FBV2pCLE1BQVgsS0FBc0IsSUFBbkQsRUFBeUQ7QUFDdkQsVUFBSUYsUUFBUSxFQUFaO0FBQUEsVUFBZ0JvQixVQUFoQixDQUR1RCxDQUV2RDtBQUNBOztBQUNBLFVBQUksV0FBV0QsVUFBZixFQUEyQjtBQUN6QkMscUJBQWFELFdBQVduQixLQUF4QjtBQUNBLFlBQUlvQixlQUFlLElBQW5CLEVBQXlCQSxhQUFhLENBQWI7QUFDMUIsT0FIRCxNQUdPO0FBQ0xBLHFCQUFhLENBQWI7QUFDRDs7QUFDRCxVQUFJbkIsWUFBWSxRQUFRaUIsU0FBeEIsQ0FWdUQsQ0FXdkQ7O0FBQ0EsVUFBSUcsZUFBZUgsVUFBVUksT0FBVixDQUFrQixTQUFsQixFQUE2QixHQUE3QixDQUFuQjtBQUNBdEIsWUFBTXFCLFlBQU4sSUFBc0JELFVBQXRCO0FBQ0EsVUFBSWxCLFNBQVMsQ0FBQyxDQUFDaUIsV0FBV2pCLE1BQWIsS0FBd0JrQixlQUFlLENBQWYsSUFBb0JBLGVBQWUsQ0FBQyxDQUE1RCxDQUFiO0FBQ0EsVUFBSWpCLFNBQVNnQixXQUFXaEIsTUFBWCxJQUFxQixLQUFsQyxDQWZ1RCxDQWlCdkQ7O0FBQ0EsVUFBSSxDQUFDQSxNQUFELElBQVdELE1BQVgsSUFBcUJpQixXQUFXSSxRQUFwQyxFQUE4Q3BCLFNBQVMsSUFBVDs7QUFFOUMsVUFBSWlCLGVBQWUsS0FBbkIsRUFBMEI7QUFDeEJYLGtCQUFVUixTQUFWO0FBQ0QsT0FGRCxNQUVPO0FBQ0xGLG9CQUFZQyxLQUFaLEVBQW1CQyxTQUFuQixFQUE4QkMsTUFBOUIsRUFBc0NDLE1BQXRDO0FBQ0Q7QUFDRjtBQUNGLEdBNUJEO0FBNkJELENBdkRELEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSXFCLFlBQUo7QUFBaUJsQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDOEIsbUJBQWE5QixDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBQXFFLElBQUlMLFdBQUo7QUFBZ0JDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxnQ0FBUixDQUFiLEVBQXVEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDTCxrQkFBWUssQ0FBWjtBQUFjOztBQUExQixDQUF2RCxFQUFtRixDQUFuRjtBQUl0RztBQUNBOEIsYUFBYUMsYUFBYixDQUEyQixDQUN6QixPQUR5QixFQUNoQjtBQUNULFFBRnlCLEVBRWY7QUFDVixRQUh5QixDQUEzQixDQUdZO0FBSFo7QUFNQXBDLFlBQVlPLEVBQVosQ0FBZSxpQkFBZixFQUFrQyxVQUFVQyxVQUFWLEVBQXNCQyxFQUF0QixFQUEwQjtBQUMxRDtBQUNBLE1BQUlBLEdBQUdlLE9BQUgsSUFBYyxDQUFkLElBQW1CZixHQUFHNEIsVUFBdEIsSUFBb0MsT0FBTzVCLEdBQUc0QixVQUFILENBQWNDLFFBQXJCLEtBQWtDLFVBQTFFLEVBQXNGO0FBQ3BGN0IsT0FBRzRCLFVBQUgsQ0FBY0MsUUFBZCxDQUF1QjtBQUNyQkMsVUFBSTtBQUNGQyxtQkFBVztBQURUO0FBRGlCLEtBQXZCO0FBS0Q7QUFDRixDQVRELEUiLCJmaWxlIjoiL3BhY2thZ2VzL2FsZGVlZF9zY2hlbWEtaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQ29sbGVjdGlvbjIgZnJvbSAnbWV0ZW9yL2FsZGVlZDpjb2xsZWN0aW9uMi1jb3JlJztcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG5pbXBvcnQgJy4vY29tbW9uJztcblxuQ29sbGVjdGlvbjIub24oJ3NjaGVtYS5hdHRhY2hlZCcsIGZ1bmN0aW9uIChjb2xsZWN0aW9uLCBzcykge1xuICBmdW5jdGlvbiBlbnN1cmVJbmRleChpbmRleCwgaW5kZXhOYW1lLCB1bmlxdWUsIHNwYXJzZSkge1xuICAgIE1ldGVvci5zdGFydHVwKGZ1bmN0aW9uICgpIHtcbiAgICAgIGNvbGxlY3Rpb24uX2NvbGxlY3Rpb24uX2Vuc3VyZUluZGV4KGluZGV4LCB7XG4gICAgICAgIGJhY2tncm91bmQ6IHRydWUsXG4gICAgICAgIG5hbWU6IGluZGV4TmFtZSxcbiAgICAgICAgdW5pcXVlOiB1bmlxdWUsXG4gICAgICAgIHNwYXJzZTogc3BhcnNlXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGRyb3BJbmRleChpbmRleE5hbWUpIHtcbiAgICBNZXRlb3Iuc3RhcnR1cChmdW5jdGlvbiAoKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb2xsZWN0aW9uLl9jb2xsZWN0aW9uLl9kcm9wSW5kZXgoaW5kZXhOYW1lKTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAvLyBubyBpbmRleCB3aXRoIHRoYXQgbmFtZSwgd2hpY2ggaXMgd2hhdCB3ZSB3YW50XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBjb25zdCBwcm9wTmFtZSA9IHNzLnZlcnNpb24gPT09IDIgPyAnbWVyZ2VkU2NoZW1hJyA6ICdzY2hlbWEnO1xuXG4gIC8vIExvb3Agb3ZlciBmaWVsZHMgZGVmaW5pdGlvbnMgYW5kIGVuc3VyZSBjb2xsZWN0aW9uIGluZGV4ZXMgKHNlcnZlciBzaWRlIG9ubHkpXG4gIHZhciBzY2hlbWEgPSBzc1twcm9wTmFtZV0oKTtcbiAgT2JqZWN0LmtleXMoc2NoZW1hKS5mb3JFYWNoKGZ1bmN0aW9uIChmaWVsZE5hbWUpIHtcbiAgICB2YXIgZGVmaW5pdGlvbiA9IHNjaGVtYVtmaWVsZE5hbWVdO1xuICAgIGlmICgnaW5kZXgnIGluIGRlZmluaXRpb24gfHwgZGVmaW5pdGlvbi51bmlxdWUgPT09IHRydWUpIHtcbiAgICAgIHZhciBpbmRleCA9IHt9LCBpbmRleFZhbHVlO1xuICAgICAgLy8gSWYgdGhleSBzcGVjaWZpZWQgYHVuaXF1ZTogdHJ1ZWAgYnV0IG5vdCBgaW5kZXhgLFxuICAgICAgLy8gd2UgYXNzdW1lIGBpbmRleDogMWAgdG8gc2V0IHVwIHRoZSB1bmlxdWUgaW5kZXggaW4gbW9uZ29cbiAgICAgIGlmICgnaW5kZXgnIGluIGRlZmluaXRpb24pIHtcbiAgICAgICAgaW5kZXhWYWx1ZSA9IGRlZmluaXRpb24uaW5kZXg7XG4gICAgICAgIGlmIChpbmRleFZhbHVlID09PSB0cnVlKSBpbmRleFZhbHVlID0gMTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGluZGV4VmFsdWUgPSAxO1xuICAgICAgfVxuICAgICAgdmFyIGluZGV4TmFtZSA9ICdjMl8nICsgZmllbGROYW1lO1xuICAgICAgLy8gSW4gdGhlIGluZGV4IG9iamVjdCwgd2Ugd2FudCBvYmplY3QgYXJyYXkga2V5cyB3aXRob3V0IHRoZSBcIi4kXCIgcGllY2VcbiAgICAgIHZhciBpZHhGaWVsZE5hbWUgPSBmaWVsZE5hbWUucmVwbGFjZSgvXFwuXFwkXFwuL2csIFwiLlwiKTtcbiAgICAgIGluZGV4W2lkeEZpZWxkTmFtZV0gPSBpbmRleFZhbHVlO1xuICAgICAgdmFyIHVuaXF1ZSA9ICEhZGVmaW5pdGlvbi51bmlxdWUgJiYgKGluZGV4VmFsdWUgPT09IDEgfHwgaW5kZXhWYWx1ZSA9PT0gLTEpO1xuICAgICAgdmFyIHNwYXJzZSA9IGRlZmluaXRpb24uc3BhcnNlIHx8IGZhbHNlO1xuXG4gICAgICAvLyBJZiB1bmlxdWUgYW5kIG9wdGlvbmFsLCBmb3JjZSBzcGFyc2UgdG8gcHJldmVudCBlcnJvcnNcbiAgICAgIGlmICghc3BhcnNlICYmIHVuaXF1ZSAmJiBkZWZpbml0aW9uLm9wdGlvbmFsKSBzcGFyc2UgPSB0cnVlO1xuXG4gICAgICBpZiAoaW5kZXhWYWx1ZSA9PT0gZmFsc2UpIHtcbiAgICAgICAgZHJvcEluZGV4KGluZGV4TmFtZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBlbnN1cmVJbmRleChpbmRleCwgaW5kZXhOYW1lLCB1bmlxdWUsIHNwYXJzZSk7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbn0pO1xuIiwiLy8gY29sbGVjdGlvbjItY29yZSBjaGVja3MgdG8gbWFrZSBzdXJlIHRoYXQgc2ltcGwtc2NoZW1hIHBhY2thZ2UgaXMgYWRkZWRcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCBDb2xsZWN0aW9uMiBmcm9tICdtZXRlb3IvYWxkZWVkOmNvbGxlY3Rpb24yLWNvcmUnO1xuXG4vLyBFeHRlbmQgdGhlIHNjaGVtYSBvcHRpb25zIGFsbG93ZWQgYnkgU2ltcGxlU2NoZW1hXG5TaW1wbGVTY2hlbWEuZXh0ZW5kT3B0aW9ucyhbXG4gICdpbmRleCcsIC8vIG9uZSBvZiBOdW1iZXIsIFN0cmluZywgQm9vbGVhblxuICAndW5pcXVlJywgLy8gQm9vbGVhblxuICAnc3BhcnNlJywgLy8gQm9vbGVhblxuXSk7XG5cbkNvbGxlY3Rpb24yLm9uKCdzY2hlbWEuYXR0YWNoZWQnLCBmdW5jdGlvbiAoY29sbGVjdGlvbiwgc3MpIHtcbiAgLy8gRGVmaW5lIHZhbGlkYXRpb24gZXJyb3IgbWVzc2FnZXNcbiAgaWYgKHNzLnZlcnNpb24gPj0gMiAmJiBzcy5tZXNzYWdlQm94ICYmIHR5cGVvZiBzcy5tZXNzYWdlQm94Lm1lc3NhZ2VzID09PSAnZnVuY3Rpb24nKSB7XG4gICAgc3MubWVzc2FnZUJveC5tZXNzYWdlcyh7XG4gICAgICBlbjoge1xuICAgICAgICBub3RVbmlxdWU6ICd7e2xhYmVsfX0gbXVzdCBiZSB1bmlxdWUnLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxufSk7XG4iXX0=
